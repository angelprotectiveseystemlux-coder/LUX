import 'package:flutter_test/flutter_test.dart';
import 'package:lux_app/data/curriculum.dart';

void main() {
  test('هر رشته‌ی نظری برای پایه‌های دهم تا دوازدهم فهرست دارد', () {
    for (final t in const ['تجربی', 'ریاضی', 'انسانی']) {
      for (final g in const [10, 11, 12]) {
        expect(Curriculum.has(t, g), isTrue, reason: '$t / $g');
        expect(Curriculum.coursesFor(t, g), isNotEmpty);
      }
    }
  });

  test('رشته‌های بدون داده و پایه‌های راهنمایی فهرستی ندارند', () {
    expect(Curriculum.has('کاردانش', 11), isFalse);
    expect(Curriculum.has('تجربی', 8), isFalse);
    expect(Curriculum.has('', 10), isFalse);
  });

  test('پایه‌ی دهم هیچ ضریبی ندارد', () {
    for (final t in const ['تجربی', 'ریاضی', 'انسانی']) {
      expect(Curriculum.coursesFor(t, 10).every((c) => c.coef == null), isTrue);
    }
  });

  test('ضریب‌های نمونه دقیق‌اند', () {
    double? coef(String t, int g, String n) =>
        Curriculum.coursesFor(t, g).firstWhere((c) => c.name == n).coef;
    expect(coef('تجربی', 11, 'زیست‌شناسی ۲'), 6.39);
    expect(coef('ریاضی', 12, 'شیمی ۳'), 10.70);
    expect(coef('انسانی', 12, 'جغرافیا ۳'), 7.71);
    expect(coef('انسانی', 11, 'فلسفه ۱'), isNull);
  });

  test('نام درس‌ها در هر فهرست تکراری نیست', () {
    for (final t in const ['تجربی', 'ریاضی', 'انسانی']) {
      for (final g in const [10, 11, 12]) {
        final names = Curriculum.coursesFor(t, g).map((c) => c.name).toList();
        expect(names.toSet().length, names.length, reason: '$t / $g');
      }
    }
  });
}
