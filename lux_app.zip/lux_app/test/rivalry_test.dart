import 'package:flutter_test/flutter_test.dart';
import 'package:lux_app/engine/rivalry.dart';

RivalExam ex(int id, int course, {double? mine, Map<int, double> rivals = const {}, double max = 20, double weight = 1}) =>
    RivalExam(
      id: id,
      courseId: course,
      courseName: 'درس $course',
      title: 'امتحان $id',
      at: DateTime(2026, 10, id),
      max: max,
      weight: weight,
      mine: mine,
      rivals: rivals,
    );

void main() {
  const coef = <int, double>{1: 1, 2: 2};

  test('سطح کلی: میانگین هر درس، سپس ضریبِ درس‌ها', () {
    final exams = [
      ex(1, 1, mine: 18, rivals: {7: 16}),
      ex(2, 2, mine: 10, rivals: {7: 14}),
    ];
    final me = RivalryCalc.overallSeries(exams, RivalryCalc.me, coef);
    expect(me[0], closeTo(18, 1e-9));
    expect(me[1], closeTo((18 * 1 + 10 * 2) / 3, 1e-9));
    final r = RivalryCalc.overallSeries(exams, 7, coef);
    expect(r[1], closeTo((16 * 1 + 14 * 2) / 3, 1e-9));
  });

  test('قبل از اولین نمره‌ی یک نفر، مقدار null است', () {
    final exams = [
      ex(1, 1, mine: 18),
      ex(2, 2, mine: 10, rivals: {9: 14}),
    ];
    final s = RivalryCalc.overallSeries(exams, 9, coef);
    expect(s[0], isNull);
    expect(s[1], closeTo(14, 1e-9));
  });

  test('نمره روی مقیاس ۲۰ برده می‌شود', () {
    final e = ex(1, 1, mine: 30, rivals: {7: 20}, max: 40);
    expect(e.norm(RivalryCalc.me), closeTo(15, 1e-9));
    expect(e.norm(7), closeTo(10, 1e-9));
    expect(e.norm(99), isNull);
  });

  test('امتحان‌های مشترک', () {
    final exams = [
      ex(1, 1, mine: 18, rivals: {7: 16, 8: 12}),
      ex(2, 1, mine: 15, rivals: {7: 14}),
      ex(3, 1, rivals: {7: 10, 8: 10}),
    ];
    expect(RivalryCalc.common(exams, [RivalryCalc.me, 7]).map((e) => e.id), [1, 2]);
    expect(RivalryCalc.common(exams, [RivalryCalc.me, 7, 8]).map((e) => e.id), [1]);
    expect(RivalryCalc.common(exams, [7, 8]).map((e) => e.id), [1, 3]);
  });

  test('میانگینِ درس با وزنِ امتحان', () {
    final exams = [
      ex(1, 1, mine: 10, weight: 1),
      ex(2, 1, mine: 20, weight: 3),
    ];
    expect(RivalryCalc.courseAverage(exams, 1, RivalryCalc.me), closeTo((10 + 60) / 4, 1e-9));
    expect(RivalryCalc.courseAverage(exams, 2, RivalryCalc.me), isNull);
    expect(RivalryCalc.count(exams, RivalryCalc.me), 2);
  });
}
