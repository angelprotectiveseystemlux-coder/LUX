import 'package:flutter_test/flutter_test.dart';
import 'package:lux_app/engine/grades.dart';
import 'package:lux_app/engine/planner.dart';
import 'package:lux_app/engine/srs.dart';
import 'package:lux_app/engine/stats.dart';

void main() {
  test('معدل وزنی', () {
    final avg = GradeMath.weightedAverage(const [
      WeightedScore(18, 20, 1),
      WeightedScore(14, 20, 3),
    ]);
    expect(avg, closeTo(15.0, 1e-9));
  });

  test('معدل با حداکثر متفاوت (۱۰۰)', () {
    final avg = GradeMath.weightedAverage(const [WeightedScore(80, 100, 1)]);
    expect(avg, closeTo(16.0, 1e-9));
  });

  test('نمره‌ی لازم برای هدف', () {
    // S = 15*4 = 60 , W = 4 , w = 2 , G = 16  => x = (16*6 - 60)/2 = 18
    final r = GradeMath.requiredScore(sumWeighted: 60, sumWeights: 4, nextWeight: 2, target: 16)!;
    expect(r.neededOnScale, closeTo(18, 1e-9));
    expect(r.possible, isTrue);
    final impossible = GradeMath.requiredScore(sumWeighted: 60, sumWeights: 4, nextWeight: 2, target: 19)!;
    expect(impossible.possible, isFalse);
  });

  test('معدل کل', () {
    final g = GradeMath.gpa(const [CourseResult(16, 3), CourseResult(12, 1)]);
    expect(g, closeTo(15.0, 1e-9));
  });

  test('SM-2', () {
    final t0 = DateTime(2026, 1, 1);
    var c = SrsCard.fresh(t0);
    c = Srs.review(c, 5, t0);
    expect(c.intervalDays, 1);
    expect(c.ef, closeTo(2.6, 1e-9));
    c = Srs.review(c, 5, t0);
    expect(c.intervalDays, 6);
    c = Srs.review(c, 4, t0);
    expect(c.intervalDays, (6 * 2.7).round());
    final failed = Srs.review(c, 2, t0);
    expect(failed.reps, 0);
    expect(failed.intervalDays, 1);
    expect(failed.ef, closeTo(c.ef, 1e-9));
  });

  test('رگرسیون و همبستگی', () {
    final fit = Stats.linearFit([1, 2, 3, 4], [2, 4, 6, 8])!;
    expect(fit.slope, closeTo(2, 1e-9));
    expect(fit.intercept, closeTo(0, 1e-9));
    expect(fit.r2, closeTo(1, 1e-9));
    expect(Stats.pearson([1, 2, 3, 4], [8, 6, 4, 2])!, closeTo(-1, 1e-9));
  });

  test('فشار امتحان', () {
    expect(Planner.examPressure(const PressureInput(3, 4, 0.5, 4)), closeTo(1.5, 1e-9));
  });

  test('تخصیص ساعت: مجموع برابر ساعت روزانه', () {
    final out = Planner.allocate(const [
      StudyItem(id: 'a', coef: 3, difficulty: 4, gap: 0.3, daysLeft: 3),
      StudyItem(id: 'b', coef: 2, difficulty: 3, gap: 0.2, daysLeft: 10),
      StudyItem(id: 'c', coef: 1, difficulty: 2, gap: 0.1, daysLeft: 20),
    ], 4.0);
    final total = out.fold<double>(0, (a, b) => a + b.hours);
    expect(total, closeTo(4.0, 1e-9));
    expect(out.first.id, 'a');
  });
}
