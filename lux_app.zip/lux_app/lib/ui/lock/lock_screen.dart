import 'dart:async';
import 'package:flutter/material.dart';
import '../../core/jalali_utils.dart';
import '../../core/palette.dart';
import '../../core/theme.dart';
import '../../services/biometric_service.dart';
import '../../services/lock_service.dart';
import '../widgets/haptic.dart';
import 'pin_pad.dart';

/// صفحه‌ی قفلِ برنامه (رمز ورود)
class LockScreen extends StatefulWidget {
  final VoidCallback onUnlocked;
  const LockScreen({super.key, required this.onUnlocked});

  @override
  State<LockScreen> createState() => _LockScreenState();
}

class _LockScreenState extends State<LockScreen> {
  final GlobalKey<PinPadState> _pad = GlobalKey<PinPadState>();
  int _len = 4;
  bool _error = false;
  bool _bio = false;
  bool _bioBusy = false;
  int _blocked = 0;
  Timer? _timer;

  @override
  void initState() {
    super.initState();
    LockService.pinLength().then((v) {
      if (mounted) setState(() => _len = v);
    });
    _tick();
    _initBio();
  }

  Future<void> _initBio() async {
    final ok = await BiometricService.isEnabled();
    if (!mounted) return;
    setState(() => _bio = ok);
    if (ok) {
      // کمی صبر می‌کنیم تا صفحه کامل نمایش داده شود، بعد خودکار اثر انگشت را می‌خواهیم.
      await Future<void>.delayed(const Duration(milliseconds: 350));
      if (mounted) _bioPrompt();
    }
  }

  Future<void> _bioPrompt() async {
    if (_bioBusy || !_bio) return;
    _bioBusy = true;
    final r = await BiometricService.authenticate('برای باز کردن LUX هویتت را تأیید کن');
    final ok = r.$1;
    _bioBusy = false;
    if (!mounted) return;
    if (ok) {
      Haptic.heavy();
      widget.onUnlocked();
    }
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  void _tick() {
    _timer?.cancel();
    _blocked = LockService.blockedSeconds();
    if (_blocked > 0) {
      _timer = Timer.periodic(const Duration(seconds: 1), (t) {
        final s = LockService.blockedSeconds();
        if (!mounted) return;
        setState(() => _blocked = s);
        if (s <= 0) t.cancel();
      });
    }
  }

  Future<void> _check(String pin) async {
    final ok = await LockService.verify(pin);
    if (!mounted) return;
    if (ok) {
      Haptic.heavy();
      widget.onUnlocked();
      return;
    }
    Haptic.alert();
    setState(() {
      _error = true;
      _tick();
    });
    await Future<void>.delayed(const Duration(milliseconds: 500));
    if (!mounted) return;
    _pad.currentState?.clear();
    setState(() => _error = false);
  }

  @override
  Widget build(BuildContext context) {
    final pad = MediaQuery.of(context).padding;
    return Scaffold(
      backgroundColor: LuxColors.bg,
      body: Padding(
        padding: EdgeInsets.fromLTRB(32, pad.top + 40, 32, pad.bottom + 24),
        child: Column(
          children: [
            Image.asset('assets/logo/lux_logo.png', width: 110, height: 110, cacheWidth: 330),
            const SizedBox(height: 18),
            Text('رمز ورود', style: LuxText.title),
            const SizedBox(height: 6),
            Text(
              _blocked > 0
                  ? 'چند بار اشتباه شد. ${faDigits(_blocked)} ثانیه صبر کن.'
                  : (_error ? 'رمز درست نیست' : 'برای باز کردن LUX رمزت را وارد کن'),
              style: LuxText.caption.copyWith(color: _error || _blocked > 0 ? LuxColors.danger : LuxColors.textDim),
              textAlign: TextAlign.center,
            ),
            const Spacer(),
            PinPad(key: _pad, length: _len, error: _error, enabled: _blocked == 0, onCompleted: _check),
            if (_bio) ...[
              const SizedBox(height: 8),
              GestureDetector(
                behavior: HitTestBehavior.opaque,
                onTap: _bioPrompt,
                child: Padding(
                  padding: const EdgeInsets.all(12),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(Icons.fingerprint_rounded, color: LuxColors.accent, size: 34),
                      const SizedBox(width: 8),
                      Text('ورود با اثر انگشت', style: LuxText.label.copyWith(color: LuxColors.accent)),
                    ],
                  ),
                ),
              ),
            ],
            const Spacer(),
          ],
        ),
      ),
    );
  }
}
