import 'dart:async';
import 'package:flutter/material.dart';
import '../../core/jalali_utils.dart';
import '../../core/palette.dart';
import '../../core/theme.dart';
import '../../services/lock_service.dart';
import '../widgets/haptic.dart';
import 'pin_pad.dart';

/// صفحه‌ی قفلِ برنامه (رمز ورود)
class LockScreen extends StatefulWidget {
  final VoidCallback onUnlocked;
  const LockScreen({super.key, required this.onUnlocked});

  @override
  State<LockScreen> createState() => _LockScreenState();
}

class _LockScreenState extends State<LockScreen> {
  final GlobalKey<PinPadState> _pad = GlobalKey<PinPadState>();
  int _len = 4;
  bool _error = false;
  int _blocked = 0;
  Timer? _timer;

  @override
  void initState() {
    super.initState();
    LockService.pinLength().then((v) {
      if (mounted) setState(() => _len = v);
    });
    _tick();
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  void _tick() {
    _timer?.cancel();
    _blocked = LockService.blockedSeconds();
    if (_blocked > 0) {
      _timer = Timer.periodic(const Duration(seconds: 1), (t) {
        final s = LockService.blockedSeconds();
        if (!mounted) return;
        setState(() => _blocked = s);
        if (s <= 0) t.cancel();
      });
    }
  }

  Future<void> _check(String pin) async {
    final ok = await LockService.verify(pin);
    if (!mounted) return;
    if (ok) {
      Haptic.heavy();
      widget.onUnlocked();
      return;
    }
    Haptic.alert();
    setState(() {
      _error = true;
      _tick();
    });
    await Future<void>.delayed(const Duration(milliseconds: 500));
    if (!mounted) return;
    _pad.currentState?.clear();
    setState(() => _error = false);
  }

  @override
  Widget build(BuildContext context) {
    final pad = MediaQuery.of(context).padding;
    return Scaffold(
      backgroundColor: LuxColors.bg,
      body: Padding(
        padding: EdgeInsets.fromLTRB(32, pad.top + 40, 32, pad.bottom + 24),
        child: Column(
          children: [
            Image.asset('assets/logo/lux_logo.png', width: 110, height: 110, cacheWidth: 330),
            const SizedBox(height: 18),
            Text('رمز ورود', style: LuxText.title),
            const SizedBox(height: 6),
            Text(
              _blocked > 0
                  ? 'چند بار اشتباه شد. ${faDigits(_blocked)} ثانیه صبر کن.'
                  : (_error ? 'رمز درست نیست' : 'برای باز کردن LUX رمزت را وارد کن'),
              style: LuxText.caption.copyWith(color: _error || _blocked > 0 ? LuxColors.danger : LuxColors.textDim),
              textAlign: TextAlign.center,
            ),
            const Spacer(),
            PinPad(key: _pad, length: _len, error: _error, enabled: _blocked == 0, onCompleted: _check),
            const Spacer(),
          ],
        ),
      ),
    );
  }
}
