import 'package:flutter/material.dart';
import '../../core/palette.dart';
import '../../core/theme.dart';
import '../widgets/haptic.dart';

/// نقطه‌های رمز + صفحه‌کلیدِ عددی. وقتی طولِ رمز کامل شد [onCompleted] صدا زده می‌شود.
class PinPad extends StatefulWidget {
  final int length;
  final ValueChanged<String> onCompleted;
  final bool error;
  final bool enabled;

  const PinPad({
    super.key,
    required this.length,
    required this.onCompleted,
    this.error = false,
    this.enabled = true,
  });

  @override
  State<PinPad> createState() => PinPadState();
}

class PinPadState extends State<PinPad> {
  String _value = '';

  void clear() => setState(() => _value = '');

  void _add(String d) {
    if (!widget.enabled || _value.length >= widget.length) return;
    Haptic.tap();
    setState(() => _value += d);
    if (_value.length == widget.length) {
      final v = _value;
      widget.onCompleted(v);
    }
  }

  void _back() {
    if (_value.isEmpty) return;
    Haptic.tap();
    setState(() => _value = _value.substring(0, _value.length - 1));
  }

  Widget _key(String label, {VoidCallback? onTap, IconData? icon}) {
    return Expanded(
      child: GestureDetector(
        behavior: HitTestBehavior.opaque,
        onTap: onTap,
        child: SizedBox(
          height: 72,
          child: Center(
            child: icon != null
                ? Icon(icon, color: LuxColors.silver, size: 26)
                : Text(label, style: LuxText.display.copyWith(fontSize: 30)),
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final digits = <List<String>>[
      ['1', '2', '3'],
      ['4', '5', '6'],
      ['7', '8', '9'],
    ];
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            for (var i = 0; i < widget.length; i++)
              AnimatedContainer(
                duration: LuxMotion.fast,
                margin: const EdgeInsets.symmetric(horizontal: 9),
                width: 16,
                height: 16,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: i < _value.length
                      ? (widget.error ? LuxColors.danger : LuxColors.accent)
                      : Colors.transparent,
                  border: Border.all(
                    color: widget.error ? LuxColors.danger : (i < _value.length ? LuxColors.accent : LuxColors.silverDim),
                    width: 1.6,
                  ),
                ),
              ),
          ],
        ),
        const SizedBox(height: 28),
        Directionality(
          textDirection: TextDirection.ltr,
          child: Column(
            children: [
              for (final row in digits)
                Row(children: [for (final d in row) _key(d, onTap: () => _add(d))]),
              Row(children: [
                _key('', onTap: null),
                _key('0', onTap: () => _add('0')),
                _key('', icon: Icons.backspace_outlined, onTap: _back),
              ]),
            ],
          ),
        ),
      ],
    );
  }
}
