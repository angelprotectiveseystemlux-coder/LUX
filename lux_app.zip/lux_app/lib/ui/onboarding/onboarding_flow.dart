import 'dart:math' as math;
import 'dart:ui' show lerpDouble;
import 'package:flutter/material.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:shamsi_date/shamsi_date.dart';
import '../../core/palette.dart';
import '../../core/theme.dart';
import '../../data/profile_repo.dart';
import '../charts/radial.dart';
import '../widgets/haptic.dart';
import '../widgets/jalali_picker.dart';
import '../widgets/lux_button.dart';
import '../widgets/lux_card.dart';
import '../widgets/lux_chip.dart';
import '../widgets/lux_switch.dart';
import '../widgets/ruler_picker.dart';

class OnboardingFlow extends StatefulWidget {
  final VoidCallback onDone;
  const OnboardingFlow({super.key, required this.onDone});

  @override
  State<OnboardingFlow> createState() => _OnboardingFlowState();
}

class _PermItem {
  final String title;
  final String why;
  final Permission perm;
  PermissionStatus? status;
  _PermItem(this.title, this.why, this.perm);
}

class _OnboardingFlowState extends State<OnboardingFlow> with SingleTickerProviderStateMixin {
  static const int _steps = 6;
  late final AnimationController _intro =
      AnimationController(vsync: this, duration: const Duration(milliseconds: 3000));

  int _step = 0;
  final TextEditingController _nameCtl = TextEditingController();
  String _title = 'آقای';
  String _level = '';
  int _grade = 0;
  String _track = '';
  bool _noGpa = false;
  double _gpa = 17.0;
  late Jalali _birth;
  late final int _nowYear;
  bool _saving = false;

  final List<_PermItem> _perms = [
    _PermItem('نوتیف', 'برای فرستادن یادآور امتحان‌ها، تکالیف و بریف.', Permission.notification),
    _PermItem('آلارم دقیق', 'تا یادآورها دقیقاً سرِ ساعت برسند، نه دیرتر.', Permission.scheduleExactAlarm),
    _PermItem('تقویم', 'برای ثبت رویدادها و امتحان‌ها در تقویم گوشی.', Permission.calendarFullAccess),
    _PermItem('اجرای پس‌زمینه', 'تا سیستم گوشی یادآورها را نبندد (معافیت از بهینه‌سازی باتری).',
        Permission.ignoreBatteryOptimizations),
  ];

  @override
  void initState() {
    super.initState();
    _nowYear = Jalali.now().year;
    _birth = Jalali(_nowYear - 16, 1, 1);
    _intro.forward();
    _nameCtl.addListener(() => setState(() {}));
  }

  @override
  void dispose() {
    _intro.dispose();
    _nameCtl.dispose();
    super.dispose();
  }

  bool get _valid {
    switch (_step) {
      case 0:
        return _nameCtl.text.trim().length >= 2;
      case 1:
        if (_level.isEmpty || _grade == 0) return false;
        return _level == 'middle' || _track.isNotEmpty;
      default:
        return true;
    }
  }

  Future<void> _loadPermStatus() async {
    for (final p in _perms) {
      try {
        p.status = await p.perm.status;
      } catch (_) {}
    }
    if (mounted) setState(() {});
  }

  Future<void> _request(_PermItem p) async {
    try {
      if (p.status != null && p.status!.isPermanentlyDenied) {
        await openAppSettings();
      } else {
        p.status = await p.perm.request();
      }
    } catch (_) {}
    if (mounted) setState(() {});
  }

  void _next() {
    if (!_valid) return;
    if (_step == _steps - 1) {
      _finish();
      return;
    }
    setState(() => _step++);
    if (_step == 4) _loadPermStatus();
  }

  void _back() {
    if (_step == 0) return;
    setState(() => _step--);
  }

  Future<void> _finish() async {
    if (_saving) return;
    setState(() => _saving = true);
    final profile = Profile(
      name: _nameCtl.text.trim(),
      titlePref: _title,
      level: _level,
      grade: _grade,
      track: _level == 'high' ? _track : '',
      prevGpa: _noGpa ? null : _gpa,
      birthY: _birth.year,
      birthM: _birth.month,
      birthD: _birth.day,
    );
    await ProfileRepo.save(profile);
    await ProfileRepo.markOnboarded();
    Haptic.heavy();
    widget.onDone();
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    // لوگو از قبل در حافظه‌ی گرافیکی آماده شود تا انیمیشن اولِ کار لگ نزند.
    precacheImage(const AssetImage('assets/logo/lux_logo.png'), context);
  }

  @override
  Widget build(BuildContext context) {
    final pad = MediaQuery.of(context).padding;
    return Scaffold(
      backgroundColor: LuxColors.bg,
      body: LayoutBuilder(builder: (context, cons) {
        final w = cons.maxWidth;
        final h = cons.maxHeight;

        const base = 260.0; // اندازه‌ی ثابتِ رندر؛ کوچک‌شدن فقط با Transform (روی GPU) انجام می‌شود
        const endSize = 150.0; // اندازه‌ی نهایی بالای صفحه (قبلاً ۹۶ بود)
        final startCy = h * 0.5 - 30;
        final endTop = pad.top + 10;
        final endCy = endTop + endSize / 2;
        final contentTop = endTop + endSize + 6;
        final startTop = startCy - base / 2;

        // محتوا یک‌بار ساخته می‌شود و با هر فریم انیمیشن دوباره ساخته نمی‌شود.
        final content = _content(pad);

        return AnimatedBuilder(
          animation: _intro,
          child: content,
          builder: (context, child) {
            final v = _intro.value;
            final appear = const Interval(0.0, 0.26, curve: Curves.easeOutCubic).transform(v);
            final sweep = const Interval(0.20, 0.60, curve: Curves.easeInOut).transform(v);
            final moveT = const Interval(0.60, 1.0, curve: Curves.easeInOutCubic).transform(v);
            final contentT = const Interval(0.86, 1.0, curve: Curves.easeOut).transform(v);

            final scale = lerpDouble(0.78, 1.0, appear)! * lerpDouble(1.0, endSize / base, moveT)!;
            final dy = lerpDouble(0, endCy - startCy, moveT)!;
            final pulse = 0.5 + 0.5 * math.sin(v * math.pi * 3);
            final glow = appear * (0.55 + 0.35 * pulse) * (1 - 0.35 * moveT);

            return Stack(
              children: [
                // درخششِ پشت لوگو
                Positioned(
                  top: startCy - 190,
                  left: (w - 380) / 2,
                  child: IgnorePointer(
                    child: RepaintBoundary(
                      child: Transform.translate(
                        offset: Offset(0, dy),
                        child: Transform.scale(
                          scale: lerpDouble(1.0, 0.62, moveT)!,
                          child: Opacity(
                            opacity: glow.clamp(0.0, 1.0),
                            child: Container(
                              width: 380,
                              height: 380,
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                gradient: RadialGradient(colors: [
                                  LuxColors.alpha(LuxColors.accent, 0.30),
                                  LuxColors.alpha(LuxColors.accent, 0.08),
                                  LuxColors.alpha(LuxColors.accent, 0.0),
                                ], stops: const [0.0, 0.55, 1.0]),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
                Positioned(
                  top: startTop,
                  left: (w - base) / 2,
                  child: RepaintBoundary(
                    child: Transform.translate(
                      offset: Offset(0, dy),
                      child: Transform.scale(
                        scale: scale,
                        child: Opacity(
                          opacity: appear,
                          child: ShaderMask(
                            blendMode: BlendMode.srcATop,
                            shaderCallback: (rect) => LinearGradient(
                              begin: Alignment(-2.2 + 4.4 * sweep, -0.6),
                              end: Alignment(-1.2 + 4.4 * sweep, 0.6),
                              colors: const [Color(0x00FFFFFF), Color(0xB3FFFFFF), Color(0x00FFFFFF)],
                              stops: const [0.0, 0.5, 1.0],
                            ).createShader(rect),
                            child: Image.asset(
                              'assets/logo/lux_logo.png',
                              width: base,
                              height: base,
                              cacheWidth: 720,
                              filterQuality: FilterQuality.medium,
                              gaplessPlayback: true,
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
                Positioned.fill(
                  top: contentTop,
                  child: IgnorePointer(
                    ignoring: contentT < 0.95,
                    child: Opacity(
                      opacity: contentT,
                      child: Transform.translate(
                        offset: Offset(0, (1 - contentT) * 24),
                        child: child,
                      ),
                    ),
                  ),
                ),
              ],
            );
          },
        );
      }),
    );
  }

  Widget _content(EdgeInsets pad) {
    return Column(
      children: [
        Expanded(
          child: AnimatedSwitcher(
            duration: const Duration(milliseconds: 320),
            switchInCurve: Curves.easeOutCubic,
            transitionBuilder: (child, anim) => FadeTransition(
              opacity: anim,
              child: SlideTransition(
                position: Tween<Offset>(begin: const Offset(0.06, 0), end: Offset.zero).animate(anim),
                child: child,
              ),
            ),
            child: KeyedSubtree(
              key: ValueKey<int>(_step),
              child: SingleChildScrollView(
                padding: const EdgeInsets.fromLTRB(24, 8, 24, 16),
                physics: const BouncingScrollPhysics(),
                child: _stepBody(),
              ),
            ),
          ),
        ),
        _bottomBar(pad),
      ],
    );
  }

  Widget _bottomBar(EdgeInsets pad) {
    final last = _step == _steps - 1;
    return Padding(
      padding: EdgeInsets.fromLTRB(24, 8, 24, 16 + pad.bottom),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              for (var i = 0; i < _steps; i++)
                AnimatedContainer(
                  duration: LuxMotion.medium,
                  curve: LuxMotion.curve,
                  margin: const EdgeInsets.symmetric(horizontal: 3),
                  width: i == _step ? 26 : 8,
                  height: 6,
                  decoration: BoxDecoration(
                    color: i <= _step ? LuxColors.accent : LuxColors.stroke,
                    borderRadius: BorderRadius.circular(3),
                  ),
                ),
            ],
          ),
          const SizedBox(height: 16),
          Row(
            children: [
              if (_step > 0) ...[
                Expanded(flex: 2, child: LuxButton(label: 'بازگشت', filled: false, onPressed: _back)),
                const SizedBox(width: 12),
              ],
              Expanded(
                flex: 3,
                child: LuxButton(
                  label: last ? 'ورود به LUX' : 'ادامه',
                  onPressed: (_valid && !_saving) ? _next : null,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _stepBody() {
    switch (_step) {
      case 0:
        return _stepName();
      case 1:
        return _stepLevel();
      case 2:
        return _stepGpa();
      case 3:
        return _stepBirth();
      case 4:
        return _stepPerms();
      default:
        return _stepDone();
    }
  }

  Widget _heading(String t, {String? sub}) => Column(
        children: [
          Text(t, style: LuxText.title.copyWith(fontSize: 24), textAlign: TextAlign.center),
          if (sub != null) ...[
            const SizedBox(height: 8),
            Text(sub, style: LuxText.caption.copyWith(fontSize: 13), textAlign: TextAlign.center),
          ],
          const SizedBox(height: 22),
        ],
      );

  // ───── ۱) نام ─────
  Widget _stepName() {
    final n = _nameCtl.text.trim();
    final greet = n.isEmpty ? 'خوش آمدید' : 'خوش آمدید ${_title.isEmpty ? '' : '$_title '}$n';
    return Column(
      children: [
        _heading(greet, sub: 'نام خود را وارد کنید'),
        TextField(
          controller: _nameCtl,
          textAlign: TextAlign.center,
          style: LuxText.title,
          textInputAction: TextInputAction.done,
          decoration: LuxInput.decoration('نام'),
        ),
        const SizedBox(height: 18),
        Wrap(
          spacing: 10,
          alignment: WrapAlignment.center,
          children: [
            for (final t in const ['آقای', 'خانم', ''])
              LuxChip(
                label: t.isEmpty ? 'بدون عنوان' : t,
                selected: _title == t,
                onTap: () => setState(() => _title = t),
              ),
          ],
        ),
      ],
    );
  }

  // ───── ۲) مقطع ─────
  Widget _stepLevel() {
    Widget levelCard(String key, String title, String sub) {
      final sel = _level == key;
      return Expanded(
        child: LuxCard(
          color: sel ? LuxColors.alpha(LuxColors.accent, 0.14) : LuxColors.card,
          border: Border.all(color: sel ? LuxColors.accent : LuxColors.stroke, width: sel ? 1.6 : 1),
          onTap: () => setState(() {
            if (_level != key) {
              _level = key;
              _grade = 0;
              _track = '';
            }
          }),
          child: Column(
            children: [
              Icon(key == 'middle' ? Icons.auto_stories_rounded : Icons.school_rounded,
                  color: sel ? LuxColors.accent : LuxColors.silver, size: 30),
              const SizedBox(height: 10),
              Text(title, style: LuxText.heading),
              const SizedBox(height: 2),
              Text(sub, style: LuxText.caption),
            ],
          ),
        ),
      );
    }

    final grades = _level == 'middle' ? const [7, 8, 9] : const [10, 11, 12];
    return Column(
      children: [
        _heading('مقطع تحصیلی شما چیست؟'),
        Row(
          children: [
            levelCard('middle', 'راهنمایی', 'هفتم تا نهم'),
            const SizedBox(width: 12),
            levelCard('high', 'دبیرستان', 'دهم تا دوازدهم'),
          ],
        ),
        if (_level.isNotEmpty) ...[
          const SizedBox(height: 26),
          Text('پایه', style: LuxText.label),
          const SizedBox(height: 12),
          Wrap(
            spacing: 10,
            runSpacing: 10,
            alignment: WrapAlignment.center,
            children: [
              for (final g in grades)
                LuxChip(label: Profile.gradeNames[g]!, selected: _grade == g, onTap: () => setState(() => _grade = g)),
            ],
          ),
        ],
        if (_level == 'high' && _grade != 0) ...[
          const SizedBox(height: 26),
          Text('رشته', style: LuxText.label),
          const SizedBox(height: 12),
          Wrap(
            spacing: 10,
            runSpacing: 10,
            alignment: WrapAlignment.center,
            children: [
              for (final t in const ['ریاضی', 'تجربی', 'انسانی', 'فنی‌حرفه‌ای', 'کاردانش'])
                LuxChip(label: t, selected: _track == t, onTap: () => setState(() => _track = t)),
            ],
          ),
        ],
      ],
    );
  }

  // ───── ۳) معدل ─────
  Widget _stepGpa() {
    return Column(
      children: [
        _heading('معدل سال قبل', sub: 'با کشیدنِ خط‌کش انتخاب کن'),
        AnimatedOpacity(
          duration: LuxMotion.medium,
          opacity: _noGpa ? 0.25 : 1,
          child: IgnorePointer(
            ignoring: _noGpa,
            child: RulerPicker(
              min: 0,
              max: 20,
              step: 0.25,
              initial: _gpa,
              onChanged: (v) => _gpa = v,
            ),
          ),
        ),
        const SizedBox(height: 26),
        LuxCard(
          padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 14),
          child: Row(
            children: [
              Expanded(child: Text('نمی‌خواهم بگویم / ندارم', style: LuxText.heading)),
              LuxSwitch(value: _noGpa, onChanged: (v) => setState(() => _noGpa = v)),
            ],
          ),
        ),
      ],
    );
  }

  // ───── ۴) تولد ─────
  Widget _stepBirth() {
    return Column(
      children: [
        _heading('تاریخ تولد', sub: 'برای تدارکاتِ روزِ تولدت'),
        JalaliDatePicker(
          minYear: _nowYear - 30,
          maxYear: _nowYear - 5,
          initial: _birth,
          onChanged: (j) => _birth = j,
        ),
      ],
    );
  }

  // ───── ۵) دسترسی‌ها ─────
  Widget _stepPerms() {
    return Column(
      children: [
        _heading('دسترسی‌ها', sub: 'همه اختیاری‌اند؛ هر کدام را ندهی، بقیه‌ی اپ کار می‌کند'),
        for (final p in _perms) ...[
          LuxCard(
            padding: const EdgeInsets.all(16),
            child: Row(
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(p.title, style: LuxText.heading),
                      const SizedBox(height: 2),
                      Text(p.why, style: LuxText.caption),
                    ],
                  ),
                ),
                const SizedBox(width: 12),
                _permButton(p),
              ],
            ),
          ),
          const SizedBox(height: 12),
        ],
      ],
    );
  }

  Widget _permButton(_PermItem p) {
    final granted = p.status?.isGranted ?? false;
    if (granted) {
      return const Icon(Icons.check_circle_rounded, color: LuxColors.ok, size: 28);
    }
    return SizedBox(
      width: 96,
      child: LuxButton(
        label: (p.status?.isPermanentlyDenied ?? false) ? 'تنظیمات' : 'فعال‌سازی',
        filled: false,
        onPressed: () => _request(p),
      ),
    );
  }

  // ───── ۶) پایان ─────
  Widget _stepDone() {
    return Column(
      children: [
        const SizedBox(height: 20),
        RingProgress(
          value: 1,
          size: 150,
          stroke: 10,
          child: const Icon(Icons.check_rounded, color: LuxColors.accent, size: 64),
        ),
        const SizedBox(height: 28),
        _heading('همه‌چیز آماده است', sub: 'هر چیزی را بعداً از «پروفایل» می‌توانی تغییر بدهی'),
      ],
    );
  }
}
