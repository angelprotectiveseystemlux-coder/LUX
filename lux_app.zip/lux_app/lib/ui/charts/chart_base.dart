import 'dart:math' as math;
import 'package:flutter/material.dart';
import '../../core/jalali_utils.dart';
import '../../core/palette.dart';
import '../../core/theme.dart';
import '../widgets/haptic.dart';

class ChartPoint {
  final String label;
  final double value;
  final Color? color;
  const ChartPoint(this.label, this.value, {this.color});
}

/// کلیدِ عددی از مقادیر برای تشخیص تغییر داده (و پخش دوباره‌ی انیمیشن)
int chartKey(Iterable<double> xs) => Object.hashAll(xs.map((e) => (e * 1000).round()));

/// کشِ TextPainter تا در هر فریم دوباره چیدمانِ متن انجام نشود.
class TextCache {
  final Map<String, TextPainter> _m = <String, TextPainter>{};

  TextPainter get(String text, TextStyle style, {double? maxWidth, TextAlign align = TextAlign.center}) {
    final key = '$text|${style.fontSize}|${style.color.hashCode}|${style.fontWeight?.index}|${maxWidth?.round()}';
    return _m.putIfAbsent(key, () {
      final tp = TextPainter(
        text: TextSpan(text: text, style: style),
        textDirection: TextDirection.rtl,
        textAlign: align,
        maxLines: 1,
        ellipsis: '…',
      );
      tp.layout(maxWidth: maxWidth ?? double.infinity);
      return tp;
    });
  }
}

void paintCentered(Canvas canvas, TextPainter tp, Offset center) {
  tp.paint(canvas, Offset(center.dx - tp.width / 2, center.dy - tp.height / 2));
}

Rect plotRect(Size s, {double l = 8, double r = 8, double t = 26, double b = 30}) =>
    Rect.fromLTRB(l, t, math.max(l + 1, s.width - r), math.max(t + 1, s.height - b));

int? slotHit(Offset p, Size size, int n, bool rtl) {
  if (n <= 0) return null;
  final plot = plotRect(size);
  if (p.dx < plot.left || p.dx > plot.right) return null;
  final slot = plot.width / n;
  final i = ((p.dx - plot.left) / slot).floor().clamp(0, n - 1).toInt();
  return rtl ? n - 1 - i : i;
}

typedef ChartPainterBuilder = CustomPainter Function(double t, int? selected, TextCache cache);
typedef ChartHit = int? Function(Offset local, Size size);

/// میزبانِ مشترک همه‌ی نمودارها: انیمیشنِ ورود، انتخاب با لمس، RepaintBoundary.
class ChartCanvas extends StatefulWidget {
  final double height;
  final ChartPainterBuilder builder;
  final ChartHit? hit;
  final Object dataKey;
  final Duration duration;

  const ChartCanvas({
    super.key,
    required this.height,
    required this.builder,
    required this.dataKey,
    this.hit,
    this.duration = const Duration(milliseconds: 700),
  });

  @override
  State<ChartCanvas> createState() => _ChartCanvasState();
}

class _ChartCanvasState extends State<ChartCanvas> with SingleTickerProviderStateMixin {
  late final AnimationController _c = AnimationController(vsync: this, duration: widget.duration);
  final TextCache _cache = TextCache();
  int? _sel;

  @override
  void initState() {
    super.initState();
    _c.forward();
  }

  @override
  void didUpdateWidget(covariant ChartCanvas old) {
    super.didUpdateWidget(old);
    if (old.dataKey != widget.dataKey) {
      _sel = null;
      _c.forward(from: 0);
    }
  }

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(builder: (context, cons) {
      final w = cons.maxWidth.isFinite ? cons.maxWidth : 300.0;
      final size = Size(w, widget.height);
      return RepaintBoundary(
        child: GestureDetector(
          behavior: HitTestBehavior.opaque,
          onTapDown: widget.hit == null
              ? null
              : (d) {
                  final i = widget.hit!(d.localPosition, size);
                  setState(() => _sel = (i == _sel) ? null : i);
                  Haptic.tap();
                },
          child: AnimatedBuilder(
            animation: _c,
            builder: (context, _) => CustomPaint(
              size: size,
              painter: widget.builder(Curves.easeOutCubic.transform(_c.value), _sel, _cache),
            ),
          ),
        ),
      );
    });
  }
}

/// راهنمای رنگ‌ها (زیر نمودار)
class ChartLegend extends StatelessWidget {
  final List<String> labels;
  final List<Color> colors;
  final List<String>? trailing;
  const ChartLegend({super.key, required this.labels, required this.colors, this.trailing});

  @override
  Widget build(BuildContext context) {
    return Wrap(
      spacing: 16,
      runSpacing: 8,
      children: [
        for (var i = 0; i < labels.length; i++)
          Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 10,
                height: 10,
                decoration: BoxDecoration(color: colors[i % colors.length], borderRadius: BorderRadius.circular(3)),
              ),
              const SizedBox(width: 6),
              Text(labels[i], style: LuxText.caption),
              if (trailing != null && i < trailing!.length) ...[
                const SizedBox(width: 6),
                Text(trailing![i], style: LuxText.caption.copyWith(color: LuxColors.silver)),
              ],
            ],
          ),
      ],
    );
  }
}

TextStyle chartAxisStyle() => LuxText.caption.copyWith(fontSize: 11, color: LuxColors.textDim);
TextStyle chartValueStyle() =>
    LuxText.caption.copyWith(fontSize: 12, color: LuxColors.text, fontWeight: FontWeight.w600);

/// نموداری که فقط یک عدد را به رقم فارسی تبدیل می‌کند.
String defaultFmt(double v) => fmtNum(v);
