import 'dart:math' as math;
import 'package:flutter/material.dart';
import '../../core/jalali_utils.dart';
import '../../core/palette.dart';
import '../../core/theme.dart';
import 'chart_base.dart';

// ════════════════ دایره‌ای / دونات ════════════════
class PieChart extends StatelessWidget {
  final List<ChartPoint> data;
  final bool donut;
  final double size;
  final String? centerTop;
  final String? centerBottom;
  final bool showLegend;
  final bool showPercent;

  const PieChart({
    super.key,
    required this.data,
    this.donut = true,
    this.size = 200,
    this.centerTop,
    this.centerBottom,
    this.showLegend = true,
    this.showPercent = true,
  });

  @override
  Widget build(BuildContext context) {
    final total = data.fold<double>(0, (a, b) => a + math.max(0, b.value));
    final colors = [for (var i = 0; i < data.length; i++) data[i].color ?? LuxColors.seriesAt(i)];
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        ChartCanvas(
          height: size,
          dataKey: chartKey(data.map((e) => e.value)),
          hit: (p, s) => _pieHit(p, s, data, donut),
          builder: (t, sel, cache) =>
              _PiePainter(data, colors, donut, centerTop, centerBottom, t, sel, cache),
        ),
        if (showLegend) ...[
          const SizedBox(height: 14),
          ChartLegend(
            labels: [for (final d in data) d.label],
            colors: colors,
            trailing: showPercent && total > 0
                ? [for (final d in data) '${fmtNum(d.value / total * 100, dec: 0)}٪']
                : null,
          ),
        ],
      ],
    );
  }
}

int? _pieHit(Offset p, Size s, List<ChartPoint> data, bool donut) {
  final total = data.fold<double>(0, (a, b) => a + math.max(0, b.value));
  if (total <= 0) return null;
  final c = Offset(s.width / 2, s.height / 2);
  final r = math.min(s.width, s.height) / 2 - 8;
  final d = p - c;
  final dist = d.distance;
  final inner = donut ? r * 0.55 : 0.0;
  if (dist < inner - 4 || dist > r + 10) return null;
  var ang = math.atan2(d.dy, d.dx) + math.pi / 2;
  if (ang < 0) ang += 2 * math.pi;
  var acc = 0.0;
  for (var i = 0; i < data.length; i++) {
    final sw = math.max(0, data[i].value) / total * 2 * math.pi;
    if (ang >= acc && ang < acc + sw) return i;
    acc += sw;
  }
  return null;
}

class _PiePainter extends CustomPainter {
  final List<ChartPoint> data;
  final List<Color> colors;
  final bool donut;
  final String? centerTop;
  final String? centerBottom;
  final double t;
  final int? sel;
  final TextCache cache;
  _PiePainter(this.data, this.colors, this.donut, this.centerTop, this.centerBottom, this.t, this.sel, this.cache);

  @override
  void paint(Canvas canvas, Size size) {
    final total = data.fold<double>(0, (a, b) => a + math.max(0, b.value));
    final c = Offset(size.width / 2, size.height / 2);
    final r = math.min(size.width, size.height) / 2 - 8;
    if (total <= 0) {
      canvas.drawCircle(
          c,
          r - 8,
          Paint()
            ..color = LuxColors.alpha(LuxColors.stroke, 0.7)
            ..style = PaintingStyle.stroke
            ..strokeWidth = 14);
      return;
    }
    final gap = data.length > 1 ? 0.035 : 0.0;
    var start = -math.pi / 2;
    final strokeW = r * 0.42;
    for (var i = 0; i < data.length; i++) {
      final full = math.max(0, data[i].value) / total * 2 * math.pi;
      final sweep = math.max(0.0, full * t - gap);
      final isSel = sel == i;
      final col = (sel == null || isSel) ? colors[i] : LuxColors.alpha(colors[i], 0.45);
      final mid = start + full * t / 2;
      final shift = isSel ? Offset(math.cos(mid) * 6, math.sin(mid) * 6) : Offset.zero;
      if (sweep > 0) {
        if (donut) {
          final rect = Rect.fromCircle(center: c + shift, radius: r - strokeW / 2);
          canvas.drawArc(
              rect,
              start + gap / 2,
              sweep,
              false,
              Paint()
                ..color = col
                ..style = PaintingStyle.stroke
                ..strokeWidth = strokeW + (isSel ? 6 : 0)
                ..strokeCap = StrokeCap.butt);
        } else {
          canvas.drawArc(Rect.fromCircle(center: c + shift, radius: r), start + gap / 2, sweep, true,
              Paint()..color = col);
        }
      }
      start += full * t;
    }
    if (donut) {
      if (sel != null && sel! < data.length) {
        final share = data[sel!].value / total * 100;
        paintCentered(canvas, cache.get(data[sel!].label, LuxText.label, maxWidth: r), c + const Offset(0, -12));
        paintCentered(canvas, cache.get('${fmtNum(share, dec: 0)}٪', LuxText.heading.copyWith(color: colors[sel!])),
            c + const Offset(0, 12));
      } else {
        if (centerTop != null) {
          paintCentered(canvas, cache.get(centerTop!, LuxText.title.copyWith(fontSize: 22)),
              c + Offset(0, centerBottom != null ? -10 : 0));
        }
        if (centerBottom != null) {
          paintCentered(canvas, cache.get(centerBottom!, LuxText.caption, maxWidth: r), c + const Offset(0, 14));
        }
      }
    }
  }

  @override
  bool shouldRepaint(covariant _PiePainter o) => o.t != t || o.sel != sel || !identical(o.data, data);
}

// ════════════════ حلقه‌ی پیشرفت / گیج ════════════════
class RingProgress extends StatelessWidget {
  final double value; // ۰..۱
  final double size;
  final double stroke;
  final Color color;
  final Widget? child;
  final double startDeg;
  final double sweepDeg;

  const RingProgress({
    super.key,
    required this.value,
    this.size = 120,
    this.stroke = 10,
    this.color = LuxColors.accent,
    this.child,
    this.startDeg = -90,
    this.sweepDeg = 360,
  });

  /// گیجِ کمانی (۲۴۰ درجه)
  const RingProgress.gauge({
    super.key,
    required this.value,
    this.size = 140,
    this.stroke = 12,
    this.color = LuxColors.accent,
    this.child,
  })  : startDeg = 150,
        sweepDeg = 240;

  @override
  Widget build(BuildContext context) {
    return TweenAnimationBuilder<double>(
      tween: Tween<double>(begin: 0, end: value.clamp(0.0, 1.0).toDouble()),
      duration: const Duration(milliseconds: 800),
      curve: Curves.easeOutCubic,
      builder: (context, v, _) {
        return SizedBox(
          width: size,
          height: size,
          child: Stack(
            alignment: Alignment.center,
            children: [
              RepaintBoundary(
                child: CustomPaint(
                  size: Size.square(size),
                  painter: _RingPainter(v, stroke, color, startDeg, sweepDeg),
                ),
              ),
              if (child != null) child!,
            ],
          ),
        );
      },
    );
  }
}

class _RingPainter extends CustomPainter {
  final double v;
  final double stroke;
  final Color color;
  final double startDeg;
  final double sweepDeg;
  _RingPainter(this.v, this.stroke, this.color, this.startDeg, this.sweepDeg);

  @override
  void paint(Canvas canvas, Size size) {
    final rect = Rect.fromCircle(center: size.center(Offset.zero), radius: size.width / 2 - stroke / 2);
    final start = startDeg * math.pi / 180;
    final sweep = sweepDeg * math.pi / 180;
    final base = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = stroke
      ..strokeCap = StrokeCap.round
      ..color = LuxColors.alpha(LuxColors.stroke, 0.8);
    canvas.drawArc(rect, start, sweep, false, base);
    if (v > 0.001) {
      canvas.drawArc(
          rect,
          start,
          sweep * v,
          false,
          Paint()
            ..style = PaintingStyle.stroke
            ..strokeWidth = stroke
            ..strokeCap = StrokeCap.round
            ..color = color);
    }
  }

  @override
  bool shouldRepaint(covariant _RingPainter o) => o.v != v || o.color != color || o.stroke != stroke;
}

// ════════════════ رادار ════════════════
class RadarChart extends StatelessWidget {
  final List<String> labels;
  final List<double> values; // ۰..۱
  final Color color;
  final double size;

  const RadarChart({super.key, required this.labels, required this.values, this.color = LuxColors.accent, this.size = 260});

  @override
  Widget build(BuildContext context) {
    return ChartCanvas(
      height: size,
      dataKey: chartKey(values),
      hit: null,
      builder: (t, sel, cache) => _RadarPainter(labels, values, color, t, cache),
    );
  }
}

class _RadarPainter extends CustomPainter {
  final List<String> labels;
  final List<double> values;
  final Color color;
  final double t;
  final TextCache cache;
  _RadarPainter(this.labels, this.values, this.color, this.t, this.cache);

  @override
  void paint(Canvas canvas, Size size) {
    final n = math.min(labels.length, values.length);
    if (n < 3) return;
    final c = Offset(size.width / 2, size.height / 2);
    final r = math.min(size.width, size.height) / 2 - 40;
    final grid = Paint()
      ..color = LuxColors.alpha(LuxColors.stroke, 0.8)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1;

    Offset at(int i, double f) {
      final a = -math.pi / 2 + 2 * math.pi * i / n;
      return Offset(c.dx + math.cos(a) * r * f, c.dy + math.sin(a) * r * f);
    }

    for (var ring = 1; ring <= 4; ring++) {
      final f = ring / 4;
      final path = Path()..moveTo(at(0, f).dx, at(0, f).dy);
      for (var i = 1; i < n; i++) {
        path.lineTo(at(i, f).dx, at(i, f).dy);
      }
      path.close();
      canvas.drawPath(path, grid);
    }
    for (var i = 0; i < n; i++) {
      canvas.drawLine(c, at(i, 1), grid);
      final lp = at(i, 1.22);
      paintCentered(canvas, cache.get(labels[i], chartAxisStyle().copyWith(color: LuxColors.silver), maxWidth: 70), lp);
    }
    final poly = Path();
    for (var i = 0; i < n; i++) {
      final f = values[i].clamp(0.0, 1.0).toDouble() * t;
      final p = at(i, f);
      if (i == 0) {
        poly.moveTo(p.dx, p.dy);
      } else {
        poly.lineTo(p.dx, p.dy);
      }
    }
    poly.close();
    canvas.drawPath(poly, Paint()..color = LuxColors.alpha(color, 0.22));
    canvas.drawPath(
        poly,
        Paint()
          ..color = color
          ..style = PaintingStyle.stroke
          ..strokeWidth = 2.4
          ..strokeJoin = StrokeJoin.round);
    for (var i = 0; i < n; i++) {
      canvas.drawCircle(at(i, values[i].clamp(0.0, 1.0).toDouble() * t), 3.6, Paint()..color = color);
    }
  }

  @override
  bool shouldRepaint(covariant _RadarPainter o) => o.t != t || !identical(o.values, values);
}
