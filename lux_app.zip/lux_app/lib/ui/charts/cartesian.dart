import 'dart:math' as math;
import 'package:flutter/material.dart';
import '../../core/jalali_utils.dart';
import '../../core/palette.dart';
import '../../engine/stats.dart';
import 'chart_base.dart';

// ════════════════ نمودار ستونی (Column) ════════════════
class ColumnChart extends StatelessWidget {
  final List<ChartPoint> data;
  final double? maxY;
  final double height;
  final bool rtl;
  final String Function(double)? fmt;
  final Color? color;

  const ColumnChart({super.key, required this.data, this.maxY, this.height = 220, this.rtl = true, this.fmt, this.color});

  @override
  Widget build(BuildContext context) {
    return ChartCanvas(
      height: height,
      dataKey: chartKey(data.map((e) => e.value)),
      hit: (p, s) => slotHit(p, s, data.length, rtl),
      builder: (t, sel, cache) => _ColumnPainter(data, maxY, rtl, fmt ?? defaultFmt, color, t, sel, cache),
    );
  }
}

class _ColumnPainter extends CustomPainter {
  final List<ChartPoint> data;
  final double? maxY;
  final bool rtl;
  final String Function(double) fmt;
  final Color? color;
  final double t;
  final int? sel;
  final TextCache cache;
  _ColumnPainter(this.data, this.maxY, this.rtl, this.fmt, this.color, this.t, this.sel, this.cache);

  @override
  void paint(Canvas canvas, Size size) {
    final n = data.length;
    if (n == 0) return;
    final plot = plotRect(size);
    var maxV = maxY ?? data.fold<double>(0, (a, b) => math.max(a, b.value));
    if (maxV <= 0) maxV = 1;

    final grid = Paint()
      ..color = LuxColors.alpha(LuxColors.stroke, 0.6)
      ..strokeWidth = 1;
    for (var g = 0; g <= 4; g++) {
      final y = plot.bottom - plot.height * g / 4;
      canvas.drawLine(Offset(plot.left, y), Offset(plot.right, y), grid);
    }

    final slot = plot.width / n;
    final barW = math.min(slot * 0.56, 36.0);
    for (var i = 0; i < n; i++) {
      final pos = rtl ? n - 1 - i : i;
      final cx = plot.left + slot * (pos + 0.5);
      final v = math.min(math.max(data[i].value, 0.0), maxV);
      final h = plot.height * (v / maxV) * t;
      final base = data[i].color ?? color ?? LuxColors.accent;
      final isSel = sel == i;
      final c = (sel == null || isSel) ? base : LuxColors.alpha(base, 0.45);
      if (h > 0.5) {
        final rect = Rect.fromLTWH(cx - barW / 2, plot.bottom - h, barW, h);
        final paint = Paint()
          ..shader = LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [c, LuxColors.alpha(c, 0.45)],
          ).createShader(rect);
        canvas.drawRRect(
          RRect.fromRectAndCorners(rect,
              topLeft: const Radius.circular(8),
              topRight: const Radius.circular(8),
              bottomLeft: const Radius.circular(2),
              bottomRight: const Radius.circular(2)),
          paint,
        );
      }
      final label = cache.get(data[i].label, chartAxisStyle(), maxWidth: slot - 2);
      paintCentered(canvas, label, Offset(cx, plot.bottom + 16));
      if (isSel || (n <= 6 && sel == null)) {
        final vt = cache.get(fmt(data[i].value), chartValueStyle());
        paintCentered(canvas, vt, Offset(cx, plot.bottom - h - 12));
      }
    }
  }

  @override
  bool shouldRepaint(covariant _ColumnPainter o) => o.t != t || o.sel != sel || !identical(o.data, data);
}

// ════════════════ نمودار میله‌ای افقی (Bar) ════════════════
class BarChart extends StatelessWidget {
  final List<ChartPoint> data;
  final double? maxX;
  final bool rtl;
  final String Function(double)? fmt;
  final Color? color;
  final double rowHeight;

  const BarChart({super.key, required this.data, this.maxX, this.rtl = true, this.fmt, this.color, this.rowHeight = 38});

  @override
  Widget build(BuildContext context) {
    final h = math.max(60.0, data.length * rowHeight + 12);
    return ChartCanvas(
      height: h,
      dataKey: chartKey(data.map((e) => e.value)),
      hit: (p, s) {
        if (data.isEmpty) return null;
        final i = ((p.dy - 6) / rowHeight).floor();
        return (i >= 0 && i < data.length) ? i : null;
      },
      builder: (t, sel, cache) => _BarPainter(data, maxX, rtl, fmt ?? defaultFmt, color, rowHeight, t, sel, cache),
    );
  }
}

class _BarPainter extends CustomPainter {
  final List<ChartPoint> data;
  final double? maxX;
  final bool rtl;
  final String Function(double) fmt;
  final Color? color;
  final double rowH;
  final double t;
  final int? sel;
  final TextCache cache;
  _BarPainter(this.data, this.maxX, this.rtl, this.fmt, this.color, this.rowH, this.t, this.sel, this.cache);

  @override
  void paint(Canvas canvas, Size size) {
    final n = data.length;
    if (n == 0) return;
    const labelW = 92.0;
    const gap = 10.0;
    const valW = 44.0;
    var maxV = maxX ?? data.fold<double>(0, (a, b) => math.max(a, b.value));
    if (maxV <= 0) maxV = 1;

    // ناحیه‌ی میله‌ها
    final left = rtl ? valW : labelW + gap;
    final right = rtl ? size.width - labelW - gap : size.width - valW;
    final trackW = math.max(1.0, right - left);

    for (var i = 0; i < n; i++) {
      final cy = 6 + rowH * (i + 0.5);
      final thick = math.min(rowH * 0.46, 16.0);
      final base = data[i].color ?? color ?? LuxColors.seriesAt(0);
      final c = (sel == null || sel == i) ? base : LuxColors.alpha(base, 0.45);

      // لیبل
      final lt = cache.get(data[i].label, chartAxisStyle().copyWith(fontSize: 12, color: LuxColors.silver),
          maxWidth: labelW, align: rtl ? TextAlign.right : TextAlign.left);
      final lx = rtl ? size.width - lt.width : 0.0;
      lt.paint(canvas, Offset(lx, cy - lt.height / 2));

      // ترک
      final track = RRect.fromRectAndRadius(
          Rect.fromLTWH(left, cy - thick / 2, trackW, thick), Radius.circular(thick / 2));
      canvas.drawRRect(track, Paint()..color = LuxColors.alpha(LuxColors.stroke, 0.5));

      // میله (در RTL از راست رشد می‌کند)
      final frac = math.min(math.max(data[i].value / maxV, 0.0), 1.0) * t;
      final w = trackW * frac;
      if (w > 0.5) {
        final rect = rtl
            ? Rect.fromLTWH(right - w, cy - thick / 2, w, thick)
            : Rect.fromLTWH(left, cy - thick / 2, w, thick);
        canvas.drawRRect(RRect.fromRectAndRadius(rect, Radius.circular(thick / 2)), Paint()..color = c);
      }
      final vt = cache.get(fmt(data[i].value), chartValueStyle());
      final vx = rtl ? 0.0 : size.width - vt.width;
      vt.paint(canvas, Offset(vx, cy - vt.height / 2));
    }
  }

  @override
  bool shouldRepaint(covariant _BarPainter o) => o.t != t || o.sel != sel || !identical(o.data, data);
}

// ════════════════ ستونیِ انباشته ════════════════
class StackedColumnChart extends StatelessWidget {
  final List<String> labels;
  final List<List<double>> parts; // parts[i] = بخش‌های ستونِ i
  final List<Color>? colors;
  final double height;
  final bool rtl;

  const StackedColumnChart({super.key, required this.labels, required this.parts, this.colors, this.height = 220, this.rtl = true});

  @override
  Widget build(BuildContext context) {
    final cs = colors ?? LuxColors.series;
    return ChartCanvas(
      height: height,
      dataKey: chartKey(parts.expand((e) => e)),
      hit: (p, s) => slotHit(p, s, labels.length, rtl),
      builder: (t, sel, cache) => _StackedPainter(labels, parts, cs, rtl, t, sel, cache),
    );
  }
}

class _StackedPainter extends CustomPainter {
  final List<String> labels;
  final List<List<double>> parts;
  final List<Color> colors;
  final bool rtl;
  final double t;
  final int? sel;
  final TextCache cache;
  _StackedPainter(this.labels, this.parts, this.colors, this.rtl, this.t, this.sel, this.cache);

  @override
  void paint(Canvas canvas, Size size) {
    final n = labels.length;
    if (n == 0) return;
    final plot = plotRect(size);
    var maxV = 0.0;
    for (final p in parts) {
      maxV = math.max(maxV, p.fold<double>(0, (a, b) => a + b));
    }
    if (maxV <= 0) maxV = 1;
    final grid = Paint()
      ..color = LuxColors.alpha(LuxColors.stroke, 0.6)
      ..strokeWidth = 1;
    for (var g = 0; g <= 4; g++) {
      final y = plot.bottom - plot.height * g / 4;
      canvas.drawLine(Offset(plot.left, y), Offset(plot.right, y), grid);
    }
    final slot = plot.width / n;
    final barW = math.min(slot * 0.56, 36.0);
    for (var i = 0; i < n; i++) {
      final pos = rtl ? n - 1 - i : i;
      final cx = plot.left + slot * (pos + 0.5);
      var y = plot.bottom;
      final dim = sel != null && sel != i;
      for (var k = 0; k < parts[i].length; k++) {
        final h = plot.height * (parts[i][k] / maxV) * t;
        if (h <= 0.3) continue;
        final c = colors[k % colors.length];
        final rect = Rect.fromLTWH(cx - barW / 2, y - h, barW, h);
        canvas.drawRRect(
            RRect.fromRectAndRadius(rect, const Radius.circular(3)), Paint()..color = dim ? LuxColors.alpha(c, 0.4) : c);
        y -= h + 1.5;
      }
      paintCentered(canvas, cache.get(labels[i], chartAxisStyle(), maxWidth: slot - 2), Offset(cx, plot.bottom + 16));
      if (sel == i) {
        final total = parts[i].fold<double>(0, (a, b) => a + b);
        paintCentered(canvas, cache.get(fmtNum(total), chartValueStyle()), Offset(cx, y - 10));
      }
    }
  }

  @override
  bool shouldRepaint(covariant _StackedPainter o) => o.t != t || o.sel != sel || !identical(o.parts, parts);
}

// ════════════════ خطی / ناحیه‌ای ════════════════
class LineSeries {
  final String name;
  final List<double> values;
  final Color color;
  const LineSeries(this.name, this.values, this.color);
}

class LineChart extends StatelessWidget {
  final List<String> labels;
  final List<LineSeries> series;
  final double? minY;
  final double? maxY;
  final bool area;
  final double height;
  final bool rtl;
  final String Function(double)? fmt;

  const LineChart({
    super.key,
    required this.labels,
    required this.series,
    this.minY,
    this.maxY,
    this.area = true,
    this.height = 220,
    this.rtl = true,
    this.fmt,
  });

  @override
  Widget build(BuildContext context) {
    return ChartCanvas(
      height: height,
      dataKey: chartKey(series.expand((s) => s.values)),
      hit: (p, size) {
        final n = labels.length;
        if (n == 0) return null;
        final plot = plotRect(size, l: 14, r: 14);
        final f = ((p.dx - plot.left) / plot.width).clamp(0.0, 1.0);
        final pos = n == 1 ? 0 : (f * (n - 1)).round();
        return rtl ? n - 1 - pos : pos;
      },
      builder: (t, sel, cache) => _LinePainter(labels, series, minY, maxY, area, rtl, fmt ?? defaultFmt, t, sel, cache),
    );
  }
}

class _LinePainter extends CustomPainter {
  final List<String> labels;
  final List<LineSeries> series;
  final double? minY;
  final double? maxY;
  final bool area;
  final bool rtl;
  final String Function(double) fmt;
  final double t;
  final int? sel;
  final TextCache cache;
  _LinePainter(this.labels, this.series, this.minY, this.maxY, this.area, this.rtl, this.fmt, this.t, this.sel, this.cache);

  @override
  void paint(Canvas canvas, Size size) {
    final n = labels.length;
    if (n == 0 || series.isEmpty) return;
    final plot = plotRect(size, l: 14, r: 14);
    var lo = double.infinity, hi = -double.infinity;
    for (final s in series) {
      for (final v in s.values) {
        lo = math.min(lo, v);
        hi = math.max(hi, v);
      }
    }
    if (lo.isInfinite) return;
    lo = minY ?? math.min(0.0, lo);
    hi = maxY ?? (hi * 1.1);
    if (hi <= lo) hi = lo + 1;

    final grid = Paint()
      ..color = LuxColors.alpha(LuxColors.stroke, 0.6)
      ..strokeWidth = 1;
    for (var g = 0; g <= 4; g++) {
      final y = plot.bottom - plot.height * g / 4;
      canvas.drawLine(Offset(plot.left, y), Offset(plot.right, y), grid);
      final tp = cache.get(fmtNum(lo + (hi - lo) * g / 4, dec: 0), chartAxisStyle());
      tp.paint(canvas, Offset(plot.left, y - tp.height - 1));
    }

    double xAt(int i) {
      final pos = rtl ? n - 1 - i : i;
      return n == 1 ? plot.center.dx : plot.left + plot.width * pos / (n - 1);
    }

    double yAt(double v) => plot.bottom - plot.height * ((v - lo) / (hi - lo)).clamp(0.0, 1.0);

    for (var i = 0; i < n; i++) {
      if (n <= 8 || i % math.max(1, (n / 6).ceil()) == 0) {
        paintCentered(canvas, cache.get(labels[i], chartAxisStyle(), maxWidth: 60), Offset(xAt(i), plot.bottom + 16));
      }
    }

    // پیش‌روی انیمیشن از سمتِ شروع
    canvas.save();
    final clip = rtl
        ? Rect.fromLTRB(plot.right + 14 - (plot.width + 28) * t, 0, size.width, size.height)
        : Rect.fromLTRB(0, 0, plot.left - 14 + (plot.width + 28) * t, size.height);
    canvas.clipRect(clip);

    for (final s in series) {
      final pts = <Offset>[];
      for (var i = 0; i < math.min(n, s.values.length); i++) {
        pts.add(Offset(xAt(i), yAt(s.values[i])));
      }
      if (pts.isEmpty) continue;
      pts.sort((a, b) => a.dx.compareTo(b.dx));
      final path = _smooth(pts);
      if (area && pts.length > 1) {
        final fill = Path.from(path)
          ..lineTo(pts.last.dx, plot.bottom)
          ..lineTo(pts.first.dx, plot.bottom)
          ..close();
        canvas.drawPath(
          fill,
          Paint()
            ..shader = LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: [LuxColors.alpha(s.color, 0.28), LuxColors.alpha(s.color, 0.0)],
            ).createShader(plot),
        );
      }
      canvas.drawPath(
        path,
        Paint()
          ..color = s.color
          ..style = PaintingStyle.stroke
          ..strokeWidth = 3
          ..strokeCap = StrokeCap.round
          ..strokeJoin = StrokeJoin.round,
      );
      if (n <= 14) {
        for (final p in pts) {
          canvas.drawCircle(p, 3.6, Paint()..color = LuxColors.bg);
          canvas.drawCircle(
              p,
              3.6,
              Paint()
                ..color = s.color
                ..style = PaintingStyle.stroke
                ..strokeWidth = 2);
        }
      }
    }
    canvas.restore();

    // انتخاب
    if (sel != null && sel! >= 0 && sel! < n) {
      final x = xAt(sel!);
      canvas.drawLine(Offset(x, plot.top), Offset(x, plot.bottom),
          Paint()..color = LuxColors.alpha(LuxColors.silver, 0.4)..strokeWidth = 1);
      final ty = plot.top;
      final lines = <TextPainter>[cache.get(labels[sel!], chartAxisStyle().copyWith(color: LuxColors.silver))];
      for (final s in series) {
        if (sel! < s.values.length) {
          final v = s.values[sel!];
          canvas.drawCircle(Offset(x, yAt(v)), 6, Paint()..color = s.color);
          lines.add(cache.get('${s.name}: ${fmt(v)}', chartValueStyle().copyWith(color: s.color)));
        }
      }
      var w = 0.0, h = 8.0;
      for (final l in lines) {
        w = math.max(w, l.width);
        h += l.height + 2;
      }
      w += 20;
      var bx = x - w / 2;
      bx = bx.clamp(2.0, math.max(2.0, size.width - w - 2)).toDouble();
      final box = RRect.fromRectAndRadius(Rect.fromLTWH(bx, ty - 4, w, h), const Radius.circular(10));
      canvas.drawRRect(box, Paint()..color = LuxColors.cardHi);
      canvas.drawRRect(
          box,
          Paint()
            ..color = LuxColors.stroke
            ..style = PaintingStyle.stroke);
      var cy = ty + 2;
      for (final l in lines) {
        l.paint(canvas, Offset(bx + (w - l.width) / 2, cy));
        cy += l.height + 2;
      }
    }
  }

  Path _smooth(List<Offset> p) {
    final path = Path()..moveTo(p.first.dx, p.first.dy);
    if (p.length == 1) return path;
    for (var i = 0; i < p.length - 1; i++) {
      final p0 = i == 0 ? p[i] : p[i - 1];
      final p1 = p[i];
      final p2 = p[i + 1];
      final p3 = i + 2 < p.length ? p[i + 2] : p2;
      final c1 = Offset(p1.dx + (p2.dx - p0.dx) / 6, p1.dy + (p2.dy - p0.dy) / 6);
      final c2 = Offset(p2.dx - (p3.dx - p1.dx) / 6, p2.dy - (p3.dy - p1.dy) / 6);
      path.cubicTo(c1.dx, c1.dy, c2.dx, c2.dy, p2.dx, p2.dy);
    }
    return path;
  }

  @override
  bool shouldRepaint(covariant _LinePainter o) => o.t != t || o.sel != sel || !identical(o.series, series);
}

// ════════════════ پراکندگی (Scatter) + خط روند ════════════════
class ScatterChart extends StatelessWidget {
  final List<Offset> points; // x و y واقعی
  final bool trend;
  final double height;
  final Color? color;

  const ScatterChart({super.key, required this.points, this.trend = true, this.height = 220, this.color});

  @override
  Widget build(BuildContext context) {
    return ChartCanvas(
      height: height,
      dataKey: chartKey(points.expand((e) => [e.dx, e.dy])),
      hit: null,
      builder: (t, sel, cache) => _ScatterPainter(points, trend, color ?? LuxColors.accent, t, cache),
    );
  }
}

class _ScatterPainter extends CustomPainter {
  final List<Offset> pts;
  final bool trend;
  final Color color;
  final double t;
  final TextCache cache;
  _ScatterPainter(this.pts, this.trend, this.color, this.t, this.cache);

  @override
  void paint(Canvas canvas, Size size) {
    if (pts.isEmpty) return;
    final plot = plotRect(size, l: 14, r: 14, t: 14, b: 14);
    var minX = pts.first.dx, maxX = pts.first.dx, minY = pts.first.dy, maxY = pts.first.dy;
    for (final p in pts) {
      minX = math.min(minX, p.dx);
      maxX = math.max(maxX, p.dx);
      minY = math.min(minY, p.dy);
      maxY = math.max(maxY, p.dy);
    }
    if (maxX == minX) maxX = minX + 1;
    if (maxY == minY) maxY = minY + 1;
    Offset map(Offset p) => Offset(plot.left + plot.width * (p.dx - minX) / (maxX - minX),
        plot.bottom - plot.height * (p.dy - minY) / (maxY - minY));

    final grid = Paint()
      ..color = LuxColors.alpha(LuxColors.stroke, 0.6)
      ..strokeWidth = 1;
    for (var g = 0; g <= 4; g++) {
      final y = plot.bottom - plot.height * g / 4;
      final x = plot.left + plot.width * g / 4;
      canvas.drawLine(Offset(plot.left, y), Offset(plot.right, y), grid);
      canvas.drawLine(Offset(x, plot.top), Offset(x, plot.bottom), grid);
    }
    for (final p in pts) {
      canvas.drawCircle(map(p), 5 * t, Paint()..color = LuxColors.alpha(color, 0.85));
    }
    if (trend) {
      final fit = Stats.linearFit(pts.map((e) => e.dx).toList(), pts.map((e) => e.dy).toList());
      if (fit != null) {
        final a = map(Offset(minX, fit.predict(minX)));
        final b = map(Offset(maxX, fit.predict(maxX)));
        canvas.drawLine(
            a,
            Offset.lerp(a, b, t)!,
            Paint()
              ..color = LuxColors.silver
              ..strokeWidth = 2
              ..strokeCap = StrokeCap.round);
        final r = Stats.pearson(pts.map((e) => e.dx).toList(), pts.map((e) => e.dy).toList());
        if (r != null) {
          final tp = cache.get('r = ${fmtNum(r, dec: 2)}', chartValueStyle());
          tp.paint(canvas, Offset(plot.right - tp.width, plot.top));
        }
      }
    }
  }

  @override
  bool shouldRepaint(covariant _ScatterPainter o) => o.t != t || !identical(o.pts, pts);
}

// ════════════════ اسپارک‌لاین ════════════════
class Sparkline extends StatelessWidget {
  final List<double> values;
  final Color? color;
  final double height;
  final bool rtl;
  const Sparkline({super.key, required this.values, this.color, this.height = 36, this.rtl = true});

  @override
  Widget build(BuildContext context) {
    return RepaintBoundary(
      child: CustomPaint(
        size: Size(double.infinity, height),
        painter: _SparkPainter(values, color ?? LuxColors.accent, rtl),
      ),
    );
  }
}

class _SparkPainter extends CustomPainter {
  final List<double> v;
  final Color color;
  final bool rtl;
  _SparkPainter(this.v, this.color, this.rtl);

  @override
  void paint(Canvas canvas, Size size) {
    if (v.length < 2) return;
    var lo = v.reduce(math.min), hi = v.reduce(math.max);
    if (hi == lo) hi = lo + 1;
    final path = Path();
    for (var i = 0; i < v.length; i++) {
      final pos = rtl ? v.length - 1 - i : i;
      final x = size.width * pos / (v.length - 1);
      final y = size.height - (size.height - 4) * (v[i] - lo) / (hi - lo) - 2;
      if (i == 0) {
        path.moveTo(x, y);
      } else {
        path.lineTo(x, y);
      }
    }
    canvas.drawPath(
        path,
        Paint()
          ..color = color
          ..style = PaintingStyle.stroke
          ..strokeWidth = 2
          ..strokeJoin = StrokeJoin.round
          ..strokeCap = StrokeCap.round);
  }

  @override
  bool shouldRepaint(covariant _SparkPainter o) => !identical(o.v, v) || o.color != color;
}
