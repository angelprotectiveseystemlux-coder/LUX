import 'dart:math' as math;
import 'package:flutter/material.dart';
import '../../core/jalali_utils.dart';
import '../../core/palette.dart';
import 'chart_base.dart';

/// یک خط در نمودارِ مقایسه؛ مقدارِ null یعنی «داده ندارد» و خط در آنجا شکسته می‌شود.
class GapSeries {
  final String name;
  final List<double?> values;
  final Color color;

  /// خودِ کاربر: ضخیم‌تر، با درخششِ ملایم و سایه‌ی زیرِ خط، و همیشه روی بقیه کشیده می‌شود.
  final bool primary;

  const GapSeries(this.name, this.values, this.color, {this.primary = false});
}

/// نمودار خطِ شکسته (پاره‌خط‌های مستقیم) برای مقایسه‌ی چند نفر روی مقیاس ۰ تا ۲۰.
/// محورِ عمودی خودکار روی بازه‌ی داده بزرگ می‌شود تا تفاوت‌های کوچک هم دیده شوند.
class PolylineChart extends StatelessWidget {
  final List<String> labels;

  /// عنوانِ بلندترِ هر نقطه برای کادرِ لمس (اگر نبود همان [labels])
  final List<String>? details;
  final List<GapSeries> series;
  final double height;
  final bool rtl;

  const PolylineChart({
    super.key,
    required this.labels,
    required this.series,
    this.details,
    this.height = 240,
    this.rtl = true,
  });

  @override
  Widget build(BuildContext context) {
    final key = Object.hash(
      labels.length,
      series.length,
      chartKey(series.expand((s) => <double>[-1.0, ...s.values.map((v) => v ?? -7.0)])),
    );
    return ChartCanvas(
      height: height,
      dataKey: key,
      hit: (p, size) {
        final n = labels.length;
        if (n == 0) return null;
        final plot = plotRect(size, l: 14, r: 14);
        final f = ((p.dx - plot.left) / plot.width).clamp(0.0, 1.0);
        final pos = n == 1 ? 0 : (f * (n - 1)).round();
        return rtl ? n - 1 - pos : pos;
      },
      builder: (t, sel, cache) => _PolyPainter(labels, details ?? labels, series, rtl, t, sel, cache),
    );
  }
}

class _PolyPainter extends CustomPainter {
  final List<String> labels;
  final List<String> details;
  final List<GapSeries> series;
  final bool rtl;
  final double t;
  final int? sel;
  final TextCache cache;
  _PolyPainter(this.labels, this.details, this.series, this.rtl, this.t, this.sel, this.cache);

  static String _fmt(double v) => fmtNum(v, dec: 2);

  @override
  void paint(Canvas canvas, Size size) {
    final n = labels.length;
    if (n == 0 || series.isEmpty) return;
    final plot = plotRect(size, l: 14, r: 14);

    var dMin = double.infinity, dMax = -double.infinity;
    for (final s in series) {
      for (final v in s.values) {
        if (v == null) continue;
        dMin = math.min(dMin, v);
        dMax = math.max(dMax, v);
      }
    }
    if (dMin.isInfinite) return;

    // بازه‌ی محور: مضربِ ۴ تا برچسب‌ها عددِ صحیح باشند؛ همیشه داخل ۰..۲۰
    var span = ((dMax - dMin) + 2);
    span = (span / 4).ceil() * 4.0;
    span = span.clamp(4.0, 20.0).toDouble();
    var lo = ((dMin + dMax) / 2 - span / 2).floorToDouble();
    lo = lo.clamp(0.0, 20.0 - span).toDouble();
    final hi = lo + span;

    final grid = Paint()
      ..color = LuxColors.alpha(LuxColors.stroke, 0.6)
      ..strokeWidth = 1;
    for (var g = 0; g <= 4; g++) {
      final y = plot.bottom - plot.height * g / 4;
      canvas.drawLine(Offset(plot.left, y), Offset(plot.right, y), grid);
      final tp = cache.get(fmtNum(lo + (hi - lo) * g / 4, dec: 0), chartAxisStyle());
      tp.paint(canvas, Offset(plot.left, y - tp.height - 1));
    }

    double xAt(int i) {
      final pos = rtl ? n - 1 - i : i;
      return n == 1 ? plot.center.dx : plot.left + plot.width * pos / (n - 1);
    }

    double yAt(double v) => plot.bottom - plot.height * ((v - lo) / (hi - lo)).clamp(0.0, 1.0);

    // خط‌های راهنمای عمودیِ کم‌رنگ زیرِ هر امتحان
    final vgrid = Paint()
      ..color = LuxColors.alpha(LuxColors.stroke, 0.28)
      ..strokeWidth = 1;
    if (n <= 16) {
      for (var i = 0; i < n; i++) {
        canvas.drawLine(Offset(xAt(i), plot.top), Offset(xAt(i), plot.bottom), vgrid);
      }
    }

    for (var i = 0; i < n; i++) {
      if (n <= 8 || i % math.max(1, (n / 6).ceil()) == 0) {
        paintCentered(canvas, cache.get(labels[i], chartAxisStyle(), maxWidth: 60), Offset(xAt(i), plot.bottom + 16));
      }
    }

    // پیش‌روی انیمیشن از سمتِ شروع
    canvas.save();
    final clip = rtl
        ? Rect.fromLTRB(plot.right + 14 - (plot.width + 28) * t, 0, size.width, size.height)
        : Rect.fromLTRB(0, 0, plot.left - 14 + (plot.width + 28) * t, size.height);
    canvas.clipRect(clip);

    // رقبا اول، خودِ کاربر آخر (روی همه)
    final ordered = <GapSeries>[
      for (final s in series)
        if (!s.primary) s,
      for (final s in series)
        if (s.primary) s,
    ];

    for (final s in ordered) {
      // تکه‌های پیوسته‌ی غیر null
      final runs = <List<Offset>>[];
      var cur = <Offset>[];
      for (var i = 0; i < math.min(n, s.values.length); i++) {
        final v = s.values[i];
        if (v == null) {
          if (cur.isNotEmpty) runs.add(cur);
          cur = <Offset>[];
        } else {
          cur.add(Offset(xAt(i), yAt(v)));
        }
      }
      if (cur.isNotEmpty) runs.add(cur);

      for (final run in runs) {
        if (run.length > 1) {
          final path = Path()..moveTo(run.first.dx, run.first.dy);
          for (var k = 1; k < run.length; k++) {
            path.lineTo(run[k].dx, run[k].dy);
          }
          if (s.primary) {
            final fill = Path.from(path)
              ..lineTo(run.last.dx, plot.bottom)
              ..lineTo(run.first.dx, plot.bottom)
              ..close();
            canvas.drawPath(
              fill,
              Paint()
                ..shader = LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [LuxColors.alpha(s.color, 0.26), LuxColors.alpha(s.color, 0.0)],
                ).createShader(plot),
            );
            canvas.drawPath(
              path,
              Paint()
                ..color = LuxColors.alpha(s.color, 0.18)
                ..style = PaintingStyle.stroke
                ..strokeWidth = 9
                ..strokeCap = StrokeCap.round
                ..strokeJoin = StrokeJoin.round,
            );
          }
          canvas.drawPath(
            path,
            Paint()
              ..color = s.color
              ..style = PaintingStyle.stroke
              ..strokeWidth = s.primary ? 3.4 : 2.2
              ..strokeCap = StrokeCap.round
              ..strokeJoin = StrokeJoin.round,
          );
        }
        // نقطه‌ها (برای نقطه‌ی تنها هم کشیده می‌شود)
        if (n <= 16 || run.length == 1) {
          final r = s.primary ? 4.4 : 3.4;
          for (final p in run) {
            canvas.drawCircle(p, r, Paint()..color = LuxColors.bg);
            canvas.drawCircle(
              p,
              r,
              Paint()
                ..color = s.color
                ..style = PaintingStyle.stroke
                ..strokeWidth = s.primary ? 2.4 : 1.8,
            );
          }
        }
      }
    }
    canvas.restore();

    // مقدارِ آخرِ خودِ کاربر روی نمودار
    if (t > 0.98) {
      for (final s in series) {
        if (!s.primary) continue;
        for (var i = math.min(n, s.values.length) - 1; i >= 0; i--) {
          final v = s.values[i];
          if (v == null) continue;
          final tp = cache.get(_fmt(v), chartValueStyle().copyWith(color: s.color));
          final c = Offset(xAt(i), yAt(v) - 17);
          final rect = Rect.fromCenter(center: c, width: tp.width + 14, height: tp.height + 6);
          final shifted = rect.shift(Offset(
            (rect.left < 2 ? 2 - rect.left : 0) + (rect.right > size.width - 2 ? size.width - 2 - rect.right : 0),
            rect.top < 0 ? -rect.top : 0,
          ));
          final rr = RRect.fromRectAndRadius(shifted, const Radius.circular(9));
          canvas.drawRRect(rr, Paint()..color = LuxColors.cardHi);
          canvas.drawRRect(
            rr,
            Paint()
              ..color = LuxColors.alpha(s.color, 0.55)
              ..style = PaintingStyle.stroke,
          );
          paintCentered(canvas, tp, shifted.center);
          break;
        }
      }
    }

    // انتخابِ با لمس: خط، نقطه‌ها و کادرِ مرتب‌شده از بالا به پایین
    if (sel != null && sel! >= 0 && sel! < n) {
      final x = xAt(sel!);
      canvas.drawLine(
        Offset(x, plot.top),
        Offset(x, plot.bottom),
        Paint()
          ..color = LuxColors.alpha(LuxColors.silver, 0.45)
          ..strokeWidth = 1,
      );
      final entries = <MapEntry<GapSeries, double>>[];
      for (final s in series) {
        if (sel! < s.values.length && s.values[sel!] != null) {
          entries.add(MapEntry(s, s.values[sel!]!));
        }
      }
      entries.sort((a, b) => b.value.compareTo(a.value));
      for (final e in entries) {
        canvas.drawCircle(Offset(x, yAt(e.value)), 6, Paint()..color = e.key.color);
      }
      final lines = <TextPainter>[
        cache.get(details[sel!], chartAxisStyle().copyWith(color: LuxColors.silver), maxWidth: size.width - 40),
        if (entries.isEmpty) cache.get('داده‌ای نیست', chartAxisStyle()),
        for (final e in entries)
          cache.get('${e.key.name}: ${_fmt(e.value)}', chartValueStyle().copyWith(color: e.key.color)),
      ];
      var w = 0.0, h = 8.0;
      for (final l in lines) {
        w = math.max(w, l.width);
        h += l.height + 2;
      }
      w += 20;
      var bx = x - w / 2;
      bx = bx.clamp(2.0, math.max(2.0, size.width - w - 2)).toDouble();
      final box = RRect.fromRectAndRadius(Rect.fromLTWH(bx, plot.top - 4, w, h), const Radius.circular(10));
      canvas.drawRRect(box, Paint()..color = LuxColors.cardHi);
      canvas.drawRRect(
        box,
        Paint()
          ..color = LuxColors.stroke
          ..style = PaintingStyle.stroke,
      );
      var cy = plot.top + 2;
      for (final l in lines) {
        l.paint(canvas, Offset(bx + (w - l.width) / 2, cy));
        cy += l.height + 2;
      }
    }
  }

  @override
  bool shouldRepaint(covariant _PolyPainter o) => o.t != t || o.sel != sel || !identical(o.series, series);
}
