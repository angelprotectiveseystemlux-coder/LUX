import 'dart:math' as math;
import 'package:flutter/material.dart';
import '../../core/jalali_utils.dart';
import '../../core/palette.dart';
import 'chart_base.dart';

/// نقشه‌ی گرمایی تقویمی: هر ستون یک هفته (شنبه تا جمعه)، قدیمی‌ترین هفته سمت راست.
class HeatmapCalendar extends StatelessWidget {
  final Map<DateTime, double> values; // کلید: فقط تاریخ (بدون ساعت)
  final int weeks;
  final DateTime? end;
  final double? maxValue;
  final String Function(double)? fmt;
  final Color color;

  const HeatmapCalendar({
    super.key,
    required this.values,
    this.weeks = 14,
    this.end,
    this.maxValue,
    this.fmt,
    this.color = LuxColors.accent,
  });

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(builder: (context, cons) {
      final w = cons.maxWidth.isFinite ? cons.maxWidth : 320.0;
      const gap = 4.0;
      const header = 26.0;
      final cell = (w - gap * (weeks - 1)) / weeks;
      final h = header + cell * 7 + gap * 6;
      final last = dateOnly(end ?? DateTime.now());
      final first = DateTime(last.year, last.month, last.day - weekdayIndex(last) - 7 * (weeks - 1));
      var maxV = maxValue ?? values.values.fold<double>(0, math.max);
      if (maxV <= 0) maxV = 1;
      return ChartCanvas(
        height: h,
        dataKey: chartKey(values.values),
        hit: (p, s) {
          final y = p.dy - header;
          if (y < 0) return null;
          final col = (p.dx / (cell + gap)).floor();
          final row = (y / (cell + gap)).floor();
          if (col < 0 || col >= weeks || row < 0 || row > 6) return null;
          final wk = weeks - 1 - col; // RTL: ستونِ چپ = جدیدترین
          return wk * 7 + row;
        },
        builder: (t, sel, cache) => _HeatPainter(values, first, last, weeks, cell, gap, header, maxV, fmt ?? defaultFmt,
            color, t, sel, cache),
      );
    });
  }
}

class _HeatPainter extends CustomPainter {
  final Map<DateTime, double> values;
  final DateTime first;
  final DateTime last;
  final int weeks;
  final double cell;
  final double gap;
  final double header;
  final double maxV;
  final String Function(double) fmt;
  final Color color;
  final double t;
  final int? sel;
  final TextCache cache;
  _HeatPainter(this.values, this.first, this.last, this.weeks, this.cell, this.gap, this.header, this.maxV, this.fmt,
      this.color, this.t, this.sel, this.cache);

  @override
  void paint(Canvas canvas, Size size) {
    for (var wk = 0; wk < weeks; wk++) {
      final col = weeks - 1 - wk;
      for (var r = 0; r < 7; r++) {
        final date = DateTime(first.year, first.month, first.day + wk * 7 + r);
        final x = col * (cell + gap);
        final y = header + r * (cell + gap);
        final rect = RRect.fromRectAndRadius(Rect.fromLTWH(x, y, cell, cell), Radius.circular(cell * 0.28));
        if (date.isAfter(last)) {
          canvas.drawRRect(
              rect,
              Paint()
                ..color = LuxColors.alpha(LuxColors.stroke, 0.35)
                ..style = PaintingStyle.stroke);
          continue;
        }
        final v = values[date] ?? 0.0;
        final f = math.min(1.0, v / maxV) * t;
        final base = LuxColors.alpha(LuxColors.stroke, 0.55);
        final paint = Paint()..color = Color.lerp(base, color, f)!;
        canvas.drawRRect(rect, paint);
        if (sel == wk * 7 + r) {
          canvas.drawRRect(
              rect,
              Paint()
                ..color = LuxColors.silver
                ..style = PaintingStyle.stroke
                ..strokeWidth = 2);
        }
      }
    }
    if (sel != null) {
      final date = DateTime(first.year, first.month, first.day + sel!);
      final v = values[date] ?? 0.0;
      final tp = cache.get('${jalaliLabel(date)} · ${fmt(v)}', chartValueStyle());
      tp.paint(canvas, Offset(size.width - tp.width, 2));
    }
  }

  @override
  bool shouldRepaint(covariant _HeatPainter o) => o.t != t || o.sel != sel || !identical(o.values, values);
}
