import 'dart:async';
import 'package:flutter/material.dart';
import '../pages/appearance_page.dart';
import '../widgets/lux_kit.dart';
import '../pages/manage/quick_add.dart';
import '../../core/app_bus.dart';
import '../../core/layout.dart';
import '../../services/island_live.dart';
import '../../core/palette.dart';
import '../../core/theme.dart';
import '../pages/attendance_page.dart';
import '../pages/manage/exam_ask.dart';
import '../pages/courses_page.dart';
import '../pages/exams_page.dart';
import '../pages/study_hub_page.dart';
import '../pages/today_page.dart';
import '../widgets/haptic.dart';

class _NavItem {
  final String label;
  final IconData icon;
  const _NavItem(this.label, this.icon);
}

class AppShell extends StatefulWidget {
  const AppShell({super.key});

  /// بعد از عوض‌شدنِ تم، برنامه از نو ساخته می‌شود؛ این‌ها تب و صفحه‌ی قبلی را برمی‌گردانند.
  static int pendingIndex = 0;
  static int currentIndex = 0; // تبِ بازِ فعلی (برای حفظِ تب بعد از تغییرِ خودکارِ شب و روز)
  static bool pendingAppearance = false;

  @override
  State<AppShell> createState() => _AppShellState();
}

class _AppShellState extends State<AppShell> with WidgetsBindingObserver {
  static const List<_NavItem> _items = [
    _NavItem('امروز', Icons.home_rounded),
    _NavItem('برنامه', Icons.event_note_rounded),
    _NavItem('مطالعه', Icons.bolt_rounded),
    _NavItem('درس‌ها', Icons.menu_book_rounded),
  ];

  Timer? _askTimer;
  int _i = 0;
  final Set<int> _visited = <int>{0};

  @override
  void initState() {
    super.initState();
    _i = 0;
    _visited.add(_i);
    AppShell.currentIndex = _i;
    WidgetsBinding.instance.addObserver(this);
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) {
        unawaited(_asks());
        unawaited(IslandLive.refresh());
      }
    });
    AppBus.data.addListener(_islandTick);
    _askTimer = Timer.periodic(const Duration(minutes: 1), (_) {
      unawaited(IslandLive.refresh());
      // فقط وقتی کاربر روی صفحه‌ی اصلی است (وسطِ خواندنِ PDF و … مزاحم نمی‌شویم).
      if (mounted && (ModalRoute.of(context)?.isCurrent ?? true)) unawaited(ExamAskPrompt.maybeAsk(context));
    });
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed && mounted) {
      unawaited(_asks());
      unawaited(IslandLive.refresh());
    }
  }

  void _islandTick() => unawaited(IslandLive.refresh());

  /// پرسش‌های خودکار: حضور و غیاب، بعد «امتحان چطور بود؟»
  Future<void> _asks() async {
    await AttendancePrompt.maybeAsk(context);
    if (!mounted) return;
    await ExamAskPrompt.maybeAsk(context);
  }

  @override
  void dispose() {
    _askTimer?.cancel();
    AppBus.data.removeListener(_islandTick);
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  Widget _page(int i) {
    switch (i) {
      case 0:
        return const TodayPage();
      case 1:
        return const ExamsPage();
      case 2:
        return const StudyHubPage();
      default:
        return const CoursesPage();
    }
  }

  void _select(int k) {
    if (k == _i) return;
    Haptic.tap();
    AppShell.currentIndex = k;
    setState(() {
      _i = k;
      _visited.add(k);
    });
  }

  void _add() {
    Haptic.light();
    showQuickAdd(context);
  }

  @override
  Widget build(BuildContext context) {
    final wide = LuxLayout.isWide(context);
    final pages = IndexedStack(
      index: _i,
      children: [
        for (var k = 0; k < _items.length; k++) _visited.contains(k) ? _page(k) : const SizedBox.shrink(),
      ],
    );

    if (wide) {
      // حالت افقی: نوار ناوبری عمودی در کنارِ صفحه، دکمه‌ی «+» بالای آن، محتوا وسط‌چین.
      return Scaffold(
        body: Row(
          children: [
            _SideRail(items: _items, index: _i, onTap: _select, onAdd: _add),
            Expanded(
              child: Align(
                alignment: Alignment.topCenter,
                child: ConstrainedBox(
                  constraints: const BoxConstraints(maxWidth: LuxLayout.maxContentWidth),
                  child: pages,
                ),
              ),
            ),
          ],
        ),
      );
    }

    final pad = MediaQuery.of(context).padding;
    return Scaffold(
      extendBody: true,
      body: Stack(
        children: [
          pages,
          Positioned(
            left: 16,
            right: 16,
            bottom: 12 + pad.bottom,
            child: _Dock(items: _items, index: _i, onTap: _select, onAdd: _add),
          ),
        ],
      ),
    );
  }
}

/// دکمه‌ی «+»ِ همیشه‌حاضر (وسط نوار پایین): افزودنِ هر چیزی از هر تب.
class _AddButton extends StatelessWidget {
  final VoidCallback onTap;
  final double size;
  const _AddButton({required this.onTap, this.size = 56});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTap: onTap,
      child: Container(
        width: size,
        height: size,
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: AlignmentDirectional.topStart,
            end: AlignmentDirectional.bottomEnd,
            colors: [LuxColors.accent, LuxColors.accentDim],
          ),
          borderRadius: BorderRadius.circular(LuxColors.r(size * 0.36)),
          border: LuxColors.hardShadow ? Border.all(color: LuxColors.stroke, width: LuxColors.strokeW) : null,
          boxShadow: LuxColors.hardShadow
              ? LuxColors.shadow()
              : [BoxShadow(color: LuxColors.alpha(LuxColors.accent, 0.38), blurRadius: 16, offset: const Offset(0, 6))],
        ),
        child: Icon(Icons.add_rounded, color: LuxColors.onAccent, size: size * 0.54),
      ),
    );
  }
}

/// نوار ناوبریِ عمودی برای حالت افقی و صفحه‌های عریض.
class _SideRail extends StatelessWidget {
  final List<_NavItem> items;
  final int index;
  final ValueChanged<int> onTap;
  final VoidCallback onAdd;
  const _SideRail({required this.items, required this.index, required this.onTap, required this.onAdd});

  @override
  Widget build(BuildContext context) {
    final pad = MediaQuery.of(context).padding;
    return Container(
      width: LuxLayout.railWidth + pad.right,
      padding: EdgeInsets.fromLTRB(8, pad.top + 8, 8 + pad.right, pad.bottom + 8),
      decoration: BoxDecoration(
        color: LuxColors.card,
        border: BorderDirectional(end: BorderSide(color: LuxColors.strokeColor, width: LuxColors.strokeW)),
      ),
      child: LayoutBuilder(builder: (context, cons) {
        return SingleChildScrollView(
          physics: const BouncingScrollPhysics(),
          child: ConstrainedBox(
            constraints: BoxConstraints(minHeight: cons.maxHeight),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                _AddButton(onTap: onAdd, size: 52),
                const SizedBox(height: 14),
                for (var k = 0; k < items.length; k++)
                  Padding(
                    padding: const EdgeInsets.symmetric(vertical: 3),
                    child: GestureDetector(
                      behavior: HitTestBehavior.opaque,
                      onTap: () => onTap(k),
                      child: AnimatedContainer(
                        duration: LuxMotion.medium,
                        curve: LuxMotion.curve,
                        width: double.infinity,
                        height: 58,
                        decoration: BoxDecoration(
                          color: k == index ? LuxColors.alpha(LuxColors.accent, 0.16) : Colors.transparent,
                          borderRadius: BorderRadius.circular(LuxColors.r(20)),
                        ),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Icon(items[k].icon, size: 23, color: k == index ? LuxColors.accent : LuxColors.silverDim),
                            const SizedBox(height: 2),
                            Text(
                              items[k].label,
                              maxLines: 1,
                              softWrap: false,
                              overflow: TextOverflow.clip,
                              style: LuxText.label.copyWith(
                                fontSize: 10.5,
                                color: k == index ? LuxColors.accent : LuxColors.silverDim,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
              ],
            ),
          ),
        );
      }),
    );
  }
}

/// نوار پایینِ شناور: دو تب، دکمه‌ی «+» در وسط، دو تب. تبِ فعال با قرصِ رنگی و برچسب مشخص می‌شود.
class _Dock extends StatelessWidget {
  final List<_NavItem> items;
  final int index;
  final ValueChanged<int> onTap;
  final VoidCallback onAdd;
  const _Dock({required this.items, required this.index, required this.onTap, required this.onAdd});

  Widget _tab(int k) {
    final on = k == index;
    return Expanded(
      child: GestureDetector(
        behavior: HitTestBehavior.opaque,
        onTap: () => onTap(k),
        child: AnimatedContainer(
          duration: LuxMotion.medium,
          curve: LuxMotion.curve,
          margin: const EdgeInsets.symmetric(horizontal: 2, vertical: 6),
          decoration: BoxDecoration(
            color: on ? LuxColors.alpha(LuxColors.accent, 0.16) : Colors.transparent,
            borderRadius: BorderRadius.circular(LuxColors.r(22)),
          ),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(items[k].icon, size: 24, color: on ? LuxColors.accent : LuxColors.silverDim),
              const SizedBox(height: 2),
              Text(
                items[k].label,
                maxLines: 1,
                softWrap: false,
                overflow: TextOverflow.clip,
                style: LuxText.label.copyWith(
                  fontSize: 10.5,
                  color: on ? LuxColors.accent : LuxColors.silverDim,
                  fontWeight: on ? FontWeight.w700 : FontWeight.w600,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 72,
      padding: const EdgeInsets.symmetric(horizontal: 6),
      decoration: BoxDecoration(
        color: LuxColors.card,
        borderRadius: BorderRadius.circular(LuxColors.r(36)),
        border: Border.all(
          color: LuxColors.hardShadow ? LuxColors.stroke : LuxColors.alpha(LuxColors.stroke, 0.7),
          width: LuxColors.hardShadow ? LuxColors.strokeW : 1,
        ),
        boxShadow: LuxColors.hardShadow
            ? LuxColors.shadow()
            : [BoxShadow(color: Color(LuxColors.isDark ? 0x66000000 : 0x1A0F1720), blurRadius: 24, offset: const Offset(0, 10))],
      ),
      child: Row(
        children: [
          _tab(0),
          _tab(1),
          SizedBox(width: 74, child: Center(child: _AddButton(onTap: onAdd))),
          _tab(2),
          _tab(3),
        ],
      ),
    );
  }
}
