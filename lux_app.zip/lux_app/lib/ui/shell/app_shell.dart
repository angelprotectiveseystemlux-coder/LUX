import 'dart:async';
import 'package:flutter/material.dart';
import '../pages/appearance_page.dart';
import '../widgets/lux_kit.dart';
import '../pages/manage/quick_add.dart';
import '../../core/layout.dart';
import '../../core/palette.dart';
import '../../core/theme.dart';
import '../pages/analysis_page.dart';
import '../pages/attendance_page.dart';
import '../pages/manage/exam_ask.dart';
import '../pages/courses_page.dart';
import '../pages/exams_page.dart';
import '../pages/profile_page.dart';
import '../pages/today_page.dart';
import '../widgets/haptic.dart';

class _NavItem {
  final String label;
  final IconData icon;
  const _NavItem(this.label, this.icon);
}

class AppShell extends StatefulWidget {
  const AppShell({super.key});

  /// بعد از عوض‌شدنِ تم، برنامه از نو ساخته می‌شود؛ این‌ها تب و صفحه‌ی قبلی را برمی‌گردانند.
  static int pendingIndex = 0;
  static int currentIndex = 0; // تبِ بازِ فعلی (برای حفظِ تب بعد از تغییرِ خودکارِ شب و روز)
  static bool pendingAppearance = false;

  @override
  State<AppShell> createState() => _AppShellState();
}

class _AppShellState extends State<AppShell> with WidgetsBindingObserver {
  static const List<_NavItem> _items = [
    _NavItem('امروز', Icons.wb_twilight_rounded),
    _NavItem('درس‌ها', Icons.menu_book_rounded),
    _NavItem('برنامه', Icons.event_note_rounded),
    _NavItem('تحلیل', Icons.insights_rounded),
    _NavItem('پروفایل', Icons.person_rounded),
  ];

  Timer? _askTimer;
  int _i = 0;
  final Set<int> _visited = <int>{0};

  @override
  void initState() {
    super.initState();
    _i = 0;
    _visited.add(_i);
    AppShell.currentIndex = _i;
    WidgetsBinding.instance.addObserver(this);
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) {
        unawaited(_asks());
      }
    });
    _askTimer = Timer.periodic(const Duration(minutes: 1), (_) {
      // فقط وقتی کاربر روی صفحه‌ی اصلی است (وسطِ خواندنِ PDF و … مزاحم نمی‌شویم).
      if (mounted && (ModalRoute.of(context)?.isCurrent ?? true)) unawaited(ExamAskPrompt.maybeAsk(context));
    });
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed && mounted) {
      unawaited(_asks());
    }
  }

  /// پرسش‌های خودکار: حضور و غیاب، بعد «امتحان چطور بود؟»
  Future<void> _asks() async {
    await AttendancePrompt.maybeAsk(context);
    if (!mounted) return;
    await ExamAskPrompt.maybeAsk(context);
  }

  @override
  void dispose() {
    _askTimer?.cancel();
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  Widget _page(int i) {
    switch (i) {
      case 0:
        return const TodayPage();
      case 1:
        return const CoursesPage();
      case 2:
        return const ExamsPage();
      case 3:
        return const AnalysisPage();
      default:
        return const ProfilePage();
    }
  }

  void _select(int k) {
    if (k == _i) return;
    Haptic.tap();
    AppShell.currentIndex = k;
    setState(() {
      _i = k;
      _visited.add(k);
    });
  }

  Widget _fab(double end, double bottom) {
    return PositionedDirectional(
      end: end,
      bottom: bottom,
      child: GestureDetector(
        onTap: () {
          Haptic.light();
          showQuickAdd(context);
        },
        child: Container(
          width: 58,
          height: 58,
          decoration: BoxDecoration(
            color: LuxColors.accent,
            borderRadius: BorderRadius.circular(LuxColors.r(29)),
            border: LuxColors.hardShadow ? Border.all(color: LuxColors.stroke, width: LuxColors.strokeW) : null,
            boxShadow: LuxColors.hardShadow
                ? LuxColors.shadow()
                : [BoxShadow(color: LuxColors.alpha(LuxColors.accent, 0.35), blurRadius: 18, offset: const Offset(0, 6))],
          ),
          child: Icon(Icons.add_rounded, color: LuxColors.onAccent, size: 30),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final pad = MediaQuery.of(context).padding;
    final wide = LuxLayout.isWide(context);
    final pages = IndexedStack(
      index: _i,
      children: [
        for (var k = 0; k < _items.length; k++) _visited.contains(k) ? _page(k) : const SizedBox.shrink(),
      ],
    );

    if (wide) {
      // حالت افقی: نوار ناوبری عمودی در کنارِ صفحه، محتوا با عرضِ محدود و وسط‌چین.
      return Scaffold(
        body: Row(
          children: [
            _SideRail(items: _items, index: _i, onTap: _select),
            Expanded(
              child: Stack(
                children: [
                  Align(
                    alignment: Alignment.topCenter,
                    child: ConstrainedBox(
                      constraints: const BoxConstraints(maxWidth: LuxLayout.maxContentWidth),
                      child: pages,
                    ),
                  ),
                  if (_i == 0) _fab(24 + pad.left, 20 + pad.bottom),
                ],
              ),
            ),
          ],
        ),
      );
    }

    return Scaffold(
      extendBody: true,
      body: Stack(
        children: [
          pages,
          if (_i == 0) _fab(22, 14 + pad.bottom + 68 + 16),
          Positioned(
            left: 18,
            right: 18,
            bottom: 14 + pad.bottom,
            child: _NavBar(items: _items, index: _i, onTap: _select),
          ),
        ],
      ),
    );
  }
}

/// نوار ناوبریِ عمودی برای حالت افقی و صفحه‌های عریض.
class _SideRail extends StatelessWidget {
  final List<_NavItem> items;
  final int index;
  final ValueChanged<int> onTap;
  const _SideRail({required this.items, required this.index, required this.onTap});

  @override
  Widget build(BuildContext context) {
    final pad = MediaQuery.of(context).padding;
    return Container(
      width: LuxLayout.railWidth + pad.right,
      padding: EdgeInsets.fromLTRB(8, pad.top + 8, 8 + pad.right, pad.bottom + 8),
      decoration: BoxDecoration(
        color: LuxColors.cardHi,
        border: BorderDirectional(end: BorderSide(color: LuxColors.strokeColor, width: LuxColors.strokeW)),
      ),
      child: LayoutBuilder(builder: (context, cons) {
        return SingleChildScrollView(
          physics: const BouncingScrollPhysics(),
          child: ConstrainedBox(
            constraints: BoxConstraints(minHeight: cons.maxHeight),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                for (var k = 0; k < items.length; k++)
                  Padding(
                    padding: const EdgeInsets.symmetric(vertical: 3),
                    child: GestureDetector(
                      behavior: HitTestBehavior.opaque,
                      onTap: () => onTap(k),
                      child: AnimatedContainer(
                        duration: LuxMotion.medium,
                        curve: LuxMotion.curve,
                        width: double.infinity,
                        height: 58,
                        decoration: BoxDecoration(
                          color: k == index ? LuxColors.accent : Colors.transparent,
                          borderRadius: BorderRadius.circular(LuxColors.r(20)),
                        ),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Icon(items[k].icon, size: 23, color: k == index ? LuxColors.onAccent : LuxColors.silverDim),
                            const SizedBox(height: 2),
                            Text(
                              items[k].label,
                              maxLines: 1,
                              softWrap: false,
                              overflow: TextOverflow.clip,
                              style: LuxText.label.copyWith(
                                fontSize: 10.5,
                                color: k == index ? LuxColors.onAccent : LuxColors.silverDim,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
              ],
            ),
          ),
        );
      }),
    );
  }
}

class _NavBar extends StatelessWidget {
  final List<_NavItem> items;
  final int index;
  final ValueChanged<int> onTap;
  const _NavBar({required this.items, required this.index, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 68,
      padding: const EdgeInsets.all(8),
      decoration: BoxDecoration(
        color: LuxColors.cardHi,
        borderRadius: BorderRadius.circular(LuxColors.r(34)),
        border: Border.all(color: LuxColors.alpha(LuxColors.stroke, 0.9)),
      ),
      child: LayoutBuilder(builder: (context, cons) {
        final avail = cons.maxWidth;
        final activeW = avail * 0.34;
        final inactiveW = (avail - activeW) / (items.length - 1);
        return Row(
          children: [
            for (var k = 0; k < items.length; k++)
              GestureDetector(
                behavior: HitTestBehavior.opaque,
                onTap: () => onTap(k),
                child: AnimatedContainer(
                  duration: LuxMotion.medium,
                  curve: LuxMotion.curve,
                  width: k == index ? activeW : inactiveW,
                  height: 52,
                  clipBehavior: Clip.hardEdge,
                  decoration: BoxDecoration(
                    color: k == index ? LuxColors.accent : Colors.transparent,
                    borderRadius: BorderRadius.circular(LuxColors.r(26)),
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(items[k].icon,
                          size: 24, color: k == index ? LuxColors.onAccent : LuxColors.silverDim),
                      if (k == index) ...[
                        const SizedBox(width: 6),
                        Flexible(
                          child: Text(
                            items[k].label,
                            maxLines: 1,
                            softWrap: false,
                            overflow: TextOverflow.clip,
                            style: LuxText.label.copyWith(color: LuxColors.onAccent),
                          ),
                        ),
                      ],
                    ],
                  ),
                ),
              ),
          ],
        );
      }),
    );
  }
}
