import 'package:flutter/material.dart';
import '../pages/appearance_page.dart';
import '../widgets/lux_kit.dart';
import '../../core/palette.dart';
import '../../core/theme.dart';
import '../pages/analysis_page.dart';
import '../pages/courses_page.dart';
import '../pages/exams_page.dart';
import '../pages/profile_page.dart';
import '../pages/today_page.dart';
import '../widgets/haptic.dart';

class _NavItem {
  final String label;
  final IconData icon;
  const _NavItem(this.label, this.icon);
}

class AppShell extends StatefulWidget {
  const AppShell({super.key});

  /// بعد از عوض‌شدنِ تم، برنامه از نو ساخته می‌شود؛ این‌ها تب و صفحه‌ی قبلی را برمی‌گردانند.
  static int pendingIndex = 0;
  static bool pendingAppearance = false;

  @override
  State<AppShell> createState() => _AppShellState();
}

class _AppShellState extends State<AppShell> {
  static const List<_NavItem> _items = [
    _NavItem('امروز', Icons.wb_twilight_rounded),
    _NavItem('درس‌ها', Icons.menu_book_rounded),
    _NavItem('برنامه', Icons.event_note_rounded),
    _NavItem('تحلیل', Icons.insights_rounded),
    _NavItem('پروفایل', Icons.person_rounded),
  ];

  int _i = 0;
  final Set<int> _visited = <int>{0};

  @override
  void initState() {
    super.initState();
    _i = AppShell.pendingIndex.clamp(0, _items.length - 1);
    _visited.add(_i);
    final reopen = AppShell.pendingAppearance;
    AppShell.pendingIndex = 0;
    AppShell.pendingAppearance = false;
    if (reopen) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (mounted) pushPage<void>(context, const AppearancePage());
      });
    }
  }

  Widget _page(int i) {
    switch (i) {
      case 0:
        return const TodayPage();
      case 1:
        return const CoursesPage();
      case 2:
        return const ExamsPage();
      case 3:
        return const AnalysisPage();
      default:
        return const ProfilePage();
    }
  }

  @override
  Widget build(BuildContext context) {
    final pad = MediaQuery.of(context).padding;
    return Scaffold(
      extendBody: true,
      body: Stack(
        children: [
          IndexedStack(
            index: _i,
            children: [
              for (var k = 0; k < _items.length; k++) _visited.contains(k) ? _page(k) : const SizedBox.shrink(),
            ],
          ),
          Positioned(
            left: 18,
            right: 18,
            bottom: 14 + pad.bottom,
            child: _NavBar(
              items: _items,
              index: _i,
              onTap: (k) {
                if (k == _i) return;
                Haptic.tap();
                setState(() {
                  _i = k;
                  _visited.add(k);
                });
              },
            ),
          ),
        ],
      ),
    );
  }
}

class _NavBar extends StatelessWidget {
  final List<_NavItem> items;
  final int index;
  final ValueChanged<int> onTap;
  const _NavBar({required this.items, required this.index, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 68,
      padding: const EdgeInsets.all(8),
      decoration: BoxDecoration(
        color: LuxColors.cardHi,
        borderRadius: BorderRadius.circular(34),
        border: Border.all(color: LuxColors.alpha(LuxColors.stroke, 0.9)),
      ),
      child: LayoutBuilder(builder: (context, cons) {
        final avail = cons.maxWidth;
        final activeW = avail * 0.34;
        final inactiveW = (avail - activeW) / (items.length - 1);
        return Row(
          children: [
            for (var k = 0; k < items.length; k++)
              GestureDetector(
                behavior: HitTestBehavior.opaque,
                onTap: () => onTap(k),
                child: AnimatedContainer(
                  duration: LuxMotion.medium,
                  curve: LuxMotion.curve,
                  width: k == index ? activeW : inactiveW,
                  height: 52,
                  clipBehavior: Clip.hardEdge,
                  decoration: BoxDecoration(
                    color: k == index ? LuxColors.accent : Colors.transparent,
                    borderRadius: BorderRadius.circular(26),
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(items[k].icon,
                          size: 24, color: k == index ? LuxColors.onAccent : LuxColors.silverDim),
                      if (k == index) ...[
                        const SizedBox(width: 6),
                        Flexible(
                          child: Text(
                            items[k].label,
                            maxLines: 1,
                            softWrap: false,
                            overflow: TextOverflow.clip,
                            style: LuxText.label.copyWith(color: LuxColors.onAccent),
                          ),
                        ),
                      ],
                    ],
                  ),
                ),
              ),
          ],
        );
      }),
    );
  }
}
