import 'package:flutter/material.dart';
import 'package:shamsi_date/shamsi_date.dart';

import '../../core/app_bus.dart';
import '../../core/jalali_utils.dart';
import '../../core/palette.dart';
import '../../core/theme.dart';
import '../../core/util.dart';
import '../../data/database.dart';
import '../../data/study_repo.dart';
import '../charts/chart_base.dart';
import '../charts/cartesian.dart';
import '../charts/radial.dart';
import '../widgets/day_picker.dart';
import '../widgets/lux_button.dart';
import '../widgets/lux_card.dart';
import '../widgets/lux_chip.dart';
import '../widgets/lux_kit.dart';
import '../widgets/lux_section.dart';
import 'manage/editors.dart';

class _Rec {
  final DateTime day;
  final int minutes;
  final int? courseId;
  final int? quality;
  const _Rec(this.day, this.minutes, this.courseId, this.quality);
}

String fmtMinutes(int m) {
  if (m <= 0) return '۰ دقیقه';
  final h = m ~/ 60;
  final r = m % 60;
  if (h == 0) return '${faDigits(r)} دقیقه';
  if (r == 0) return '${faDigits(h)} ساعت';
  return '${faDigits(h)} ساعت و ${faDigits(r)} دقیقه';
}

class StudyStatsPage extends StatefulWidget {
  const StudyStatsPage({super.key});

  @override
  State<StudyStatsPage> createState() => _StudyStatsPageState();
}

class _StudyStatsPageState extends State<StudyStatsPage> {
  static const List<int> _goals = <int>[60, 90, 120, 180, 240];

  List<_Rec> _recs = <_Rec>[];
  Map<int, String> _courseNames = <int, String>{};
  int _goal = 120;
  bool _loaded = false;

  @override
  void initState() {
    super.initState();
    _load();
    AppBus.data.addListener(_load);
  }

  @override
  void dispose() {
    AppBus.data.removeListener(_load);
    super.dispose();
  }

  Future<void> _load() async {
    final db = LuxDb.instance;
    final recs = <_Rec>[];

    final ss = await db.rawQuery(
      'SELECT start_ts, end_ts, course_id, quality FROM study_sessions WHERE completed = 1 AND end_ts IS NOT NULL',
    );
    for (final r in ss) {
      final m = ((asInt(r['end_ts']) - asInt(r['start_ts'])) / 60000).round();
      if (m <= 0) continue;
      recs.add(_Rec(dateOnly(fromTs(r['start_ts'])), m, r['course_id'] == null ? null : asInt(r['course_id']), r['quality'] == null ? null : asInt(r['quality'])));
    }
    final rs = await db.rawQuery(
      'SELECT rs.start_ts, rs.end_ts, b.course_id FROM reading_sessions rs JOIN books b ON b.id = rs.book_id',
    );
    for (final r in rs) {
      final m = ((asInt(r['end_ts']) - asInt(r['start_ts'])) / 60000).round();
      if (m <= 0) continue;
      recs.add(_Rec(dateOnly(fromTs(r['start_ts'])), m, r['course_id'] == null ? null : asInt(r['course_id']), null));
    }

    final names = <int, String>{};
    for (final c in await StudyRepo.courses()) {
      names[asInt(c['id'])] = asStr(c['name']);
    }
    final goal = int.tryParse(await db.kvGet('study_goal_min') ?? '') ?? 120;
    if (!mounted) return;
    setState(() {
      _recs = recs;
      _courseNames = names;
      _goal = goal;
      _loaded = true;
    });
  }

  int _sum(bool Function(_Rec) test) {
    var s = 0;
    for (final r in _recs) {
      if (test(r)) s += r.minutes;
    }
    return s;
  }

  Future<void> _manualLog() async {
    int? cid;
    var date = dateOnly(DateTime.now());
    final minutes = TextEditingController(text: '30');
    await showLuxSheet<void>(
      context,
      (ctx) => StatefulBuilder(builder: (ctx, setS) {
        return Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Text('ثبتِ دستیِ مطالعه', style: LuxText.title),
            const SizedBox(height: 16),
            LuxCourseChips(label: 'درس', selectedId: cid, allowNone: true, onChanged: (id) => setS(() => cid = id)),
            LuxField(label: 'چند دقیقه؟', controller: minutes, keyboard: TextInputType.number),
            LuxPickField(
              label: 'تاریخ',
              value: '${jalaliLabelWithDay(date)} ${faDigits(Jalali.fromDateTime(date).year)}',
              icon: Icons.calendar_month_rounded,
              onTap: () async {
                final r = await pickJalaliDay(ctx, initial: date);
                if (r != null) setS(() => date = r);
              },
            ),
            LuxButton(
              label: 'ذخیره',
              onPressed: () async {
                final m = (parseNum(minutes.text) ?? 0).round();
                if (m <= 0 || m > 960) {
                  luxNotice(ctx, 'مدت رو بین ۱ تا ۹۶۰ دقیقه بنویس.');
                  return;
                }
                final end = DateTime(date.year, date.month, date.day, 20);
                final start = end.subtract(Duration(minutes: m));
                await LuxDb.instance.insert('study_sessions', <String, Object?>{
                  'course_id': cid,
                  'start_ts': start.millisecondsSinceEpoch,
                  'end_ts': end.millisecondsSinceEpoch,
                  'kind': 'manual',
                  'planned_min': m,
                  'completed': 1,
                });
                AppBus.bump();
                if (ctx.mounted) Navigator.of(ctx).pop();
              },
            ),
          ],
        );
      }),
    );
  }

  @override
  Widget build(BuildContext context) {
    final today = dateOnly(DateTime.now());
    final weekStart = DateTime(today.year, today.month, today.day - weekdayIndex(today));
    final jt = Jalali.fromDateTime(today);
    final monthStart = dateOnly(Jalali(jt.year, jt.month, 1).toDateTime());

    final todayMin = _sum((r) => r.day == today);
    final weekMin = _sum((r) => !r.day.isBefore(weekStart));
    final monthMin = _sum((r) => !r.day.isBefore(monthStart));
    final totalMin = _sum((r) => true);

    // ۱۴ روز اخیر
    final perDay = <DateTime, int>{};
    for (final r in _recs) {
      perDay[r.day] = (perDay[r.day] ?? 0) + r.minutes;
    }
    final last14 = <ChartPoint>[];
    for (var i = 13; i >= 0; i--) {
      final d = DateTime(today.year, today.month, today.day - i);
      last14.add(ChartPoint(faDigits(Jalali.fromDateTime(d).day), (perDay[d] ?? 0) / 60.0));
    }

    // میانگینِ روزهای فعال در ۳۰ روز اخیر
    var active = 0;
    var sum30 = 0;
    for (var i = 0; i < 30; i++) {
      final m = perDay[DateTime(today.year, today.month, today.day - i)] ?? 0;
      if (m > 0) {
        active++;
        sum30 += m;
      }
    }
    final avg = active == 0 ? 0 : (sum30 / active).round();

    // رکورد و زنجیره
    var bestDay = 0;
    DateTime? bestAt;
    perDay.forEach((d, m) {
      if (m > bestDay) {
        bestDay = m;
        bestAt = d;
      }
    });
    var streak = 0;
    var cursor = today;
    if ((perDay[cursor] ?? 0) == 0) cursor = DateTime(today.year, today.month, today.day - 1);
    while ((perDay[cursor] ?? 0) > 0) {
      streak++;
      cursor = DateTime(cursor.year, cursor.month, cursor.day - 1);
    }

    // به‌تفکیکِ درس (۳۰ روز اخیر)
    final since = DateTime(today.year, today.month, today.day - 29);
    final perCourse = <int, int>{};
    var noCourse = 0;
    for (final r in _recs) {
      if (r.day.isBefore(since)) continue;
      if (r.courseId == null) {
        noCourse += r.minutes;
      } else {
        perCourse[r.courseId!] = (perCourse[r.courseId!] ?? 0) + r.minutes;
      }
    }
    final courseRows = perCourse.entries.toList()..sort((a, b) => b.value.compareTo(a.value));
    final maxCourse = courseRows.isEmpty ? 1 : courseRows.first.value;

    // کیفیتِ تمرکز
    var qSum = 0;
    var qN = 0;
    for (final r in _recs) {
      if (r.quality != null) {
        qSum += r.quality!;
        qN++;
      }
    }

    final goalProgress = _goal == 0 ? 0.0 : (todayMin / _goal).clamp(0.0, 1.0);

    return LuxSubPage(
      title: 'آمار مطالعه',
      subtitle: _loaded && totalMin == 0 ? 'پومودورو بزن یا PDF بخون تا اینجا پر بشه' : 'جمعِ تایمر، پومودورو و خواندنِ PDF',
      action: LuxAddButton(onTap: _manualLog),
      children: [
        LuxCard(
          radius: 28,
          child: Row(
            children: [
              RingProgress(
                value: goalProgress,
                size: 110,
                stroke: 10,
                color: goalProgress >= 1 ? LuxColors.ok : LuxColors.accent,
                child: Text('${faDigits((goalProgress * 100).round())}٪', style: LuxText.heading),
              ),
              const SizedBox(width: 18),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('هدفِ امروز', style: LuxText.caption),
                    Text(fmtMinutes(todayMin), style: LuxText.title),
                    Text('از ${fmtMinutes(_goal)}', style: LuxText.caption),
                    if (streak > 0) ...[
                      const SizedBox(height: 6),
                      Text('🔥 ${faDigits(streak)} روزِ پشت‌سرهم', style: LuxText.label.copyWith(color: LuxColors.accent)),
                    ],
                  ],
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 12),
        Row(
          children: [
            Expanded(child: _tile('این هفته', fmtMinutes(weekMin))),
            const SizedBox(width: 10),
            Expanded(child: _tile('این ماه', fmtMinutes(monthMin))),
          ],
        ),
        const SizedBox(height: 10),
        Row(
          children: [
            Expanded(child: _tile('میانگینِ روزهای فعال', fmtMinutes(avg))),
            const SizedBox(width: 10),
            Expanded(child: _tile('کل', fmtMinutes(totalMin))),
          ],
        ),
        const SizedBox(height: 16),
        LuxCard(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Text('۱۴ روزِ اخیر (ساعت)', style: LuxText.heading),
              const SizedBox(height: 10),
              ColumnChart(data: last14, height: 190, fmt: (v) => v == 0 ? '۰' : faDigits(double.parse(v.toStringAsFixed(1)))),
            ],
          ),
        ),
        const SizedBox(height: 16),
        LuxSection(title: 'به‌تفکیکِ درس (۳۰ روز اخیر)', children: [
          if (courseRows.isEmpty && noCourse == 0) const LuxEmpty(icon: Icons.bar_chart_rounded, title: 'هنوز داده‌ای نیست'),
          for (final e in courseRows) _courseBar(_courseNames[e.key] ?? 'درس', e.value, maxCourse),
          if (noCourse > 0) _courseBar('بدون درس', noCourse, maxCourse),
        ]),
        const SizedBox(height: 16),
        LuxCard(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Text('رکورد و تمرکز', style: LuxText.heading),
              const SizedBox(height: 10),
              Text(
                bestAt == null
                    ? 'هنوز رکوردی ثبت نشده.'
                    : 'بهترین روز: ${fmtMinutes(bestDay)} (${jalaliLabelWithDay(bestAt!)})',
                style: LuxText.body,
              ),
              const SizedBox(height: 6),
              Text(
                qN == 0 ? 'کیفیتِ تمرکز: بعد از هر پومودورو ازت می‌پرسم.' : 'میانگینِ کیفیتِ تمرکز: ${faDigits((qSum / qN).toStringAsFixed(1))} از ۵',
                style: LuxText.body,
              ),
            ],
          ),
        ),
        const SizedBox(height: 16),
        LuxChoice(
          label: 'هدفِ روزانه',
          options: [for (final g in _goals) fmtMinutes(g)],
          selected: _goals.indexOf(_goal) < 0 ? 2 : _goals.indexOf(_goal),
          onChanged: (i) async {
            await LuxDb.instance.kvSet('study_goal_min', _goals[i].toString());
            setState(() => _goal = _goals[i]);
          },
        ),
      ],
    );
  }

  Widget _tile(String label, String value) => LuxCard(
        radius: 22,
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(label, style: LuxText.caption),
            const SizedBox(height: 4),
            Text(value, style: LuxText.heading),
          ],
        ),
      );

  Widget _courseBar(String name, int minutes, int maxM) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 8),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Row(children: [
              Expanded(child: Text(name, style: LuxText.body)),
              Text(fmtMinutes(minutes), style: LuxText.caption),
            ]),
            const SizedBox(height: 6),
            ClipRRect(
              borderRadius: BorderRadius.circular(6),
              child: LinearProgressIndicator(
                value: maxM == 0 ? 0 : minutes / maxM,
                minHeight: 7,
                backgroundColor: LuxColors.cardHi,
                valueColor: AlwaysStoppedAnimation<Color>(LuxColors.accent),
              ),
            ),
          ],
        ),
      );
}
