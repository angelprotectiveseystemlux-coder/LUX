import 'package:flutter/material.dart';

import '../../../core/app_bus.dart';
import '../../../core/jalali_utils.dart';
import '../../../core/palette.dart';
import '../../../core/theme.dart';
import '../../../core/util.dart';
import '../../../data/cards_repo.dart';
import '../../widgets/haptic.dart';
import '../../widgets/lux_button.dart';
import '../../widgets/lux_card.dart';
import '../../widgets/lux_chip.dart';
import '../../widgets/lux_kit.dart';
import '../../widgets/lux_section.dart';
import '../manage/editors.dart';

/// فلش‌کارت‌ها: از هایلایت‌های کتاب یا دستی؛ مرورِ فاصله‌دار (SM-2).
class CardsPage extends StatefulWidget {
  const CardsPage({super.key});

  @override
  State<CardsPage> createState() => _CardsPageState();
}

class _CardsPageState extends State<CardsPage> {
  List<Map<String, Object?>> _due = <Map<String, Object?>>[];
  List<Map<String, Object?>> _all = <Map<String, Object?>>[];
  int _idx = 0;
  bool _show = false;
  bool _loading = true;
  int _tab = 0; // ۰ مرور، ۱ همه
  int _reviewed = 0;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final due = await CardsRepo.due();
    final all = await CardsRepo.all();
    if (!mounted) return;
    setState(() {
      _due = due;
      _all = all;
      _idx = 0;
      _show = false;
      _loading = false;
    });
  }

  Future<void> _rate(int q) async {
    Haptic.tap();
    final c = _due[_idx];
    await CardsRepo.review(c, q);
    _reviewed++;
    AppBus.bump();
    if (_idx + 1 >= _due.length) {
      await _load();
    } else {
      setState(() {
        _idx++;
        _show = false;
      });
    }
  }

  Future<void> _edit({Map<String, Object?>? card}) async {
    final f = TextEditingController(text: asStr(card?['front']));
    final b = TextEditingController(text: asStr(card?['back']));
    int? courseId = card?['course_id'] == null ? null : asInt(card!['course_id']);
    String courseName = courseId == null ? '' : await courseNameOf(courseId);
    if (!mounted) return;
    await showLuxSheet<void>(
      context,
      (ctx) => StatefulBuilder(builder: (ctx, setS) {
        return Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Text(card == null ? 'کارتِ تازه' : 'ویرایشِ کارت', style: LuxText.title),
            const SizedBox(height: 14),
            LuxField(label: 'روی کارت (سؤال یا مفهوم)', controller: f, maxLines: 4),
            LuxField(label: 'پشتِ کارت (پاسخ)', controller: b, maxLines: 4, hint: 'اختیاری؛ می‌توانی خودت پاسخ را بگویی'),
            LuxPickField(
              label: 'درس',
              value: courseName.isEmpty ? 'بدون درس' : courseName,
              placeholder: courseName.isEmpty,
              onTap: () async {
                final r = await pickCourse(ctx, selectedId: courseId, allowNone: true);
                if (r == null) return;
                courseId = r < 0 ? null : r;
                courseName = r < 0 ? '' : await courseNameOf(r);
                setS(() {});
              },
            ),
            LuxButton(
              label: 'ذخیره',
              onPressed: () async {
                if (f.text.trim().isEmpty) {
                  luxNotice(ctx, 'روی کارت را بنویس.');
                  return;
                }
                if (card == null) {
                  await CardsRepo.add(front: f.text.trim(), back: b.text.trim(), courseId: courseId);
                } else {
                  await CardsRepo.update(asInt(card['id']), front: f.text.trim(), back: b.text.trim());
                }
                AppBus.bump();
                if (ctx.mounted) Navigator.of(ctx).pop();
              },
            ),
            if (card != null) ...[
              const SizedBox(height: 8),
              LuxButton(
                label: 'حذفِ کارت',
                filled: false,
                onPressed: () async {
                  await CardsRepo.delete(asInt(card['id']));
                  AppBus.bump();
                  if (ctx.mounted) Navigator.of(ctx).pop();
                },
              ),
            ],
          ],
        );
      }),
    );
    f.dispose();
    b.dispose();
    _load();
  }

  Widget _review() {
    if (_loading) return const Padding(padding: EdgeInsets.all(40), child: Center(child: CircularProgressIndicator()));
    if (_due.isEmpty) {
      return LuxCard(
        child: LuxEmpty(
          icon: Icons.celebration_rounded,
          title: _reviewed > 0 ? 'همه‌ی کارت‌های امروز را مرور کردی' : 'کارتی برای مرورِ امروز نیست',
          hint: _all.isEmpty ? 'در PDF ریدر روی متنِ انتخاب‌شده «فلش‌کارت» را بزن، یا با دکمه‌ی پایین یکی بساز.' : 'کارت‌ها در زمانِ مناسبِ مرورشان دوباره می‌آیند.',
        ),
      );
    }
    final c = _due[_idx];
    final back = asStr(c['back']);
    return Column(
      children: [
        Row(
          children: [
            Text('${faDigits(_idx + 1)} از ${faDigits(_due.length)}', style: LuxText.caption),
            const Spacer(),
            if (asStr(c['course_name']).isNotEmpty) Text(asStr(c['course_name']), style: LuxText.caption),
          ],
        ),
        const SizedBox(height: 10),
        LuxCard(
          radius: 30,
          padding: const EdgeInsets.all(22),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Text(asStr(c['front']), style: LuxText.heading.copyWith(height: 1.7)),
              if (_show) ...[
                const Divider(height: 28),
                Text(back.isEmpty ? 'پاسخ را در ذهنت (یا بلند) بگو، بعد خودت امتیاز بده.' : back, style: LuxText.body.copyWith(height: 1.7)),
              ],
            ],
          ),
        ),
        const SizedBox(height: 14),
        if (!_show)
          LuxButton(label: 'نشان بده', onPressed: () => setState(() => _show = true))
        else
          Row(
            children: [
              Expanded(child: LuxButton(label: 'یادم نبود', filled: false, compact: true, onPressed: () => _rate(1))),
              const SizedBox(width: 6),
              Expanded(child: LuxButton(label: 'سخت بود', filled: false, compact: true, onPressed: () => _rate(3))),
              const SizedBox(width: 6),
              Expanded(child: LuxButton(label: 'خوب بود', compact: true, onPressed: () => _rate(4))),
              const SizedBox(width: 6),
              Expanded(child: LuxButton(label: 'آسان', compact: true, onPressed: () => _rate(5))),
            ],
          ),
      ],
    );
  }

  Widget _list() {
    if (_all.isEmpty) return const LuxCard(child: LuxEmpty(icon: Icons.style_rounded, title: 'هنوز کارتی نداری', hint: 'از هایلایت‌های کتاب یا دستی کارت بساز.'));
    return Column(
      children: [
        for (final c in _all)
          Padding(
            padding: const EdgeInsets.only(bottom: 8),
            child: LuxCard(
              child: GestureDetector(
                behavior: HitTestBehavior.opaque,
                onTap: () => _edit(card: c),
                child: Row(
                  children: [
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(asStr(c['front']), maxLines: 2, overflow: TextOverflow.ellipsis, style: LuxText.body),
                          const SizedBox(height: 3),
                          Text('${asStr(c['course_name']).isEmpty ? 'بدون درس' : asStr(c['course_name'])} · ${faDigits(asInt(c['reps']))} مرور', style: LuxText.caption),
                        ],
                      ),
                    ),
                    Icon(Icons.edit_rounded, color: LuxColors.silverDim, size: 18),
                  ],
                ),
              ),
            ),
          ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return LuxSubPage(
      title: 'فلش‌کارت',
      subtitle: _loading ? null : '${faDigits(_due.length)} کارت برای مرورِ امروز · ${faDigits(_all.length)} کارت',
      children: [
        Wrap(spacing: 8, runSpacing: 8, children: [
          LuxChip(label: 'مرور', selected: _tab == 0, onTap: () => setState(() => _tab = 0)),
          LuxChip(label: 'همه‌ی کارت‌ها', selected: _tab == 1, onTap: () => setState(() => _tab = 1)),
        ]),
        const SizedBox(height: 14),
        if (_tab == 0) _review() else _list(),
        const SizedBox(height: 14),
        LuxButton(label: 'کارتِ تازه', icon: Icons.add_rounded, filled: false, onPressed: () => _edit()),
      ],
    );
  }
}
