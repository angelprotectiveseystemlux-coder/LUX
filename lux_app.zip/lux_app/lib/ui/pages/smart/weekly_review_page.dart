import 'package:flutter/material.dart';

import '../../../core/jalali_utils.dart';
import '../../../core/palette.dart';
import '../../../core/theme.dart';
import '../../../core/util.dart';
import '../../../data/database.dart';
import '../../../data/smart_repo.dart';
import '../../../engine/smart/estimators.dart';
import '../../../engine/smart/models.dart';
import '../../widgets/lux_card.dart';
import '../../widgets/lux_chip.dart';
import '../../widgets/lux_kit.dart';

/// مرورِ هفته: کار کرد / نکرد، هدفِ هفتگی، زنجیره‌ی روزها و پیشنهادِ هفته‌ی بعد.
class WeeklyReviewPage extends StatefulWidget {
  const WeeklyReviewPage({super.key});

  @override
  State<WeeklyReviewPage> createState() => _WeeklyReviewPageState();
}

class _WeeklyReviewPageState extends State<WeeklyReviewPage> {
  SSnapshot? _s;
  int _goalMin = 600;
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final s = await SmartRepo.snapshot();
    final g = int.tryParse(await LuxDb.instance.kvGet('smart_week_goal') ?? '');
    if (!mounted) return;
    setState(() {
      _s = s;
      _goalMin = g ?? 600;
      _loading = false;
    });
  }

  Map<int, double> _perDay(SSnapshot s) {
    final out = <int, double>{};
    for (final x in s.sessions) {
      final k = dayKey(x.start);
      out[k] = (out[k] ?? 0) + x.minutes;
    }
    return out;
  }

  /// روزهای پیاپیِ مطالعه (≥ ۲۰ دقیقه)؛ در هر هفته یک روزِ آزاد زنجیره را نمی‌شکند.
  int _streak(SSnapshot s) {
    final per = _perDay(s);
    final today = dateOnly0(s.now);
    var d = today;
    var streak = 0;
    var sinceGap = 99;
    if ((per[dayKey(d)] ?? 0) < 20) d = d.subtract(const Duration(days: 1));
    for (var i = 0; i < 120; i++) {
      final m = per[dayKey(d)] ?? 0;
      if (m >= 20) {
        streak++;
        sinceGap++;
      } else {
        if (sinceGap >= 6) {
          sinceGap = 0;
        } else {
          break;
        }
      }
      d = d.subtract(const Duration(days: 1));
    }
    return streak;
  }

  Widget _bar(String label, double v, double max, Color c) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 4),
        child: Row(
          children: [
            SizedBox(width: 96, child: Text(label, style: LuxText.caption, maxLines: 1, overflow: TextOverflow.ellipsis)),
            Expanded(
              child: ClipRRect(
                borderRadius: BorderRadius.circular(LuxColors.r(6)),
                child: SizedBox(height: 10, child: LinearProgressIndicator(value: max <= 0 ? 0 : (v / max).clamp(0.0, 1.0).toDouble(), color: c, backgroundColor: LuxColors.cardHi)),
              ),
            ),
            const SizedBox(width: 8),
            SizedBox(width: 52, child: Text('${faDigits((v / 60).toStringAsFixed(1))}س', style: LuxText.caption)),
          ],
        ),
      );

  @override
  Widget build(BuildContext context) {
    final s = _s;
    if (_loading || s == null) {
      return const LuxSubPage(title: 'مرورِ هفته', children: [Padding(padding: EdgeInsets.all(40), child: Center(child: CircularProgressIndicator()))]);
    }
    final now = s.now;
    final from = now.subtract(const Duration(days: 7));
    final prevFrom = now.subtract(const Duration(days: 14));
    final totalMin = Estimators.minutesBetween(s, from, now);
    final prevMin = Estimators.minutesBetween(s, prevFrom, from);
    final q = Estimators.avgQuality(s, from, now);
    final qPrev = Estimators.avgQuality(s, prevFrom, from);
    final byCourse = <int, double>{};
    for (final x in s.sessions) {
      if (x.courseId == null || !x.end.isAfter(from)) continue;
      byCourse[x.courseId!] = (byCourse[x.courseId!] ?? 0) + x.minutes;
    }
    final blocks = [for (final b in s.history) if (b.kind != 'micro' && !dayFromKey(b.day).isBefore(dateOnly0(from))) b];
    final bDone = blocks.where((b) => b.status == 'done').length;
    final bSkip = blocks.where((b) => b.status == 'skipped').length;
    final completion = bDone + bSkip == 0 ? null : bDone / (bDone + bSkip);
    final hs = Estimators.hourScores(s);
    final best = Estimators.bestHour(hs);
    final streak = _streak(s);
    final progress = _goalMin <= 0 ? 0.0 : (totalMin / _goalMin).clamp(0.0, 1.0).toDouble();
    final maxCourse = byCourse.values.fold<double>(0, (a, b) => a > b ? a : b);

    final insights = <String>[];
    if (completion != null) {
      if (completion < 0.55) {
        insights.add('فقط ${faDigits((completion * 100).round())}٪ از بلوک‌های برنامه انجام شد. برنامه‌ی هفته‌ی بعد را سبک‌تر می‌چینم تا واقع‌بینانه باشد؛ ظرفیتِ تو بیشتر از برنامه نیست، برنامه از ظرفیتت بیشتر بود.');
      } else if (completion >= 0.8) {
        insights.add('${faDigits((completion * 100).round())}٪ از برنامه را انجام دادی؛ عالی. می‌شود هفته‌ی بعد کمی بلندپروازانه‌تر بود.');
      }
    }
    if (prevMin > 60) {
      final ch = (totalMin - prevMin) / prevMin;
      if (ch > 0.25) insights.add('مطالعه‌ات نسبت به هفته‌ی قبل ${faDigits((ch * 100).round())}٪ بیشتر شد.');
      if (ch < -0.25) insights.add('مطالعه‌ات نسبت به هفته‌ی قبل ${faDigits((-ch * 100).round())}٪ کمتر شد. اگر دلیلش خستگی یا شلوغی بود طبیعی است؛ مهم این است که زنجیره نشکند.');
    }
    if (!q.isNaN && !qPrev.isNaN) {
      if (q > qPrev + 0.3) insights.add('کیفیتِ تمرکزت بالاتر رفت (${faDigits(q.toStringAsFixed(1))} از ۵).');
      if (q < qPrev - 0.3) insights.add('کیفیتِ تمرکزت پایین‌تر آمد؛ استراحت و خواب را جدی بگیر.');
    }
    final upcoming = [for (final e in s.exams) if (e.status == 'planned' && e.at.isAfter(now) && e.at.difference(now).inDays <= 14) e];
    for (final e in upcoming) {
      final m = byCourse[e.courseId] ?? 0;
      if (m < 30) {
        final c = s.course(e.courseId);
        insights.add('برای ${c?.name ?? 'یک درس'} که ${faDigits(e.at.difference(now).inDays)} روز دیگر امتحان دارد، این هفته کمتر از نیم ساعت خواندی؛ اولویتِ هفته‌ی بعد.');
      }
    }
    if (insights.isEmpty) insights.add('داده‌ی کافی برای تحلیل نیست؛ چند روز که مطالعه ثبت شود، این بخش پُر می‌شود.');

    return LuxSubPage(
      title: 'مرورِ هفته',
      subtitle: '۷ روزِ گذشته',
      children: [
        LuxCard(
          radius: 28,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Expanded(child: Text('هدفِ هفتگی', style: LuxText.heading)),
                  Text('${faDigits((totalMin / 60).toStringAsFixed(1))} از ${faDigits((_goalMin / 60).toStringAsFixed(0))} ساعت', style: LuxText.label.copyWith(color: LuxColors.accent)),
                ],
              ),
              const SizedBox(height: 10),
              ClipRRect(
                borderRadius: BorderRadius.circular(LuxColors.r(8)),
                child: SizedBox(height: 10, child: LinearProgressIndicator(value: progress, color: progress >= 1 ? LuxColors.ok : LuxColors.accent, backgroundColor: LuxColors.cardHi)),
              ),
              const SizedBox(height: 12),
              Wrap(spacing: 8, runSpacing: 8, children: [
                for (final h in const [5, 8, 10, 12, 15, 20])
                  LuxChip(
                    label: '${faDigits(h)} ساعت',
                    selected: _goalMin == h * 60,
                    onTap: () async {
                      setState(() => _goalMin = h * 60);
                      await LuxDb.instance.kvSet('smart_week_goal', '${h * 60}');
                    },
                  ),
              ]),
            ],
          ),
        ),
        const SizedBox(height: 12),
        Row(
          children: [
            Expanded(child: _stat('زنجیره‌ی روزها', '${faDigits(streak)} روز', 'هر هفته یک روزِ آزاد دارد', Icons.local_fire_department_rounded)),
            const SizedBox(width: 10),
            Expanded(child: _stat('اجرای برنامه', completion == null ? '—' : '${faDigits((completion * 100).round())}٪', '${faDigits(bDone)} از ${faDigits(bDone + bSkip)} بلوک', Icons.checklist_rounded)),
          ],
        ),
        const SizedBox(height: 10),
        Row(
          children: [
            Expanded(child: _stat('ساعتِ اوج', 'حدود ${faDigits(best)}', 'بهترین تمرکزِ تو', Icons.wb_sunny_rounded)),
            const SizedBox(width: 10),
            Expanded(child: _stat('کیفیتِ تمرکز', q.isNaN ? '—' : '${faDigits(q.toStringAsFixed(1))}/۵', 'میانگینِ این هفته', Icons.psychology_rounded)),
          ],
        ),
        const SizedBox(height: 14),
        if (byCourse.isNotEmpty)
          LuxCard(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('سهمِ هر درس', style: LuxText.heading),
                const SizedBox(height: 8),
                for (final e in ([...byCourse.entries]..sort((a, b) => b.value.compareTo(a.value))))
                  _bar(s.course(e.key)?.name ?? '', e.value, maxCourse, courseColor(s.course(e.key)?.colorValue)),
              ],
            ),
          ),
        const SizedBox(height: 14),
        LuxCard(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('چه کار کرد و چه نه؟', style: LuxText.heading),
              const SizedBox(height: 8),
              for (final t in insights)
                Padding(
                  padding: const EdgeInsets.symmetric(vertical: 5),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Icon(Icons.chevron_left_rounded, size: 20, color: LuxColors.accent),
                      const SizedBox(width: 4),
                      Expanded(child: Text(t, style: LuxText.body.copyWith(height: 1.6))),
                    ],
                  ),
                ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _stat(String t, String v, String sub, IconData icon) => LuxCard(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Icon(icon, color: LuxColors.accent),
            const SizedBox(height: 8),
            Text(v, style: LuxText.heading),
            Text(t, style: LuxText.label),
            Text(sub, style: LuxText.caption),
          ],
        ),
      );
}
