import 'dart:async';

import 'package:flutter/material.dart';

import '../../../core/app_bus.dart';
import '../../../core/jalali_utils.dart';
import '../../../core/palette.dart';
import '../../../core/theme.dart';
import '../../../core/util.dart';
import '../../../data/smart_repo.dart';
import '../../../engine/smart/estimators.dart';
import '../../../engine/smart/models.dart';
import '../../../engine/smart/simulator.dart';
import '../../widgets/haptic.dart';
import '../../widgets/lux_button.dart';
import '../../widgets/lux_card.dart';
import '../../widgets/lux_chip.dart';
import '../../widgets/lux_kit.dart';
import '../../widgets/lux_section.dart';
import '../manage/pomodoro_page.dart';
import '../manage/review_pages.dart';
import 'cards_page.dart';
import 'mock_exam_page.dart';
import 'quick_log_sheet.dart';
import 'smart_settings_sheet.dart';
import 'weakness_page.dart';
import 'weekly_review_page.dart';

String _hm(int m) => faDigits('${two(m ~/ 60)}:${two(m % 60)}');

const Map<String, String> _kindName = <String, String>{
  'learn': 'یادگیری',
  'practice': 'تمرین',
  'mock': 'امتحان آزمایشی',
  'light': 'مرور سبک',
  'review': 'مرور',
  'task': 'تکلیف',
  'micro': 'مرور فوری',
  'cards': 'فلش‌کارت',
};

const Map<String, IconData> _kindIcon = <String, IconData>{
  'learn': Icons.menu_book_rounded,
  'practice': Icons.edit_note_rounded,
  'mock': Icons.timer_rounded,
  'light': Icons.spa_rounded,
  'review': Icons.replay_rounded,
  'task': Icons.task_alt_rounded,
  'micro': Icons.bolt_rounded,
  'cards': Icons.style_rounded,
};

/// برنامه‌ی هوشمند: روزانه و هفتگی، با دلیلِ هر بلوک، پیش‌بینیِ ترم و هشدارهای واقع‌بینانه.
class SmartPlanPage extends StatefulWidget {
  const SmartPlanPage({super.key});

  @override
  State<SmartPlanPage> createState() => _SmartPlanPageState();
}

class _SmartPlanPageState extends State<SmartPlanPage> with WidgetsBindingObserver {
  SmartBundle? _b;
  String? _error;
  bool _busy = true;
  int _day = 0; // شاخصِ روز نسبت به امروز
  final Set<int> _open = <int>{};
  Timer? _tick;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    AppBus.data.addListener(_onData);
    _load();
    _tick = Timer.periodic(const Duration(minutes: 1), (_) {
      if (mounted) setState(() {});
    });
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    AppBus.data.removeListener(_onData);
    _tick?.cancel();
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) _load(quiet: true);
  }

  void _onData() => _load(quiet: true);

  Future<void> _load({bool regenerate = false, bool quiet = false}) async {
    if (!quiet) setState(() => _busy = true);
    try {
      final b = await SmartRepo.load(regenerate: regenerate);
      if (!mounted) return;
      setState(() {
        _b = b;
        _error = null;
        _busy = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _error = 'ساختنِ برنامه ناموفق بود: $e';
        _busy = false;
      });
    }
  }

  DateTime get _today => dateOnly(DateTime.now());

  DateTime _dateOf(int i) => DateTime(_today.year, _today.month, _today.day + i);

  Color _colorOf(SBlock b) {
    final c = _b?.snapshot.course(b.courseId);
    return courseColor(c?.colorValue);
  }

  String _courseName(int? id) => _b?.snapshot.course(id)?.name ?? '';

  // ───────── کنش‌ها ─────────

  Future<void> _start(SBlock b, {int? minutes}) async {
    Haptic.light();
    await SmartRepo.markStarted(b.id);
    if (!mounted) return;
    switch (b.kind) {
      case 'mock':
        await pushPage<void>(context, MockExamPage(courseId: b.courseId, examId: b.refId, minutes: b.durMin));
        break;
      case 'review':
        await pushPage<void>(context, const ReviewPage());
        break;
      case 'micro':
      case 'cards':
        await pushPage<void>(context, const CardsPage());
        break;
      case 'task':
        await SmartRepo.markDone(b.id);
        if (mounted) luxToast(context, 'ثبت شد. دستت درد نکند!');
        break;
      default:
        await pushPage<void>(context, PomodoroPage(courseId: b.courseId, minutes: minutes ?? b.durMin, autoStart: true));
    }
    if (mounted) _load(quiet: true);
  }

  Future<void> _menu(SBlock b) async {
    await showLuxSheet<void>(
      context,
      (ctx) => Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Text(b.title, style: LuxText.title),
          const SizedBox(height: 10),
          if (b.status == 'planned') ...[
            LuxRow(
              leading: Icon(Icons.check_circle_rounded, color: LuxColors.ok),
              title: 'انجام شد',
              onTap: () async {
                Navigator.of(ctx).pop();
                await SmartRepo.markDone(b.id);
                _load(quiet: true);
              },
            ),
            LuxRow(
              leading: Icon(b.locked ? Icons.lock_open_rounded : Icons.lock_rounded, color: LuxColors.accent),
              title: b.locked ? 'بازکردنِ قفل' : 'قفل کردن',
              subtitle: b.locked ? 'دوباره می‌تواند جابه‌جا شود' : 'هنگامِ بازچینیِ برنامه همین‌جا می‌ماند',
              onTap: () async {
                Navigator.of(ctx).pop();
                await SmartRepo.setLocked(b.id, !b.locked);
                _load(quiet: true);
              },
            ),
            LuxRow(
              leading: Icon(Icons.schedule_rounded, color: LuxColors.accent),
              title: 'تغییرِ ساعت',
              subtitle: 'ساعتِ دلخواهت قفل می‌شود',
              onTap: () async {
                Navigator.of(ctx).pop();
                final t = await pickTimeOfDayMinutes(context, b.startMin);
                if (t == null) return;
                await SmartRepo.move(b.id, t);
                _load(quiet: true);
              },
            ),
            LuxRow(
              leading: Icon(Icons.close_rounded, color: LuxColors.danger),
              title: 'این بلوک را نمی‌خواهم',
              subtitle: 'برنامه یاد می‌گیرد و دفعه‌ی بعد کمتر در این ساعت/درس می‌گذارد',
              onTap: () async {
                Navigator.of(ctx).pop();
                await SmartRepo.reject(b.id);
                _load(quiet: true);
              },
            ),
          ],
          if (b.courseId != null && b.kind != 'micro')
            LuxRow(
              leading: Icon(Icons.bolt_rounded, color: LuxColors.warn),
              title: 'فقط ۵ دقیقه شروع کن',
              subtitle: 'شروعِ کوتاه معمولاً راهِ ادامه را باز می‌کند',
              onTap: () {
                Navigator.of(ctx).pop();
                _start(b, minutes: 5);
              },
            ),
        ],
      ),
    );
  }

  // ───────── بخش‌ها ─────────

  Widget _forecastCard(SmartBundle b) {
    final sim = b.sim;
    final st = b.snapshot.settings;
    final fs = [...b.meta.forecasts]..sort((a, c) => (b.snapshot.exams.firstWhere((e) => e.id == a.examId).at).compareTo(b.snapshot.exams.firstWhere((e) => e.id == c.examId).at));
    return LuxCard(
      radius: 28,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(child: Text('پیش‌بینیِ معدلِ ترم', style: LuxText.heading)),
              GestureDetector(
                onTap: () async {
                  await showSmartSettings(context);
                  _load(regenerate: true);
                },
                child: Icon(Icons.tune_rounded, color: LuxColors.silverDim),
              ),
            ],
          ),
          const SizedBox(height: 10),
          if (sim == null || sim.runs == 0)
            Text('برای پیش‌بینی، امتحان و نمره‌هایت را ثبت کن؛ هرچه داده‌ی بیشتری باشد برنامه دقیق‌تر می‌شود.', style: LuxText.caption)
          else ...[
            Row(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                Text(faDigits(sim.p50.toStringAsFixed(1)), style: LuxText.dot(44, color: LuxColors.accent)),
                const SizedBox(width: 10),
                Padding(
                  padding: const EdgeInsets.only(bottom: 8),
                  child: Text('بازه‌ی محتمل ${faDigits(sim.p10.toStringAsFixed(1))} تا ${faDigits(sim.p90.toStringAsFixed(1))}', style: LuxText.caption),
                ),
              ],
            ),
            const SizedBox(height: 6),
            Text(
              'احتمالِ رسیدن به هدفِ ${faDigits(st.target.toStringAsFixed(1))}: ${faDigits((sim.pTarget * 100).round())}٪',
              style: LuxText.label.copyWith(color: sim.pTarget >= 0.6 ? LuxColors.ok : (sim.pTarget >= 0.3 ? LuxColors.warn : LuxColors.danger)),
            ),
            const SizedBox(height: 6),
            ClipRRect(
              borderRadius: BorderRadius.circular(LuxColors.r(8)),
              child: SizedBox(height: 8, child: LinearProgressIndicator(value: sim.pTarget, color: LuxColors.accent, backgroundColor: LuxColors.cardHi)),
            ),
          ],
          if (fs.isNotEmpty) ...[
            const SizedBox(height: 14),
            Text('امتحان‌های پیش‌رو', style: LuxText.label),
            const SizedBox(height: 6),
            for (final f in fs.take(4)) _forecastRow(b, f),
          ],
          const SizedBox(height: 12),
          Row(
            children: [
              Expanded(
                child: LuxButton(
                  label: 'اگر… چه می‌شود؟',
                  icon: Icons.psychology_alt_rounded,
                  compact: true,
                  onPressed: () => _whatIf(b),
                ),
              ),
              const SizedBox(width: 8),
              Expanded(child: LuxButton(label: 'بازچینیِ برنامه', icon: Icons.autorenew_rounded, filled: false, compact: true, onPressed: () => _load(regenerate: true))),
            ],
          ),
        ],
      ),
    );
  }

  Widget _forecastRow(SmartBundle b, SExamForecast f) {
    final e = b.snapshot.exams.firstWhere((e) => e.id == f.examId);
    final c = b.snapshot.course(f.courseId);
    final dl = daysBetween(_today, dateOnly(e.at));
    final tgt = b.snapshot.settings.target;
    final ok = f.mean >= tgt - 0.3;
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 5),
      child: Row(
        children: [
          LuxDot(color: courseColor(c?.colorValue), size: 12),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('${c?.name ?? ''} · ${dl <= 0 ? 'امروز' : '${faDigits(dl)} روز دیگر'}', style: LuxText.body),
                Text(
                  'ساعتِ برنامه‌ریزی‌شده ${faDigits(f.hoursPlanned.toStringAsFixed(1))}${f.hoursNeeded > 0 && f.hoursNeeded < 40 ? ' از ${faDigits(f.hoursNeeded.toStringAsFixed(0))} ساعتِ لازم برای هدف' : ''}',
                  style: LuxText.caption,
                ),
              ],
            ),
          ),
          Text('${faDigits(f.mean.toStringAsFixed(1))} ± ${faDigits(f.sd.toStringAsFixed(1))}', style: LuxText.label.copyWith(color: ok ? LuxColors.ok : LuxColors.warn)),
        ],
      ),
    );
  }

  Future<void> _whatIf(SmartBundle b) async {
    final cs = [for (final c in b.snapshot.courses) if (b.meta.forecasts.any((f) => f.courseId == c.id)) c];
    if (cs.isEmpty) {
      luxToast(context, 'برای این بخش به یک امتحانِ پیش‌رو نیاز است.');
      return;
    }
    var sel = cs.first.id;
    var extra = 2.0;
    SimResult? alt;
    final base = b.sim;
    await showLuxSheet<void>(
      context,
      (ctx) => StatefulBuilder(builder: (ctx, setS) {
        void run() {
          alt = SmartRepo.whatIf(b, courseId: sel, extraHours: extra);
          setS(() {});
        }

        alt ??= SmartRepo.whatIf(b, courseId: sel, extraHours: extra);
        final d = base == null || alt == null ? 0.0 : alt!.p50 - base.p50;
        final dp = base == null || alt == null ? 0.0 : (alt!.pTarget - base.pTarget) * 100;
        return Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Text('اگر… چه می‌شود؟', style: LuxText.title),
            const SizedBox(height: 4),
            Text('چند ساعتِ بیشتر روی یک درس بگذاری، پیش‌بینی چقدر عوض می‌شود؟', style: LuxText.caption),
            const SizedBox(height: 14),
            Wrap(spacing: 8, runSpacing: 8, children: [
              for (final c in cs)
                LuxChip(
                  label: c.name,
                  selected: sel == c.id,
                  onTap: () {
                    sel = c.id;
                    run();
                  },
                ),
            ]),
            const SizedBox(height: 14),
            Text('ساعتِ بیشتر: ${faDigits(extra.toStringAsFixed(1))}', style: LuxText.label),
            Slider(
              value: extra,
              min: 0.5,
              max: 12,
              divisions: 23,
              onChanged: (v) => setS(() => extra = v),
              onChangeEnd: (_) => run(),
            ),
            if (alt != null && base != null)
              LuxCard(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('معدلِ پیش‌بینی‌شده: ${faDigits(base.p50.toStringAsFixed(2))} ← ${faDigits(alt!.p50.toStringAsFixed(2))}', style: LuxText.body),
                    const SizedBox(height: 6),
                    Text(
                      'تغییر: ${d >= 0 ? '+' : ''}${faDigits(d.toStringAsFixed(2))} نمره · احتمالِ رسیدن به هدف: ${faDigits((alt!.pTarget * 100).round())}٪ (${dp >= 0 ? '+' : ''}${faDigits(dp.round())}٪)',
                      style: LuxText.label.copyWith(color: d > 0.02 ? LuxColors.ok : LuxColors.silverDim),
                    ),
                    const SizedBox(height: 6),
                    Text('این یک برآوردِ آماری از داده‌های خودت است، نه قول.', style: LuxText.caption),
                  ],
                ),
              ),
          ],
        );
      }),
    );
  }

  Widget _alerts(SmartBundle b) {
    final list = [for (final a in b.meta.alerts) if (a.severity >= 1) a]..sort((a, c) => c.severity.compareTo(a.severity));
    if (list.isEmpty) return const SizedBox.shrink();
    IconData icon(String k) {
      switch (k) {
        case 'collision':
          return Icons.event_busy_rounded;
        case 'capacity':
          return Icons.hourglass_bottom_rounded;
        case 'burnout':
          return Icons.battery_alert_rounded;
        case 'late':
          return Icons.bolt_rounded;
        case 'rival':
          return Icons.emoji_events_rounded;
        case 'realism':
          return Icons.balance_rounded;
        case 'sleep':
          return Icons.bedtime_rounded;
        default:
          return Icons.lightbulb_rounded;
      }
    }

    return Column(
      children: [
        for (final a in list.take(5))
          Padding(
            padding: const EdgeInsets.only(bottom: 10),
            child: LuxCard(
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Icon(icon(a.kind), color: a.severity >= 3 ? LuxColors.danger : (a.severity == 2 ? LuxColors.warn : LuxColors.accent)),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(a.title, style: LuxText.label),
                        const SizedBox(height: 2),
                        Text(faDigits(a.body), style: LuxText.caption),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
      ],
    );
  }

  Widget _dayStrip(SmartBundle b) {
    final H = b.snapshot.settings.horizonDays;
    return SizedBox(
      height: 74,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        itemCount: H,
        separatorBuilder: (_, __) => const SizedBox(width: 8),
        itemBuilder: (context, i) {
          final d = _dateOf(i);
          final info = i < b.meta.days.length ? b.meta.days[i] : null;
          final sel = _day == i;
          final p = info?.pressure ?? 0.0;
          final dot = p > 0.66 ? LuxColors.danger : (p > 0.33 ? LuxColors.warn : LuxColors.ok);
          final planned = b.on(dayKey(d)).where((x) => x.status != 'skipped' && x.kind != 'micro').fold<int>(0, (a, x) => a + x.durMin);
          return GestureDetector(
            onTap: () => setState(() => _day = i),
            child: Container(
              width: 70,
              padding: const EdgeInsets.symmetric(vertical: 8),
              decoration: BoxDecoration(
                color: sel ? LuxColors.accent : LuxColors.card,
                borderRadius: BorderRadius.circular(LuxColors.r(20)),
                border: Border.all(color: sel ? LuxColors.accent : LuxColors.strokeColor, width: LuxColors.strokeW),
              ),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(i == 0 ? 'امروز' : weekdayName(weekdayIndex(d)), style: LuxText.label.copyWith(color: sel ? LuxColors.onAccent : LuxColors.text, fontSize: 12)),
                  const SizedBox(height: 4),
                  Text('${faDigits(toJalali(d).day)}', style: LuxText.heading.copyWith(color: sel ? LuxColors.onAccent : LuxColors.text)),
                  const SizedBox(height: 4),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Container(width: 7, height: 7, decoration: BoxDecoration(color: dot, shape: BoxShape.circle)),
                      const SizedBox(width: 4),
                      Text(planned == 0 ? '—' : '${faDigits((planned / 60).toStringAsFixed(1))}س', style: LuxText.caption.copyWith(fontSize: 10.5, color: sel ? LuxColors.onAccent : LuxColors.silverDim)),
                    ],
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }

  Widget _blockCard(SBlock b) {
    final done = b.status == 'done';
    final skipped = b.status == 'skipped';
    final now = DateTime.now();
    final d = dayFromKey(b.day);
    final start = DateTime(d.year, d.month, d.day, 0, b.startMin);
    final isLate = b.status == 'planned' && b.day == dayKey(now) && now.isAfter(start.add(const Duration(minutes: 15))) && b.startedAt == null && b.kind != 'micro';
    final open = _open.contains(b.id);
    final color = _colorOf(b);
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Opacity(
        opacity: (done || skipped) ? 0.62 : 1.0,
        child: LuxCard(
          radius: 24,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              GestureDetector(
                behavior: HitTestBehavior.opaque,
                onTap: () => setState(() => open ? _open.remove(b.id) : _open.add(b.id)),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Column(
                      children: [
                        Text(_hm(b.startMin), style: LuxText.label),
                        Text(_hm(b.endMin), style: LuxText.caption),
                      ],
                    ),
                    const SizedBox(width: 12),
                    Container(width: 3, height: 44, decoration: BoxDecoration(color: color, borderRadius: BorderRadius.circular(3))),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              Icon(_kindIcon[b.kind] ?? Icons.circle, size: 17, color: LuxColors.accent),
                              const SizedBox(width: 6),
                              Expanded(child: Text(b.title, style: LuxText.label, maxLines: 2, overflow: TextOverflow.ellipsis)),
                              if (b.locked) Icon(Icons.lock_rounded, size: 15, color: LuxColors.silverDim),
                            ],
                          ),
                          const SizedBox(height: 3),
                          Text('${_kindName[b.kind] ?? ''} · ${faDigits(b.durMin)} دقیقه${done ? ' · انجام شد' : (skipped ? ' · انجام نشد' : '')}', style: LuxText.caption),
                        ],
                      ),
                    ),
                    Icon(open ? Icons.expand_less_rounded : Icons.expand_more_rounded, color: LuxColors.silverDim),
                  ],
                ),
              ),
              if (open && b.reason.isNotEmpty) ...[
                const SizedBox(height: 10),
                Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(color: LuxColors.cardHi, borderRadius: BorderRadius.circular(LuxColors.r(16))),
                  child: Text('چرا اینجا؟ ${faDigits(b.reason)}', style: LuxText.caption.copyWith(color: LuxColors.text, height: 1.6)),
                ),
              ],
              if (b.status == 'planned') ...[
                const SizedBox(height: 12),
                Row(
                  children: [
                    Expanded(
                      child: LuxButton(
                        label: isLate ? 'فقط ۵ دقیقه شروع کن' : (b.kind == 'task' ? 'انجام دادم' : 'شروع'),
                        icon: isLate ? Icons.bolt_rounded : Icons.play_arrow_rounded,
                        compact: true,
                        onPressed: () => _start(b, minutes: isLate && b.courseId != null && b.kind != 'task' ? 5 : null),
                      ),
                    ),
                    const SizedBox(width: 8),
                    GestureDetector(
                      onTap: () => _menu(b),
                      child: Container(
                        width: 42,
                        height: 42,
                        decoration: BoxDecoration(color: LuxColors.cardHi, borderRadius: BorderRadius.circular(LuxColors.r(14))),
                        child: Icon(Icons.more_horiz_rounded, color: LuxColors.text),
                      ),
                    ),
                  ],
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }

  Widget _quickLinks() {
    Widget tile(IconData icon, String title, String sub, VoidCallback onTap) => Expanded(
          child: GestureDetector(
            onTap: () {
              Haptic.tap();
              onTap();
            },
            child: Container(
              padding: const EdgeInsets.all(12),
              margin: const EdgeInsets.symmetric(horizontal: 4),
              decoration: BoxDecoration(color: LuxColors.card, borderRadius: BorderRadius.circular(LuxColors.r(20)), border: Border.all(color: LuxColors.strokeColor, width: LuxColors.strokeW)),
              child: Column(
                children: [
                  Icon(icon, color: LuxColors.accent, size: 26),
                  const SizedBox(height: 6),
                  Text(title, style: LuxText.label.copyWith(fontSize: 12), textAlign: TextAlign.center),
                  Text(sub, style: LuxText.caption.copyWith(fontSize: 10.5), textAlign: TextAlign.center, maxLines: 2),
                ],
              ),
            ),
          ),
        );
    return Column(
      children: [
        Row(children: [
          tile(Icons.map_rounded, 'نقشه‌ی ضعف', 'کدام فصل‌ها؟', () => pushPage<void>(context, const WeaknessPage())),
          tile(Icons.timer_rounded, 'امتحان آزمایشی', 'با تایمر', () => pushPage<void>(context, const MockExamPage())),
          tile(Icons.style_rounded, 'فلش‌کارت', 'مرور فاصله‌دار', () => pushPage<void>(context, const CardsPage())),
        ]),
        const SizedBox(height: 8),
        Row(children: [
          tile(Icons.insights_rounded, 'مرور هفته', 'نتیجه و هدف', () => pushPage<void>(context, const WeeklyReviewPage())),
          tile(Icons.mic_rounded, 'ثبتِ سریع', 'با متن یا صدا', () async {
            await showQuickLog(context);
            _load(quiet: true);
          }),
          tile(Icons.timer_outlined, 'پومودورو', 'شروعِ تمرکز', () => pushPage<void>(context, const PomodoroPage())),
        ]),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    final b = _b;
    final children = <Widget>[];
    if (_busy && b == null) {
      children.add(const Padding(padding: EdgeInsets.all(40), child: Center(child: CircularProgressIndicator())));
    } else if (_error != null && b == null) {
      children.add(LuxCard(child: Text(_error!, style: LuxText.body)));
      children.add(const SizedBox(height: 10));
      children.add(LuxButton(label: 'تلاش دوباره', onPressed: _load));
    } else if (b != null) {
      if (b.snapshot.courses.isEmpty) {
        children.add(const LuxCard(child: LuxEmpty(icon: Icons.school_rounded, title: 'هنوز درسی ثبت نشده', hint: 'اول درس‌ها را از تبِ «درس‌ها» اضافه کن؛ بعد برنامه‌ی هوشمند ساخته می‌شود.')));
      } else {
        children.add(_forecastCard(b));
        children.add(const SizedBox(height: 14));
        children.add(_alerts(b));
        children.add(_dayStrip(b));
        children.add(const SizedBox(height: 14));
        final key = dayKey(_dateOf(_day));
        final list = b.on(key);
        if (list.isEmpty) {
          children.add(LuxCard(
            child: LuxEmpty(
              icon: Icons.spa_rounded,
              title: _day == 0 ? 'برای باقیِ امروز بلوکی نمانده' : 'این روز بلوکی ندارد',
              hint: 'اگر وقت آزاد داری، با «بازچینیِ برنامه» دوباره حساب کن، یا خودت در پومودورو تمرکز را شروع کن.',
            ),
          ));
        } else {
          final planned = list.where((x) => x.status == 'planned' && x.kind != 'micro').fold<int>(0, (a, x) => a + x.durMin);
          final done = list.where((x) => x.status == 'done' && x.kind != 'micro').fold<int>(0, (a, x) => a + x.durMin);
          children.add(Padding(
            padding: const EdgeInsets.only(bottom: 8),
            child: Text('${faDigits((planned / 60).toStringAsFixed(1))} ساعتِ باقی‌مانده${done > 0 ? ' · ${faDigits((done / 60).toStringAsFixed(1))} ساعتِ انجام‌شده' : ''}', style: LuxText.caption),
          ));
          for (final x in list) {
            children.add(_blockCard(x));
          }
        }
        children.add(const SizedBox(height: 10));
        children.add(_quickLinks());
        children.add(const SizedBox(height: 10));
        children.add(Text(
          'برنامه با هر نمره، امتحان و جلسه‌ی مطالعه به‌روز می‌شود. هرچه داده‌ی بیشتری ثبت کنی، پیش‌بینی‌ها دقیق‌تر می‌شوند.',
          style: LuxText.caption,
          textAlign: TextAlign.center,
        ));
      }
    }
    return LuxSubPage(
      title: 'برنامه‌ی هوشمند',
      subtitle: b == null ? null : '${faDigits(b.snapshot.courses.length)} درس · هدف ${faDigits(b.snapshot.settings.target.toStringAsFixed(1))}',
      children: children,
    );
  }
}
