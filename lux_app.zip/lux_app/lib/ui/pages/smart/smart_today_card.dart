import 'package:flutter/material.dart';

import '../../../core/app_bus.dart';
import '../../../core/jalali_utils.dart';
import '../../../core/palette.dart';
import '../../../core/theme.dart';
import '../../../data/smart_repo.dart';
import '../../../engine/smart/models.dart';
import '../../widgets/haptic.dart';
import '../../widgets/lux_card.dart';
import '../../widgets/lux_kit.dart';
import '../manage/pomodoro_page.dart';
import 'smart_plan_page.dart';

/// خلاصه‌ی «برنامه‌ی هوشمندِ امروز» در صفحه‌ی اصلی.
class SmartTodayCard extends StatefulWidget {
  const SmartTodayCard({super.key});

  @override
  State<SmartTodayCard> createState() => _SmartTodayCardState();
}

class _SmartTodayCardState extends State<SmartTodayCard> {
  SmartBundle? _b;
  bool _failed = false;

  @override
  void initState() {
    super.initState();
    AppBus.data.addListener(_load);
    _load();
  }

  @override
  void dispose() {
    AppBus.data.removeListener(_load);
    super.dispose();
  }

  Future<void> _load() async {
    try {
      final b = await SmartRepo.load(useCache: true);
      if (!mounted) return;
      setState(() {
        _b = b;
        _failed = false;
      });
    } catch (_) {
      if (mounted) setState(() => _failed = true);
    }
  }

  String _hm(int m) => faDigits('${two(m ~/ 60)}:${two(m % 60)}');

  @override
  Widget build(BuildContext context) {
    final b = _b;
    if (_failed || b == null || b.snapshot.courses.isEmpty) return const SizedBox.shrink();
    final key = dayKey(DateTime.now());
    final today = b.on(key).where((x) => x.kind != 'micro').toList();
    final nowMin = DateTime.now().hour * 60 + DateTime.now().minute;
    final planned = today.where((x) => x.status == 'planned').toList();
    SBlock? next;
    for (final x in planned) {
      if (x.endMin > nowMin) {
        next = x;
        break;
      }
    }
    final SBlock? nx = next;
    final left = planned.fold<int>(0, (a, x) => a + x.durMin);
    final done = today.where((x) => x.status == 'done').fold<int>(0, (a, x) => a + x.durMin);
    final sim = b.sim;
    return GestureDetector(
      onTap: () {
        Haptic.tap();
        pushPage<void>(context, const SmartPlanPage());
      },
      child: LuxCard(
        radius: 28,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(Icons.auto_awesome_rounded, color: LuxColors.accent),
                const SizedBox(width: 8),
                Expanded(child: Text('برنامه‌ی هوشمندِ امروز', style: LuxText.heading)),
                if (sim != null && sim.runs > 0)
                  Text('پیش‌بینی ${faDigits(sim.p50.toStringAsFixed(1))}', style: LuxText.caption.copyWith(color: LuxColors.accent)),
                const SizedBox(width: 4),
                Icon(Icons.chevron_left_rounded, color: LuxColors.silverDim),
              ],
            ),
            const SizedBox(height: 10),
            if (nx == null)
              Text(
                planned.isEmpty ? (done > 0 ? 'امروز ${faDigits((done / 60).toStringAsFixed(1))} ساعت کار کردی؛ دست مریزاد!' : 'برای باقیِ امروز بلوکی نیست. برنامه‌ی روزهای بعد را ببین.') : 'بلوکِ بعدی را ببین.',
                style: LuxText.body,
              )
            else ...[
              Row(
                children: [
                  Container(width: 4, height: 38, decoration: BoxDecoration(color: courseColor(b.snapshot.course(nx.courseId)?.colorValue), borderRadius: BorderRadius.circular(4))),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(nx.title, style: LuxText.label, maxLines: 1, overflow: TextOverflow.ellipsis),
                        Text('${_hm(nx.startMin)} · ${faDigits(nx.durMin)} دقیقه', style: LuxText.caption),
                      ],
                    ),
                  ),
                  if (nx.courseId != null && nx.kind != 'mock' && nx.kind != 'task' && nx.kind != 'review')
                    GestureDetector(
                      onTap: () {
                        Haptic.light();
                        pushPage<void>(context, PomodoroPage(courseId: nx.courseId, minutes: nx.durMin, autoStart: true));
                      },
                      child: Container(
                        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                        decoration: BoxDecoration(color: LuxColors.accent, borderRadius: BorderRadius.circular(LuxColors.r(16))),
                        child: Text('شروع', style: LuxText.label.copyWith(color: LuxColors.onAccent)),
                      ),
                    ),
                ],
              ),
            ],
            const SizedBox(height: 10),
            Text(
              '${faDigits(planned.length)} بلوک · ${faDigits((left / 60).toStringAsFixed(1))} ساعتِ باقی‌مانده${done > 0 ? ' · ${faDigits((done / 60).toStringAsFixed(1))} ساعتِ انجام‌شده' : ''}',
              style: LuxText.caption,
            ),
          ],
        ),
      ),
    );
  }
}
