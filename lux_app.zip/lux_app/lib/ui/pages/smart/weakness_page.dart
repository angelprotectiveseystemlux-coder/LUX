import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../../../core/jalali_utils.dart';
import '../../../core/palette.dart';
import '../../../core/theme.dart';
import '../../../core/util.dart';
import '../../../data/database.dart';
import '../../../data/smart_repo.dart';
import '../../../engine/smart/models.dart';
import '../../widgets/lux_button.dart';
import '../../widgets/lux_card.dart';
import '../../widgets/lux_kit.dart';
import '../../widgets/lux_section.dart';
import '../reader/study_reader_page.dart';

class _Weak {
  final SChapter ch;
  final SCourse? course;
  final double score; // ۰ قوی … ۱ ضعیف
  final int mistakes;
  final double hours;
  final double expectedHours;
  _Weak(this.ch, this.course, this.score, this.mistakes, this.hours, this.expectedHours);
}

/// نقشه‌ی ضعف: هر فصل با رنگ؛ از اشتباه‌ها، زمانِ مطالعه و مرورِ فاصله‌دار ساخته می‌شود.
class WeaknessPage extends StatefulWidget {
  const WeaknessPage({super.key});

  @override
  State<WeaknessPage> createState() => _WeaknessPageState();
}

class _WeaknessPageState extends State<WeaknessPage> {
  SSnapshot? _s;
  List<_Weak> _w = <_Weak>[];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final s = await SmartRepo.snapshot();
    final rs = await LuxDb.instance.rawQuery('SELECT * FROM reading_sessions');
    final byBook = <int, List<Map<String, Object?>>>{};
    for (final r in rs) {
      (byBook[asInt(r['book_id'])] ??= <Map<String, Object?>>[]).add(r);
    }
    final speed = {for (final b in s.books) b.id: b.pagesPerHour};
    final out = <_Weak>[];
    for (final ch in s.chapters) {
      if (ch.courseId == null) continue;
      final from = ch.startPage;
      final to = ch.endPage;
      var mistakes = 0;
      if (from != null && to != null) {
        for (final m in s.mistakes) {
          if (!m.open || m.bookId != ch.bookId || m.page == null) continue;
          if (m.page! >= from && m.page! <= to) mistakes++;
        }
      }
      var hours = 0.0;
      if (from != null && to != null) {
        for (final r in byBook[ch.bookId] ?? const <Map<String, Object?>>[]) {
          if (r['from_page'] == null || r['to_page'] == null) continue;
          final fp = asInt(r['from_page']);
          final tp = asInt(r['to_page']);
          if (tp < fp) continue;
          final ov = math.min(to, tp) - math.max(from, fp) + 1;
          if (ov <= 0) continue;
          final frac = ov / (tp - fp + 1);
          final secs = (asInt(r['end_ts']) - asInt(r['start_ts'])) / 1000.0;
          if (secs <= 0 || secs > 6 * 3600) continue;
          hours += frac * secs / 3600.0;
        }
      }
      final exp = math.max(0.3, ch.pages / math.max(6.0, speed[ch.bookId] ?? 18.0));
      final neglect = 1 - math.min(1.0, hours / exp);
      final mastery = ch.done ? (1 - math.min(1.0, ch.reps / 4.0)) : (hours >= exp ? 0.6 : 1.0);
      final sc = (0.45 * math.min(1.0, mistakes / 4.0) + 0.30 * mastery + 0.25 * neglect).clamp(0.0, 1.0).toDouble();
      out.add(_Weak(ch, s.course(ch.courseId), sc, mistakes, hours, exp));
    }
    if (!mounted) return;
    setState(() {
      _s = s;
      _w = out;
      _loading = false;
    });
  }

  Color _col(double w) {
    final good = LuxColors.ok;
    final mid = LuxColors.warn;
    final bad = LuxColors.danger;
    return w < 0.5 ? Color.lerp(good, mid, w / 0.5)! : Color.lerp(mid, bad, (w - 0.5) / 0.5)!;
  }

  Future<void> _detail(_Weak w) async {
    await showLuxSheet<void>(
      context,
      (ctx) => Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Text(w.ch.title, style: LuxText.title),
          const SizedBox(height: 4),
          Text('${w.course?.name ?? ''}${w.ch.startPage != null ? ' · صفحه‌ی ${faDigits(w.ch.startPage)}' : ''}', style: LuxText.caption),
          const SizedBox(height: 14),
          LuxRow(title: 'اشتباه‌های بازِ این فصل', trailing: Text(faDigits(w.mistakes), style: LuxText.heading)),
          LuxRow(title: 'زمانِ مطالعه', subtitle: 'انتظار: حدود ${faDigits(w.expectedHours.toStringAsFixed(1))} ساعت', trailing: Text('${faDigits(w.hours.toStringAsFixed(1))} ساعت', style: LuxText.heading)),
          LuxRow(title: 'وضعیت', trailing: Text(w.ch.done ? 'خوانده شده · ${faDigits(w.ch.reps)} مرور' : 'هنوز تمام نشده', style: LuxText.label)),
          const SizedBox(height: 10),
          if (w.ch.startPage != null)
            LuxButton(
              label: 'باز کردنِ فصل در کتاب',
              icon: Icons.menu_book_rounded,
              onPressed: () {
                Navigator.of(ctx).pop();
                pushPage<void>(context, StudyReaderPage(bookId: w.ch.bookId, startPage: w.ch.startPage));
              },
            ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final children = <Widget>[];
    if (_loading) {
      children.add(const Padding(padding: EdgeInsets.all(40), child: Center(child: CircularProgressIndicator())));
    } else if (_w.isEmpty) {
      children.add(const LuxCard(child: LuxEmpty(icon: Icons.map_rounded, title: 'هنوز فصلی ثبت نشده', hint: 'فصل‌های هر کتاب را اضافه کن؛ بعد اینجا هر فصل با رنگِ ضعف یا قوتش می‌آید.')));
    } else {
      final worst = [..._w]..sort((a, b) => b.score.compareTo(a.score));
      children.add(LuxCard(
        radius: 26,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('ضعیف‌ترین فصل‌ها', style: LuxText.heading),
            const SizedBox(height: 10),
            for (final w in worst.take(3))
              GestureDetector(
                behavior: HitTestBehavior.opaque,
                onTap: () => _detail(w),
                child: Padding(
                  padding: const EdgeInsets.symmetric(vertical: 6),
                  child: Row(
                    children: [
                      Container(width: 12, height: 12, decoration: BoxDecoration(color: _col(w.score), shape: BoxShape.circle)),
                      const SizedBox(width: 10),
                      Expanded(child: Text('${w.course?.name ?? ''} · ${w.ch.title}', style: LuxText.body, maxLines: 1, overflow: TextOverflow.ellipsis)),
                      Text('${faDigits((w.score * 100).round())}٪', style: LuxText.label.copyWith(color: _col(w.score))),
                    ],
                  ),
                ),
              ),
          ],
        ),
      ));
      children.add(const SizedBox(height: 14));
      final byCourse = <int, List<_Weak>>{};
      for (final w in _w) {
        (byCourse[w.ch.courseId!] ??= <_Weak>[]).add(w);
      }
      for (final e in byCourse.entries) {
        final c = _s?.course(e.key);
        final avg = e.value.fold<double>(0, (a, x) => a + x.score) / e.value.length;
        children.add(LuxCard(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  LuxDot(color: courseColor(c?.colorValue), size: 12),
                  const SizedBox(width: 8),
                  Expanded(child: Text(c?.name ?? '', style: LuxText.heading)),
                  Text('میانگینِ ضعف ${faDigits((avg * 100).round())}٪', style: LuxText.caption.copyWith(color: _col(avg))),
                ],
              ),
              const SizedBox(height: 12),
              Wrap(spacing: 8, runSpacing: 8, children: [
                for (final w in e.value)
                  GestureDetector(
                    onTap: () => _detail(w),
                    child: Container(
                      constraints: const BoxConstraints(minWidth: 62, maxWidth: 150),
                      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
                      decoration: BoxDecoration(color: LuxColors.alpha(_col(w.score), 0.22), borderRadius: BorderRadius.circular(LuxColors.r(12)), border: Border.all(color: _col(w.score), width: 1.4)),
                      child: Text(w.ch.title, style: LuxText.caption.copyWith(color: LuxColors.text), maxLines: 1, overflow: TextOverflow.ellipsis),
                    ),
                  ),
              ]),
            ],
          ),
        ));
        children.add(const SizedBox(height: 10));
      }
      children.add(Text('رنگِ هر فصل: سبز = قوی، زرد = متوسط، قرمز = ضعیف. از اشتباه‌های ثبت‌شده، زمانِ مطالعه و مرورِ فاصله‌دار حساب می‌شود.', style: LuxText.caption, textAlign: TextAlign.center));
    }
    return LuxSubPage(title: 'نقشه‌ی ضعف', subtitle: 'فصل‌هایی که بیشتر به وقت نیاز دارند', children: children);
  }
}
