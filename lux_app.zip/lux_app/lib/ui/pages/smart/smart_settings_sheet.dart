import 'package:flutter/material.dart';

import '../../../core/jalali_utils.dart';
import '../../../core/palette.dart';
import '../../../core/theme.dart';
import '../../../data/smart_repo.dart';
import '../../../engine/smart/models.dart';
import '../../widgets/lux_chip.dart';
import '../../widgets/lux_kit.dart';
import '../../widgets/lux_section.dart';

String _hm(int m) => faDigits('${two(m ~/ 60)}:${two(m % 60)}');

/// تنظیماتِ برنامه‌ی هوشمند: هدف، ساعت‌های مدرسه و خواب، سقفِ روزانه.
Future<void> showSmartSettings(BuildContext context) async {
  final st = await SmartRepo.settings();
  if (!context.mounted) return;
  await showLuxSheet<void>(
    context,
    (ctx) => _SettingsBody(st: st),
  );
  await SmartRepo.saveSettings(st);
}

class _SettingsBody extends StatefulWidget {
  final SSettings st;
  const _SettingsBody({required this.st});

  @override
  State<_SettingsBody> createState() => _SettingsBodyState();
}

class _SettingsBodyState extends State<_SettingsBody> {
  SSettings get st => widget.st;

  Widget _label(String t, {String? sub}) => Padding(
        padding: const EdgeInsets.only(top: 14, bottom: 8),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(t, style: LuxText.label),
          if (sub != null) Text(sub, style: LuxText.caption),
        ]),
      );

  Future<void> _time(int cur, void Function(int) set) async {
    final r = await pickTimeOfDayMinutes(context, cur);
    if (r == null) return;
    setState(() => set(r));
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Text('تنظیماتِ برنامه‌ی هوشمند', style: LuxText.title),
        _label('معدلِ هدف'),
        Wrap(spacing: 8, runSpacing: 8, children: [
          for (final v in const [16.0, 17.0, 18.0, 19.0, 19.5, 20.0])
            LuxChip(label: faDigits(v == v.roundToDouble() ? v.round() : v), selected: (st.target - v).abs() < 0.01, onTap: () => setState(() => st.target = v)),
        ]),
        _label('زمانِ بازگشت از مدرسه', sub: 'برنامه از این ساعت (به‌علاوه‌ی استراحت) شروع می‌شود'),
        LuxRow(title: 'پایانِ مدرسه', trailing: Text(_hm(st.schoolEndMin), style: LuxText.label.copyWith(color: LuxColors.accent)), onTap: () => _time(st.schoolEndMin, (v) => st.schoolEndMin = v)),
        _label('استراحت بعد از مدرسه'),
        Wrap(spacing: 8, runSpacing: 8, children: [
          for (final v in const [30, 45, 60, 90])
            LuxChip(label: '${faDigits(v)} دقیقه', selected: st.restAfterSchoolMin == v, onTap: () => setState(() => st.restAfterSchoolMin = v)),
        ]),
        LuxRow(title: 'پایانِ مطالعه‌ی شبانه', subtitle: 'شبِ قبلِ امتحان خودکار زودتر بسته می‌شود', trailing: Text(_hm(st.bedMin), style: LuxText.label.copyWith(color: LuxColors.accent)), onTap: () => _time(st.bedMin, (v) => st.bedMin = v)),
        LuxRow(title: 'شروعِ مطالعه در روزهای تعطیل', trailing: Text(_hm(st.offStartMin), style: LuxText.label.copyWith(color: LuxColors.accent)), onTap: () => _time(st.offStartMin, (v) => st.offStartMin = v)),
        _label('سقفِ مطالعه در روز', sub: 'خودکار یعنی بر پایه‌ی عادتِ واقعی‌ات'),
        Wrap(spacing: 8, runSpacing: 8, children: [
          LuxChip(label: 'خودکار', selected: st.maxDailyMin == null, onTap: () => setState(() => st.maxDailyMin = null)),
          for (final v in const [120, 180, 240, 300, 360, 480])
            LuxChip(label: '${faDigits(v ~/ 60)} ساعت', selected: st.maxDailyMin == v, onTap: () => setState(() => st.maxDailyMin = v)),
        ]),
        _label('طولِ دلخواهِ هر بلوک'),
        Wrap(spacing: 8, runSpacing: 8, children: [
          for (final v in const [30, 40, 45, 60, 75])
            LuxChip(label: '${faDigits(v)} دقیقه', selected: st.blockMin == v, onTap: () => setState(() => st.blockMin = v)),
        ]),
        _label('برنامه تا چند روز جلوتر؟'),
        Wrap(spacing: 8, runSpacing: 8, children: [
          for (final v in const [5, 7, 10, 14])
            LuxChip(label: '${faDigits(v)} روز', selected: st.horizonDays == v, onTap: () => setState(() => st.horizonDays = v)),
        ]),
        const SizedBox(height: 16),
        Text('با بستنِ این برگه، برنامه از نو چیده می‌شود.', style: LuxText.caption),
      ],
    );
  }
}
