import 'dart:async';

import 'package:flutter/material.dart';

import '../../../core/app_bus.dart';
import '../../../core/jalali_utils.dart';
import '../../../core/palette.dart';
import '../../../core/theme.dart';
import '../../../core/util.dart';
import '../../../data/database.dart';
import '../../../data/smart_repo.dart';
import '../../widgets/haptic.dart';
import '../../widgets/lux_button.dart';
import '../../widgets/lux_card.dart';
import '../../widgets/lux_chip.dart';
import '../../widgets/lux_kit.dart';
import '../manage/editors.dart';

class _Item {
  final String title;
  final String answer;
  final int? mistakeId;
  bool? ok;
  _Item(this.title, this.answer, this.mistakeId);
}

/// امتحان آزمایشی با تایمرِ واقعی؛ از اشتباه‌های قبلی و فصل‌های ضعیفِ همان درس ساخته می‌شود.
class MockExamPage extends StatefulWidget {
  final int? courseId;
  final int? examId;
  final int? minutes;
  const MockExamPage({super.key, this.courseId, this.examId, this.minutes});

  @override
  State<MockExamPage> createState() => _MockExamPageState();
}

class _MockExamPageState extends State<MockExamPage> {
  int _stage = 0; // ۰ آماده‌سازی، ۱ در جریان، ۲ تمام
  int? _courseId;
  String _courseName = '';
  int _minutes = 60;
  List<_Item> _items = <_Item>[];
  int _left = 0;
  Timer? _t;
  DateTime? _startedAt;
  final TextEditingController _score = TextEditingController();
  final Set<int> _reveal = <int>{};

  @override
  void initState() {
    super.initState();
    _courseId = widget.courseId;
    _minutes = (widget.minutes ?? 60).clamp(10, 180).toInt();
    _init();
  }

  Future<void> _init() async {
    if (_courseId != null) _courseName = await courseNameOf(_courseId);
    if (mounted) setState(() {});
  }

  @override
  void dispose() {
    _t?.cancel();
    _score.dispose();
    super.dispose();
  }

  Future<void> _build() async {
    final db = LuxDb.instance;
    final rows = await db.rawQuery(
      "SELECT * FROM mistakes WHERE status = 'open' ${_courseId == null ? '' : 'AND course_id = ?'} ORDER BY due_ts LIMIT 12",
      _courseId == null ? null : [_courseId],
    );
    final items = <_Item>[
      for (final r in rows) _Item(asStr(r['title']), asStr(r['answer']), asInt(r['id'])),
    ];
    if (_courseId != null) {
      final ch = await db.rawQuery(
        'SELECT ch.* FROM chapters ch JOIN books b ON b.id = ch.book_id WHERE b.course_id = ? ORDER BY ch.done, ch.reps LIMIT 4',
        [_courseId],
      );
      for (final r in ch) {
        items.add(_Item('بدونِ نگاه‌کردن به کتاب، خلاصه‌ی فصلِ «${asStr(r['title'])}» را بنویس یا بگو.', '', null));
      }
    }
    setState(() {
      _items = items;
      _stage = 1;
      _left = _minutes * 60;
      _startedAt = DateTime.now();
    });
    _t?.cancel();
    _t = Timer.periodic(const Duration(seconds: 1), (_) {
      if (!mounted) return;
      setState(() => _left--);
      if (_left <= 0) _finish();
    });
  }

  void _finish() {
    _t?.cancel();
    final marked = _items.where((e) => e.ok != null).toList();
    if (marked.length >= 3) {
      final r = marked.where((e) => e.ok == true).length / marked.length * 20;
      _score.text = latinNum(r, dec: 1);
    }
    setState(() => _stage = 2);
  }

  Future<void> _save() async {
    final sc = parseNum(_score.text);
    if (sc == null || sc < 0 || sc > 20) {
      luxNotice(context, 'نمره را بین ۰ تا ۲۰ بنویس.');
      return;
    }
    final db = LuxDb.instance;
    final start = _startedAt ?? DateTime.now();
    final end = DateTime.now();
    await db.insert('mocks', <String, Object?>{
      'course_id': _courseId,
      'exam_id': widget.examId,
      'at_ts': end.millisecondsSinceEpoch,
      'dur_min': end.difference(start).inMinutes,
      'score': sc,
      'max_score': 20,
    });
    await db.insert('study_sessions', <String, Object?>{
      'course_id': _courseId,
      'start_ts': start.millisecondsSinceEpoch,
      'end_ts': end.millisecondsSinceEpoch,
      'kind': 'mock',
      'planned_min': _minutes,
      'completed': 1,
    });
    // اشتباه‌های این امتحانِ آزمایشی دوباره در صفِ مرور می‌آیند.
    for (final it in _items) {
      if (it.mistakeId != null && it.ok == false) {
        await db.update('mistakes', <String, Object?>{'due_ts': DateTime.now().millisecondsSinceEpoch, 'status': 'open'}, where: 'id = ?', args: [it.mistakeId]);
      }
    }
    SmartRepo.invalidate();
    AppBus.bump();
    if (mounted) {
      luxToast(context, 'ثبت شد؛ در پیش‌بینی‌ات اثر می‌گذارد.');
      Navigator.of(context).pop();
    }
  }

  String get _clock => '${two(_left.clamp(0, 99999) ~/ 60)}:${two(_left.clamp(0, 99999) % 60)}';

  @override
  Widget build(BuildContext context) {
    final ch = <Widget>[];
    if (_stage == 0) {
      ch.addAll([
        LuxCard(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('امتحانِ آزمایشی', style: LuxText.heading),
              const SizedBox(height: 6),
              Text('شرایطِ واقعی: تایمر، بدونِ کتاب. سؤال‌ها از اشتباه‌های قبلیِ خودت و فصل‌های ضعیفِ همان درس می‌آیند.', style: LuxText.caption),
              const SizedBox(height: 14),
              LuxPickField(
                label: 'درس',
                value: _courseName.isEmpty ? 'همه‌ی درس‌ها' : _courseName,
                placeholder: _courseName.isEmpty,
                onTap: () async {
                  final r = await pickCourse(context, selectedId: _courseId, allowNone: true);
                  if (r == null) return;
                  _courseId = r < 0 ? null : r;
                  _courseName = r < 0 ? '' : await courseNameOf(r);
                  if (mounted) setState(() {});
                },
              ),
              const SizedBox(height: 6),
              Text('مدت', style: LuxText.label),
              const SizedBox(height: 8),
              Wrap(spacing: 8, runSpacing: 8, children: [
                for (final m in const [20, 30, 45, 60, 90])
                  LuxChip(label: '${faDigits(m)} دقیقه', selected: _minutes == m, onTap: () => setState(() => _minutes = m)),
              ]),
            ],
          ),
        ),
        const SizedBox(height: 14),
        LuxButton(label: 'شروع', icon: Icons.play_arrow_rounded, onPressed: _build),
      ]);
    } else if (_stage == 1) {
      ch.add(LuxCard(
        radius: 30,
        child: Column(
          children: [
            Directionality(textDirection: TextDirection.ltr, child: Text(_clock, style: LuxText.dot(52, color: _left < 300 ? LuxColors.danger : LuxColors.accent))),
            const SizedBox(height: 6),
            Text(_courseName.isEmpty ? 'همه‌ی درس‌ها' : _courseName, style: LuxText.caption),
          ],
        ),
      ));
      ch.add(const SizedBox(height: 12));
      if (_items.isEmpty) {
        ch.add(const LuxCard(child: LuxEmpty(icon: Icons.edit_note_rounded, title: 'اشتباهی ثبت نشده', hint: 'تایمر را به‌عنوانِ تمرینِ زمان‌دار استفاده کن: تمرین‌های کتاب را حل کن و بعد نمره‌ی خودت را بنویس.')));
      }
      for (var i = 0; i < _items.length; i++) {
        final it = _items[i];
        ch.add(Padding(
          padding: const EdgeInsets.only(bottom: 10),
          child: LuxCard(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Text('${faDigits(i + 1)}. ${it.title}', style: LuxText.body.copyWith(height: 1.6)),
                if (_reveal.contains(i) && it.answer.isNotEmpty) ...[
                  const SizedBox(height: 8),
                  Container(
                    padding: const EdgeInsets.all(10),
                    decoration: BoxDecoration(color: LuxColors.cardHi, borderRadius: BorderRadius.circular(LuxColors.r(12))),
                    child: Text(it.answer, style: LuxText.caption.copyWith(color: LuxColors.text)),
                  ),
                ],
                const SizedBox(height: 10),
                Row(
                  children: [
                    if (it.answer.isNotEmpty) Expanded(child: LuxButton(label: _reveal.contains(i) ? 'پنهان' : 'پاسخ', filled: false, compact: true, onPressed: () => setState(() => _reveal.contains(i) ? _reveal.remove(i) : _reveal.add(i)))),
                    if (it.answer.isNotEmpty) const SizedBox(width: 8),
                    Expanded(child: LuxButton(label: 'درست', filled: it.ok == true, compact: true, onPressed: () { Haptic.tap(); setState(() => it.ok = true); })),
                    const SizedBox(width: 8),
                    Expanded(child: LuxButton(label: 'غلط', filled: it.ok == false, compact: true, onPressed: () { Haptic.tap(); setState(() => it.ok = false); })),
                  ],
                ),
              ],
            ),
          ),
        ));
      }
      ch.add(LuxButton(label: 'پایانِ امتحان', onPressed: _finish));
    } else {
      final ok = _items.where((e) => e.ok == true).length;
      final bad = _items.where((e) => e.ok == false).length;
      ch.addAll([
        LuxCard(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('نتیجه', style: LuxText.heading),
              const SizedBox(height: 8),
              Text('${faDigits(ok)} درست · ${faDigits(bad)} غلط · ${faDigits(_items.length - ok - bad)} بدونِ پاسخ', style: LuxText.body),
              const SizedBox(height: 14),
              LuxField(label: 'نمره‌ی خودت (از ۲۰)', controller: _score, keyboard: TextInputType.number, hint: 'با شرایطِ واقعی چند می‌گرفتی؟'),
              Text('غلط‌ها دوباره به صفِ مرورِ اشتباه‌هایت برمی‌گردند.', style: LuxText.caption),
            ],
          ),
        ),
        const SizedBox(height: 14),
        LuxButton(label: 'ثبت', onPressed: _save),
      ]);
    }
    return LuxSubPage(title: 'امتحان آزمایشی', subtitle: _stage == 1 ? 'در جریان' : null, children: ch);
  }
}
