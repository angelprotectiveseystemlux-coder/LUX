import 'package:flutter/material.dart';

import '../../../core/app_bus.dart';
import '../../../core/jalali_utils.dart';
import '../../../core/palette.dart';
import '../../../core/theme.dart';
import '../../../core/util.dart';
import '../../../data/smart_repo.dart';
import '../../widgets/haptic.dart';
import '../../widgets/lux_button.dart';
import '../../widgets/lux_chip.dart';
import '../../widgets/lux_kit.dart';

/// بعد از ثبتِ نمره: «چرا نمره‌ی بیشتری نگرفتی؟» تا برنامه از روی دلیلِ واقعی ساخته شود.
Future<void> showExamReflection(BuildContext context, Map<String, Object?> exam, {double? scoreOf20}) async {
  final examId = asInt(exam['id']);
  final courseId = exam['course_id'] == null ? null : asInt(exam['course_id']);
  final chosen = <String>{};
  int? feel;
  final note = TextEditingController();
  await showLuxSheet<void>(
    context,
    (ctx) => StatefulBuilder(builder: (ctx, setS) {
      return Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Text('تحلیلِ این امتحان', style: LuxText.title),
          const SizedBox(height: 4),
          Text(
            scoreOf20 == null ? 'چه چیزی نمره را کم کرد؟ می‌توانی چند مورد را انتخاب کنی.' : 'نمره‌ات ${fmtNum(scoreOf20)} از ۲۰ شد. چه چیزی نمره را کم کرد؟ (چند مورد را می‌شود انتخاب کرد)',
            style: LuxText.caption,
          ),
          const SizedBox(height: 14),
          Wrap(spacing: 8, runSpacing: 8, children: [
            for (var i = 0; i < SmartRepo.reasonKeys.length; i++)
              LuxChip(
                label: SmartRepo.reasonNames[i],
                selected: chosen.contains(SmartRepo.reasonKeys[i]),
                onTap: () {
                  Haptic.tap();
                  setS(() {
                    final k = SmartRepo.reasonKeys[i];
                    if (!chosen.add(k)) chosen.remove(k);
                  });
                },
              ),
          ]),
          const SizedBox(height: 14),
          Text('حالِ خودت بعد از امتحان', style: LuxText.label),
          const SizedBox(height: 8),
          Wrap(spacing: 8, runSpacing: 8, children: [
            for (var i = 0; i < 5; i++)
              LuxChip(label: const ['خیلی بد', 'بد', 'معمولی', 'خوب', 'عالی'][i], selected: feel == i, onTap: () => setS(() => feel = i)),
          ]),
          const SizedBox(height: 14),
          LuxField(label: 'یادداشت (اختیاری)', controller: note, maxLines: 2, hint: 'مثلاً کدام بخش‌ها'),
          LuxButton(
            label: 'ذخیره و بهتر کردنِ برنامه',
            onPressed: () async {
              await SmartRepo.saveReflection(examId: examId, courseId: courseId, reasons: chosen.toList(), feel: feel, note: note.text.trim());
              AppBus.bump();
              if (ctx.mounted) Navigator.of(ctx).pop();
              if (context.mounted) luxToast(context, 'ثبت شد؛ برنامه از این بعد با آن تنظیم می‌شود.');
            },
          ),
          const SizedBox(height: 6),
          LuxButton(label: 'الان نه', filled: false, compact: true, onPressed: () => Navigator.of(ctx).pop()),
        ],
      );
    }),
  );
  note.dispose();
}
