import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../../../core/app_bus.dart';
import '../../../core/jalali_utils.dart';
import '../../../core/palette.dart';
import '../../../core/theme.dart';
import '../../../data/smart_repo.dart';
import '../../../engine/smart/models.dart';
import '../../widgets/haptic.dart';
import '../../widgets/lux_button.dart';
import '../../widgets/lux_kit.dart';

const MethodChannel _speech = MethodChannel('lux/speech');

/// ثبتِ سریعِ مطالعه با متن یا صدا: «فیزیک ۴۵ دقیقه»، «ریاضی یک ساعت و نیم».
Future<void> showQuickLog(BuildContext context) async {
  final snap = await SmartRepo.snapshot();
  if (!context.mounted) return;
  final c = TextEditingController();
  await showLuxSheet<void>(
    context,
    (ctx) => StatefulBuilder(builder: (ctx, setS) {
      final parsed = c.text.trim().isEmpty ? null : SmartRepo.parseQuick(c.text, snap.courses);
      return Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Text('ثبتِ سریع', style: LuxText.title),
          const SizedBox(height: 4),
          Text('مثلاً «فیزیک ۴۵ دقیقه» یا «ریاضی یک ساعت و نیم». آخرین لحظه تا همین الان ثبت می‌شود.', style: LuxText.caption),
          const SizedBox(height: 14),
          Row(
            children: [
              Expanded(
                child: LuxField(label: 'چه خواندی؟', controller: c, hint: 'فیزیک ۴۵ دقیقه', onChanged: (_) => setS(() {})),
              ),
              const SizedBox(width: 10),
              GestureDetector(
                onTap: () async {
                  Haptic.tap();
                  try {
                    final r = await _speech.invokeMethod<String>('listen');
                    if (r != null && r.trim().isNotEmpty) {
                      c.text = r.trim();
                      setS(() {});
                    }
                  } catch (_) {
                    if (ctx.mounted) luxToast(ctx, 'تشخیصِ صدا روی این گوشی در دسترس نیست.');
                  }
                },
                child: Container(
                  width: 52,
                  height: 52,
                  margin: const EdgeInsets.only(top: 22),
                  decoration: BoxDecoration(color: LuxColors.accent, borderRadius: BorderRadius.circular(LuxColors.r(18))),
                  child: Icon(Icons.mic_rounded, color: LuxColors.onAccent),
                ),
              ),
            ],
          ),
          if (c.text.trim().isNotEmpty) ...[
            const SizedBox(height: 12),
            Text(
              parsed == null
                  ? 'نفهمیدم؛ اسمِ درس و مدت را بنویس. مثل: «شیمی ۳۰ دقیقه»'
                  : '${parsed.courseName.isEmpty ? 'بدونِ درس' : parsed.courseName} · ${faDigits(parsed.minutes)} دقیقه',
              style: LuxText.label.copyWith(color: parsed == null ? LuxColors.warn : LuxColors.ok),
            ),
          ],
          const SizedBox(height: 14),
          LuxButton(
            label: 'ثبت',
            onPressed: parsed == null
                ? null
                : () async {
                    await SmartRepo.logSession(courseId: parsed.courseId, minutes: parsed.minutes);
                    AppBus.bump();
                    if (ctx.mounted) Navigator.of(ctx).pop();
                    if (context.mounted) luxToast(context, 'ثبت شد.');
                  },
          ),
        ],
      );
    }),
  );
  c.dispose();
}
