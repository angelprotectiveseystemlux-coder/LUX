import 'package:flutter/material.dart';
import '../../core/app_bus.dart';
import '../../core/jalali_utils.dart';
import '../../core/palette.dart';
import '../../core/theme.dart';
import '../../core/util.dart';
import '../../data/database.dart';
import '../../data/rivalry_repo.dart';
import '../../engine/rival_intel.dart';
import '../../engine/rivalry.dart';
import '../charts/chart_base.dart';
import '../charts/compare.dart';
import '../charts/radial.dart';
import '../widgets/lux_button.dart';
import '../widgets/lux_card.dart';
import '../widgets/lux_chip.dart';
import '../widgets/lux_kit.dart';
import '../widgets/lux_switch.dart';
import '../widgets/rival_visuals.dart';

Color _colorOf(PersonIntel p) => p.who.isMe ? LuxColors.accent : LuxColors.seriesAt(p.who.colorIdx);

String _nm(IntelReport r, int id) => r.byId[id]?.who.name ?? '؟';

String _sd(DateTime d) => '${faDigits(d.month)}/${faDigits(d.day)}';

String _nextLine(UpcomingExam? n) {
  if (n == null) return '';
  final d = n.at.difference(DateTime.now());
  if (d.isNegative) return '';
  final days = (d.inHours / 24).ceil();
  return days <= 0 ? ' امتحانِ بعدی امروز است.' : ' امتحانِ بعدی ${faDigits(days)} روز دیگر است.';
}

Widget _pill(String text, Color c) => Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
      decoration: BoxDecoration(color: LuxColors.alpha(c, 0.15), borderRadius: BorderRadius.circular(LuxColors.r(12))),
      child: Text(text, style: LuxText.caption.copyWith(color: LuxColors.text, fontWeight: FontWeight.w600)),
    );

Widget _block(String title, String? sub, Widget body) => LuxCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Text(title, style: LuxText.heading),
          if (sub != null) ...[const SizedBox(height: 2), Text(sub, style: LuxText.caption)],
          const SizedBox(height: 12),
          body,
        ],
      ),
    );

// ═════════════════════════ مرکزِ تحلیلِ رقابت ═════════════════════════

class RivalIntelPage extends StatefulWidget {
  final List<RivalExam> raw;
  final Map<int, double> coef;
  final Map<int, Map<int, double>> behavior;
  final List<Map<String, Object?>> rivals;
  final Map<int, String> policies;

  const RivalIntelPage({
    super.key,
    required this.raw,
    required this.coef,
    required this.behavior,
    required this.rivals,
    required this.policies,
  });

  @override
  State<RivalIntelPage> createState() => _RivalIntelPageState();
}

class _RivalIntelPageState extends State<RivalIntelPage> {
  IntelReport? _r;

  @override
  void initState() {
    super.initState();
    _build();
  }

  Future<void> _build() async {
    final now = DateTime.now();
    final rows = await LuxDb.instance.rawQuery(
      'SELECT e.course_id, e.title, e.type_name, e.at_ts FROM exams e WHERE e.status = ? AND e.at_ts >= ? ORDER BY e.at_ts',
      ['planned', now.millisecondsSinceEpoch],
    );
    final up = <int, UpcomingExam>{};
    for (final x in rows) {
      final cid = asInt(x['course_id']);
      if (up.containsKey(cid)) continue;
      final t = asStr(x['title']).isNotEmpty ? asStr(x['title']) : asStr(x['type_name']);
      up[cid] = UpcomingExam(cid, t, fromTs(x['at_ts']));
    }
    final adjusted = RivalryCalc.fillMissing(widget.raw, widget.policies);
    final rep = RivalIntel.analyze(
      exams: adjusted,
      coef: widget.coef,
      behavior: widget.behavior,
      rivals: [for (final r in widget.rivals) IntelPerson(asInt(r['id']), asStr(r['name']), asInt(r['color'], 1))],
      upcoming: up,
      now: now,
    );
    if (mounted) setState(() => _r = rep);
  }

  // ───────── پیشنهادها ─────────

  Widget _actionCard(int i, IntelAction a, IntelReport r) {
    Color c;
    IconData icon;
    String title;
    String body;
    final mine = r.me.courses[a.courseId];
    switch (a.kind) {
      case 'urgent':
        c = LuxColors.danger;
        icon = Icons.priority_high_rounded;
        title = 'جبرانِ فوری · ${a.courseName}';
        final parts = <String>[];
        if (mine != null) parts.add('میانگینت ${fmtNum(mine.avg, dec: 2)} است');
        if (mine != null && r.me.isWeak(mine)) parts.add('از سطحِ کلی‌ات پایین‌تر است');
        if (a.delta != null && a.delta! <= -1.0) parts.add('روندش نزولی است (${fmtNum(a.delta!, dec: 1)})');
        body = '${parts.join('؛ ')}. ضریبِ درس ${fmtNum(a.coef, dec: 0)}.${_nextLine(a.next)} '
            'همین الان مرورش را شروع کن و اشتباه‌های قبلی را از دفترچه‌ی اشتباهات ببین.';
        break;
      case 'overtake':
        c = LuxColors.accent;
        icon = Icons.trending_up_rounded;
        final whoO = _nm(r, a.targetId ?? -1);
        title = 'جلوزدن از $whoO · ${a.courseName}';
        final need = a.needScore;
        String needText;
        if (need == null) {
          needText = '';
        } else if (need <= 0) {
          needText = 'با همین روند هم از او جلو می‌افتی.';
        } else if (need <= 20) {
          needText = 'اگر او مثل میانگینش بگیرد، در امتحانِ بعدی حدوداً ${fmtNum(need, dec: 1)} از ۲۰ لازم داری.';
        } else {
          needText = 'با یک امتحان ممکن نیست؛ باید چند امتحانِ پیاپی از او بالاتر بگیری.';
        }
        body = '${fmtNum(a.gap ?? 0, dec: 2)} نمره عقب‌تری. $needText${_nextLine(a.next)}';
        break;
      default:
        c = LuxColors.warn;
        icon = Icons.shield_rounded;
        final whoD = _nm(r, a.targetId ?? -1);
        title = 'مراقبِ $whoD باش · ${a.courseName}';
        body = 'فقط ${fmtNum(a.gap ?? 0, dec: 2)} نمره جلوتر از او هستی و او در این درس بالا می‌آید (${fmtNum(a.delta ?? 0, dec: 1)}).${_nextLine(a.next)}';
    }
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: LuxCard(
        padding: const EdgeInsets.all(14),
        radius: 22,
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              width: 42,
              height: 42,
              decoration: BoxDecoration(color: LuxColors.alpha(c, 0.16), borderRadius: BorderRadius.circular(LuxColors.r(14))),
              child: Icon(icon, color: c),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('${faDigits(i + 1)}. $title', style: LuxText.heading.copyWith(fontSize: 15)),
                  const SizedBox(height: 4),
                  Text(body, style: LuxText.body),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _actions(IntelReport r) {
    if (r.actions.isEmpty) {
      return _block(
        'همین الان چه کنم؟',
        null,
        Text('با داده‌ی فعلی کاریِ فوری پیدا نشد. وضعیتت خوب است یا هنوز نمره‌ی کافی نیست.', style: LuxText.body),
      );
    }
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Padding(
          padding: const EdgeInsetsDirectional.only(start: 4, bottom: 10),
          child: Text('همین الان چه کنم؟', style: LuxText.title),
        ),
        for (var i = 0; i < r.actions.length; i++) _actionCard(i, r.actions[i], r),
      ],
    );
  }

  // ───────── وضعیت کلی ─────────

  Widget _status(IntelReport r) {
    final total = r.people.where((p) => p.overall != null).length;
    final me = r.me;
    final main = r.mainRivalId == null ? null : r.byId[r.mainRivalId!];
    final threat = r.threatId == null ? null : r.byId[r.threatId!];
    Widget stat(String label, String value, {Color? c}) => Expanded(
          child: Column(
            children: [
              Text(value, style: LuxText.heading.copyWith(color: c ?? LuxColors.text), textAlign: TextAlign.center, maxLines: 1, overflow: TextOverflow.ellipsis),
              const SizedBox(height: 4),
              Text(label, style: LuxText.caption, textAlign: TextAlign.center),
            ],
          ),
        );
    return LuxCard(
      radius: 28,
      child: Column(
        children: [
          Row(
            children: [
              RingProgress(
                value: total <= 1 || r.myOverallRank == 0 ? 1.0 : 1 - (r.myOverallRank - 1) / (total - 1),
                size: 84,
                stroke: 8,
                child: Text(r.myOverallRank == 0 ? '—' : faDigits(r.myOverallRank), style: LuxText.dot(28, color: LuxColors.accent)),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      r.myOverallRank == 1
                          ? 'نفر اولِ جمعی'
                          : (r.myOverallRank == 0 ? 'هنوز رتبه‌ای نیست' : 'رتبه‌ی ${faDigits(r.myOverallRank)} از ${faDigits(total)}'),
                      style: LuxText.title,
                    ),
                    const SizedBox(height: 4),
                    Text('سطحِ کلی: ${me.overall == null ? '—' : fmtNum(me.overall!, dec: 2)}', style: LuxText.caption),
                    const SizedBox(height: 6),
                    TrendBadge(state: me.momentum == null ? 'unknown' : (me.momentum! >= 1 ? 'rise' : (me.momentum! <= -1 ? 'fall' : 'flat')), delta: me.momentum),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          Row(
            children: [
              stat('رقیبِ اصلی', main == null ? '—' : main.who.name),
              stat('بزرگ‌ترین تهدید', threat == null ? 'کسی نیست' : threat.who.name, c: threat == null ? null : LuxColors.warn),
              stat('درس‌های رتبه‌ی ۲', faDigits(r.secondPlaces.length)),
              stat('درس‌های رتبه‌ی ۱', faDigits(r.firstPlaces.length), c: LuxColors.ok),
            ],
          ),
        ],
      ),
    );
  }

  // ───────── بخش‌ها ─────────

  Widget _heat(IntelReport r) {
    final cols = [for (final c in r.courseRanks) c.name];
    return _block(
      'نقشه‌ی حرارتی',
      'میانگینِ هر نفر در هر درس؛ قرمز = ضعیف، سبز = قوی. کادرِ رنگی = خودت.',
      RivalHeatmap(
        columns: cols,
        rows: [
          for (final p in r.people)
            HeatPerson(p.who.name, _colorOf(p), p.who.isMe, [for (final c in r.courseRanks) p.courses[c.courseId]?.avg]),
        ],
      ),
    );
  }

  Widget _momentum(IntelReport r) {
    final items = [for (final p in r.people) MomentumItem(p.who.name, _colorOf(p), p.momentum, p.who.isMe)]
      ..sort((a, b) => (b.delta ?? -99).compareTo(a.delta ?? -99));
    return _block(
      'شتاب: چه کسی بالا می‌آید، چه کسی پایین؟',
      'میانگینِ امتحان‌های اخیر منهای قبلی‌ها (از ۲۰). راستِ خط = بهتر شده، چپ = بدتر شده.',
      MomentumBars(items: items),
    );
  }

  Widget _rankJourney(IntelReport r) {
    if (r.rankSeries.where((e) => e != null).length < 2) return const SizedBox.shrink();
    return Padding(
      padding: const EdgeInsets.only(bottom: 14),
      child: _block('مسیرِ رتبه‌ی من', 'رتبه‌ی کلی پس از هر امتحان؛ بالاتر = بهتر', RankLine(ranks: r.rankSeries, totals: r.rankTotals)),
    );
  }

  Widget _perCourse(IntelReport r) {
    final rows = <Widget>[];
    for (final c in r.courseRanks) {
      if (c.myRank == 0) continue;
      final mine = r.me.courses[c.courseId]!;
      final pills = <Widget>[
        _pill('رتبه‌ی ${faDigits(c.myRank)} از ${faDigits(c.order.length)}', c.myRank == 1 ? LuxColors.ok : LuxColors.accent),
      ];
      if (c.aboveId != null) {
        pills.add(_pill('رقیبِ مستقیم: ${_nm(r, c.aboveId!)} (+${fmtNum(c.avgOf(c.aboveId!)! - mine.avg, dec: 1)})', LuxColors.warn));
      }
      if (c.belowId != null) {
        pills.add(_pill('پشت‌سرت: ${_nm(r, c.belowId!)} (−${fmtNum(mine.avg - c.avgOf(c.belowId!)!, dec: 1)})', LuxColors.silverDim));
      }
      rows.add(Padding(
        padding: const EdgeInsets.symmetric(vertical: 8),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Expanded(child: Text(c.name, style: LuxText.label)),
                Text(fmtNum(mine.avg, dec: 2), style: LuxText.label.copyWith(color: scoreColor(mine.avg))),
                const SizedBox(width: 8),
                TrendBadge(state: mine.state, delta: mine.delta),
              ],
            ),
            const SizedBox(height: 8),
            Wrap(spacing: 8, runSpacing: 8, children: pills),
          ],
        ),
      ));
    }
    if (rows.isEmpty) return const SizedBox.shrink();
    return Padding(
      padding: const EdgeInsets.only(bottom: 14),
      child: _block('رقیبِ من در هر درس', 'رقیبِ مستقیم = نفرِ درست بالای تو در همان درس', Column(children: rows)),
    );
  }

  Widget _flags(String title, String empty, List<CourseFlag> list, IntelReport r, {bool showPerson = true, String Function(CourseFlag)? note}) {
    if (list.isEmpty) {
      return Padding(
        padding: const EdgeInsets.symmetric(vertical: 6),
        child: Text('$title: $empty', style: LuxText.caption),
      );
    }
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(title, style: LuxText.label),
          const SizedBox(height: 6),
          for (final f in list.take(6))
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 3),
              child: Row(
                children: [
                  Container(width: 8, height: 8, decoration: BoxDecoration(color: _colorOf(r.byId[f.personId]!), shape: BoxShape.circle)),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      showPerson ? '${_nm(r, f.personId)} · ${f.courseName}' : f.courseName,
                      style: LuxText.body,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                  ),
                  Text(note == null ? fmtNum(f.avg, dec: 1) : note(f), style: LuxText.caption.copyWith(color: LuxColors.text)),
                ],
              ),
            ),
        ],
      ),
    );
  }

  String _rise(CourseFlag f) => '${fmtNum(f.earlier ?? 0, dec: 1)} ← ${fmtNum(f.recent ?? 0, dec: 1)}';

  Widget _rivalsMap(IntelReport r) {
    return _block(
      'ضعف و قوتِ رقبا',
      'همه از روی نمره‌هایی که ثبت کرده‌ای؛ هر چه داده بیشتر، دقیق‌تر.',
      Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          _flags('کجا ضعیف‌اند (فرصتِ تو)', 'رقیبِ ضعیفی در درسی پیدا نشد.', r.rivalsWeak, r),
          const Divider(height: 18),
          _flags('ضعیف بودند و دارند بالا می‌کشند', 'کسی در حالِ جبران نیست.', r.rivalsComeback, r, note: _rise),
          const Divider(height: 18),
          _flags('دارند ضعیف می‌شوند', 'افتِ محسوسی دیده نشد.', r.rivalsDeclining, r, note: _rise),
        ],
      ),
    );
  }

  Widget _myMap(IntelReport r) {
    return _block(
      'وضعیتِ خودم',
      'ضعیف = پایین‌تر از ۱۲ یا ۱٫۵ نمره زیرِ سطحِ کلیِ خودت.',
      Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          _flags('کجا ضعیفم', 'درسِ ضعیفی نداری.', r.myWeak, r, showPerson: false),
          const Divider(height: 18),
          _flags('کجا ضعیف شده‌ام', 'افتِ محسوسی نداشته‌ای.', r.myFalling, r, showPerson: false, note: _rise),
          const Divider(height: 18),
          _flags('کجا دارم ضعیف می‌شوم', 'نشانه‌ی خطری نیست.', r.myBecomingWeak, r, showPerson: false, note: _rise),
        ],
      ),
    );
  }

  Widget _peopleList(IntelReport r) {
    final rivals = r.people.skip(1).toList();
    if (rivals.isEmpty) return const SizedBox.shrink();
    return _block(
      'پرونده‌ی رقبا',
      'برای دیدنِ رادار، نمودار و سبکِ تحصیلیِ هر نفر لمسش کن.',
      Column(
        children: [
          for (final p in rivals)
            GestureDetector(
              behavior: HitTestBehavior.opaque,
              onTap: () => pushPage<void>(context, RivalProfilePage(report: r, personId: p.who.id)),
              child: Padding(
                padding: const EdgeInsets.symmetric(vertical: 9),
                child: Row(
                  children: [
                    Container(width: 12, height: 12, decoration: BoxDecoration(color: _colorOf(p), shape: BoxShape.circle)),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(p.who.name, style: LuxText.label),
                          const SizedBox(height: 2),
                          Text(p.tags.isEmpty ? 'سبک: هنوز مشخص نیست' : p.tags.join(' · '), style: LuxText.caption, maxLines: 1, overflow: TextOverflow.ellipsis),
                        ],
                      ),
                    ),
                    Text(p.overall == null ? '—' : fmtNum(p.overall!, dec: 2), style: LuxText.label.copyWith(color: p.overall == null ? null : scoreColor(p.overall!))),
                    const SizedBox(width: 6),
                    Icon(Icons.chevron_left_rounded, color: LuxColors.silverDim),
                  ],
                ),
              ),
            ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final r = _r;
    if (r == null) {
      return LuxSubPage(title: 'مرکز تحلیل رقابت', children: [
        Padding(padding: const EdgeInsets.all(40), child: Center(child: CircularProgressIndicator(color: LuxColors.accent))),
      ]);
    }
    if (r.steps.isEmpty || r.people.length < 2) {
      return LuxSubPage(title: 'مرکز تحلیل رقابت', children: [
        LuxCard(
          child: LuxEmpty(
            icon: Icons.radar_rounded,
            title: 'هنوز داده‌ی کافی نیست',
            hint: 'حداقل یک رقیب و نمره‌ی چند امتحان لازم است. هر چه نمره‌ی رقبا را بیشتر ثبت کنی، تحلیل دقیق‌تر می‌شود.',
          ),
        ),
      ]);
    }
    final thin = r.steps.length < 3;
    final gap = const SizedBox(height: 14);
    return LuxSubPage(
      title: 'مرکز تحلیل رقابت',
      subtitle: 'ناظرِ کاملِ تو و رقبا',
      children: [
        if (thin) ...[
          LuxCard(
            child: Row(
              children: [
                Icon(Icons.info_outline_rounded, color: LuxColors.warn),
                const SizedBox(width: 12),
                Expanded(child: Text('هنوز کم‌تر از ۳ امتحان ثبت شده؛ روندها و سبک‌ها تقریبی‌اند.', style: LuxText.body)),
              ],
            ),
          ),
          gap,
        ],
        _status(r),
        gap,
        _actions(r),
        gap,
        _rankJourney(r),
        _heat(r),
        gap,
        _momentum(r),
        gap,
        _perCourse(r),
        _rivalsMap(r),
        gap,
        _myMap(r),
        gap,
        _peopleList(r),
      ],
    );
  }
}

// ═════════════════════════ پرونده‌ی یک رقیب ═════════════════════════

class RivalProfilePage extends StatefulWidget {
  final IntelReport report;
  final int personId;
  const RivalProfilePage({super.key, required this.report, required this.personId});

  @override
  State<RivalProfilePage> createState() => _RivalProfilePageState();
}

class _RivalProfilePageState extends State<RivalProfilePage> {
  Map<String, Object?> _info = <String, Object?>{};

  static const List<String> _hours = <String>['کمتر از ۱ ساعت', '۱ تا ۲ ساعت', '۲ تا ۴ ساعت', 'بیشتر از ۴ ساعت'];

  @override
  void initState() {
    super.initState();
    _loadInfo();
  }

  Future<void> _loadInfo() async {
    final i = await RivalryRepo.info(widget.personId);
    if (mounted) setState(() => _info = i);
  }

  Future<void> _editInfo() async {
    var study = asStr(_info['study']);
    var tutor = _info['tutor'] == true;
    final note = TextEditingController(text: asStr(_info['note']));
    await showLuxSheet<void>(
      context,
      (ctx) => StatefulBuilder(
        builder: (ctx, set) => Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Text('اطلاعاتِ تکمیلی', style: LuxText.title),
            const SizedBox(height: 6),
            Text('اختیاری؛ هر چه بیشتر بدانی، تحلیلت واقعی‌تر می‌شود.', style: LuxText.caption),
            const SizedBox(height: 16),
            Text('روزانه چقدر درس می‌خواند؟', style: LuxText.label),
            const SizedBox(height: 8),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: [
                for (final h in _hours) LuxChip(label: h, selected: study == h, onTap: () => set(() => study = study == h ? '' : h)),
              ],
            ),
            const SizedBox(height: 16),
            Row(
              children: [
                Expanded(child: Text('کلاسِ خصوصی یا تقویتی می‌رود', style: LuxText.label)),
                LuxSwitch(value: tutor, onChanged: (v) => set(() => tutor = v)),
              ],
            ),
            const SizedBox(height: 12),
            LuxField(label: 'یادداشت', controller: note, hint: 'مثلاً: ریاضی را از کلاسِ خصوصی قوی کرده', maxLines: 3),
            LuxButton(
              label: 'ذخیره',
              onPressed: () async {
                await RivalryRepo.setInfo(widget.personId, <String, Object?>{'study': study, 'tutor': tutor, 'note': note.text.trim()});
                AppBus.bump();
                if (ctx.mounted) Navigator.of(ctx).pop();
              },
            ),
          ],
        ),
      ),
    );
    await _loadInfo();
  }

  Widget _kv(String k, String v) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 4),
        child: Row(
          children: [
            Expanded(child: Text(k, style: LuxText.caption)),
            Text(v, style: LuxText.label),
          ],
        ),
      );

  @override
  Widget build(BuildContext context) {
    final r = widget.report;
    final p = r.byId[widget.personId];
    if (p == null) return const LuxSubPage(title: 'پرونده', children: []);
    final me = r.me;
    final col = _colorOf(p);
    final courses = r.courseRanks.where((c) => p.courses[c.courseId] != null).toList();
    final steps = r.steps;
    final iHave = steps.where((e) => e.mine != null).length;
    final missing = iHave - p.n;

    final strong = [for (final c in p.courses.values) if (p.isStrong(c)) c]..sort((a, b) => b.avg.compareTo(a.avg));
    final weak = [for (final c in p.courses.values) if (p.isWeak(c)) c]..sort((a, b) => a.avg.compareTo(b.avg));

    final children = <Widget>[
      // ── خلاصه ──
      LuxCard(
        radius: 28,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Row(
              children: [
                Container(
                  width: 54,
                  height: 54,
                  alignment: Alignment.center,
                  decoration: BoxDecoration(color: LuxColors.alpha(col, 0.18), borderRadius: BorderRadius.circular(LuxColors.r(18))),
                  child: Text(p.who.name.isEmpty ? '?' : p.who.name.substring(0, 1), style: LuxText.title.copyWith(color: col)),
                ),
                const SizedBox(width: 14),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(p.who.name, style: LuxText.title),
                      const SizedBox(height: 4),
                      Text('نمره‌ی ${faDigits(p.n)} امتحان ثبت شده', style: LuxText.caption),
                    ],
                  ),
                ),
                Text(p.overall == null ? '—' : fmtNum(p.overall!, dec: 2), style: LuxText.dot(34, color: col)),
              ],
            ),
            if (p.tags.isNotEmpty) ...[
              const SizedBox(height: 14),
              Wrap(spacing: 8, runSpacing: 8, children: [for (final t in p.tags) _pill(t, col)]),
              const SizedBox(height: 10),
              for (final t in p.tags)
                if (RivalIntel.tagNotes[t] != null)
                  Padding(
                    padding: const EdgeInsets.only(top: 3),
                    child: Text('• ${RivalIntel.tagNotes[t]}', style: LuxText.caption),
                  ),
              const SizedBox(height: 6),
              Text('این برچسب‌ها فقط از روی نمره‌هاست و درباره‌ی شخصیتِ واقعیِ او نیست.', style: LuxText.caption.copyWith(color: LuxColors.silverDim)),
            ],
          ],
        ),
      ),
      const SizedBox(height: 14),
    ];

    // ── رادار ──
    if (courses.length >= 3) {
      final ordered = r.courseRanks.where((c) => p.courses[c.courseId] != null || me.courses[c.courseId] != null).toList();
      children.add(_block(
        'رادار: من در برابر ${p.who.name}',
        'هر محور یک درس (از ۲۰)',
        Column(
          children: [
            RivalRadar(
              labels: [for (final c in ordered) c.name],
              series: [
                RadarSeries('من', LuxColors.accent, [for (final c in ordered) me.courses[c.courseId]?.avg]),
                RadarSeries(p.who.name, col, [for (final c in ordered) p.courses[c.courseId]?.avg]),
              ],
            ),
            const SizedBox(height: 8),
            ChartLegend(labels: ['من', p.who.name], colors: [LuxColors.accent, col]),
          ],
        ),
      ));
      children.add(const SizedBox(height: 14));
    }

    // ── روند ──
    if (r.steps.isNotEmpty) {
      final series = <GapSeries>[
        GapSeries('من', me.series, LuxColors.accent, primary: true),
        GapSeries(p.who.name, p.series, col),
      ];
      children.add(_block(
        'روندِ سطحِ کلی',
        'بعد از هر امتحان؛ لمس کن تا مقدارها را ببینی',
        Column(
          children: [
            PolylineChart(
              labels: [for (final e in r.steps) e.courseName],
              details: [for (final e in r.steps) '${e.title} — ${_sd(e.at)}'],
              series: series,
            ),
            const SizedBox(height: 10),
            ChartLegend(labels: [for (final s in series) s.name], colors: [for (final s in series) s.color]),
          ],
        ),
      ));
      children.add(const SizedBox(height: 14));
    }

    // ── جدولِ درس‌ها ──
    if (courses.isNotEmpty) {
      children.add(_block(
        'درس‌به‌درس',
        'میانگین، روند، بهترین و بدترین نمره و رتبه‌اش در کلاس',
        Column(
          children: [
            for (final c in courses)
              Builder(builder: (context) {
                final s = p.courses[c.courseId]!;
                final rank = c.order.indexWhere((e) => e.personId == p.who.id) + 1;
                return Padding(
                  padding: const EdgeInsets.symmetric(vertical: 8),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      Row(
                        children: [
                          Expanded(child: Text(c.name, style: LuxText.label)),
                          Text(fmtNum(s.avg, dec: 2), style: LuxText.label.copyWith(color: scoreColor(s.avg))),
                          const SizedBox(width: 8),
                          TrendBadge(state: s.state, delta: s.delta),
                        ],
                      ),
                      const SizedBox(height: 6),
                      ClipRRect(
                        borderRadius: BorderRadius.circular(6),
                        child: LinearProgressIndicator(value: (s.avg / 20).clamp(0.0, 1.0).toDouble(), minHeight: 7, color: col, backgroundColor: LuxColors.cardHi),
                      ),
                      const SizedBox(height: 6),
                      Text(
                        'رتبه ${faDigits(rank)} از ${faDigits(c.order.length)} · بهترین ${fmtNum(s.best, dec: 1)} · بدترین ${fmtNum(s.worst, dec: 1)}'
                        '${s.std == null ? '' : ' · نوسان ${fmtNum(s.std!, dec: 1)}'}',
                        style: LuxText.caption,
                      ),
                    ],
                  ),
                );
              }),
          ],
        ),
      ));
      children.add(const SizedBox(height: 14));
    }

    // ── قوت و ضعف ──
    children.add(_block(
      'نقاط قوت و ضعف',
      null,
      Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('قوی در', style: LuxText.label.copyWith(color: LuxColors.ok)),
          const SizedBox(height: 6),
          if (strong.isEmpty) Text('درسِ برجسته‌ای نیست.', style: LuxText.caption) else Wrap(spacing: 8, runSpacing: 8, children: [for (final c in strong.take(4)) _pill('${c.name}  ${fmtNum(c.avg, dec: 1)}', LuxColors.ok)]),
          const SizedBox(height: 14),
          Text('ضعیف در', style: LuxText.label.copyWith(color: LuxColors.danger)),
          const SizedBox(height: 6),
          if (weak.isEmpty) Text('درسِ ضعیفی دیده نمی‌شود.', style: LuxText.caption) else Wrap(spacing: 8, runSpacing: 8, children: [for (final c in weak.take(4)) _pill('${c.name}  ${fmtNum(c.avg, dec: 1)}', LuxColors.danger)]),
        ],
      ),
    ));
    children.add(const SizedBox(height: 14));

    // ── اطلاعاتِ تکمیلی ──
    final study = asStr(_info['study']);
    final note = asStr(_info['note']);
    children.add(_block(
      'اطلاعاتِ تکمیلی',
      'چیزهایی که خودت از او می‌دانی',
      Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          _kv('مطالعه‌ی روزانه', study.isEmpty ? 'ثبت نشده' : study),
          _kv('کلاسِ خصوصی/تقویتی', _info.isEmpty ? 'ثبت نشده' : (_info['tutor'] == true ? 'دارد' : 'ندارد')),
          if (note.isNotEmpty) _kv('یادداشت', note),
          if (missing > 0) ...[
            const SizedBox(height: 8),
            Text('نمره‌ی ${faDigits(missing)} امتحان از او ثبت نشده؛ با ثبتِ آن‌ها تحلیل دقیق‌تر می‌شود.', style: LuxText.caption.copyWith(color: LuxColors.warn)),
          ],
          const SizedBox(height: 12),
          LuxButton(label: 'ثبت یا ویرایش', icon: Icons.edit_rounded, filled: false, onPressed: _editInfo),
        ],
      ),
    ));

    return LuxSubPage(title: p.who.name, subtitle: 'پرونده‌ی رقیب', children: children);
  }
}
