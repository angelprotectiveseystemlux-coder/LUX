import 'package:flutter/material.dart';
import '../../core/app_bus.dart';
import '../../core/jalali_utils.dart';
import '../../core/util.dart';
import '../../core/palette.dart';
import '../../core/theme.dart';
import '../../services/daily_brief.dart';
import '../../services/notification_service.dart';
import '../widgets/lux_card.dart';
import '../widgets/lux_chip.dart';
import '../widgets/lux_kit.dart';
import '../widgets/lux_section.dart';
import '../widgets/lux_switch.dart';

/// خلاصه‌ی روزانه: پیش‌نمایش + تنظیمات (روشن/خاموش، ساعت ارسال، محتوا)
class DailyBriefPage extends StatefulWidget {
  const DailyBriefPage({super.key});

  @override
  State<DailyBriefPage> createState() => _DailyBriefPageState();
}

class _DailyBriefPageState extends State<DailyBriefPage> {
  BriefSettings _s = const BriefSettings();
  BriefData? _data;
  int _day = 0; // 0 امروز، 1 فردا
  bool _loaded = false;

  @override
  void initState() {
    super.initState();
    _load();
    AppBus.data.addListener(_load);
  }

  @override
  void dispose() {
    AppBus.data.removeListener(_load);
    super.dispose();
  }

  Future<void> _load() async {
    final s = await DailyBrief.load();
    final d = DateTime.now().add(Duration(days: _day));
    final data = await DailyBrief.compose(d, s, at: DateTime(d.year, d.month, d.day, s.hour, s.minute));
    if (!mounted) return;
    setState(() {
      _s = s;
      _data = data;
      _loaded = true;
    });
  }

  Future<void> _update(BriefSettings n) async {
    await DailyBrief.save(n);
    if (n.on) {
      try {
        await NotificationService.instance.ensurePermissions();
      } catch (_) {}
    }
    await DailyBrief.reschedule();
    await _load();
  }

  Future<void> _pickTime() async {
    final r = await pickTimeOfDayMinutes(context, _s.hour * 60 + _s.minute);
    if (r == null) return;
    await _update(_s.copyWith(hour: r ~/ 60, minute: r % 60));
    if (mounted) luxToast(context, 'ساعت ارسال: ${minutesLabel(r)}');
  }

  Future<void> _sample() async {
    try {
      await NotificationService.instance.ensurePermissions();
      await DailyBrief.sendSample();
      if (mounted) luxToast(context, 'یک نمونه از اعلانِ خلاصه فرستاده شد.');
    } catch (e) {
      if (mounted) luxNotice(context, 'ارسال نمونه ممکن نشد: $e');
    }
  }

  Widget _switchRow(String title, String sub, bool value, ValueChanged<bool> onChanged) {
    return LuxRow(
      title: title,
      subtitle: sub,
      trailing: LuxSwitch(value: value, onChanged: onChanged),
    );
  }

  @override
  Widget build(BuildContext context) {
    final data = _data;
    return LuxSubPage(
      title: 'خلاصه روزانه',
      subtitle: _s.on ? 'هر روز ساعت ${minutesLabel(_s.hour * 60 + _s.minute)}' : 'خاموش',
      children: [
        if (_loaded && data != null)
          LuxCard(
            radius: 28,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Wrap(spacing: 8, children: [
                  LuxChip(
                    label: 'امروز',
                    selected: _day == 0,
                    onTap: () {
                      setState(() => _day = 0);
                      _load();
                    },
                  ),
                  LuxChip(
                    label: 'فردا',
                    selected: _day == 1,
                    onTap: () {
                      setState(() => _day = 1);
                      _load();
                    },
                  ),
                ]),
                const SizedBox(height: 16),
                Text(data.title, style: LuxText.title),
                const SizedBox(height: 2),
                Text(data.dateLine, style: LuxText.caption),
                for (final sec in data.sections) ...[
                  const SizedBox(height: 16),
                  Text(sec.title, style: LuxText.label.copyWith(color: LuxColors.accent)),
                  const SizedBox(height: 6),
                  for (final l in sec.lines)
                    Padding(
                      padding: const EdgeInsets.only(bottom: 4),
                      child: Text('• $l', style: LuxText.body),
                    ),
                ],
              ],
            ),
          ),
        const SizedBox(height: 22),
        LuxSection(title: 'ارسال خودکار', children: [
          _switchRow('خلاصه‌ی روزانه', 'هر روز یک اعلانِ کامل از برنامه‌ی همان روز', _s.on, (v) => _update(_s.copyWith(on: v))),
          LuxRow(
            title: 'ساعت ارسال',
            subtitle: 'برای تغییر بزن',
            trailing: Text(minutesLabel(_s.hour * 60 + _s.minute), style: LuxText.heading.copyWith(color: LuxColors.accent)),
            onTap: _pickTime,
          ),
          LuxRow(
            title: 'ارسال یک نمونه',
            subtitle: 'همین حالا اعلانِ خلاصه را ببین',
            trailing: Icon(Icons.send_rounded, color: LuxColors.accent),
            onTap: _sample,
          ),
        ]),
        LuxSection(title: 'شامل چه چیزهایی باشد؟', children: [
          _switchRow('کلاس‌های امروز', 'ساعت و مکانِ هر کلاس', _s.classes, (v) => _update(_s.copyWith(classes: v))),
          _switchRow('امتحان‌ها', 'امتحان‌های ۸ روز آینده با محدوده', _s.exams, (v) => _update(_s.copyWith(exams: v))),
          _switchRow('تکالیف', 'عقب‌افتاده، امروز و فردا', _s.tasks, (v) => _update(_s.copyWith(tasks: v))),
          _switchRow('تولد و مناسبت‌ها', 'نزدیک‌شدنِ تولدت', _s.birthday, (v) => _update(_s.copyWith(birthday: v))),
          _switchRow('پیشنهادِ روز', 'یک توصیه‌ی کوتاه برای مرور و اولویت‌ها', _s.tip, (v) => _update(_s.copyWith(tip: v))),
        ]),
        Text(
          'متنِ اعلان‌ها برای ۱۴ روز آینده از روی برنامه‌ی فعلی ساخته می‌شود و با هر تغییر یا باز شدنِ برنامه به‌روز می‌شود. اگر چند هفته برنامه را باز نکنی، اعلان‌ها تمام می‌شوند.',
          style: LuxText.caption,
          textAlign: TextAlign.center,
        ),
      ],
    );
  }
}
