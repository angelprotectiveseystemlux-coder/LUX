import 'package:flutter/material.dart';
import '../../core/app_theme.dart';
import '../../core/palette.dart';
import '../../core/theme.dart';
import '../../data/database.dart';
import '../shell/app_shell.dart';
import '../widgets/haptic.dart';
import '../widgets/lux_card.dart';
import '../widgets/lux_chip.dart';
import '../widgets/lux_kit.dart';
import '../widgets/lux_section.dart';
import '../widgets/lux_switch.dart';

/// شخصی‌سازی ظاهر: حالت روشن/تیره، پنج تم، اندازه‌ی متن، ویبره و انیمیشن ورود
class AppearancePage extends StatefulWidget {
  const AppearancePage({super.key});

  @override
  State<AppearancePage> createState() => _AppearancePageState();
}

class _AppearancePageState extends State<AppearancePage> {
  bool _haptics = Haptic.enabled;

  /// با تغییرِ تم، کلِ برنامه دوباره ساخته می‌شود؛ این دو پرچم باعث می‌شود همین صفحه دوباره باز شود.
  void _willRebuild() {
    AppShell.pendingIndex = 4;
    AppShell.pendingAppearance = true;
  }

  Widget _modeTile(int index, IconData icon, String label) {
    final t = AppTheme.instance;
    final selected = t.mode == index;
    return Expanded(
      child: GestureDetector(
        behavior: HitTestBehavior.opaque,
        onTap: () {
          if (selected) return;
          Haptic.tap();
          _willRebuild();
          t.setMode(index);
        },
        child: Container(
          height: 92,
          margin: const EdgeInsets.symmetric(horizontal: 5),
          decoration: BoxDecoration(
            color: selected ? LuxColors.cardHi : LuxColors.card,
            borderRadius: BorderRadius.circular(LuxColors.r(22)),
            border: Border.all(color: selected ? LuxColors.accent : LuxColors.stroke, width: selected ? 1.6 : 1),
          ),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(icon, size: 28, color: selected ? LuxColors.accent : LuxColors.silverDim),
              const SizedBox(height: 8),
              Text(label, style: LuxText.caption.copyWith(color: selected ? LuxColors.text : LuxColors.textDim)),
              const SizedBox(height: 6),
              Container(
                width: 34,
                height: 3,
                decoration: BoxDecoration(
                  color: selected ? LuxColors.accent : LuxColors.stroke,
                  borderRadius: BorderRadius.circular(LuxColors.r(2)),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _themeTile(int i, double width) {
    final t = AppTheme.instance;
    final def = LuxThemes.all[i];
    final p = def.of(t.brightness);
    final selected = t.themeIndex == i;
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTap: () {
        if (selected) return;
        Haptic.light();
        _willRebuild();
        t.setTheme(i);
      },
      child: Container(
        width: width,
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: p.bg,
          borderRadius: BorderRadius.circular(LuxColors.r(22)),
          border: Border.all(color: selected ? p.accent : p.stroke, width: selected ? 2 : 1),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                _swatch(p.accent),
                const SizedBox(width: 6),
                _swatch(p.card),
                const SizedBox(width: 6),
                _swatch(p.silver),
                const Spacer(),
                if (selected) Icon(Icons.check_circle_rounded, size: 20, color: p.accent),
              ],
            ),
            const SizedBox(height: 14),
            Text(def.name, style: LuxText.heading.copyWith(color: p.text)),
          ],
        ),
      ),
    );
  }

  Widget _swatch(Color c) => Container(
        width: 18,
        height: 18,
        decoration: BoxDecoration(color: c, shape: BoxShape.circle, border: Border.all(color: LuxColors.alpha(LuxColors.silver, 0.25))),
      );

  @override
  Widget build(BuildContext context) {
    final t = AppTheme.instance;
    final w = (MediaQuery.of(context).size.width - 40 - 12) / 2;
    return LuxSubPage(
      title: 'ظاهر و شخصی‌سازی',
      subtitle: 'تم، حالت نمایش و حس برنامه',
      children: [
        LuxCard(
          radius: 28,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('پیش‌نمایش', style: LuxText.caption),
              const SizedBox(height: 10),
              Text('عنوانِ نمونه', style: LuxText.title),
              const SizedBox(height: 4),
              Text('این‌طور به نظر می‌رسد وقتی تم و حالتِ فعلی را انتخاب کرده باشی.', style: LuxText.body),
              const SizedBox(height: 14),
              Wrap(spacing: 8, runSpacing: 8, children: [
                LuxChip(label: 'انتخاب‌شده', selected: true, onTap: () {}),
                LuxChip(label: 'عادی', selected: false, onTap: () {}),
              ]),
              const SizedBox(height: 14),
              ClipRRect(
                borderRadius: BorderRadius.circular(LuxColors.r(8)),
                child: LinearProgressIndicator(
                  value: 0.65,
                  minHeight: 8,
                  backgroundColor: LuxColors.cardHi,
                  valueColor: AlwaysStoppedAnimation<Color>(LuxColors.accent),
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 22),
        Padding(
          padding: const EdgeInsetsDirectional.only(start: 6, bottom: 10),
          child: Text('حالت نمایش', style: LuxText.label),
        ),
        Row(
          children: [
            _modeTile(0, Icons.light_mode_rounded, 'روشن'),
            _modeTile(1, Icons.contrast_rounded, 'خودکار'),
            _modeTile(2, Icons.dark_mode_rounded, 'تیره'),
          ],
        ),
        const SizedBox(height: 22),
        Padding(
          padding: const EdgeInsetsDirectional.only(start: 6, bottom: 10),
          child: Text('تم رنگی', style: LuxText.label),
        ),
        Wrap(
          spacing: 12,
          runSpacing: 12,
          children: [for (var i = 0; i < LuxThemes.all.length; i++) _themeTile(i, w)],
        ),
        const SizedBox(height: 22),
        LuxCard(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('اندازه‌ی متن', style: LuxText.heading),
              const SizedBox(height: 12),
              Wrap(spacing: 8, runSpacing: 8, children: [
                for (var i = 0; i < AppTheme.textScaleNames.length; i++)
                  LuxChip(
                    label: AppTheme.textScaleNames[i],
                    selected: t.textScaleIndex == i,
                    onTap: () {
                      if (t.textScaleIndex == i) return;
                      _willRebuild();
                      t.setTextScale(i);
                    },
                  ),
              ]),
            ],
          ),
        ),
        const SizedBox(height: 22),
        LuxSection(title: 'حس و حرکت', children: [
          LuxRow(
            title: 'ویبره‌ی لمسی',
            subtitle: 'لرزشِ کوتاه هنگام لمس دکمه‌ها',
            trailing: LuxSwitch(
              value: _haptics,
              onChanged: (v) async {
                setState(() => _haptics = v);
                Haptic.enabled = v;
                await LuxDb.instance.kvSet('haptics', v ? '1' : '0');
                if (v) Haptic.light();
              },
            ),
          ),
          LuxRow(
            title: 'انیمیشن ورود',
            subtitle: 'نمایشِ لوگوی LUX هر بار که برنامه باز می‌شود',
            trailing: LuxSwitch(
              value: t.splash,
              onChanged: (v) async {
                await t.setSplash(v);
                if (mounted) setState(() {});
              },
            ),
          ),
        ]),
      ],
    );
  }
}
