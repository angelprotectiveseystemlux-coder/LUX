import 'package:flutter/material.dart';
import '../../core/app_theme.dart';
import '../../core/material_you.dart';
import '../../core/palette.dart';
import '../../core/theme.dart';
import '../../core/jalali_utils.dart';
import '../../data/database.dart';
import '../shell/app_shell.dart';
import '../widgets/haptic.dart';
import '../widgets/lux_card.dart';
import '../widgets/lux_chip.dart';
import '../widgets/lux_kit.dart';
import '../widgets/lux_section.dart';
import '../widgets/lux_switch.dart';

/// شخصی‌سازی ظاهر: حالت روشن/تیره، پنج تم، اندازه‌ی متن، ویبره و انیمیشن ورود
class AppearancePage extends StatefulWidget {
  const AppearancePage({super.key});

  @override
  State<AppearancePage> createState() => _AppearancePageState();
}

class _AppearancePageState extends State<AppearancePage> {
  bool _haptics = Haptic.enabled;
  double _hue = HSVColor.fromColor(AppTheme.instance.mySeedColor).hue;

    /// دیگر لازم نیست؛ تم در جا عوض می‌شود و این صفحه بسته نمی‌شود. (برای سازگاری با فراخوانی‌های قبلی ماند.)
  void _willRebuild() {}

  Widget _modeTile(int index, IconData icon, String label) {
    final t = AppTheme.instance;
    final selected = t.mode == index;
    return Expanded(
      child: GestureDetector(
        behavior: HitTestBehavior.opaque,
        onTap: () {
          if (selected) return;
          Haptic.tap();
          _willRebuild();
          t.setMode(index);
        },
        child: Container(
          height: 92,
          margin: const EdgeInsets.symmetric(horizontal: 4),
          decoration: BoxDecoration(
            color: selected ? LuxColors.cardHi : LuxColors.card,
            borderRadius: BorderRadius.circular(LuxColors.r(22)),
            border: Border.all(color: selected ? LuxColors.accent : LuxColors.stroke, width: selected ? 1.6 : 1),
          ),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(icon, size: 28, color: selected ? LuxColors.accent : LuxColors.silverDim),
              const SizedBox(height: 8),
              Text(label, style: LuxText.caption.copyWith(color: selected ? LuxColors.text : LuxColors.textDim)),
              const SizedBox(height: 6),
              Container(
                width: 34,
                height: 3,
                decoration: BoxDecoration(
                  color: selected ? LuxColors.accent : LuxColors.stroke,
                  borderRadius: BorderRadius.circular(LuxColors.r(2)),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _themeTile(int i, double width) {
    final t = AppTheme.instance;
    final def = LuxThemes.all[i];
    final selected = t.themeIndex == i;
    final p = (def.id == MaterialYou.id && selected) ? LuxColors.current : def.of(t.brightness);
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTap: () {
        if (selected) return;
        Haptic.light();
        _willRebuild();
        t.setTheme(i);
      },
      child: Container(
        width: width,
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: p.bg,
          borderRadius: BorderRadius.circular(LuxColors.r(22)),
          border: Border.all(color: selected ? p.accent : p.stroke, width: selected ? 2 : 1),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                _swatch(p.accent),
                const SizedBox(width: 6),
                _swatch(p.card),
                const SizedBox(width: 6),
                _swatch(p.silver),
                const Spacer(),
                if (selected) Icon(Icons.check_circle_rounded, size: 20, color: p.accent),
              ],
            ),
            const SizedBox(height: 14),
            Text(def.name, style: LuxText.heading.copyWith(color: p.text)),
          ],
        ),
      ),
    );
  }

  Widget _swatch(Color c) => Container(
        width: 18,
        height: 18,
        decoration: BoxDecoration(color: c, shape: BoxShape.circle, border: Border.all(color: LuxColors.alpha(LuxColors.silver, 0.25))),
      );

  String _hm(int minutes) {
    final h = (minutes ~/ 60).toString().padLeft(2, '0');
    final m = (minutes % 60).toString().padLeft(2, '0');
    return faDigits('$h:$m');
  }

  Future<void> _pickNight(AppTheme t, bool from) async {
    final cur = from ? t.nightFrom : t.nightTo;
    final r = await showTimePicker(
      context: context,
      initialTime: TimeOfDay(hour: cur ~/ 60, minute: cur % 60),
      helpText: from ? 'شروعِ حالتِ تیره' : 'پایانِ حالتِ تیره (روشن‌شدن)',
    );
    if (r == null || !mounted) return;
    final v = r.hour * 60 + r.minute;
    _willRebuild();
    await (from ? t.setNight(from: v) : t.setNight(to: v));
    if (mounted) setState(() {});
  }

  Future<void> _nightPreset(AppTheme t, int from, int to) async {
    Haptic.tap();
    _willRebuild();
    await t.setNight(from: from, to: to);
    if (mounted) setState(() {});
  }

  List<Widget> _nightSection(AppTheme t) {
    final night = t.isNightAt(DateTime.now());
    final next = t.nextScheduleChange();
    final nextMin = next == null ? null : next.hour * 60 + next.minute;
    final presets = <List<Object>>[
      <Object>['غروب تا صبح', 18 * 60 + 30, 6 * 60],
      <Object>['شبانه', 21 * 60, 7 * 60],
      <Object>['زودتر', 17 * 60, 6 * 60 + 30],
    ];
    return [
      const SizedBox(height: 14),
      LuxCard(
        radius: 28,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('زمان‌بندیِ شب و روز', style: LuxText.heading),
            const SizedBox(height: 4),
            Text('بین این ساعت‌ها برنامه خودکار تیره می‌شود و بقیه‌ی روز روشن است.', style: LuxText.caption),
            const SizedBox(height: 14),
            LuxRow(
              leading: Icon(Icons.dark_mode_rounded, color: LuxColors.accent),
              title: 'تیره شدن از ساعت',
              trailing: Text(_hm(t.nightFrom), style: LuxText.label.copyWith(color: LuxColors.accent)),
              onTap: () => _pickNight(t, true),
            ),
            LuxRow(
              leading: Icon(Icons.light_mode_rounded, color: LuxColors.accent),
              title: 'روشن شدن از ساعت',
              trailing: Text(_hm(t.nightTo), style: LuxText.label.copyWith(color: LuxColors.accent)),
              onTap: () => _pickNight(t, false),
            ),
            const SizedBox(height: 12),
            Wrap(spacing: 8, runSpacing: 8, children: [
              for (final p in presets)
                LuxChip(
                  label: '${p[0]} (${_hm(p[1] as int)} تا ${_hm(p[2] as int)})',
                  selected: t.nightFrom == p[1] && t.nightTo == p[2],
                  onTap: () => _nightPreset(t, p[1] as int, p[2] as int),
                ),
            ]),
            const SizedBox(height: 12),
            Text(
              t.nightFrom == t.nightTo
                  ? 'شروع و پایان یکی است؛ برنامه همیشه روشن می‌ماند.'
                  : 'الان ${night ? 'شب است و برنامه تیره است' : 'روز است و برنامه روشن است'}${nextMin == null ? '' : '؛ تغییرِ بعدی ساعت ${_hm(nextMin)}'}.',
              style: LuxText.caption,
            ),
            const SizedBox(height: 4),
            Text('اگر وسطِ یک صفحه باشی، تغییر بعد از بسته‌شدنِ همان صفحه انجام می‌شود تا کارت نیمه‌کاره نماند.', style: LuxText.caption),
          ],
        ),
      ),
    ];
  }

  Widget _group(String title, Widget child) => Padding(
        padding: const EdgeInsets.only(bottom: 18),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(title, style: LuxText.label),
            const SizedBox(height: 10),
            child,
          ],
        ),
      );

  Widget _chips(List<String> names, int selected, void Function(int) onPick) => Wrap(
        spacing: 8,
        runSpacing: 8,
        children: [
          for (var i = 0; i < names.length; i++)
            LuxChip(
              label: names[i],
              selected: selected == i,
              onTap: () {
                if (selected == i) return;
                _willRebuild();
                onPick(i);
              },
            ),
        ],
      );

  Widget _seedDot(AppTheme t, Color c) {
    final sel = t.mySeed == c.value;
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTap: () {
        if (sel) return;
        Haptic.tap();
        _willRebuild();
        _hue = HSVColor.fromColor(c).hue;
        t.setMy(source: 1, seed: c);
      },
      child: Container(
        width: 40,
        height: 40,
        decoration: BoxDecoration(
          color: c,
          shape: BoxShape.circle,
          border: Border.all(color: sel ? LuxColors.text : Colors.transparent, width: 2.5),
        ),
        child: sel ? const Icon(Icons.check_rounded, size: 20, color: Colors.white) : null,
      ),
    );
  }

  List<Widget> _materialSection(AppTheme t) {
    return [
      const SizedBox(height: 22),
      LuxCard(
        radius: 28,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('شخصی‌سازیِ متریال', style: LuxText.heading),
            const SizedBox(height: 4),
            Text('رنگ، گردی و سبکِ کارت‌ها را خودت تنظیم کن.', style: LuxText.caption),
            const SizedBox(height: 18),
            _group(
              'منبعِ رنگ',
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  _chips(['از والپیپر', 'رنگ دلخواه'], t.mySource, (i) => t.setMy(source: i)),
                  if (t.mySource == 0 && !t.wallpaperSupported)
                    Padding(
                      padding: const EdgeInsets.only(top: 8),
                      child: Text(
                        'رنگِ والپیپر روی این گوشی در دسترس نیست (اندروید ۱۲ به بالا لازم است). فعلاً آبیِ گوگل استفاده می‌شود.',
                        style: LuxText.caption,
                      ),
                    ),
                ],
              ),
            ),
            if (t.mySource == 1) ...[
              _group(
                'رنگ',
                Wrap(spacing: 10, runSpacing: 10, children: [for (final c in MaterialYou.swatches) _seedDot(t, c)]),
              ),
              _group(
                'طیفِ رنگ',
                Slider(
                  value: _hue,
                  min: 0,
                  max: 360,
                  onChanged: (v) => setState(() => _hue = v),
                  onChangeEnd: (v) {
                    _willRebuild();
                    t.setMy(source: 1, seed: HSVColor.fromAHSV(1, v, 0.65, 0.85).toColor());
                  },
                ),
              ),
            ],
            _group('سبکِ رنگ', _chips(MaterialYou.variantNames, t.myVariant, (i) => t.setMy(variant: i))),
            _group('کنتراست', _chips(MaterialYou.contrastNames, t.myContrast, (i) => t.setMy(contrast: i))),
            _group('گردیِ گوشه‌ها', _chips(MaterialYou.roundNames, t.myRound, (i) => t.setMy(round: i))),
            _group('سبکِ کارت‌ها', _chips(MaterialYou.cardNames, t.myCard, (i) => t.setMy(card: i))),
            LuxRow(
              title: 'مشکیِ واقعی (AMOLED)',
              subtitle: 'در حالت تیره پس‌زمینه کاملاً مشکی می‌شود',
              trailing: LuxSwitch(
                value: t.myAmoled,
                onChanged: (v) {
                  _willRebuild();
                  t.setMy(amoled: v);
                },
              ),
            ),
            const SizedBox(height: 12),
            LuxChip(
              label: 'بازگشت به پیش‌فرض',
              selected: false,
              onTap: () {
                _willRebuild();
                _hue = HSVColor.fromColor(MaterialYou.googleBlue).hue;
                t.resetMy();
              },
            ),
          ],
        ),
      ),
    ];
  }

  @override
  Widget build(BuildContext context) {
    final t = AppTheme.instance;
    final sw = MediaQuery.of(context).size.width;
    final w = ((sw > 720 ? 720 : sw) - 40 - 12) / 2;
    return LuxSubPage(
      title: 'ظاهر و شخصی‌سازی',
      subtitle: 'تم، حالت نمایش و حس برنامه',
      children: [
        LuxCard(
          radius: 28,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('پیش‌نمایش', style: LuxText.caption),
              const SizedBox(height: 10),
              Text('عنوانِ نمونه', style: LuxText.title),
              const SizedBox(height: 4),
              Text('این‌طور به نظر می‌رسد وقتی تم و حالتِ فعلی را انتخاب کرده باشی.', style: LuxText.body),
              const SizedBox(height: 14),
              Wrap(spacing: 8, runSpacing: 8, children: [
                LuxChip(label: 'انتخاب‌شده', selected: true, onTap: () {}),
                LuxChip(label: 'عادی', selected: false, onTap: () {}),
              ]),
              const SizedBox(height: 14),
              ClipRRect(
                borderRadius: BorderRadius.circular(LuxColors.r(8)),
                child: LinearProgressIndicator(
                  value: 0.65,
                  minHeight: 8,
                  backgroundColor: LuxColors.cardHi,
                  valueColor: AlwaysStoppedAnimation<Color>(LuxColors.accent),
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 22),
        Padding(
          padding: const EdgeInsetsDirectional.only(start: 6, bottom: 10),
          child: Text('حالت نمایش', style: LuxText.label),
        ),
        Row(
          children: [
            _modeTile(0, Icons.light_mode_rounded, 'روشن'),
            _modeTile(1, Icons.contrast_rounded, 'خودکار'),
            _modeTile(2, Icons.dark_mode_rounded, 'تیره'),
            _modeTile(3, Icons.schedule_rounded, 'شب و روز'),
          ],
        ),
        if (t.mode == 3) ..._nightSection(t),
        const SizedBox(height: 22),
        Padding(
          padding: const EdgeInsetsDirectional.only(start: 6, bottom: 10),
          child: Text('تم رنگی', style: LuxText.label),
        ),
        Wrap(
          spacing: 12,
          runSpacing: 12,
          children: [for (var i = 0; i < LuxThemes.all.length; i++) _themeTile(i, w)],
        ),
        if (t.isMaterial) ..._materialSection(t),
        const SizedBox(height: 22),
        LuxCard(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('اندازه‌ی متن', style: LuxText.heading),
              const SizedBox(height: 12),
              Wrap(spacing: 8, runSpacing: 8, children: [
                for (var i = 0; i < AppTheme.textScaleNames.length; i++)
                  LuxChip(
                    label: AppTheme.textScaleNames[i],
                    selected: t.textScaleIndex == i,
                    onTap: () {
                      if (t.textScaleIndex == i) return;
                      _willRebuild();
                      t.setTextScale(i);
                    },
                  ),
              ]),
            ],
          ),
        ),
        const SizedBox(height: 22),
        LuxSection(title: 'حس و حرکت', children: [
          LuxRow(
            title: 'ویبره‌ی لمسی',
            subtitle: 'لرزشِ کوتاه هنگام لمس دکمه‌ها',
            trailing: LuxSwitch(
              value: _haptics,
              onChanged: (v) async {
                setState(() => _haptics = v);
                Haptic.enabled = v;
                await LuxDb.instance.kvSet('haptics', v ? '1' : '0');
                if (v) Haptic.light();
              },
            ),
          ),
          LuxRow(
            title: 'انیمیشن ورود',
            subtitle: 'نمایشِ لوگوی LUX هر بار که برنامه باز می‌شود',
            trailing: LuxSwitch(
              value: t.splash,
              onChanged: (v) async {
                await t.setSplash(v);
                if (mounted) setState(() {});
              },
            ),
          ),
        ]),
      ],
    );
  }
}
