import 'package:flutter/material.dart';
import '../../core/app_bus.dart';
import '../../core/jalali_utils.dart';
import '../../core/palette.dart';
import '../../core/theme.dart';
import '../../core/util.dart';
import '../../data/database.dart';
import '../widgets/lux_card.dart';
import '../widgets/lux_kit.dart';
import '../widgets/lux_section.dart';
import '../widgets/page_frame.dart';
import 'manage/exam_pages.dart';
import 'manage/plan_pages.dart';
import 'manage/task_pages.dart';

class ExamsPage extends StatefulWidget {
  const ExamsPage({super.key});

  @override
  State<ExamsPage> createState() => _ExamsPageState();
}

class _ExamsPageState extends State<ExamsPage> {
  final Map<String, int> _n = <String, int>{};
  List<Map<String, Object?>> _nextExams = <Map<String, Object?>>[];
  List<Map<String, Object?>> _nextTasks = <Map<String, Object?>>[];

  @override
  void initState() {
    super.initState();
    _load();
    AppBus.data.addListener(_load);
  }

  @override
  void dispose() {
    AppBus.data.removeListener(_load);
    super.dispose();
  }

  Future<void> _load() async {
    final db = LuxDb.instance;
    final m = <String, int>{
      'exams': await db.count('exams', where: "status = 'planned'"),
      'tasks': await db.count('tasks', where: "status = 'open'"),
      'sessions': await db.count('study_sessions', where: 'completed = 1'),
      'slots': await db.count('class_slots'),
    };
    final exams = await db.rawQuery(
      'SELECT e.*, c.name AS course_name FROM exams e JOIN courses c ON c.id = e.course_id '
      "WHERE e.status = 'planned' AND e.at_ts >= ? ORDER BY e.at_ts LIMIT 3",
      [DateTime.now().millisecondsSinceEpoch],
    );
    final tasks = await db.rawQuery(
      'SELECT t.*, c.name AS course_name FROM tasks t LEFT JOIN courses c ON c.id = t.course_id '
      "WHERE t.status = 'open' ORDER BY t.due_ts IS NULL, t.due_ts ASC, t.priority DESC LIMIT 4",
    );
    if (!mounted) return;
    setState(() {
      _n
        ..clear()
        ..addAll(m);
      _nextExams = exams;
      _nextTasks = tasks;
    });
  }

  Widget _count(String key) => Text(faDigits(_n[key] ?? 0), style: LuxText.heading.copyWith(color: LuxColors.accent));

  Widget _chev() => Icon(Icons.chevron_left_rounded, color: LuxColors.silverDim);

  Widget _tr(String key) => Row(mainAxisSize: MainAxisSize.min, children: [_count(key), const SizedBox(width: 6), _chev()]);

  @override
  Widget build(BuildContext context) {
    return PageFrame(
      title: 'برنامه',
      subtitle: 'امتحان‌ها، تقویم، تکالیف و پومودورو',
      trailing: LuxAddButton(
        icon: Icons.event_rounded,
        onTap: () => showExamEditor(context),
      ),
      children: [
        if (_nextExams.isNotEmpty)
          LuxSection(title: 'امتحان‌های نزدیک', children: [
            for (final e in _nextExams)
              LuxRow(
                leading: Icon(Icons.edit_note_rounded, color: LuxColors.accent),
                title: examTitle(e),
                subtitle: '${jalaliLabelWithDay(fromTs(e['at_ts']))} · ${clockLabel(fromTs(e['at_ts']))}',
                trailing: Text(relativeDay(fromTs(e['at_ts'])), style: LuxText.caption.copyWith(color: LuxColors.accent)),
                onTap: () => pushPage<void>(context, const ExamsListPage()),
              ),
          ]),
        if (_nextTasks.isNotEmpty)
          LuxSection(title: 'تکالیف باز', children: [
            for (final t in _nextTasks)
              LuxRow(
                leading: GestureDetector(
                  onTap: () => toggleTask(t),
                  child: Icon(Icons.radio_button_unchecked_rounded, color: priorityColor(asInt(t['priority'], 2)), size: 28),
                ),
                title: asStr(t['title']),
                subtitle: [
                  if (asStr(t['course_name']).isNotEmpty) asStr(t['course_name']),
                  if (t['due_ts'] != null) relativeDay(fromTs(t['due_ts'])),
                ].join(' · '),
                onTap: () => showTaskEditor(context, task: t),
              ),
          ]),
        if (_nextExams.isEmpty && _nextTasks.isEmpty)
          const LuxCard(
            child: LuxEmpty(
              icon: Icons.event_available_rounded,
              title: 'برنامه‌ات خالی است',
              hint: 'از بخش‌های پایین امتحان یا تکلیف اضافه کن. ابتدا باید در تب «درس‌ها» درس‌هایت را بسازی.',
            ),
          ),
        LuxSection(title: 'امتحان‌ها', children: [
          LuxRow(
            title: 'امتحان‌ها',
            subtitle: 'افزودن، ثبت نمره، لغو و یادآور',
            trailing: _tr('exams'),
            onTap: () => pushPage<void>(context, const ExamsListPage()),
          ),
          LuxRow(
            title: 'تقویم',
            subtitle: 'امتحان‌ها و موعدها روزبه‌روز',
            trailing: _chev(),
            onTap: () => pushPage<void>(context, const AgendaPage()),
          ),
        ]),
        LuxSection(title: 'برنامه‌ریزی', children: [
          LuxRow(
            title: 'جدول کلاس‌ها',
            subtitle: 'ساعت کلاس‌های هفتگی',
            trailing: _tr('slots'),
            onTap: () => pushPage<void>(context, const TimetablePage()),
          ),
          LuxRow(
            title: 'تکالیف',
            subtitle: 'موعد، اولویت و یادآور',
            trailing: _tr('tasks'),
            onTap: () => pushPage<void>(context, const TasksPage()),
          ),
        ]),
        LuxSection(title: 'تمرکز', children: [
          LuxRow(
            title: 'پومودورو',
            subtitle: 'تایمر مطالعه و ثبت جلسه‌ها',
            trailing: _tr('sessions'),
            onTap: () => pushPage<void>(context, const PomodoroPage()),
          ),
        ]),
      ],
    );
  }
}
