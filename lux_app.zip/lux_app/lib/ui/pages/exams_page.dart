import 'package:flutter/material.dart';
import '../../core/palette.dart';
import '../../core/theme.dart';
import '../widgets/haptic.dart';
import '../widgets/lux_card.dart';
import '../widgets/lux_kit.dart';
import '../widgets/page_frame.dart';
import 'manage/editors.dart';
import 'manage/exam_pages.dart';
import 'manage/plan_pages.dart';
import 'manage/quick_add.dart';
import 'manage/task_pages.dart';

/// تبِ «برنامه»: چهار بخشِ کنار هم — پیش‌رو، امتحان‌ها، تکالیف، کلاس‌ها
class ExamsPage extends StatefulWidget {
  const ExamsPage({super.key});

  @override
  State<ExamsPage> createState() => _ExamsPageState();
}

class _ExamsPageState extends State<ExamsPage> {
  int _seg = 0;

  static const List<String> _names = <String>['پیش‌رو', 'امتحان‌ها', 'تکالیف', 'کلاس‌ها'];
  static const List<String> _subs = <String>[
    'امتحان‌ها و تکالیفِ روزهای آینده',
    'تاریخ، محدوده، یادآور و نمره',
    'کارهایی که باید انجام بدهی',
    'برنامه‌ی هفتگی کلاس‌ها',
  ];

  void _add() {
    switch (_seg) {
      case 1:
        showExamEditor(context);
        break;
      case 2:
        showTaskEditor(context);
        break;
      case 3:
        showSlotEditor(context);
        break;
      default:
        showQuickAdd(context);
    }
  }

  Widget _segments() {
    return Container(
      padding: const EdgeInsets.all(4),
      decoration: BoxDecoration(
        color: LuxColors.card,
        borderRadius: BorderRadius.circular(22),
        border: Border.all(color: LuxColors.stroke),
      ),
      child: Row(
        children: [
          for (var i = 0; i < _names.length; i++)
            Expanded(
              child: GestureDetector(
                behavior: HitTestBehavior.opaque,
                onTap: () {
                  if (_seg == i) return;
                  Haptic.tap();
                  setState(() => _seg = i);
                },
                child: AnimatedContainer(
                  duration: LuxMotion.fast,
                  padding: const EdgeInsets.symmetric(vertical: 11),
                  decoration: BoxDecoration(
                    color: _seg == i ? LuxColors.alpha(LuxColors.accent, 0.18) : Colors.transparent,
                    borderRadius: BorderRadius.circular(18),
                  ),
                  child: Text(
                    _names[i],
                    textAlign: TextAlign.center,
                    style: LuxText.label.copyWith(color: _seg == i ? LuxColors.accent : LuxColors.textDim),
                  ),
                ),
              ),
            ),
        ],
      ),
    );
  }

  Widget _pomodoroCard() {
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTap: () => pushPage<void>(context, const PomodoroPage()),
      child: LuxCard(
        child: Row(
          children: [
            Icon(Icons.timer_rounded, color: LuxColors.accent, size: 28),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('تایمر تمرکز', style: LuxText.heading),
                  Text('پومودورو؛ مطالعه‌ی بی‌وقفه و ثبتِ خودکارِ جلسه‌ها', style: LuxText.caption),
                ],
              ),
            ),
            Icon(Icons.chevron_left_rounded, color: LuxColors.silverDim),
          ],
        ),
      ),
    );
  }

  Widget _body() {
    switch (_seg) {
      case 1:
        return const ExamsBody();
      case 2:
        return const TasksBody();
      case 3:
        return const TimetableBody();
      default:
        return Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            _pomodoroCard(),
            const SizedBox(height: 16),
            const AgendaBody(),
          ],
        );
    }
  }

  @override
  Widget build(BuildContext context) {
    return PageFrame(
      title: 'برنامه',
      subtitle: _subs[_seg],
      trailing: LuxAddButton(onTap: _add),
      children: [
        _segments(),
        const SizedBox(height: 18),
        _body(),
      ],
    );
  }
}
