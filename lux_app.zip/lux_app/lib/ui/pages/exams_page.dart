import 'package:flutter/material.dart';
import '../../core/app_bus.dart';
import '../../core/jalali_utils.dart';
import '../../core/palette.dart';
import '../../core/theme.dart';
import '../../data/database.dart';
import '../widgets/lux_section.dart';
import '../widgets/page_frame.dart';

class ExamsPage extends StatefulWidget {
  const ExamsPage({super.key});

  @override
  State<ExamsPage> createState() => _ExamsPageState();
}

class _ExamsPageState extends State<ExamsPage> {
  final Map<String, int> _n = {};

  @override
  void initState() {
    super.initState();
    _load();
    AppBus.data.addListener(_load);
  }

  @override
  void dispose() {
    AppBus.data.removeListener(_load);
    super.dispose();
  }

  Future<void> _load() async {
    final db = LuxDb.instance;
    final m = <String, int>{
      'exams': await db.count('exams', where: "status = 'planned'"),
      'tasks': await db.count('tasks', where: "status = 'open'"),
      'sessions': await db.count('study_sessions'),
    };
    if (!mounted) return;
    setState(() => _n
      ..clear()
      ..addAll(m));
  }

  Widget _count(String key) => Text(faDigits(_n[key] ?? 0), style: LuxText.dot(22, color: LuxColors.accent));

  @override
  Widget build(BuildContext context) {
    return PageFrame(
      title: 'برنامه',
      subtitle: 'امتحان‌ها، تقویم، تکالیف و پومودورو',
      children: [
        LuxSection(title: 'امتحان‌ها', children: [
          LuxRow(title: 'امتحان‌های پیش‌رو', subtitle: 'تاریخ، محدوده، یادآور و پرسش بعد از امتحان', trailing: _count('exams')),
          const LuxRow(title: 'تقویم امتحان‌ها', subtitle: 'نمای ماهانه و هفتگی'),
        ]),
        LuxSection(title: 'برنامه‌ریزی', children: [
          const LuxRow(title: 'جدول‌های برنامه‌ریزی', subtitle: 'هفتگی، ماهانه، مرور و ساعت کلاس‌ها'),
          LuxRow(title: 'تکالیف', subtitle: 'موعد، اولویت و یادآور', trailing: _count('tasks')),
        ]),
        LuxSection(title: 'تمرکز', children: [
          LuxRow(title: 'پومودورو', subtitle: 'جلسه‌های مطالعه‌ی ثبت‌شده', trailing: _count('sessions')),
        ]),
      ],
    );
  }
}
