import 'package:flutter/material.dart';
import 'package:shamsi_date/shamsi_date.dart';
import '../../core/app_bus.dart';
import '../../core/jalali_utils.dart';
import '../../core/palette.dart';
import '../../core/theme.dart';
import '../../core/util.dart';
import '../../data/database.dart';
import '../../data/rivalry_repo.dart';
import '../../engine/rivalry.dart';
import '../charts/chart_base.dart';
import '../charts/compare.dart';
import '../widgets/haptic.dart';
import '../widgets/lux_button.dart';
import '../widgets/lux_card.dart';
import '../widgets/lux_chip.dart';
import '../widgets/lux_kit.dart';
import '../widgets/lux_section.dart';
import '../widgets/lux_switch.dart';

String _shortDate(DateTime d) {
  final j = Jalali.fromDateTime(d);
  return '${faDigits(j.day)} ${jalaliMonths[j.month - 1]}';
}

/// رقابت: فهرست رقبا + مقایسه‌ی سطحِ کلی و سطحِ هر درس با نمودارِ خطِ شکسته.
/// نمره‌ی رقبا هنگامِ «ثبت نمره»ی هر امتحان نوشته می‌شود و اختیاری است.
class RivalryPage extends StatefulWidget {
  const RivalryPage({super.key});

  @override
  State<RivalryPage> createState() => _RivalryPageState();
}

class _RivalryPageState extends State<RivalryPage> {
  bool _on = false;
  bool _loaded = false;
  List<Map<String, Object?>> _rivals = <Map<String, Object?>>[];
  List<RivalExam> _exams = <RivalExam>[];
  Map<int, double> _coef = <int, double>{};
  Map<int, int> _counts = <int, int>{};

  final Set<int> _hidden = <int>{};
  bool _common = false;
  int? _courseId;

  @override
  void initState() {
    super.initState();
    _load();
    AppBus.data.addListener(_load);
  }

  @override
  void dispose() {
    AppBus.data.removeListener(_load);
    super.dispose();
  }

  Future<void> _load() async {
    final db = LuxDb.instance;
    final on = await RivalryRepo.enabled();
    final rivals = await RivalryRepo.rivals();
    final exams = <RivalExam>[];
    final coef = <int, double>{};
    final counts = <int, int>{};
    if (on && rivals.isNotEmpty) {
      final sc = await db.query('rival_scores');
      final byExam = <int, Map<int, double>>{};
      for (final r in sc) {
        final rid = asInt(r['rival_id']);
        byExam.putIfAbsent(asInt(r['exam_id']), () => <int, double>{})[rid] = asDouble(r['score']);
        counts[rid] = (counts[rid] ?? 0) + 1;
      }
      final rows = await db.rawQuery(
        'SELECT e.id, e.course_id, e.at_ts, e.max_score, e.weight, e.score, e.title, e.type_name, '
        'c.name AS cname, c.coef AS ccoef FROM exams e JOIN courses c ON c.id = e.course_id '
        "WHERE e.status = 'done' ORDER BY e.at_ts, e.id",
      );
      for (final r in rows) {
        final rv = byExam[asInt(r['id'])] ?? <int, double>{};
        final mine = r['score'] == null ? null : asDouble(r['score']);
        if (mine == null && rv.isEmpty) continue;
        final t = asStr(r['title']).isNotEmpty ? asStr(r['title']) : asStr(r['type_name']);
        final cname = asStr(r['cname']);
        final cid = asInt(r['course_id']);
        coef[cid] = asDouble(r['ccoef'], 1);
        exams.add(RivalExam(
          id: asInt(r['id']),
          courseId: cid,
          courseName: cname,
          title: t.isEmpty ? cname : '$cname · $t',
          at: fromTs(r['at_ts']),
          max: asDouble(r['max_score'], 20),
          weight: asDouble(r['weight'], 1),
          mine: mine,
          rivals: rv,
        ));
      }
    }
    if (!mounted) return;
    setState(() {
      _on = on;
      _rivals = rivals;
      _exams = exams;
      _coef = coef;
      _counts = counts;
      _hidden.removeWhere((id) => !rivals.any((r) => asInt(r['id']) == id));
      _loaded = true;
    });
  }

  Future<void> _toggle(bool v) async {
    await RivalryRepo.setEnabled(v);
    AppBus.bump();
  }

  Future<void> _delete(Map<String, Object?> r) async {
    final ok = await luxConfirm(
      context,
      'حذف ${asStr(r['name'])}؟',
      body: 'نمره‌هایی که برای این رقیب ثبت کرده‌ای هم حذف می‌شود.',
    );
    if (!ok) return;
    await RivalryRepo.deleteRival(asInt(r['id']));
    AppBus.bump();
  }

  Color _color(Map<String, Object?> r) => LuxColors.seriesAt(asInt(r['color'], 1));

  // ───────── بخش‌ها ─────────

  Widget _switchCard() {
    return LuxCard(
      child: Row(
        children: [
          Icon(Icons.emoji_events_rounded, color: LuxColors.accent, size: 30),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('رقابت', style: LuxText.heading),
                const SizedBox(height: 2),
                Text(
                  _on ? 'روشن است' : 'نمره‌های رقبایت را بنویس و خودت را با آن‌ها مقایسه کن',
                  style: LuxText.caption,
                ),
              ],
            ),
          ),
          LuxSwitch(value: _on, onChanged: _toggle),
        ],
      ),
    );
  }

  Widget _offInfo() {
    return LuxCard(
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 6),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Text('رقابت چطور کار می‌کند؟', style: LuxText.title),
            const SizedBox(height: 10),
            Text(
              'بعد از روشن‌کردن، اسم رقبایت را اضافه می‌کنی. هر وقت نمره‌ی یک امتحان را ثبت کردی، زیرش می‌توانی بنویسی هر رقیب چند شده؛ '
              'اگر نمی‌دانی یا نمی‌خواهی، خالی بگذار. بعد نمودارها سطح کلی و سطح هر درس را بین تو و رقبا مقایسه می‌کنند.',
              style: LuxText.body,
            ),
            const SizedBox(height: 10),
            Text('اطلاعاتِ رقابت فقط روی گوشی خودت می‌ماند و با خاموش‌کردن پاک نمی‌شود.', style: LuxText.caption),
          ],
        ),
      ),
    );
  }

  Widget _rivalList() {
    return LuxSection(title: 'رقبا', children: [
      for (final r in _rivals)
        LuxRow(
          leading: Container(width: 14, height: 14, decoration: BoxDecoration(color: _color(r), shape: BoxShape.circle)),
          title: asStr(r['name']),
          subtitle: (_counts[asInt(r['id'])] ?? 0) == 0
              ? 'نمره‌ای ثبت نشده'
              : 'نمره‌ی ${faDigits(_counts[asInt(r['id'])])} امتحان ثبت شده',
          trailing: GestureDetector(
            onTap: () => _delete(r),
            child: Icon(Icons.delete_outline_rounded, color: LuxColors.silverDim),
          ),
          onTap: () => showRivalEditor(context, rival: r),
        ),
      LuxRow(
        leading: Icon(Icons.person_add_alt_1_rounded, color: LuxColors.accent),
        title: 'افزودن رقیب',
        subtitle: 'می‌توانی چند اسم را یک‌جا بنویسی',
        onTap: () => showRivalEditor(context),
      ),
    ]);
  }

  Widget _chipsRow() {
    return Wrap(
      spacing: 8,
      runSpacing: 8,
      children: [
        for (final r in _rivals)
          _PersonChip(
            label: asStr(r['name']),
            color: _color(r),
            on: !_hidden.contains(asInt(r['id'])),
            onTap: () => setState(() {
              final id = asInt(r['id']);
              if (!_hidden.remove(id)) _hidden.add(id);
            }),
          ),
      ],
    );
  }

  Widget _commonSwitch() {
    return LuxCard(
      padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 14),
      child: Row(
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('فقط امتحان‌های مشترک', style: LuxText.heading),
                const SizedBox(height: 2),
                Text('امتحان‌هایی که همه‌ی افراد انتخاب‌شده نمره دارند؛ مقایسه‌ی منصفانه‌تر', style: LuxText.caption),
              ],
            ),
          ),
          LuxSwitch(value: _common, onChanged: (v) => setState(() => _common = v)),
        ],
      ),
    );
  }

  String _avgText(double? v) => v == null ? '—' : fmtNum(v, dec: 2);

  Widget _chartCard({
    required String title,
    required String sub,
    required Widget chart,
    required Widget legend,
    Widget? extra,
  }) {
    return LuxCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Text(title, style: LuxText.heading),
          const SizedBox(height: 2),
          Text(sub, style: LuxText.caption),
          if (extra != null) ...[const SizedBox(height: 12), extra],
          const SizedBox(height: 12),
          chart,
          const SizedBox(height: 12),
          legend,
        ],
      ),
    );
  }

  /// ردیف‌های جدول و نمودارها برای مجموعه‌ی فعلیِ افراد
  List<Widget> _analysis() {
    final visible = [for (final r in _rivals) if (!_hidden.contains(asInt(r['id']))) r];
    final ids = <int>[RivalryCalc.me, for (final r in visible) asInt(r['id'])];
    final exams = _common ? RivalryCalc.common(_exams, ids) : _exams;

    final out = <Widget>[_chipsRow(), const SizedBox(height: 14), _commonSwitch(), const SizedBox(height: 14)];

    if (exams.isEmpty) {
      out.add(LuxCard(
        child: LuxEmpty(
          icon: Icons.stacked_line_chart_rounded,
          title: _common && _exams.isNotEmpty ? 'امتحانِ مشترکی نیست' : 'هنوز نمره‌ای برای مقایسه نیست',
          hint: _common && _exams.isNotEmpty
              ? 'کلید «فقط امتحان‌های مشترک» را خاموش کن یا نمره‌ی بیشتری ثبت کن.'
              : 'وقتی نمره‌ی یک امتحان را ثبت می‌کنی، زیرش می‌توانی نمره‌ی رقبا را هم بنویسی (اختیاری).',
        ),
      ));
      return out;
    }

    // ── سطح کلی ──
    final selfColor = LuxColors.accent;
    final overallSeries = <GapSeries>[
      GapSeries('من', RivalryCalc.overallSeries(exams, RivalryCalc.me, _coef), selfColor, primary: true),
      for (final r in visible) GapSeries(asStr(r['name']), RivalryCalc.overallSeries(exams, asInt(r['id']), _coef), _color(r)),
    ];
    out.add(_chartCard(
      title: 'سطح کلی',
      sub: 'میانگینِ ضریب‌دارِ همه‌ی درس‌ها تا هر امتحان، از ۲۰ — لمس کن تا مقدارها را ببینی',
      chart: PolylineChart(
        labels: [for (final e in exams) e.courseName],
        details: [for (final e in exams) '${e.title} — ${_shortDate(e.at)}'],
        series: overallSeries,
      ),
      legend: ChartLegend(
        labels: [for (final s in overallSeries) s.name],
        colors: [for (final s in overallSeries) s.color],
        trailing: [
          for (final s in overallSeries) _avgText(s.values.isEmpty ? null : s.values.last),
        ],
      ),
    ));
    out.add(const SizedBox(height: 14));

    // ── سطح در هر درس ──
    final courseIds = <int>[];
    final courseNames = <int, String>{};
    for (final e in exams) {
      if (!courseIds.contains(e.courseId)) {
        courseIds.add(e.courseId);
        courseNames[e.courseId] = e.courseName;
      }
    }
    final cid = courseIds.contains(_courseId) ? _courseId! : courseIds.first;
    final cx = [for (final e in exams) if (e.courseId == cid) e];
    final courseSeries = <GapSeries>[
      GapSeries('من', RivalryCalc.courseSeries(cx, RivalryCalc.me), selfColor, primary: true),
      for (final r in visible) GapSeries(asStr(r['name']), RivalryCalc.courseSeries(cx, asInt(r['id'])), _color(r)),
    ];
    final courseAvgs = <double?>[
      RivalryCalc.courseAverage(cx, cid, RivalryCalc.me),
      for (final r in visible) RivalryCalc.courseAverage(cx, cid, asInt(r['id'])),
    ];
    out.add(_chartCard(
      title: 'سطح در هر درس',
      sub: 'نمره‌ی هر امتحانِ درس (از ۲۰). عددِ کنار نام‌ها میانگینِ همان درس است.',
      extra: Wrap(
        spacing: 8,
        runSpacing: 8,
        children: [
          for (final id in courseIds)
            LuxChip(label: courseNames[id] ?? '', selected: id == cid, onTap: () => setState(() => _courseId = id)),
        ],
      ),
      chart: PolylineChart(
        labels: [for (final e in cx) _shortDate(e.at)],
        details: [for (final e in cx) '${e.title} — ${_shortDate(e.at)}'],
        series: courseSeries,
      ),
      legend: ChartLegend(
        labels: [for (final s in courseSeries) s.name],
        colors: [for (final s in courseSeries) s.color],
        trailing: [for (final a in courseAvgs) _avgText(a)],
      ),
    ));
    out.add(const SizedBox(height: 14));

    // ── جدول مقایسه ──
    final people = <_Person>[
      _Person('من', selfColor, RivalryCalc.overall(exams, RivalryCalc.me, _coef), RivalryCalc.count(exams, RivalryCalc.me), true),
      for (final r in visible)
        _Person(
          asStr(r['name']),
          _color(r),
          RivalryCalc.overall(exams, asInt(r['id']), _coef),
          RivalryCalc.count(exams, asInt(r['id'])),
          false,
        ),
    ];
    final mine = people.first.avg;
    final sorted = [...people]..sort((a, b) {
        if (a.avg == null && b.avg == null) return 0;
        if (a.avg == null) return 1;
        if (b.avg == null) return -1;
        return b.avg!.compareTo(a.avg!);
      });
    out.add(LuxCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Text('جدول مقایسه', style: LuxText.heading),
          const SizedBox(height: 2),
          Text('بر اساسِ سطحِ کلی؛ «اختلاف» یعنی رقیب چقدر از تو جلوتر (+) یا عقب‌تر (−) است.', style: LuxText.caption),
          const SizedBox(height: 10),
          for (var i = 0; i < sorted.length; i++) _tableRow(i + 1, sorted[i], mine),
        ],
      ),
    ));
    return out;
  }

  Widget _tableRow(int rank, _Person p, double? mine) {
    String? diff;
    Color diffColor = LuxColors.textDim;
    if (!p.isMe && p.avg != null && mine != null) {
      final d = p.avg! - mine;
      diff = d == 0 ? '۰' : '${d > 0 ? '+' : '−'}${fmtNum(d.abs(), dec: 2)}';
      diffColor = d > 0 ? LuxColors.danger : (d < 0 ? LuxColors.ok : LuxColors.textDim);
    }
    return Container(
      margin: const EdgeInsets.only(top: 8),
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 12),
      decoration: BoxDecoration(
        color: p.isMe ? LuxColors.alpha(LuxColors.accent, 0.12) : LuxColors.cardHi,
        borderRadius: BorderRadius.circular(16),
        border: p.isMe ? Border.all(color: LuxColors.alpha(LuxColors.accent, 0.5)) : null,
      ),
      child: Row(
        children: [
          SizedBox(width: 24, child: Text(faDigits(rank), style: LuxText.heading.copyWith(color: LuxColors.silver))),
          Container(width: 10, height: 10, decoration: BoxDecoration(color: p.color, shape: BoxShape.circle)),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(p.name, style: LuxText.body.copyWith(fontWeight: FontWeight.w700)),
                Text(p.n == 0 ? 'نمره‌ای ثبت نشده' : 'نمره‌ی ${faDigits(p.n)} امتحان', style: LuxText.caption),
              ],
            ),
          ),
          if (diff != null) ...[
            Text(diff, style: LuxText.caption.copyWith(color: diffColor, fontWeight: FontWeight.w700)),
            const SizedBox(width: 12),
          ],
          Text(_avgText(p.avg), style: LuxText.dot(20, color: p.avg == null ? LuxColors.textDim : LuxColors.accent)),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return LuxSubPage(
      title: 'رقابت',
      subtitle: 'مقایسه‌ی تو با رقبایت',
      action: _on ? LuxAddButton(onTap: () => showRivalEditor(context)) : null,
      children: [
        _switchCard(),
        const SizedBox(height: 18),
        if (!_loaded)
          const SizedBox.shrink()
        else if (!_on)
          _offInfo()
        else if (_rivals.isEmpty)
          LuxCard(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                const LuxEmpty(
                  icon: Icons.groups_rounded,
                  title: 'هنوز رقیبی ننوشته‌ای',
                  hint: 'اسم رقبایت را اضافه کن؛ بعد در هر امتحان می‌توانی نمره‌شان را هم بنویسی.',
                ),
                LuxButton(label: 'افزودن رقیب', icon: Icons.person_add_alt_1_rounded, onPressed: () => showRivalEditor(context)),
              ],
            ),
          )
        else ...[
          _rivalList(),
          ..._analysis(),
        ],
      ],
    );
  }
}

class _Person {
  final String name;
  final Color color;
  final double? avg;
  final int n;
  final bool isMe;
  const _Person(this.name, this.color, this.avg, this.n, this.isMe);
}

class _PersonChip extends StatelessWidget {
  final String label;
  final Color color;
  final bool on;
  final VoidCallback onTap;
  const _PersonChip({required this.label, required this.color, required this.on, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTap: () {
        Haptic.tap();
        onTap();
      },
      child: AnimatedContainer(
        duration: LuxMotion.fast,
        curve: LuxMotion.curve,
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 9),
        decoration: BoxDecoration(
          color: on ? LuxColors.alpha(color, 0.16) : LuxColors.cardHi,
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: on ? color : LuxColors.stroke),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(width: 10, height: 10, decoration: BoxDecoration(color: on ? color : LuxColors.textDim, shape: BoxShape.circle)),
            const SizedBox(width: 8),
            Text(label, style: LuxText.label.copyWith(color: on ? LuxColors.text : LuxColors.textDim)),
          ],
        ),
      ),
    );
  }
}

/// افزودن (یک یا چند رقیب با ویرگول/خط جدید) یا ویرایشِ نامِ یک رقیب.
Future<void> showRivalEditor(BuildContext context, {Map<String, Object?>? rival}) {
  final isNew = rival == null;
  final name = TextEditingController(text: asStr(rival?['name']));
  return showLuxSheet<void>(
    context,
    (ctx) => Column(
      mainAxisSize: MainAxisSize.min,
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Text(isNew ? 'رقیب جدید' : 'ویرایش رقیب', style: LuxText.title),
        const SizedBox(height: 16),
        LuxField(
          label: isNew ? 'نامِ رقیب‌ها' : 'نامِ رقیب',
          controller: name,
          hint: isNew ? 'هر اسم را در یک خط یا با ویرگول جدا بنویس' : null,
          maxLines: isNew ? 4 : 1,
        ),
        LuxButton(
          label: 'ذخیره',
          onPressed: () async {
            final names = name.text.split(RegExp(r'[\n,،]')).map((e) => e.trim()).where((e) => e.isNotEmpty).toList();
            if (names.isEmpty) {
              luxNotice(ctx, 'اسم را بنویس.');
              return;
            }
            if (isNew) {
              final added = await RivalryRepo.addRivals(names);
              if (added == 0) {
                if (ctx.mounted) luxNotice(ctx, 'این اسم‌ها از قبل هست.');
                return;
              }
            } else {
              final n = names.first;
              final dup = (await RivalryRepo.rivals()).any(
                (r) => asInt(r['id']) != asInt(rival!['id']) && asStr(r['name']).trim().toLowerCase() == n.toLowerCase(),
              );
              if (dup) {
                if (ctx.mounted) luxNotice(ctx, 'رقیبی با این اسم از قبل هست.');
                return;
              }
              await LuxDb.instance.update('rivals', <String, Object?>{'name': n}, where: 'id = ?', args: [asInt(rival!['id'])]);
            }
            AppBus.bump();
            if (ctx.mounted) Navigator.of(ctx).pop();
          },
        ),
      ],
    ),
  );
}
