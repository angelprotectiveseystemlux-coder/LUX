import 'package:flutter/material.dart';
import 'package:shamsi_date/shamsi_date.dart';
import '../../core/app_bus.dart';
import '../../core/jalali_utils.dart';
import '../../core/palette.dart';
import '../../core/theme.dart';
import '../../core/util.dart';
import '../../data/database.dart';
import '../../data/rivalry_repo.dart';
import '../../data/study_repo.dart';
import '../../engine/rivalry.dart';
import '../charts/chart_base.dart';
import '../charts/compare.dart';
import '../widgets/haptic.dart';
import '../widgets/lux_button.dart';
import '../widgets/lux_card.dart';
import '../widgets/lux_chip.dart';
import '../widgets/lux_kit.dart';
import '../widgets/lux_section.dart';
import '../widgets/lux_switch.dart';

String _shortDate(DateTime d) {
  final j = Jalali.fromDateTime(d);
  return '${faDigits(j.day)} ${jalaliMonths[j.month - 1]}';
}

/// رقابت: فهرست رقبا + مقایسه‌ی سطحِ کلی و سطحِ هر درس با نمودارِ خطِ شکسته.
/// نمره‌ی رقبا هنگامِ «ثبت نمره»ی هر امتحان نوشته می‌شود و اختیاری است.
class RivalryPage extends StatefulWidget {
  const RivalryPage({super.key});

  @override
  State<RivalryPage> createState() => _RivalryPageState();
}

class _RivalryPageState extends State<RivalryPage> {
  bool _on = false;
  bool _loaded = false;
  List<Map<String, Object?>> _rivals = <Map<String, Object?>>[];
  List<RivalExam> _exams = <RivalExam>[];
  Map<int, double> _coef = <int, double>{};
  Map<int, int> _counts = <int, int>{};
  Map<int, Map<int, double>> _behavior = <int, Map<int, double>>{};

  final Set<int> _hidden = <int>{};
  bool _common = false;
  int? _courseId;

  @override
  void initState() {
    super.initState();
    _load();
    AppBus.data.addListener(_load);
  }

  @override
  void dispose() {
    AppBus.data.removeListener(_load);
    super.dispose();
  }

  Future<void> _load() async {
    final db = LuxDb.instance;
    final on = await RivalryRepo.enabled();
    final rivals = await RivalryRepo.rivals();
    final exams = <RivalExam>[];
    final coef = <int, double>{};
    final counts = <int, int>{};
    final behavior = <int, Map<int, double>>{};
    if (on && rivals.isNotEmpty) {
      final sc = await db.query('rival_scores');
      final byExam = <int, Map<int, double>>{};
      for (final r in sc) {
        final rid = asInt(r['rival_id']);
        byExam.putIfAbsent(asInt(r['exam_id']), () => <int, double>{})[rid] = asDouble(r['score']);
        counts[rid] = (counts[rid] ?? 0) + 1;
      }
      final rows = await db.rawQuery(
        'SELECT e.id, e.course_id, e.at_ts, e.max_score, e.weight, e.score, e.title, e.type_name, '
        'c.name AS cname, c.coef AS ccoef FROM exams e JOIN courses c ON c.id = e.course_id '
        "WHERE e.status = 'done' ORDER BY e.at_ts, e.id",
      );
      for (final r in rows) {
        final rv = byExam[asInt(r['id'])] ?? <int, double>{};
        final mine = r['score'] == null ? null : asDouble(r['score']);
        if (mine == null && rv.isEmpty) continue;
        final t = asStr(r['title']).isNotEmpty ? asStr(r['title']) : asStr(r['type_name']);
        final cname = asStr(r['cname']);
        final cid = asInt(r['course_id']);
        coef[cid] = asDouble(r['ccoef'], 1);
        exams.add(RivalExam(
          id: asInt(r['id']),
          courseId: cid,
          courseName: cname,
          title: t.isEmpty ? cname : '$cname · $t',
          at: fromTs(r['at_ts']),
          max: asDouble(r['max_score'], 20),
          weight: asDouble(r['weight'], 1),
          mine: mine,
          rivals: rv,
        ));
      }

      // ── کنفرانس ──
      final courseRows = await db.rawQuery('SELECT id, name, coef FROM courses WHERE archived = 0');
      final cnames = <int, String>{};
      for (final c in courseRows) {
        cnames[asInt(c['id'])] = asStr(c['name']);
        coef.putIfAbsent(asInt(c['id']), () => asDouble(c['coef'], 1));
      }
      final myConf = await db.rawQuery(
        'SELECT course_id, score, max_score, weight, at_ts FROM grades '
        "WHERE kind = 'conference' AND COALESCE(phase, 'continuous') != 'final'",
      );
      final mineSum = <int, double>{};
      final mineW = <int, double>{};
      final mineAt = <int, int>{};
      for (final g in myConf) {
        final cid = asInt(g['course_id']);
        final mx = asDouble(g['max_score'], 20);
        if (mx <= 0) continue;
        final w0 = asDouble(g['weight'], 1);
        final w = w0 <= 0 ? 1.0 : w0;
        mineSum[cid] = (mineSum[cid] ?? 0) + asDouble(g['score']) / mx * 20 * w;
        mineW[cid] = (mineW[cid] ?? 0) + w;
        final ts = asInt(g['at_ts']);
        if (ts > (mineAt[cid] ?? 0)) mineAt[cid] = ts;
      }
      final rivalConf = <int, Map<int, double>>{}; // درس ← رقیب ← نمره
      final confAt = <int, int>{};
      for (final r in await RivalryRepo.conferenceRows()) {
        final cid = asInt(r['course_id']);
        final rid = asInt(r['rival_id']);
        rivalConf.putIfAbsent(cid, () => <int, double>{})[rid] = asDouble(r['score']);
        counts[rid] = (counts[rid] ?? 0) + 1;
        final ts = asInt(r['at_ts']);
        if (ts > (confAt[cid] ?? 0)) confAt[cid] = ts;
      }
      final confCourses = <int>{...mineSum.keys, ...rivalConf.keys};
      for (final cid in confCourses) {
        final cn = cnames[cid];
        if (cn == null) continue;
        final at0 = mineAt[cid] ?? confAt[cid] ?? DateTime.now().millisecondsSinceEpoch;
        final mw = mineW[cid];
        exams.add(RivalExam(
          id: -cid,
          courseId: cid,
          courseName: cn,
          title: '$cn · کنفرانس',
          at: fromTs(at0),
          max: 20,
          weight: 1,
          mine: mw == null ? null : (mineSum[cid] ?? 0) / mw,
          rivals: rivalConf[cid] ?? <int, double>{},
          isConference: true,
        ));
      }
      exams.sort((a, b) {
        final c = a.at.compareTo(b.at);
        return c != 0 ? c : a.id.compareTo(b.id);
      });

      // ── مثبت و منفی (خودت و رقبا با یک قاعده) ──
      final rule = await StudyRepo.behaviorRule();
      final mineCounts = await StudyRepo.behaviorCounts();
      mineCounts.forEach((cid, v) {
        (behavior[RivalryCalc.me] ??= <int, double>{})[cid] = rule.delta(v[0], v[1]);
      });
      (await RivalryRepo.behaviorCounts()).forEach((rid, byCourse) {
        byCourse.forEach((cid, v) {
          (behavior[rid] ??= <int, double>{})[cid] = rule.delta(v[0], v[1]);
        });
      });
    }
    if (!mounted) return;
    setState(() {
      _on = on;
      _behavior = behavior;
      _rivals = rivals;
      _exams = exams;
      _coef = coef;
      _counts = counts;
      _hidden.removeWhere((id) => !rivals.any((r) => asInt(r['id']) == id));
      _loaded = true;
    });
  }

  Future<void> _toggle(bool v) async {
    await RivalryRepo.setEnabled(v);
    AppBus.bump();
  }

  Future<void> _delete(Map<String, Object?> r) async {
    final ok = await luxConfirm(
      context,
      'حذف ${asStr(r['name'])}؟',
      body: 'نمره‌هایی که برای این رقیب ثبت کرده‌ای هم حذف می‌شود.',
    );
    if (!ok) return;
    await RivalryRepo.deleteRival(asInt(r['id']));
    AppBus.bump();
  }

  Color _color(Map<String, Object?> r) => LuxColors.seriesAt(asInt(r['color'], 1));

  // ───────── بخش‌ها ─────────

  Widget _switchCard() {
    return LuxCard(
      child: Row(
        children: [
          Icon(Icons.emoji_events_rounded, color: LuxColors.accent, size: 30),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('رقابت', style: LuxText.heading),
                const SizedBox(height: 2),
                Text(
                  _on ? 'روشن است' : 'نمره‌های رقبایت را بنویس و خودت را با آن‌ها مقایسه کن',
                  style: LuxText.caption,
                ),
              ],
            ),
          ),
          LuxSwitch(value: _on, onChanged: _toggle),
        ],
      ),
    );
  }

  Widget _offInfo() {
    return LuxCard(
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 6),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Text('رقابت چطور کار می‌کند؟', style: LuxText.title),
            const SizedBox(height: 10),
            Text(
              'بعد از روشن‌کردن، اسم رقبایت را اضافه می‌کنی. هر وقت نمره‌ی یک امتحان را ثبت کردی، زیرش می‌توانی بنویسی هر رقیب چند شده؛ '
              'اگر نمی‌دانی یا نمی‌خواهی، خالی بگذار. بعد نمودارها سطح کلی و سطح هر درس را بین تو و رقبا مقایسه می‌کنند.',
              style: LuxText.body,
            ),
            const SizedBox(height: 10),
            Text('اطلاعاتِ رقابت فقط روی گوشی خودت می‌ماند و با خاموش‌کردن پاک نمی‌شود.', style: LuxText.caption),
          ],
        ),
      ),
    );
  }

  Widget _rivalList() {
    return LuxSection(title: 'رقبا', children: [
      for (final r in _rivals)
        LuxRow(
          leading: Container(width: 14, height: 14, decoration: BoxDecoration(color: _color(r), shape: BoxShape.circle)),
          title: asStr(r['name']),
          subtitle: (_counts[asInt(r['id'])] ?? 0) == 0
              ? 'نمره‌ای ثبت نشده · برای مثبت و منفی و کنفرانس لمس کن'
              : 'نمره‌ی ${faDigits(_counts[asInt(r['id'])])} مورد ثبت شده · مثبت و منفی و کنفرانس: لمس کن',
          trailing: GestureDetector(
            onTap: () => _delete(r),
            child: Icon(Icons.delete_outline_rounded, color: LuxColors.silverDim),
          ),
          onTap: () => showRivalEditor(context, rival: r),
        ),
      LuxRow(
        leading: Icon(Icons.person_add_alt_1_rounded, color: LuxColors.accent),
        title: 'افزودن رقیب',
        subtitle: 'می‌توانی چند اسم را یک‌جا بنویسی',
        onTap: () => showRivalEditor(context),
      ),
    ]);
  }

  Widget _chipsRow() {
    return Wrap(
      spacing: 8,
      runSpacing: 8,
      children: [
        for (final r in _rivals)
          _PersonChip(
            label: asStr(r['name']),
            color: _color(r),
            on: !_hidden.contains(asInt(r['id'])),
            onTap: () => setState(() {
              final id = asInt(r['id']);
              if (!_hidden.remove(id)) _hidden.add(id);
            }),
          ),
      ],
    );
  }

  Widget _commonSwitch() {
    return LuxCard(
      padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 14),
      child: Row(
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('فقط امتحان‌های مشترک', style: LuxText.heading),
                const SizedBox(height: 2),
                Text('امتحان‌هایی که همه‌ی افراد انتخاب‌شده نمره دارند؛ مقایسه‌ی منصفانه‌تر', style: LuxText.caption),
              ],
            ),
          ),
          LuxSwitch(value: _common, onChanged: (v) => setState(() => _common = v)),
        ],
      ),
    );
  }

  String _avgText(double? v) => v == null ? '—' : fmtNum(v, dec: 2);

  Widget _chartCard({
    required String title,
    required String sub,
    required Widget chart,
    required Widget legend,
    Widget? extra,
  }) {
    return LuxCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Text(title, style: LuxText.heading),
          const SizedBox(height: 2),
          Text(sub, style: LuxText.caption),
          if (extra != null) ...[const SizedBox(height: 12), extra],
          const SizedBox(height: 12),
          chart,
          const SizedBox(height: 12),
          legend,
        ],
      ),
    );
  }

  /// ردیف‌های جدول و نمودارها برای مجموعه‌ی فعلیِ افراد
  List<Widget> _analysis() {
    final visible = [for (final r in _rivals) if (!_hidden.contains(asInt(r['id']))) r];
    final ids = <int>[RivalryCalc.me, for (final r in visible) asInt(r['id'])];
    final exams = _common ? RivalryCalc.common(_exams, ids) : _exams;

    final out = <Widget>[_chipsRow(), const SizedBox(height: 14), _commonSwitch(), const SizedBox(height: 14)];

    if (exams.isEmpty) {
      out.add(LuxCard(
        child: LuxEmpty(
          icon: Icons.stacked_line_chart_rounded,
          title: _common && _exams.isNotEmpty ? 'امتحانِ مشترکی نیست' : 'هنوز نمره‌ای برای مقایسه نیست',
          hint: _common && _exams.isNotEmpty
              ? 'کلید «فقط امتحان‌های مشترک» را خاموش کن یا نمره‌ی بیشتری ثبت کن.'
              : 'وقتی نمره‌ی یک امتحان را ثبت می‌کنی، زیرش می‌توانی نمره‌ی رقبا را هم بنویسی (اختیاری).',
        ),
      ));
      return out;
    }

    // ── سطح کلی ──
    final selfColor = LuxColors.accent;
    final overallSeries = <GapSeries>[
      GapSeries('من', RivalryCalc.overallSeries(exams, RivalryCalc.me, _coef, behavior: _behavior), selfColor, primary: true),
      for (final r in visible) GapSeries(asStr(r['name']), RivalryCalc.overallSeries(exams, asInt(r['id']), _coef, behavior: _behavior), _color(r)),
    ];
    out.add(_chartCard(
      title: 'سطح کلی',
      sub: 'میانگینِ ضریب‌دارِ همه‌ی درس‌ها تا هر امتحان، از ۲۰ — لمس کن تا مقدارها را ببینی',
      chart: PolylineChart(
        labels: [for (final e in exams) e.courseName],
        details: [for (final e in exams) '${e.title} — ${_shortDate(e.at)}'],
        series: overallSeries,
      ),
      legend: ChartLegend(
        labels: [for (final s in overallSeries) s.name],
        colors: [for (final s in overallSeries) s.color],
        trailing: [
          for (final s in overallSeries) _avgText(s.values.isEmpty ? null : s.values.last),
        ],
      ),
    ));
    out.add(const SizedBox(height: 14));

    // ── سطح در هر درس ──
    final courseIds = <int>[];
    final courseNames = <int, String>{};
    for (final e in exams) {
      if (!courseIds.contains(e.courseId)) {
        courseIds.add(e.courseId);
        courseNames[e.courseId] = e.courseName;
      }
    }
    final cid = courseIds.contains(_courseId) ? _courseId! : courseIds.first;
    final cx = [for (final e in exams) if (e.courseId == cid) e];
    final courseSeries = <GapSeries>[
      GapSeries('من', RivalryCalc.courseSeries(cx, RivalryCalc.me), selfColor, primary: true),
      for (final r in visible) GapSeries(asStr(r['name']), RivalryCalc.courseSeries(cx, asInt(r['id'])), _color(r)),
    ];
    final courseAvgs = <double?>[
      RivalryCalc.courseAverage(cx, cid, RivalryCalc.me, behavior: _behavior),
      for (final r in visible) RivalryCalc.courseAverage(cx, cid, asInt(r['id']), behavior: _behavior),
    ];
    out.add(_chartCard(
      title: 'سطح در هر درس',
      sub: 'نمره‌ی هر امتحانِ درس (از ۲۰)؛ کنفرانس هم یک نقطه است. عددِ کنار نام‌ها میانگینِ همان درس است (با اثرِ مثبت و منفی).',
      extra: Wrap(
        spacing: 8,
        runSpacing: 8,
        children: [
          for (final id in courseIds)
            LuxChip(label: courseNames[id] ?? '', selected: id == cid, onTap: () => setState(() => _courseId = id)),
        ],
      ),
      chart: PolylineChart(
        labels: [for (final e in cx) _shortDate(e.at)],
        details: [for (final e in cx) '${e.title} — ${_shortDate(e.at)}'],
        series: courseSeries,
      ),
      legend: ChartLegend(
        labels: [for (final s in courseSeries) s.name],
        colors: [for (final s in courseSeries) s.color],
        trailing: [for (final a in courseAvgs) _avgText(a)],
      ),
    ));
    out.add(const SizedBox(height: 14));

    // ── جدول مقایسه ──
    final people = <_Person>[
      _Person('من', selfColor, RivalryCalc.overall(exams, RivalryCalc.me, _coef, behavior: _behavior), RivalryCalc.count(exams, RivalryCalc.me), true),
      for (final r in visible)
        _Person(
          asStr(r['name']),
          _color(r),
          RivalryCalc.overall(exams, asInt(r['id']), _coef, behavior: _behavior),
          RivalryCalc.count(exams, asInt(r['id'])),
          false,
        ),
    ];
    final mine = people.first.avg;
    final sorted = [...people]..sort((a, b) {
        if (a.avg == null && b.avg == null) return 0;
        if (a.avg == null) return 1;
        if (b.avg == null) return -1;
        return b.avg!.compareTo(a.avg!);
      });
    out.add(LuxCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Text('جدول مقایسه', style: LuxText.heading),
          const SizedBox(height: 2),
          Text('بر اساسِ سطحِ کلی؛ «اختلاف» یعنی رقیب چقدر از تو جلوتر (+) یا عقب‌تر (−) است.', style: LuxText.caption),
          const SizedBox(height: 10),
          for (var i = 0; i < sorted.length; i++) _tableRow(i + 1, sorted[i], mine),
        ],
      ),
    ));
    return out;
  }

  Widget _tableRow(int rank, _Person p, double? mine) {
    String? diff;
    Color diffColor = LuxColors.textDim;
    if (!p.isMe && p.avg != null && mine != null) {
      final d = p.avg! - mine;
      diff = d == 0 ? '۰' : '${d > 0 ? '+' : '−'}${fmtNum(d.abs(), dec: 2)}';
      diffColor = d > 0 ? LuxColors.danger : (d < 0 ? LuxColors.ok : LuxColors.textDim);
    }
    return Container(
      margin: const EdgeInsets.only(top: 8),
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 12),
      decoration: BoxDecoration(
        color: p.isMe ? LuxColors.alpha(LuxColors.accent, 0.12) : LuxColors.cardHi,
        borderRadius: BorderRadius.circular(16),
        border: p.isMe ? Border.all(color: LuxColors.alpha(LuxColors.accent, 0.5)) : null,
      ),
      child: Row(
        children: [
          SizedBox(width: 24, child: Text(faDigits(rank), style: LuxText.heading.copyWith(color: LuxColors.silver))),
          Container(width: 10, height: 10, decoration: BoxDecoration(color: p.color, shape: BoxShape.circle)),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(p.name, style: LuxText.body.copyWith(fontWeight: FontWeight.w700)),
                Text(p.n == 0 ? 'نمره‌ای ثبت نشده' : 'نمره‌ی ${faDigits(p.n)} امتحان', style: LuxText.caption),
              ],
            ),
          ),
          if (diff != null) ...[
            Text(diff, style: LuxText.caption.copyWith(color: diffColor, fontWeight: FontWeight.w700)),
            const SizedBox(width: 12),
          ],
          Text(_avgText(p.avg), style: LuxText.dot(20, color: p.avg == null ? LuxColors.textDim : LuxColors.accent)),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return LuxSubPage(
      title: 'رقابت',
      subtitle: 'مقایسه‌ی تو با رقبایت',
      action: _on ? LuxAddButton(onTap: () => showRivalEditor(context)) : null,
      children: [
        _switchCard(),
        const SizedBox(height: 18),
        if (!_loaded)
          const SizedBox.shrink()
        else if (!_on)
          _offInfo()
        else if (_rivals.isEmpty)
          LuxCard(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                const LuxEmpty(
                  icon: Icons.groups_rounded,
                  title: 'هنوز رقیبی ننوشته‌ای',
                  hint: 'اسم رقبایت را اضافه کن؛ بعد در هر امتحان می‌توانی نمره‌شان را هم بنویسی.',
                ),
                LuxButton(label: 'افزودن رقیب', icon: Icons.person_add_alt_1_rounded, onPressed: () => showRivalEditor(context)),
              ],
            ),
          )
        else ...[
          _rivalList(),
          ..._analysis(),
        ],
      ],
    );
  }
}

class _Person {
  final String name;
  final Color color;
  final double? avg;
  final int n;
  final bool isMe;
  const _Person(this.name, this.color, this.avg, this.n, this.isMe);
}

class _PersonChip extends StatelessWidget {
  final String label;
  final Color color;
  final bool on;
  final VoidCallback onTap;
  const _PersonChip({required this.label, required this.color, required this.on, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTap: () {
        Haptic.tap();
        onTap();
      },
      child: AnimatedContainer(
        duration: LuxMotion.fast,
        curve: LuxMotion.curve,
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 9),
        decoration: BoxDecoration(
          color: on ? LuxColors.alpha(color, 0.16) : LuxColors.cardHi,
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: on ? color : LuxColors.stroke),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(width: 10, height: 10, decoration: BoxDecoration(color: on ? color : LuxColors.textDim, shape: BoxShape.circle)),
            const SizedBox(width: 8),
            Text(label, style: LuxText.label.copyWith(color: on ? LuxColors.text : LuxColors.textDim)),
          ],
        ),
      ),
    );
  }
}

/// افزودن (یک یا چند رقیب با ویرگول/خط جدید) یا ویرایشِ نامِ یک رقیب.
/// بعد از افزودنِ رقیبِ تازه، اگر امتحانِ گذشته‌ای هست، پیشنهادِ ثبتِ یک‌جای نمره‌های گذشته‌اش داده می‌شود.
Future<void> showRivalEditor(BuildContext context, {Map<String, Object?>? rival}) {
  final isNew = rival == null;
  final name = TextEditingController(text: asStr(rival?['name']));
  return showLuxSheet<void>(
    context,
    (ctx) => Column(
      mainAxisSize: MainAxisSize.min,
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Text(isNew ? 'رقیب جدید' : 'ویرایش رقیب', style: LuxText.title),
        const SizedBox(height: 16),
        LuxField(
          label: isNew ? 'نامِ رقیب‌ها' : 'نامِ رقیب',
          controller: name,
          hint: isNew ? 'هر اسم را در یک خط یا با ویرگول جدا بنویس' : null,
          maxLines: isNew ? 4 : 1,
        ),
        if (!isNew)
          Padding(
            padding: const EdgeInsets.only(bottom: 12),
            child: LuxButton(
              label: 'مثبت و منفی و کنفرانس',
              icon: Icons.thumbs_up_down_rounded,
              onPressed: () {
                Navigator.of(ctx).pop();
                pushPage<void>(context, RivalCoursesPage(rivalId: asInt(rival!['id']), rivalName: asStr(rival!['name'])));
              },
            ),
          ),
        if (!isNew)
          Padding(
            padding: const EdgeInsets.only(bottom: 12),
            child: LuxButton(
              label: 'ثبت نمره‌های امتحان‌های گذشته',
              icon: Icons.history_edu_rounded,
              filled: false,
              onPressed: () {
                Navigator.of(ctx).pop();
                pushPage<void>(context, RivalBackfillPage(rivalId: asInt(rival!['id']), rivalName: asStr(rival!['name'])));
              },
            ),
          ),
        LuxButton(
          label: 'ذخیره',
          onPressed: () async {
            final names = name.text.split(RegExp(r'[\n,،]')).map((e) => e.trim()).where((e) => e.isNotEmpty).toList();
            if (names.isEmpty) {
              luxNotice(ctx, 'اسم را بنویس.');
              return;
            }
            if (isNew) {
              final ids = await RivalryRepo.addRivalIds(names);
              if (ids.isEmpty) {
                if (ctx.mounted) luxNotice(ctx, 'این اسم‌ها از قبل هست.');
                return;
              }
              AppBus.bump();
              if (ctx.mounted) Navigator.of(ctx).pop();
              if (!context.mounted) return;
              final past = (await RivalryRepo.doneExams()).length;
              if (past == 0) return;
              final byId = {for (final r in await RivalryRepo.rivals()) asInt(r['id']): asStr(r['name'])};
              for (final id in ids) {
                if (!context.mounted) return;
                final who = byId[id] ?? '';
                final ok = await luxConfirm(
                  context,
                  'نمره‌های گذشته‌ی $who را هم ثبت می‌کنی؟',
                  body: '${faDigits(past)} امتحان تا الان گرفته شده. همه‌شان یک‌جا و به‌ترتیبِ درس می‌آید؛ نمره‌ای که نمی‌دانی را خالی بگذار.',
                  yes: 'بله، ثبت می‌کنم',
                );
                if (!ok) break;
                if (!context.mounted) return;
                await pushPage<void>(context, RivalBackfillPage(rivalId: id, rivalName: who));
              }
              return;
            } else {
              final n = names.first;
              final dup = (await RivalryRepo.rivals()).any(
                (r) => asInt(r['id']) != asInt(rival!['id']) && asStr(r['name']).trim().toLowerCase() == n.toLowerCase(),
              );
              if (dup) {
                if (ctx.mounted) luxNotice(ctx, 'رقیبی با این اسم از قبل هست.');
                return;
              }
              await LuxDb.instance.update('rivals', <String, Object?>{'name': n}, where: 'id = ?', args: [asInt(rival!['id'])]);
            }
            AppBus.bump();
            if (ctx.mounted) Navigator.of(ctx).pop();
          },
        ),
      ],
    ),
  );
}

// ───────────────────────── ثبتِ یک‌جای نمره‌های گذشته‌ی یک رقیب ─────────────────────────

/// همه‌ی امتحان‌های انجام‌شده، گروه‌بندی‌شده بر اساس درس، با یک خانه‌ی نمره برای رقیب.
/// خالی‌گذاشتن یعنی «نمره‌اش را نمی‌دانم» (و اگر قبلاً نمره‌ای بود، پاک می‌شود).
class RivalBackfillPage extends StatefulWidget {
  final int rivalId;
  final String rivalName;
  const RivalBackfillPage({super.key, required this.rivalId, required this.rivalName});

  @override
  State<RivalBackfillPage> createState() => _RivalBackfillPageState();
}

class _RivalBackfillPageState extends State<RivalBackfillPage> {
  List<Map<String, Object?>> _exams = <Map<String, Object?>>[];
  final Map<int, TextEditingController> _ctl = <int, TextEditingController>{};
  bool _loaded = false;
  bool _saving = false;

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void dispose() {
    for (final c in _ctl.values) {
      c.dispose();
    }
    super.dispose();
  }

  Future<void> _load() async {
    final exams = await RivalryRepo.doneExams();
    final mine = await RivalryRepo.scoresOfRival(widget.rivalId);
    for (final e in exams) {
      final id = asInt(e['id']);
      _ctl[id] = TextEditingController(text: mine.containsKey(id) ? latinNum(mine[id]!) : '');
    }
    if (!mounted) return;
    setState(() {
      _exams = exams;
      _loaded = true;
    });
  }

  Future<void> _save() async {
    if (_saving) return;
    final scores = <int, double?>{};
    for (final e in _exams) {
      final id = asInt(e['id']);
      final max = asDouble(e['max_score'], 20);
      final t = _ctl[id]?.text.trim() ?? '';
      if (t.isEmpty) {
        scores[id] = null;
        continue;
      }
      final v = parseNum(t);
      if (v == null || v < 0 || v > max) {
        final label = asStr(e['title']).isNotEmpty ? asStr(e['title']) : asStr(e['type_name'], 'امتحان');
        luxNotice(context, 'نمره‌ی «${asStr(e['cname'])} · $label» باید بین صفر و ${fmtNum(max)} باشد.');
        return;
      }
      scores[id] = v;
    }
    setState(() => _saving = true);
    var filled = 0;
    for (final e in scores.entries) {
      await RivalryRepo.saveExamScores(e.key, <int, double?>{widget.rivalId: e.value});
      if (e.value != null) filled++;
    }
    AppBus.bump();
    if (!mounted) return;
    luxToast(context, '${faDigits(filled)} نمره برای ${widget.rivalName} ثبت شد.');
    Navigator.of(context).pop();
  }

  Widget _row(Map<String, Object?> e) {
    final id = asInt(e['id']);
    final max = asDouble(e['max_score'], 20);
    final label = asStr(e['title']).isNotEmpty ? asStr(e['title']) : asStr(e['type_name'], 'امتحان');
    final mine = e['score'] == null ? 'نمره‌ی من —' : 'نمره‌ی من ${fmtNum(asDouble(e['score']), dec: 2)} از ${fmtNum(max)}';
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 12),
      child: Row(
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(label, style: LuxText.heading),
                const SizedBox(height: 2),
                Text('${_shortDate(fromTs(e['at_ts']))} · $mine', style: LuxText.caption),
              ],
            ),
          ),
          const SizedBox(width: 12),
          SizedBox(
            width: 92,
            child: TextField(
              controller: _ctl[id],
              keyboardType: TextInputType.number,
              textAlign: TextAlign.center,
              style: LuxText.body,
              decoration: LuxInput.decoration('از ${fmtNum(max)}').copyWith(
                contentPadding: const EdgeInsets.symmetric(horizontal: 8, vertical: 12),
              ),
            ),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    // گروه‌بندی بر اساسِ درس (ترتیبِ پرس‌وجو حفظ می‌شود)
    final groups = <int, List<Map<String, Object?>>>{};
    final names = <int, String>{};
    for (final e in _exams) {
      final cid = asInt(e['course_id']);
      groups.putIfAbsent(cid, () => <Map<String, Object?>>[]).add(e);
      names[cid] = asStr(e['cname']);
    }
    return LuxSubPage(
      title: 'نمره‌های گذشته',
      subtitle: widget.rivalName,
      children: [
        if (_loaded && _exams.isEmpty)
          const LuxCard(child: LuxEmpty(icon: Icons.history_edu_rounded, title: 'هنوز امتحانی با نمره ثبت نشده'))
        else ...[
          LuxCard(
            child: Row(
              children: [
                Icon(Icons.info_outline_rounded, color: LuxColors.accent),
                const SizedBox(width: 12),
                Expanded(
                  child: Text(
                    'نمره‌ی ${widget.rivalName} را در هر امتحانِ گذشته بنویس. هر کدام را که نمی‌دانی خالی بگذار.',
                    style: LuxText.body,
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 16),
          for (final entry in groups.entries)
            LuxSection(title: names[entry.key] ?? '', children: [for (final e in entry.value) _row(e)]),
          LuxButton(label: _saving ? 'در حال ذخیره…' : 'ذخیره‌ی نمره‌ها', icon: Icons.check_rounded, onPressed: _save),
        ],
      ],
    );
  }
}


// ───────────────────────── مثبت و منفی و کنفرانسِ یک رقیب ─────────────────────────

/// برای هر درس: چند مثبت، چند منفی، و نمره‌ی کنفرانسِ این رقیب (از ۲۰).
/// کنفرانسِ خالی یعنی «نمره‌اش را نمی‌دانم». اثرِ مثبت و منفی با همان قاعده‌ای حساب می‌شود که برای خودت تنظیم کرده‌ای.
class RivalCoursesPage extends StatefulWidget {
  final int rivalId;
  final String rivalName;
  const RivalCoursesPage({super.key, required this.rivalId, required this.rivalName});

  @override
  State<RivalCoursesPage> createState() => _RivalCoursesPageState();
}

class _RivalCoursesPageState extends State<RivalCoursesPage> {
  List<Map<String, Object?>> _courses = <Map<String, Object?>>[];
  final Map<int, int> _pos = <int, int>{};
  final Map<int, int> _neg = <int, int>{};
  final Map<int, TextEditingController> _conf = <int, TextEditingController>{};
  bool _loaded = false;
  bool _saving = false;

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void dispose() {
    for (final c in _conf.values) {
      c.dispose();
    }
    super.dispose();
  }

  Future<void> _load() async {
    final courses = await StudyRepo.courses();
    final beh = await RivalryRepo.behaviorOfRival(widget.rivalId);
    final conf = await RivalryRepo.conferenceOfRival(widget.rivalId);
    for (final c in courses) {
      final id = asInt(c['id']);
      final b = beh[id];
      _pos[id] = b == null ? 0 : b[0];
      _neg[id] = b == null ? 0 : b[1];
      final v = conf[id];
      _conf[id] = TextEditingController(text: v == null ? '' : latinNum(v));
    }
    if (!mounted) return;
    setState(() {
      _courses = courses;
      _loaded = true;
    });
  }

  Future<void> _save() async {
    if (_saving) return;
    final behavior = <int, List<int>>{};
    final conference = <int, double?>{};
    for (final c in _courses) {
      final id = asInt(c['id']);
      behavior[id] = <int>[_pos[id] ?? 0, _neg[id] ?? 0];
      final t = _conf[id]?.text.trim() ?? '';
      if (t.isEmpty) {
        conference[id] = null;
        continue;
      }
      final v = parseNum(t);
      if (v == null || v < 0 || v > 20) {
        luxNotice(context, 'کنفرانسِ «${asStr(c['name'])}» باید بین صفر و ۲۰ باشد.');
        return;
      }
      conference[id] = v;
    }
    setState(() => _saving = true);
    await RivalryRepo.saveRivalCourseData(widget.rivalId, behavior: behavior, conference: conference);
    AppBus.bump();
    if (!mounted) return;
    luxToast(context, 'برای ${widget.rivalName} ذخیره شد.');
    Navigator.of(context).pop();
  }

  Widget _stepper(String label, int value, ValueChanged<int> onChanged, Color color) {
    Widget btn(IconData icon, VoidCallback onTap) => GestureDetector(
          behavior: HitTestBehavior.opaque,
          onTap: () {
            Haptic.tap();
            onTap();
          },
          child: Container(
            width: 36,
            height: 36,
            decoration: BoxDecoration(color: LuxColors.cardHi, shape: BoxShape.circle),
            child: Icon(icon, size: 20, color: color),
          ),
        );
    return Expanded(
      child: Column(
        children: [
          Text(label, style: LuxText.caption),
          const SizedBox(height: 6),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              btn(Icons.remove_rounded, () => onChanged(value > 0 ? value - 1 : 0)),
              const SizedBox(width: 12),
              Text(faDigits(value), style: LuxText.heading),
              const SizedBox(width: 12),
              btn(Icons.add_rounded, () => onChanged(value + 1)),
            ],
          ),
        ],
      ),
    );
  }

  Widget _courseCard(Map<String, Object?> c) {
    final id = asInt(c['id']);
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: LuxCard(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Text(asStr(c['name']), style: LuxText.heading),
            const SizedBox(height: 12),
            Row(
              children: [
                _stepper('مثبت', _pos[id] ?? 0, (v) => setState(() => _pos[id] = v), LuxColors.ok),
                _stepper('منفی', _neg[id] ?? 0, (v) => setState(() => _neg[id] = v), LuxColors.danger),
              ],
            ),
            const SizedBox(height: 12),
            TextField(
              controller: _conf[id],
              keyboardType: TextInputType.number,
              style: LuxText.body,
              decoration: LuxInput.decoration('نمره‌ی کنفرانس (از ۲۰) — اگر نمی‌دانی خالی بگذار'),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return LuxSubPage(
      title: 'مثبت و منفی و کنفرانس',
      subtitle: widget.rivalName,
      children: [
        if (_loaded && _courses.isEmpty)
          const LuxCard(child: LuxEmpty(icon: Icons.menu_book_rounded, title: 'هنوز درسی نساخته‌ای'))
        else ...[
          LuxCard(
            child: Row(
              children: [
                Icon(Icons.info_outline_rounded, color: LuxColors.accent),
                const SizedBox(width: 12),
                Expanded(
                  child: Text(
                    'برای هر درس بنویس ${widget.rivalName} چند مثبت و چند منفی دارد و کنفرانسش چند شده. در مقایسه، با همان قاعده‌ی مثبت و منفیِ خودت حساب می‌شود.',
                    style: LuxText.body,
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 16),
          for (final c in _courses) _courseCard(c),
          LuxButton(label: _saving ? 'در حال ذخیره…' : 'ذخیره', icon: Icons.check_rounded, onPressed: _save),
        ],
      ],
    );
  }
}
