import 'dart:async';
import 'package:flutter/material.dart';
import 'package:shamsi_date/shamsi_date.dart';
import '../../core/app_bus.dart';
import '../../core/jalali_utils.dart';
import '../../core/palette.dart';
import '../../core/theme.dart';
import '../../data/database.dart';
import '../../data/profile_repo.dart';
import '../charts/radial.dart';
import '../widgets/lux_card.dart';
import '../widgets/page_frame.dart';

class TodayPage extends StatefulWidget {
  const TodayPage({super.key});

  @override
  State<TodayPage> createState() => _TodayPageState();
}

class _TodayPageState extends State<TodayPage> {
  Profile? _p;
  Map<String, Object?>? _exam;
  int _courses = 0, _books = 0, _exams = 0, _tasks = 0;
  DateTime _now = DateTime.now();
  Timer? _timer;

  @override
  void initState() {
    super.initState();
    _load();
    AppBus.data.addListener(_load);
    _timer = Timer.periodic(const Duration(seconds: 30), (_) {
      if (mounted) setState(() => _now = DateTime.now());
    });
  }

  @override
  void dispose() {
    AppBus.data.removeListener(_load);
    _timer?.cancel();
    super.dispose();
  }

  Future<void> _load() async {
    final db = LuxDb.instance;
    final p = await ProfileRepo.get();
    final rows = await db.rawQuery(
      'SELECT e.id, e.at_ts, e.title, e.type_name, c.name AS course FROM exams e '
      'JOIN courses c ON c.id = e.course_id WHERE e.status = ? AND e.at_ts >= ? ORDER BY e.at_ts LIMIT 1',
      ['planned', DateTime.now().millisecondsSinceEpoch],
    );
    final courses = await db.count('courses', where: 'archived = 0');
    final books = await db.count('books');
    final exams = await db.count('exams', where: "status = 'planned'");
    final tasks = await db.count('tasks', where: "status = 'open'");
    if (!mounted) return;
    setState(() {
      _p = p;
      _exam = rows.isEmpty ? null : rows.first;
      _courses = courses;
      _books = books;
      _exams = exams;
      _tasks = tasks;
    });
  }

  int _daysToBirthday(Profile p) {
    final today = dateOnly(DateTime.now());
    final jNow = Jalali.now();
    DateTime at(int y) {
      final len = jalaliMonthLength(y, p.birthM);
      return Jalali(y, p.birthM, p.birthD > len ? len : p.birthD).toDateTime();
    }

    var target = dateOnly(at(jNow.year));
    if (target.isBefore(today)) target = dateOnly(at(jNow.year + 1));
    return daysBetween(today, target);
  }

  @override
  Widget build(BuildContext context) {
    final p = _p;
    return PageFrame(
      title: p == null ? 'امروز' : 'سلام، ${p.name}',
      subtitle: jalaliLabelWithDay(_now),
      trailing: SizedBox(
        width: 52,
        height: 52,
        child: Image.asset('assets/logo/lux_logo.png', cacheWidth: 160, filterQuality: FilterQuality.medium),
      ),
      children: [
        _examHero(),
        const SizedBox(height: 14),
        if (p != null) _birthday(p),
        const SizedBox(height: 14),
        Row(
          children: [
            Expanded(child: _tile('درس‌ها', _courses, Icons.menu_book_rounded)),
            const SizedBox(width: 12),
            Expanded(child: _tile('کتاب‌ها', _books, Icons.auto_stories_rounded)),
          ],
        ),
        const SizedBox(height: 12),
        Row(
          children: [
            Expanded(child: _tile('امتحان پیش‌رو', _exams, Icons.event_available_rounded)),
            const SizedBox(width: 12),
            Expanded(child: _tile('تکلیف باز', _tasks, Icons.checklist_rounded)),
          ],
        ),
        const SizedBox(height: 18),
        LuxCard(
          child: Row(
            children: [
              const Icon(Icons.wb_twilight_rounded, color: LuxColors.accent),
              const SizedBox(width: 12),
              Expanded(
                child: Text(
                  'بریف روزانه بعد از ثبت درس‌ها و امتحان‌ها فعال می‌شود.',
                  style: LuxText.body.copyWith(color: LuxColors.textDim),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _examHero() {
    final e = _exam;
    String d = '--', h = '--', m = '--';
    String title = 'امتحانی ثبت نشده';
    String sub = 'وقتی امتحانی اضافه کنی، شمارش معکوسش اینجا می‌آید.';
    if (e != null) {
      final at = DateTime.fromMillisecondsSinceEpoch(e['at_ts'] as int);
      var left = at.difference(_now);
      if (left.isNegative) left = Duration.zero;
      d = two(left.inDays);
      h = two(left.inHours % 24);
      m = two(left.inMinutes % 60);
      title = '${e['course']}${(e['title'] as String?)?.isNotEmpty == true ? ' · ${e['title']}' : ''}';
      sub = '${jalaliLabelWithDay(at)} · ساعت ${faDigits(two(at.hour))}:${faDigits(two(at.minute))}';
    }
    Widget unit(String v, String label) => Column(
          children: [
            Text(v, style: LuxText.dot(46)),
            const SizedBox(height: 8),
            Text(label, style: LuxText.caption),
          ],
        );
    return LuxCard(
      padding: const EdgeInsets.fromLTRB(18, 20, 18, 20),
      radius: 28,
      child: Column(
        children: [
          Text(title, style: LuxText.heading, textAlign: TextAlign.center),
          const SizedBox(height: 4),
          Text(sub, style: LuxText.caption, textAlign: TextAlign.center),
          const SizedBox(height: 22),
          Directionality(
            textDirection: TextDirection.ltr,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                unit(d, 'روز'),
                Text(':', style: LuxText.dot(40, color: LuxColors.silverDim)),
                unit(h, 'ساعت'),
                Text(':', style: LuxText.dot(40, color: LuxColors.silverDim)),
                unit(m, 'دقیقه'),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _birthday(Profile p) {
    final days = _daysToBirthday(p);
    return LuxCard(
      child: Row(
        children: [
          RingProgress(
            value: 1 - days / 365,
            size: 72,
            stroke: 7,
            child: const Icon(Icons.cake_rounded, color: LuxColors.accent, size: 26),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(days == 0 ? 'تولدت مبارک!' : 'تا تولدت', style: LuxText.heading),
                const SizedBox(height: 2),
                Text(
                  days == 0 ? 'امروز روز توست.' : '${faDigits(days)} روز مانده',
                  style: LuxText.caption,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _tile(String label, int n, IconData icon) {
    return LuxCard(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(icon, color: LuxColors.silverDim, size: 22),
          const SizedBox(height: 14),
          Text('$n', style: LuxText.dot(34, color: LuxColors.accent)),
          const SizedBox(height: 6),
          Text(label, style: LuxText.caption),
        ],
      ),
    );
  }
}
