import 'dart:async';
import 'package:flutter/material.dart';
import 'package:shamsi_date/shamsi_date.dart';
import '../../core/app_bus.dart';
import '../../core/jalali_utils.dart';
import '../../core/palette.dart';
import '../../core/theme.dart';
import '../../core/util.dart';
import '../../data/database.dart';
import '../../data/study_repo.dart';
import '../../data/profile_repo.dart';
import '../charts/radial.dart';
import '../widgets/lux_button.dart';
import '../widgets/lux_card.dart';
import '../widgets/lux_hub.dart';
import '../widgets/lux_kit.dart';
import '../widgets/profile_button.dart';
import 'manage/exam_pages.dart';
import 'manage/pomodoro_page.dart';
import '../widgets/lux_section.dart';
import '../widgets/page_frame.dart';
import '../../services/daily_brief.dart';
import 'brief_pages.dart';
import 'manage/editors.dart';
import 'manage/task_pages.dart';
import 'manage/week_plan_pages.dart';
import 'calendar_page.dart';
import '../widgets/study_nudges.dart';
import 'smart/smart_today_card.dart';

class TodayPage extends StatefulWidget {
  const TodayPage({super.key});

  @override
  State<TodayPage> createState() => _TodayPageState();
}

class _TodayPageState extends State<TodayPage> {
  Profile? _p;
  Map<String, Object?>? _exam;
  int _courses = 0, _exams = 0, _tasks = 0;
  double? _gpa;
  BriefData? _brief;
  List<Map<String, Object?>> _todaySlots = <Map<String, Object?>>[];
  List<Map<String, Object?>> _todayTasks = <Map<String, Object?>>[];
  DateTime _now = DateTime.now();
  Timer? _timer;

  @override
  void initState() {
    super.initState();
    _load();
    AppBus.data.addListener(_load);
    _timer = Timer.periodic(const Duration(seconds: 30), (_) {
      if (mounted) setState(() => _now = DateTime.now());
    });
  }

  @override
  void dispose() {
    AppBus.data.removeListener(_load);
    _timer?.cancel();
    super.dispose();
  }

  Future<void> _load() async {
    final db = LuxDb.instance;
    final p = await ProfileRepo.get();
    final rows = await db.rawQuery(
      'SELECT e.id, e.at_ts, e.title, e.type_name, c.name AS course FROM exams e '
      'JOIN courses c ON c.id = e.course_id WHERE e.status = ? AND e.at_ts >= ? ORDER BY e.at_ts LIMIT 1',
      ['planned', DateTime.now().millisecondsSinceEpoch],
    );
    final courses = await db.count('courses', where: 'archived = 0');
    final gpa = await StudyRepo.gpa();
    final bs = await DailyBrief.load();
    final brief = await DailyBrief.compose(DateTime.now(), bs);
    final exams = await db.count('exams', where: "status = 'planned'");
    final tasks = await db.count('tasks', where: "status = 'open'");
    final slots = await db.rawQuery(
      'SELECT s.*, c.name AS course_name, c.color AS course_color FROM class_slots s '
      'JOIN courses c ON c.id = s.course_id WHERE s.weekday = ? AND c.archived = 0 ORDER BY s.start_min',
      [weekdayIndex(DateTime.now())],
    );
    final endOfDay = dateOnly(DateTime.now()).add(const Duration(days: 2)).millisecondsSinceEpoch;
    final todayTasks = await db.rawQuery(
      'SELECT t.*, c.name AS course_name FROM tasks t LEFT JOIN courses c ON c.id = t.course_id '
      "WHERE t.status = 'open' AND t.due_ts IS NOT NULL AND t.due_ts < ? ORDER BY t.due_ts LIMIT 5",
      [endOfDay],
    );
    if (!mounted) return;
    setState(() {
      _p = p;
      _exam = rows.isEmpty ? null : rows.first;
      _courses = courses;
      _gpa = gpa;
      _brief = brief;
      _exams = exams;
      _tasks = tasks;
      _todaySlots = slots;
      _todayTasks = todayTasks;
    });
  }


  Widget _quickActions() {
    Widget act(IconData icon, String label, VoidCallback go) => Expanded(
          child: LuxCard(
            padding: const EdgeInsets.symmetric(vertical: 12),
            radius: 20,
            onTap: go,
            child: Column(
              children: [
                Icon(icon, color: LuxColors.accent, size: 24),
                const SizedBox(height: 6),
                Text(label, style: LuxText.caption.copyWith(color: LuxColors.text, fontWeight: FontWeight.w600), maxLines: 1),
              ],
            ),
          ),
        );
    return Row(
      children: [
        act(Icons.timer_rounded, 'تمرکز', () => pushPage<void>(context, const PomodoroPage())),
        const SizedBox(width: 10),
        act(Icons.checklist_rounded, 'تکلیف', () => showTaskEditor(context)),
        const SizedBox(width: 10),
        act(Icons.edit_note_rounded, 'امتحان', () => showExamEditor(context)),
        const SizedBox(width: 10),
        act(Icons.grade_rounded, 'نمره', () => showGradeEditor(context)),
      ],
    );
  }

  Widget _statsStrip() {
    Widget cell(String v, String label, IconData icon) => Expanded(
          child: Column(
            children: [
              Icon(icon, color: LuxColors.silverDim, size: 20),
              const SizedBox(height: 8),
              Text(v, style: LuxText.dot(26, color: LuxColors.accent)),
              const SizedBox(height: 6),
              Text(label, style: LuxText.caption, maxLines: 1, overflow: TextOverflow.ellipsis),
            ],
          ),
        );
    return LuxCard(
      padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 8),
      child: Row(
        children: [
          cell('$_courses', 'درس', Icons.menu_book_rounded),
          cell(_gpa == null ? '—' : latinNum(_gpa!, dec: 2), 'معدل', Icons.insights_rounded),
          cell('$_exams', 'امتحان', Icons.event_available_rounded),
          cell('$_tasks', 'تکلیف باز', Icons.checklist_rounded),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final p = _p;
    return PageFrame(
      title: p == null ? 'امروز' : 'سلام، ${p.name}',
      subtitle: jalaliLabelWithDay(_now),
      trailing: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          LuxIconBtn(icon: Icons.calendar_month_rounded, onTap: () => pushPage<void>(context, const CalendarPage())),
          const SizedBox(width: 10),
          const ProfileButton(),
        ],
      ),
      children: [
        if (_courses == 0)
          LuxCard(
            radius: 28,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Text('به LUX خوش آمدی', style: LuxText.title, textAlign: TextAlign.center),
                const SizedBox(height: 8),
                Text(
                  'سه قدم تا شروع: ۱) درس‌هایت را اضافه کن  ۲) امتحان و تکلیف‌ها را بنویس  ۳) هر روز خلاصه‌ی برنامه‌ات را اینجا ببین.',
                  style: LuxText.body,
                  textAlign: TextAlign.center,
                ),
                const SizedBox(height: 16),
                LuxButton(label: 'ساخت اولین درس', icon: Icons.add_rounded, onPressed: () => showCourseEditor(context)),
              ],
            ),
          ),
        if (_courses == 0) const SizedBox(height: 14),
        _examHero(),
        const SizedBox(height: 14),
        _quickActions(),
        const SizedBox(height: 14),
        const StudyNudges(),
        if (_courses > 0) const SmartTodayCard(),
        if (_courses > 0) const SizedBox(height: 14),
        if (_todaySlots.isNotEmpty)
          LuxSection(title: 'کلاس‌های امروز', children: [
            for (final sl in _todaySlots)
              LuxRow(
                leading: LuxDot(color: courseColor(sl['course_color']), size: 14),
                title: asStr(sl['course_name']),
                subtitle: asStr(sl['room']).isEmpty ? null : 'کلاس ${asStr(sl['room'])}',
                trailing: Text(
                  '${minutesLabel(asInt(sl['start_min']))} – ${minutesLabel(asInt(sl['end_min']))}',
                  style: LuxText.body,
                ),
              ),
          ]),
        if (_todayTasks.isNotEmpty)
          LuxSection(title: 'تکالیفِ امروز و فردا', children: [
            for (final t in _todayTasks)
              LuxRow(
                leading: GestureDetector(
                  onTap: () => toggleTask(t),
                  child: Icon(Icons.radio_button_unchecked_rounded, color: priorityColor(asInt(t['priority'], 2)), size: 28),
                ),
                title: asStr(t['title']),
                subtitle: '${relativeDay(fromTs(t['due_ts']))} · ${clockLabel(fromTs(t['due_ts']))}',
              ),
          ]),
        if (_todaySlots.isEmpty && _todayTasks.isEmpty)
          LuxCard(
            child: Row(
              children: [
                Icon(Icons.wb_twilight_rounded, color: LuxColors.accent),
                const SizedBox(width: 12),
                Expanded(
                  child: Text(
                    _courses == 0
                        ? 'از تب «درس‌ها» اولین درست را اضافه کن؛ بعد امتحان و تکلیف و ساعت کلاس‌ها اینجا می‌آیند.'
                        : 'امروز کلاس یا تکلیفِ نزدیکی نداری.',
                    style: LuxText.body.copyWith(color: LuxColors.textDim),
                  ),
                ),
              ],
            ),
          ),
        const SizedBox(height: 14),
        if (_brief != null) _briefCard(_brief!),
        if (_brief != null) const SizedBox(height: 14),
        if (_courses > 0) const TomorrowBagCard(),
        if (_courses > 0) const SizedBox(height: 14),
        _statsStrip(),
      ],
    );
  }

  Widget _examHero() {
    final e = _exam;
    String d = '--', h = '--', m = '--';
    String title = 'امتحانی ثبت نشده';
    String sub = 'وقتی امتحانی اضافه کنی، شمارش معکوسش اینجا می‌آید.';
    if (e != null) {
      final at = DateTime.fromMillisecondsSinceEpoch(e['at_ts'] as int);
      var left = at.difference(_now);
      if (left.isNegative) left = Duration.zero;
      d = two(left.inDays);
      h = two(left.inHours % 24);
      m = two(left.inMinutes % 60);
      title = '${e['course']}${(e['title'] as String?)?.isNotEmpty == true ? ' · ${e['title']}' : ''}';
      sub = '${jalaliLabelWithDay(at)} · ساعت ${faDigits(two(at.hour))}:${faDigits(two(at.minute))}';
    }
    Widget unit(String v, String label) => Column(
          children: [
            Text(v, style: LuxText.dot(46)),
            const SizedBox(height: 8),
            Text(label, style: LuxText.caption),
          ],
        );
    return LuxCard(
      padding: const EdgeInsets.fromLTRB(18, 20, 18, 20),
      radius: 28,
      child: Column(
        children: [
          Text(title, style: LuxText.heading, textAlign: TextAlign.center),
          const SizedBox(height: 4),
          Text(sub, style: LuxText.caption, textAlign: TextAlign.center),
          const SizedBox(height: 22),
          Directionality(
            textDirection: TextDirection.ltr,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                unit(d, 'روز'),
                Text(':', style: LuxText.dot(40, color: LuxColors.silverDim)),
                unit(h, 'ساعت'),
                Text(':', style: LuxText.dot(40, color: LuxColors.silverDim)),
                unit(m, 'دقیقه'),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _briefCard(BriefData b) {
    final lines = <String>[for (final s in b.sections) ...s.lines].take(3).toList();
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTap: () => pushPage<void>(context, const DailyBriefPage()),
      child: LuxCard(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(Icons.wb_twilight_rounded, color: LuxColors.accent),
                const SizedBox(width: 10),
                Expanded(child: Text(b.title, style: LuxText.heading)),
                Icon(Icons.chevron_left_rounded, color: LuxColors.silverDim),
              ],
            ),
            const SizedBox(height: 4),
            Text(b.summary.isEmpty ? b.dateLine : '${b.dateLine} — ${b.summary}', style: LuxText.caption),
            const SizedBox(height: 10),
            for (final l in lines)
              Padding(
                padding: const EdgeInsets.only(bottom: 3),
                child: Text('• $l', style: LuxText.body, maxLines: 2, overflow: TextOverflow.ellipsis),
              ),
          ],
        ),
      ),
    );
  }
}
