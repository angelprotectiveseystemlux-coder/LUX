import 'package:flutter/material.dart';
import 'package:shamsi_date/shamsi_date.dart';

import '../../core/app_bus.dart';
import '../../core/app_gate.dart';
import '../../core/jalali_utils.dart';
import '../../core/palette.dart';
import '../../core/theme.dart';
import '../../core/util.dart';
import '../../data/calendar_repo.dart';
import '../../data/database.dart';
import '../../data/holidays.dart';
import '../../data/profile_repo.dart';
import '../widgets/day_picker.dart';
import '../widgets/haptic.dart';
import '../widgets/lux_button.dart';
import '../widgets/lux_card.dart';
import '../widgets/lux_chip.dart';
import '../widgets/lux_kit.dart';
import '../widgets/lux_section.dart';

const List<String> kAttKeys = <String>['absent', 'early', 'holiday', 'present'];
const List<String> kAttLabels = <String>['غیبت', 'زود رفتن', 'مدرسه تعطیل بود', 'حضور'];

Color attColor(String k) {
  switch (k) {
    case 'absent':
      return LuxColors.danger;
    case 'early':
      return LuxColors.warn;
    case 'holiday':
      return LuxColors.ok;
    default:
      return LuxColors.silverDim;
  }
}

IconData attIcon(String k) {
  switch (k) {
    case 'absent':
      return Icons.person_off_rounded;
    case 'early':
      return Icons.directions_run_rounded;
    case 'holiday':
      return Icons.celebration_rounded;
    default:
      return Icons.school_rounded;
  }
}

String _fullDay(DateTime d) => '${jalaliLabelWithDay(d)} ${faDigits(Jalali.fromDateTime(d).year)}';

// ───────────────────────── صفحه‌ی غیبت‌ها ─────────────────────────

class AttendancePage extends StatefulWidget {
  const AttendancePage({super.key});

  @override
  State<AttendancePage> createState() => _AttendancePageState();
}

class _AttendancePageState extends State<AttendancePage> {
  List<Map<String, Object?>> _rows = <Map<String, Object?>>[];
  int _filter = 0; // ۰ = همه، ۱.. = kAttKeys[i-1]
  bool _loaded = false;

  @override
  void initState() {
    super.initState();
    _load();
    AppBus.data.addListener(_load);
  }

  @override
  void dispose() {
    AppBus.data.removeListener(_load);
    super.dispose();
  }

  Future<void> _load() async {
    final r = await CalendarRepo.attendanceAll();
    if (!mounted) return;
    setState(() {
      _rows = r;
      _loaded = true;
    });
  }

  DateTime _yearStart() {
    final j = Jalali.now();
    final y = j.month >= 7 ? j.year : j.year - 1;
    return dateOnly(Jalali(y, 7, 1).toDateTime());
  }

  Widget _stat(String value, String label, Color color) {
    return Expanded(
      child: Column(
        children: [
          Text(value, style: LuxText.display.copyWith(fontSize: 30, color: color)),
          const SizedBox(height: 2),
          Text(label, style: LuxText.caption, textAlign: TextAlign.center),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final now = DateTime.now();
    final yearStart = _yearStart();
    final jNow = Jalali.fromDateTime(now);
    final monthStart = dateOnly(Jalali(jNow.year, jNow.month, 1).toDateTime());

    var total = 0;
    var thisYear = 0;
    var thisMonth = 0;
    var early = 0;
    DateTime? last;
    for (final r in _rows) {
      final d = CalendarRepo.parseKey(asStr(r['day']));
      final k = asStr(r['kind']);
      if (k == 'early') early++;
      if (k != 'absent') continue;
      total++;
      if (!d.isBefore(yearStart)) thisYear++;
      if (!d.isBefore(monthStart)) thisMonth++;
      if (last == null || d.isAfter(last)) last = d;
    }

    final shown = <Map<String, Object?>>[
      for (final r in _rows)
        if (_filter == 0 || asStr(r['kind']) == kAttKeys[_filter - 1]) r,
    ];

    String? lastLine;
    if (last != null) {
      final n = daysBetween(last, dateOnly(now));
      lastLine = n <= 0 ? 'آخرین غیبت: امروز' : 'آخرین غیبت: ${faDigits(n)} روز پیش';
    }

    return LuxSubPage(
      title: 'غیبت‌ها',
      subtitle: 'ثبتِ غیبت و حضور در مدرسه',
      action: LuxAddButton(onTap: () => showAttendanceEditor(context)),
      children: [
        LuxCard(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Row(
                children: [
                  _stat(faDigits(thisYear), 'غیبت امسال', thisYear == 0 ? LuxColors.ok : LuxColors.danger),
                  _stat(faDigits(thisMonth), 'غیبت این ماه', LuxColors.text),
                  _stat(faDigits(total), 'کل غیبت‌ها', LuxColors.text),
                ],
              ),
              const SizedBox(height: 12),
              Text(
                [
                  if (lastLine != null) lastLine,
                  if (early > 0) 'زود رفتن: ${faDigits(early)} بار',
                  if (lastLine == null && early == 0) 'هنوز غیبتی ثبت نشده؛ آفرین! 👏',
                ].join(' · '),
                style: LuxText.caption,
                textAlign: TextAlign.center,
              ),
            ],
          ),
        ),
        const SizedBox(height: 16),
        Wrap(
          spacing: 8,
          runSpacing: 8,
          children: [
            LuxChip(label: 'همه', selected: _filter == 0, onTap: () => setState(() => _filter = 0)),
            for (var i = 0; i < kAttKeys.length; i++)
              LuxChip(label: kAttLabels[i], selected: _filter == i + 1, onTap: () => setState(() => _filter = i + 1)),
          ],
        ),
        const SizedBox(height: 16),
        if (_loaded && shown.isEmpty)
          const LuxCard(
            child: LuxEmpty(
              icon: Icons.event_available_rounded,
              title: 'چیزی ثبت نشده',
              hint: 'روزهای مدرسه‌ای که لوکس ازت می‌پرسد، اینجا و توی تقویم ثبت می‌شوند. با «+» هم می‌توانی دستی اضافه کنی.',
            ),
          )
        else if (shown.isNotEmpty)
          LuxSection(
            title: 'ثبت‌ها',
            children: [
              for (final r in shown)
                LuxRow(
                  leading: Icon(attIcon(asStr(r['kind'])), color: attColor(asStr(r['kind']))),
                  title: kAttLabels[kAttKeys.indexOf(asStr(r['kind'])).clamp(0, 3).toInt()],
                  subtitle: [
                    _fullDay(CalendarRepo.parseKey(asStr(r['day']))),
                    if (asStr(r['note']).isNotEmpty) asStr(r['note']),
                  ].join(' · '),
                  onTap: () => showAttendanceEditor(context, record: r),
                ),
            ],
          ),
      ],
    );
  }
}

// ───────────────────────── ثبت / ویرایش دستی ─────────────────────────

Future<void> showAttendanceEditor(BuildContext context, {DateTime? day, Map<String, Object?>? record}) {
  final isNew = record == null;
  var kind = isNew ? 0 : kAttKeys.indexOf(asStr(record['kind'])).clamp(0, 3).toInt();
  var date = isNew ? dateOnly(day ?? DateTime.now()) : CalendarRepo.parseKey(asStr(record['day']));
  final note = TextEditingController(text: isNew ? '' : asStr(record['note']));

  return showLuxSheet<void>(
    context,
    (ctx) => StatefulBuilder(builder: (ctx, setS) {
      return Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Text(isNew ? 'ثبت غیبت و حضور' : 'ویرایش', style: LuxText.title),
          const SizedBox(height: 16),
          LuxChoice(label: 'وضعیت آن روز', options: kAttLabels, selected: kind, onChanged: (i) => setS(() => kind = i)),
          LuxPickField(
            label: 'تاریخ',
            value: _fullDay(date),
            icon: Icons.calendar_month_rounded,
            onTap: () async {
              final r = await pickJalaliDay(ctx, initial: date);
              if (r != null) setS(() => date = r);
            },
          ),
          LuxField(label: 'یادداشت (اختیاری)', controller: note, hint: 'مثلاً مریض بودم'),
          LuxButton(
            label: 'ذخیره',
            onPressed: () async {
              if (!isNew && CalendarRepo.key(date) != asStr(record['day'])) {
                await CalendarRepo.deleteAttendance(asInt(record['id']));
              }
              await CalendarRepo.setAttendance(date, kAttKeys[kind], note: note.text.trim());
              if (ctx.mounted) Navigator.of(ctx).pop();
            },
          ),
          if (!isNew) ...[
            const SizedBox(height: 10),
            LuxButton(
              label: 'حذف این ثبت',
              filled: false,
              onPressed: () async {
                final ok = await luxConfirm(ctx, 'این ثبت حذف شود؟');
                if (!ok) return;
                await CalendarRepo.deleteAttendance(asInt(record['id']));
                if (ctx.mounted) Navigator.of(ctx).pop();
              },
            ),
          ],
        ],
      );
    }),
  );
}

// ───────────────────────── پرسشِ «غیبت کردی؟» ─────────────────────────

class AttendancePrompt {
  AttendancePrompt._();

  static bool _running = false;

  /// روزهای مدرسه (شنبه تا چهارشنبه)، بین ۸ تا ۱۴: اولین باری که برنامه باز می‌شود، لوکس یک بار می‌پرسد.
  static Future<void> maybeAsk(BuildContext context) async {
    if (_running) return;
    _running = true;
    try {
      var waited = 0;
      while (AppGate.blocked && waited < 40) {
        await Future<void>.delayed(const Duration(milliseconds: 500));
        waited++;
        if (!context.mounted) return;
      }
      if (AppGate.blocked || !context.mounted) return;

      final now = DateTime.now();
      if (weekdayIndex(now) > 4) return;
      final mins = now.hour * 60 + now.minute;
      if (mins < 8 * 60 || mins >= 14 * 60) return;
      if (HolidayData.isHoliday(now)) return;

      final k = CalendarRepo.key(now);
      if (await LuxDb.instance.kvGet('att_prompt_day') == k) return;
      if (await CalendarRepo.attendanceOn(now) != null) return;

      final prof = await ProfileRepo.get();
      await LuxDb.instance.kvSet('att_prompt_day', k);
      if (!context.mounted) return;
      await showAttendancePrompt(context, prof?.name ?? '');
    } catch (_) {
      // پرسشِ غیبت هیچ‌وقت نباید جلوی کارِ برنامه را بگیرد.
    } finally {
      _running = false;
    }
  }
}

Future<void> showAttendancePrompt(BuildContext context, String name) {
  Future<void> answer(BuildContext ctx, String kind, String note, String reply) async {
    Haptic.light();
    await CalendarRepo.setAttendance(DateTime.now(), kind, note: note);
    if (ctx.mounted) Navigator.of(ctx).pop();
    if (context.mounted) luxToast(context, reply);
  }

  return showDialog<void>(
    context: context,
    builder: (ctx) => Dialog(
      backgroundColor: LuxColors.card,
      insetPadding: const EdgeInsets.symmetric(horizontal: 22, vertical: 24),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(LuxColors.r(28))),
      child: Padding(
        padding: const EdgeInsets.all(22),
        child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              const Text('🤨', textAlign: TextAlign.center, style: TextStyle(fontSize: 46)),
              const SizedBox(height: 10),
              Text(
                name.trim().isEmpty ? 'نکنه مدرسه نرفتی؟' : '${name.trim()}! نکنه مدرسه نرفتی؟',
                style: LuxText.title,
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 4),
              Text('غیبت کردی؟', style: LuxText.heading.copyWith(color: LuxColors.textDim), textAlign: TextAlign.center),
              const SizedBox(height: 20),
              LuxButton(
                label: 'نوالا تعطیل بود',
                filled: false,
                onPressed: () => answer(ctx, 'holiday', 'مدرسه تعطیل بود', 'آهان، پس تعطیل بوده! توی تقویم ثبتش کردم 🎉'),
              ),
              const SizedBox(height: 10),
              LuxButton(
                label: 'زود اومدم خونه',
                filled: false,
                onPressed: () => answer(ctx, 'early', 'زود از مدرسه برگشتم', 'زود اومدی خونه؟ ثبت شد 🏃'),
              ),
              const SizedBox(height: 10),
              LuxButton(
                label: 'توی مدرسه دست گرفتم گوشیو',
                filled: false,
                onPressed: () => answer(ctx, 'present', 'توی مدرسه با گوشی', 'پس سر کلاسی و داری با لوکس حال می‌کنی 😏 ثبت شد.'),
              ),
              const SizedBox(height: 10),
              LuxButton(
                label: 'آره غیبت کردم 😂',
                onPressed: () => answer(ctx, 'absent', '', 'ثبت شد! بین خودمون می‌مونه 🤫'),
              ),
            ],
          ),
        ),
      ),
    ),
  );
}
