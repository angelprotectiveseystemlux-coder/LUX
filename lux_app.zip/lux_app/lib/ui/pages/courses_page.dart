import 'package:flutter/material.dart';
import '../../core/app_bus.dart';
import '../../core/jalali_utils.dart';
import '../../core/palette.dart';
import '../../core/theme.dart';
import '../../core/util.dart';
import '../../data/database.dart';
import '../../data/study_repo.dart';
import '../widgets/lux_card.dart';
import '../widgets/lux_kit.dart';
import '../widgets/lux_section.dart';
import '../widgets/page_frame.dart';
import 'manage/book_pages.dart';
import 'manage/course_detail_page.dart';
import 'manage/editors.dart';
import 'manage/record_pages.dart';
import 'manage/teachers_page.dart';

class CoursesPage extends StatefulWidget {
  const CoursesPage({super.key});

  @override
  State<CoursesPage> createState() => _CoursesPageState();
}

class _CoursesPageState extends State<CoursesPage> {
  List<Map<String, Object?>> _courses = <Map<String, Object?>>[];
  Map<int, double> _avg = <int, double>{};
  double? _gpa;
  final Map<String, int> _n = <String, int>{};
  bool _loaded = false;

  @override
  void initState() {
    super.initState();
    _load();
    AppBus.data.addListener(_load);
  }

  @override
  void dispose() {
    AppBus.data.removeListener(_load);
    super.dispose();
  }

  Future<void> _load() async {
    final db = LuxDb.instance;
    final courses = await StudyRepo.courses();
    final avg = await StudyRepo.courseAverages();
    final gpa = await StudyRepo.gpa();
    final m = <String, int>{
      'teachers': await db.count('teachers'),
      'books': await db.count('books'),
      'positives': await db.count('class_positives'),
      'warnings': await db.count('discipline_warnings'),
    };
    if (!mounted) return;
    setState(() {
      _courses = courses;
      _avg = avg;
      _gpa = gpa;
      _n
        ..clear()
        ..addAll(m);
      _loaded = true;
    });
  }

  Widget _count(String key) => Text(faDigits(_n[key] ?? 0), style: LuxText.heading.copyWith(color: LuxColors.accent));

  Widget _chev() => const Icon(Icons.chevron_left_rounded, color: LuxColors.silverDim);

  @override
  Widget build(BuildContext context) {
    final rows = <Widget>[];
    for (final c in _courses) {
      final id = asInt(c['id']);
      final avg = _avg[id];
      final teacher = asStr(c['teacher_name']);
      rows.add(LuxRow(
        leading: LuxDot(color: courseColor(c['color']), size: 16),
        title: asStr(c['name']),
        subtitle: 'ضریب ${fmtNum(asDouble(c['coef'], 1))}${teacher.isEmpty ? '' : ' · $teacher'}',
        trailing: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            if (avg != null)
              Text(fmtNum(avg, dec: 2), style: LuxText.heading.copyWith(color: LuxColors.accent))
            else
              Text('—', style: LuxText.caption),
            const SizedBox(width: 6),
            _chev(),
          ],
        ),
        onTap: () => pushPage<void>(context, CourseDetailPage(courseId: id)),
      ));
    }

    return PageFrame(
      title: 'درس‌ها',
      subtitle: _gpa == null ? 'دروس، معلم‌ها، کتاب‌ها و سوابق کلاسی' : 'معدل فعلی: ${fmtNum(_gpa!, dec: 2)}',
      trailing: LuxAddButton(onTap: () => showCourseEditor(context)),
      children: [
        if (_loaded && _courses.isEmpty)
          LuxCard(
            child: LuxEmpty(
              icon: Icons.menu_book_rounded,
              title: 'هنوز درسی اضافه نکرده‌ای',
              hint: 'با دکمه‌ی + بالای صفحه اولین درست را بساز؛ بقیه‌ی بخش‌ها (امتحان، نمره، برنامه) به درس‌ها وصل می‌شوند.',
            ),
          )
        else if (_courses.isNotEmpty)
          LuxSection(title: 'درس‌های من', children: rows),
        LuxSection(title: 'آدم‌ها و منابع', children: [
          LuxRow(
            title: 'معلم‌ها',
            subtitle: 'اطلاعات، سبک تدریس و یادداشت‌ها',
            trailing: Row(mainAxisSize: MainAxisSize.min, children: [_count('teachers'), const SizedBox(width: 6), _chev()]),
            onTap: () => pushPage<void>(context, const TeachersPage()),
          ),
          LuxRow(
            title: 'کتاب‌ها',
            subtitle: 'فصل‌ها، صفحه‌ی فعلی و پیشرفت',
            trailing: Row(mainAxisSize: MainAxisSize.min, children: [_count('books'), const SizedBox(width: 6), _chev()]),
            onTap: () => pushPage<void>(context, const BooksPage()),
          ),
        ]),
        LuxSection(title: 'سوابق مدرسه', children: [
          LuxRow(
            title: 'مثبت‌های سر کلاس',
            subtitle: 'ثبت و دیدنِ مثبت‌ها در هر درس',
            trailing: Row(mainAxisSize: MainAxisSize.min, children: [_count('positives'), const SizedBox(width: 6), _chev()]),
            onTap: () => pushPage<void>(context, const PositivesPage()),
          ),
          LuxRow(
            title: 'اخطارهای مدرسه',
            subtitle: 'اخطار انضباطی و پیگیری آن',
            trailing: Row(mainAxisSize: MainAxisSize.min, children: [_count('warnings'), const SizedBox(width: 6), _chev()]),
            onTap: () => pushPage<void>(context, const WarningsPage()),
          ),
        ]),
      ],
    );
  }
}
