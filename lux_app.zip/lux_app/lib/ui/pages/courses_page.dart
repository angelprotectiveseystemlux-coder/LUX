import 'package:flutter/material.dart';
import '../../core/app_bus.dart';
import '../../core/jalali_utils.dart';
import '../../core/palette.dart';
import '../../core/theme.dart';
import '../../data/database.dart';
import '../widgets/lux_section.dart';
import '../widgets/page_frame.dart';

class CoursesPage extends StatefulWidget {
  const CoursesPage({super.key});

  @override
  State<CoursesPage> createState() => _CoursesPageState();
}

class _CoursesPageState extends State<CoursesPage> {
  final Map<String, int> _n = {};

  @override
  void initState() {
    super.initState();
    _load();
    AppBus.data.addListener(_load);
  }

  @override
  void dispose() {
    AppBus.data.removeListener(_load);
    super.dispose();
  }

  Future<void> _load() async {
    final db = LuxDb.instance;
    final m = <String, int>{
      'courses': await db.count('courses', where: 'archived = 0'),
      'teachers': await db.count('teachers'),
      'books': await db.count('books'),
      'positives': await db.count('class_positives'),
      'warnings': await db.count('discipline_warnings'),
    };
    if (!mounted) return;
    setState(() => _n
      ..clear()
      ..addAll(m));
  }

  Widget _count(String key) => Text(faDigits(_n[key] ?? 0), style: LuxText.dot(22, color: LuxColors.accent));

  @override
  Widget build(BuildContext context) {
    return PageFrame(
      title: 'درس‌ها',
      subtitle: 'دروس، معلم‌ها، کتاب‌ها و سوابق کلاسی',
      children: [
        LuxSection(title: 'دروس و معلم‌ها', children: [
          LuxRow(title: 'دروس', subtitle: 'ضریب، سختی، ارزیابی‌ها و ساعت کلاس', trailing: _count('courses')),
          LuxRow(title: 'معلم‌ها', subtitle: 'اطلاعات، سبک تدریس و صندوق سؤال', trailing: _count('teachers')),
        ]),
        LuxSection(title: 'کتاب‌ها', children: [
          LuxRow(title: 'کتاب‌ها و خواننده‌ی PDF', subtitle: 'فصل‌ها، پیشرفت و نمودار هر کتاب', trailing: _count('books')),
        ]),
        LuxSection(title: 'سوابق مدرسه', children: [
          LuxRow(title: 'مثبت‌های سر کلاس', subtitle: 'ثبت و تحلیل مثبت‌ها در هر درس', trailing: _count('positives')),
          LuxRow(title: 'اخطارهای مدرسه', subtitle: 'اخطار انضباطی و امنیتی با پیگیری', trailing: _count('warnings')),
        ]),
      ],
    );
  }
}
