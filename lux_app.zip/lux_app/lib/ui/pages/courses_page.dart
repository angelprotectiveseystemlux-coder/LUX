import 'package:flutter/material.dart';
import '../../core/app_bus.dart';
import '../../core/jalali_utils.dart';
import '../../core/palette.dart';
import '../../core/theme.dart';
import '../../core/util.dart';
import '../../data/database.dart';
import '../../data/study_repo.dart';
import '../widgets/lux_button.dart';
import '../widgets/lux_card.dart';
import '../widgets/lux_kit.dart';
import '../widgets/lux_section.dart';
import '../widgets/page_frame.dart';
import 'manage/course_detail_page.dart';
import 'manage/curriculum_sheet.dart';
import 'manage/editors.dart';
import 'manage/record_pages.dart';
import 'manage/teachers_page.dart';
import 'manage/week_plan_pages.dart';
import 'calendar_page.dart';
import 'attendance_page.dart';
import '../../data/rivalry_repo.dart';
import 'rivalry_page.dart';

class CoursesPage extends StatefulWidget {
  const CoursesPage({super.key});

  @override
  State<CoursesPage> createState() => _CoursesPageState();
}

class _CoursesPageState extends State<CoursesPage> {
  List<Map<String, Object?>> _courses = <Map<String, Object?>>[];
  Map<int, double> _avg = <int, double>{};
  Map<int, int> _bookCount = <int, int>{};
  Map<int, DateTime> _nextExam = <int, DateTime>{};
  double? _gpa;
  final Map<String, int> _n = <String, int>{};
  bool _loaded = false;
  bool _offered = false;
  bool _rivalOn = false;

  @override
  void initState() {
    super.initState();
    _load();
    AppBus.data.addListener(_load);
  }

  @override
  void dispose() {
    AppBus.data.removeListener(_load);
    super.dispose();
  }

  Future<void> _load() async {
    final db = LuxDb.instance;
    final courses = await StudyRepo.courses();
    final avg = await StudyRepo.courseAverages();
    final gpa = await StudyRepo.gpa();
    final bc = await db.rawQuery('SELECT course_id, COUNT(*) AS n FROM books WHERE course_id IS NOT NULL GROUP BY course_id');
    final books = <int, int>{for (final r in bc) asInt(r['course_id']): asInt(r['n'])};
    final ex = await db.rawQuery(
      "SELECT course_id, MIN(at_ts) AS t FROM exams WHERE status = 'planned' AND at_ts >= ? GROUP BY course_id",
      [DateTime.now().millisecondsSinceEpoch],
    );
    final next = <int, DateTime>{for (final r in ex) asInt(r['course_id']): fromTs(r['t'])};
    final m = <String, int>{
      'teachers': await db.count('teachers'),
      'positives': await db.count('class_positives'),
      'warnings': await db.count('discipline_warnings'),
      'rivals': await db.count('rivals'),
    };
    final rivalOn = await RivalryRepo.enabled();
    if (!mounted) return;
    setState(() {
      _courses = courses;
      _avg = avg;
      _gpa = gpa;
      _bookCount = books;
      _nextExam = next;
      _n
        ..clear()
        ..addAll(m);
      _rivalOn = rivalOn;
      _loaded = true;
    });
    if (!_offered) {
      _offered = true;
      // بعد از اولین نمایشِ صفحه، یک‌بار می‌پرسد درس‌ها از روی فهرست اضافه شوند یا نه.
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (mounted) offerCurriculumOnce(context);
      });
    }
  }

  Future<void> _openCurriculum() async {
    final n = await showCurriculumSheet(context);
    if (n > 0 && mounted) luxToast(context, '${faDigits(n)} درس اضافه شد.');
  }

  Widget _tag(String text, {bool accent = false}) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      decoration: BoxDecoration(
        color: accent ? LuxColors.alpha(LuxColors.accent, 0.14) : LuxColors.cardHi,
        borderRadius: BorderRadius.circular(10),
      ),
      child: Text(text, style: LuxText.caption.copyWith(color: accent ? LuxColors.accent : LuxColors.textDim)),
    );
  }

  Widget _courseCard(Map<String, Object?> c) {
    final id = asInt(c['id']);
    final avg = _avg[id];
    final teacher = asStr(c['teacher_name']);
    final books = _bookCount[id] ?? 0;
    final exam = _nextExam[id];
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: GestureDetector(
        behavior: HitTestBehavior.opaque,
        onTap: () => pushPage<void>(context, CourseDetailPage(courseId: id)),
        child: LuxCard(
          child: Row(
            children: [
              Container(
                width: 6,
                height: 64,
                decoration: BoxDecoration(color: courseColor(c['color']), borderRadius: BorderRadius.circular(3)),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(asStr(c['name']), style: LuxText.heading),
                    if (teacher.isNotEmpty) Text(teacher, style: LuxText.caption),
                    const SizedBox(height: 8),
                    Wrap(spacing: 6, runSpacing: 6, children: [
                      _tag('ضریب ${fmtNum(asDouble(c['coef'], 1))}'),
                      if (books > 0) _tag('${faDigits(books)} کتاب'),
                      if (exam != null) _tag('امتحان ${relativeDay(exam)}', accent: true),
                    ]),
                  ],
                ),
              ),
              const SizedBox(width: 10),
              Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(avg == null ? '—' : latinNum(avg, dec: 2), style: LuxText.dot(24, color: avg == null ? LuxColors.textDim : LuxColors.accent)),
                  Text('میانگین', style: LuxText.caption),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _firstRun() {
    return LuxCard(
      radius: 28,
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 8),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Icon(Icons.menu_book_rounded, size: 44, color: LuxColors.accent),
            const SizedBox(height: 12),
            Text('از اینجا شروع کن', style: LuxText.title, textAlign: TextAlign.center),
            const SizedBox(height: 8),
            Text(
              'اول درس‌هایت را اضافه کن. بعد برای هر درس می‌توانی امتحان، تکلیف، نمره و کتاب ثبت کنی؛ همه‌چیز همان‌جا کنار هم است.',
              style: LuxText.body,
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 18),
            LuxButton(label: 'ساخت اولین درس', icon: Icons.add_rounded, onPressed: () => showCourseEditor(context)),
            const SizedBox(height: 10),
            LuxButton(
              label: 'افزودن از فهرست درس‌های پایه‌ی من',
              icon: Icons.playlist_add_rounded,
              filled: false,
              onPressed: _openCurriculum,
            ),
          ],
        ),
      ),
    );
  }

  /// میانبرهای بالای صفحه (قبلاً انتهای فهرستِ درس‌ها بودند و دور از دسترس).
  Widget _link(IconData icon, String title, VoidCallback onTap, {String? badge}) {
    return Expanded(
      child: LuxCard(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
        radius: 20,
        onTap: onTap,
        child: Row(
          children: [
            Icon(icon, color: LuxColors.accent, size: 22),
            const SizedBox(width: 10),
            Expanded(child: Text(title, style: LuxText.label, maxLines: 1, overflow: TextOverflow.ellipsis)),
            if (badge != null) Text(badge, style: LuxText.caption.copyWith(color: LuxColors.accent)),
          ],
        ),
      ),
    );
  }

  Widget _quickLinks() {
    Widget pair(Widget a, Widget b) => Padding(
          padding: const EdgeInsets.only(bottom: 10),
          child: Row(children: [a, const SizedBox(width: 10), b]),
        );
    return Column(
      children: [
        pair(
          _link(Icons.calendar_view_week_rounded, 'برنامه‌ی هفتگی', () => pushPage<void>(context, const WeekPlanPage())),
          _link(
            Icons.emoji_events_rounded,
            'رقابت',
            () => pushPage<void>(context, const RivalryPage()),
            badge: _rivalOn ? faDigits(_n['rivals'] ?? 0) : 'خاموش',
          ),
        ),
        pair(
          _link(Icons.thumb_up_alt_rounded, 'مثبت و منفی', () => pushPage<void>(context, const PositivesPage()),
              badge: faDigits(_n['positives'] ?? 0)),
          _link(Icons.report_gmailerrorred_rounded, 'اخطارها', () => pushPage<void>(context, const WarningsPage()),
              badge: faDigits(_n['warnings'] ?? 0)),
        ),
        pair(
          _link(Icons.person_rounded, 'معلم‌ها', () => pushPage<void>(context, const TeachersPage()),
              badge: faDigits(_n['teachers'] ?? 0)),
          _link(Icons.playlist_add_rounded, 'درس‌های آماده', _openCurriculum),
        ),
        pair(
          _link(Icons.calendar_month_rounded, 'تقویم', () => pushPage<void>(context, const CalendarPage())),
          _link(Icons.person_off_rounded, 'غیبت‌ها', () => pushPage<void>(context, const AttendancePage())),
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return PageFrame(
      title: 'درس‌ها',
      subtitle: _gpa == null ? 'هر درس همه‌چیزش را یک‌جا دارد' : 'معدل فعلی: ${fmtNum(_gpa!, dec: 2)}',
      trailing: LuxAddButton(onTap: () => showCourseEditor(context)),
      children: [
        _quickLinks(),
        const SizedBox(height: 16),
        if (_loaded && _courses.isEmpty) _firstRun(),
        for (final c in _courses) _courseCard(c),
      ],
    );
  }
}
