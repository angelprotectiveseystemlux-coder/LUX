import 'package:flutter/material.dart';
import '../../core/jalali_utils.dart';
import '../../core/palette.dart';
import '../../core/theme.dart';
import '../charts/cartesian.dart';
import '../charts/chart_base.dart';
import '../charts/heatmap.dart';
import '../charts/radial.dart';
import '../widgets/lux_card.dart';
import '../widgets/page_frame.dart';

/// نمایشگاهِ نمودارها با داده‌ی نمونه — برای دیدنِ ظاهر و سنجشِ روانی.
/// بعد از ثبت نمره‌ها، همین نمودارها با داده‌ی واقعی پر می‌شوند.
class AnalysisPage extends StatelessWidget {
  const AnalysisPage({super.key});

  Widget _block(String title, String? sub, Widget chart) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 16),
      child: LuxCard(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(title, style: LuxText.heading),
            if (sub != null) ...[
              const SizedBox(height: 2),
              Text(sub, style: LuxText.caption),
            ],
            const SizedBox(height: 16),
            chart,
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final courses = const ['ریاضی', 'ادبیات', 'عربی', 'دینی', 'تاریخ', 'زبان'];
    final scores = const [17.5, 15.0, 13.25, 18.0, 14.5, 16.0];

    final heat = <DateTime, double>{};
    final today = dateOnly(DateTime.now());
    for (var i = 0; i < 100; i++) {
      final d = DateTime(today.year, today.month, today.day - i);
      if (i % 4 == 3) continue;
      heat[d] = ((i * 37) % 11) / 10.0 + 0.2;
    }

    return PageFrame(
      title: 'تحلیل',
      subtitle: 'نمونه‌ی ظاهر نمودارها؛ داده‌ی واقعی بعد از ثبت نمره‌ها و جلسه‌ها',
      children: [
        _block(
          'نمره‌ی درس‌ها',
          'ستونی — برای دیدن عدد، لمس کن',
          ColumnChart(
            data: [for (var i = 0; i < courses.length; i++) ChartPoint(courses[i], scores[i])],
            maxY: 20,
          ),
        ),
        _block(
          'ساعت مطالعه در هر درس',
          'میله‌ای افقی',
          BarChart(
            data: const [
              ChartPoint('ریاضی', 12.5),
              ChartPoint('ادبیات', 9),
              ChartPoint('عربی', 7.5),
              ChartPoint('دینی', 4),
              ChartPoint('تاریخ', 6),
            ],
          ),
        ),
        _block(
          'روند معدل',
          'خطی با ناحیه — ماه‌به‌ماه',
          LineChart(
            labels: const ['مهر', 'آبان', 'آذر', 'دی', 'بهمن', 'اسفند'],
            series: const [
              LineSeries('معدل', [15.2, 15.8, 15.5, 16.4, 16.9, 17.3], LuxColors.accent),
              LineSeries('هدف', [16, 16, 16, 17, 17, 17], LuxColors.silverDim),
            ],
            minY: 12,
            maxY: 20,
          ),
        ),
        _block(
          'تقسیم زمان هفته',
          'دایره‌ای / دونات',
          const PieChart(
            data: [
              ChartPoint('مطالعه', 14),
              ChartPoint('مرور', 6),
              ChartPoint('تست', 5),
              ChartPoint('تکلیف', 4),
            ],
            centerTop: '۲۹',
            centerBottom: 'ساعت',
          ),
        ),
        _block(
          'پیشرفت کتاب و گیج آمادگی',
          'حلقه و گیج',
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              RingProgress(
                value: 0.64,
                size: 120,
                child: Text('۶۴٪', style: LuxText.heading),
              ),
              RingProgress.gauge(
                value: 0.78,
                size: 130,
                child: Text('۷٫۸', style: LuxText.heading),
              ),
            ],
          ),
        ),
        _block(
          'نقاط قوت و ضعف',
          'رادار',
          const RadarChart(
            labels: ['ریاضی', 'ادبیات', 'عربی', 'دینی', 'تاریخ', 'زبان'],
            values: [0.88, 0.75, 0.62, 0.9, 0.7, 0.8],
          ),
        ),
        _block(
          'فشار هفته‌ها',
          'نقشه‌ی گرمایی تقویمی — هر خانه یک روز',
          HeatmapCalendar(values: heat, weeks: 14),
        ),
        _block(
          'مثبت و اخطار در هر ماه',
          'ستونی انباشته',
          StackedColumnChart(
            labels: const ['مهر', 'آبان', 'آذر', 'دی', 'بهمن'],
            parts: const [
              [5, 1],
              [7, 0],
              [4, 2],
              [8, 1],
              [6, 0],
            ],
            colors: const [LuxColors.accent, LuxColors.silverDim],
          ),
        ),
        _block(
          'ساعت مطالعه و نمره',
          'پراکندگی با خط روند',
          ScatterChart(
            points: const [
              Offset(2, 13),
              Offset(3, 14),
              Offset(4, 14.5),
              Offset(5, 16),
              Offset(6, 15.5),
              Offset(8, 18),
              Offset(9, 17.5),
            ],
          ),
        ),
      ],
    );
  }
}
