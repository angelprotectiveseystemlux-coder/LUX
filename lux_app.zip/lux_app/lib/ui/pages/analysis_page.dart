import 'package:flutter/material.dart';
import 'package:shamsi_date/shamsi_date.dart';
import '../../core/app_bus.dart';
import '../../core/jalali_utils.dart';
import '../../core/palette.dart';
import '../../core/theme.dart';
import '../../data/database.dart';
import '../charts/cartesian.dart';
import '../charts/chart_base.dart';
import '../charts/heatmap.dart';
import '../charts/radial.dart';
import '../widgets/lux_card.dart';
import '../widgets/page_frame.dart';

/// تحلیل — فقط با داده‌ی واقعیِ خودت.
/// تا وقتی نمره یا جلسه‌ی مطالعه‌ای ثبت نکرده‌ای، هیچ نموداری ساخته نمی‌شود.
class AnalysisPage extends StatefulWidget {
  const AnalysisPage({super.key});

  @override
  State<AnalysisPage> createState() => _AnalysisPageState();
}

class _Data {
  List<ChartPoint> courseScores = const [];
  List<ChartPoint> studyHours = const [];
  List<String> trendLabels = const [];
  List<double> trendValues = const [];
  List<ChartPoint> kindSplit = const [];
  double totalHours = 0;
  Map<DateTime, double> heat = const {};
  List<String> pwLabels = const [];
  List<List<double>> pwParts = const [];

  bool get isEmpty =>
      courseScores.isEmpty &&
      studyHours.isEmpty &&
      trendValues.isEmpty &&
      kindSplit.isEmpty &&
      heat.isEmpty &&
      pwLabels.isEmpty;
}

class _AnalysisPageState extends State<AnalysisPage> {
  _Data? _d;

  @override
  void initState() {
    super.initState();
    _load();
    AppBus.data.addListener(_load);
  }

  @override
  void dispose() {
    AppBus.data.removeListener(_load);
    super.dispose();
  }

  static String _monthKey(DateTime d) {
    final j = Jalali.fromDateTime(d);
    return '${j.year}-${j.month.toString().padLeft(2, '0')}';
  }

  static String _monthName(String key) => jalaliMonths[int.parse(key.split('-')[1]) - 1];

  Future<void> _load() async {
    final db = LuxDb.instance;
    final d = _Data();

    // نمره‌ی هر درس (به مقیاس ۲۰)
    final g = await db.rawQuery(
      'SELECT c.name AS name, AVG(g.score * 1.0 / g.max_score) * 20 AS avg '
      'FROM grades g JOIN courses c ON c.id = g.course_id GROUP BY c.id ORDER BY c.name',
    );
    d.courseScores = [
      for (final r in g) ChartPoint(r['name'] as String, ((r['avg'] as num?) ?? 0).toDouble()),
    ];

    // ساعت مطالعه در هر درس
    final s = await db.rawQuery(
      'SELECT c.name AS name, SUM(s.end_ts - s.start_ts) / 3600000.0 AS h '
      'FROM study_sessions s JOIN courses c ON c.id = s.course_id '
      'WHERE s.end_ts IS NOT NULL GROUP BY c.id HAVING h > 0 ORDER BY h DESC',
    );
    d.studyHours = [
      for (final r in s) ChartPoint(r['name'] as String, ((r['h'] as num?) ?? 0).toDouble()),
    ];

    // روند نمره‌ها ماه‌به‌ماه
    final gr = await db.rawQuery('SELECT score, max_score, at_ts FROM grades ORDER BY at_ts');
    final byMonth = <String, List<double>>{};
    for (final r in gr) {
      final mx = ((r['max_score'] as num?) ?? 20).toDouble();
      if (mx <= 0) continue;
      final v = ((r['score'] as num).toDouble() / mx) * 20;
      final k = _monthKey(DateTime.fromMillisecondsSinceEpoch(r['at_ts'] as int));
      byMonth.putIfAbsent(k, () => []).add(v);
    }
    final keys = byMonth.keys.toList()..sort();
    final last = keys.length > 6 ? keys.sublist(keys.length - 6) : keys;
    if (last.length >= 2) {
      d.trendLabels = [for (final k in last) _monthName(k)];
      d.trendValues = [for (final k in last) byMonth[k]!.reduce((a, b) => a + b) / byMonth[k]!.length];
    }

    // تقسیم زمان مطالعه بر اساس نوع جلسه + نقشه‌ی گرمایی روزانه
    final ses = await db.rawQuery(
      'SELECT kind, start_ts, end_ts FROM study_sessions WHERE end_ts IS NOT NULL AND end_ts > start_ts',
    );
    final kindMin = <String, double>{};
    final dayMin = <DateTime, double>{};
    var totalMin = 0.0;
    for (final r in ses) {
      final st = DateTime.fromMillisecondsSinceEpoch(r['start_ts'] as int);
      final min = ((r['end_ts'] as int) - (r['start_ts'] as int)) / 60000.0;
      totalMin += min;
      final kind = (r['kind'] as String?) ?? 'pomodoro';
      kindMin[kind] = (kindMin[kind] ?? 0) + min;
      final day = dateOnly(st);
      dayMin[day] = (dayMin[day] ?? 0) + min;
    }
    const kindNames = {'pomodoro': 'پومودورو', 'free': 'مطالعه‌ی آزاد', 'review': 'مرور', 'test': 'تست'};
    d.kindSplit = [
      for (final e in kindMin.entries) ChartPoint(kindNames[e.key] ?? e.key, e.value / 60.0),
    ];
    d.totalHours = totalMin / 60.0;
    d.heat = {for (final e in dayMin.entries) e.key: e.value / 60.0};

    // مثبت‌ها و اخطارها در هر ماه
    final pos = await db.rawQuery('SELECT at_ts, count FROM class_positives');
    final warn = await db.rawQuery('SELECT at_ts FROM discipline_warnings');
    final pw = <String, List<double>>{};
    for (final r in pos) {
      final k = _monthKey(DateTime.fromMillisecondsSinceEpoch(r['at_ts'] as int));
      pw.putIfAbsent(k, () => [0, 0])[0] += ((r['count'] as num?) ?? 1).toDouble();
    }
    for (final r in warn) {
      final k = _monthKey(DateTime.fromMillisecondsSinceEpoch(r['at_ts'] as int));
      pw.putIfAbsent(k, () => [0, 0])[1] += 1;
    }
    final pk = pw.keys.toList()..sort();
    final pl = pk.length > 6 ? pk.sublist(pk.length - 6) : pk;
    d.pwLabels = [for (final k in pl) _monthName(k)];
    d.pwParts = [for (final k in pl) pw[k]!];

    if (!mounted) return;
    setState(() => _d = d);
  }

  Widget _block(String title, String? sub, Widget chart) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 16),
      child: LuxCard(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(title, style: LuxText.heading),
            if (sub != null) ...[
              const SizedBox(height: 2),
              Text(sub, style: LuxText.caption),
            ],
            const SizedBox(height: 16),
            chart,
          ],
        ),
      ),
    );
  }

  Widget _empty() {
    return LuxCard(
      padding: const EdgeInsets.fromLTRB(20, 28, 20, 28),
      child: Column(
        children: [
          const Icon(Icons.insights_rounded, color: LuxColors.accent, size: 40),
          const SizedBox(height: 14),
          Text('هنوز داده‌ای نیست', style: LuxText.heading),
          const SizedBox(height: 6),
          Text(
            'بعد از ثبت نمره‌ها و جلسه‌های مطالعه‌ی خودت، نمودارها اینجا ساخته می‌شوند.',
            style: LuxText.caption,
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final d = _d;
    if (d == null) {
      return const Center(child: CircularProgressIndicator(color: LuxColors.accent));
    }
    final blocks = <Widget>[];

    if (d.courseScores.isNotEmpty) {
      blocks.add(_block(
        'نمره‌ی درس‌ها',
        'میانگین نمره‌ها از ۲۰ — برای دیدن عدد، لمس کن',
        ColumnChart(data: d.courseScores, maxY: 20),
      ));
    }
    if (d.studyHours.isNotEmpty) {
      blocks.add(_block('ساعت مطالعه در هر درس', 'میله‌ای افقی', BarChart(data: d.studyHours)));
    }
    if (d.trendValues.length >= 2) {
      blocks.add(_block(
        'روند نمره‌ها',
        'میانگین ماهانه',
        LineChart(
          labels: d.trendLabels,
          series: [LineSeries('میانگین', d.trendValues, LuxColors.accent)],
          minY: 0,
          maxY: 20,
        ),
      ));
    }
    if (d.kindSplit.isNotEmpty) {
      blocks.add(_block(
        'تقسیم زمان مطالعه',
        'بر اساس نوع جلسه',
        PieChart(
          data: d.kindSplit,
          centerTop: faDigits(d.totalHours.round()),
          centerBottom: 'ساعت',
        ),
      ));
    }
    if (d.courseScores.length >= 3) {
      blocks.add(_block(
        'نقاط قوت و ضعف',
        'رادار نمره‌ها',
        RadarChart(
          labels: [for (final p in d.courseScores) p.label],
          values: [for (final p in d.courseScores) (p.value / 20).clamp(0.0, 1.0)],
        ),
      ));
    }
    if (d.heat.isNotEmpty) {
      blocks.add(_block(
        'تلاش روزانه',
        'نقشه‌ی گرمایی — هر خانه یک روز (ساعت مطالعه)',
        HeatmapCalendar(values: d.heat, weeks: 14),
      ));
    }
    if (d.pwLabels.isNotEmpty) {
      blocks.add(_block(
        'مثبت و اخطار در هر ماه',
        'ستونی انباشته',
        StackedColumnChart(
          labels: d.pwLabels,
          parts: d.pwParts,
          colors: const [LuxColors.accent, LuxColors.silverDim],
        ),
      ));
    }

    return PageFrame(
      title: 'تحلیل',
      subtitle: 'فقط با داده‌های خودت',
      children: blocks.isEmpty ? [_empty()] : blocks,
    );
  }
}
