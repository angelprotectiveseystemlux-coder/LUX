import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:path_provider/path_provider.dart';

import '../../../core/jalali_utils.dart';
import '../../../core/palette.dart';
import '../../../core/theme.dart';
import '../../../core/util.dart';
import '../../../data/database.dart';
import '../../../data/reader_repo.dart';
import '../../../services/file_bridge.dart';
import '../../../services/pdf_bridge.dart';
import '../../widgets/haptic.dart';
import '../../widgets/lux_button.dart';
import '../../widgets/lux_chip.dart';
import '../../widgets/lux_kit.dart';
import '../../widgets/lux_section.dart';
import '../manage/review_pages.dart';
import 'reader_models.dart';
import 'reader_panels.dart';

/// محیطِ مطالعه‌ی PDF: صفحه‌ها با رندرِ خودِ اندروید نشان داده می‌شوند و حاشیه‌نویسی‌ها روی مختصاتِ صفحه ذخیره می‌شوند.
class StudyReaderPage extends StatefulWidget {
  final int bookId;
  final int? startPage; // از ۱
  const StudyReaderPage({super.key, required this.bookId, this.startPage});

  @override
  State<StudyReaderPage> createState() => _StudyReaderPageState();
}

class _StudyReaderPageState extends State<StudyReaderPage> with WidgetsBindingObserver {
  static const double _gap = 10;

  Map<String, Object?>? _book;
  PdfInfo? _info;
  String _path = '';
  String? _error;
  bool _loading = true;

  List<ReaderAnn> _anns = <ReaderAnn>[];
  Map<int, List<ReaderAnn>> _byPage = <int, List<ReaderAnn>>{};
  List<Map<String, Object?>> _chapters = <Map<String, Object?>>[];

  int _page = 0; // از صفر
  int _mode = 0; // ۰ پیوسته، ۱ تک‌صفحه
  int _filter = 0; // ۰ عادی، ۱ شب، ۲ کاغذی
  double _zoom = 1.0;
  int _tool = 0; // ۰ مطالعه، ۱ هایلایت، ۲ قلم، ۳ پاک‌کن
  int _colorI = 0;
  bool _chrome = true;
  bool _awake = true;
  double? _dragPage;

  final ScrollController _scroll = ScrollController();
  final List<int> _undo = <int>[];
  DateTime _sessionStart = DateTime.now();
  int _fromPage = 0;
  Timer? _saveTimer;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _scroll.addListener(_onScroll);
    _init();
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _saveTimer?.cancel();
    _flushSession();
    PdfBridge.keepAwake(false);
    PdfBridge.close();
    PageCache.clear();
    _scroll.dispose();
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.paused || state == AppLifecycleState.inactive) {
      _flushSession();
      _sessionStart = DateTime.now();
      _fromPage = _page + 1;
    }
  }

  // ───────────────────────── بارگذاری ─────────────────────────

  Future<void> _init() async {
    final book = await ReaderRepo.book(widget.bookId);
    if (book == null) {
      _fail('این کتاب پیدا نشد.');
      return;
    }
    final path = asStr(book['file_path']);
    if (path.isEmpty || !File(path).existsSync()) {
      _fail('فایل PDF این کتاب پیدا نشد. آن را دوباره از کتابخانه اضافه کن.');
      return;
    }
    final info = await PdfBridge.open(path);
    if (info == null) {
      _fail('این PDF باز نشد (شاید رمز دارد یا خراب است).');
      return;
    }
    if (asInt(book['pages']) != info.count) {
      await ReaderRepo.setPages(widget.bookId, info.count);
    }
    final db = LuxDb.instance;
    final mode = int.tryParse(await db.kvGet('reader_mode') ?? '') ?? 0;
    final filter = int.tryParse(await db.kvGet('reader_filter') ?? '') ?? 0;
    final awake = (await db.kvGet('reader_awake')) != '0';
    final start = (widget.startPage ?? (asInt(book['last_page']) > 0 ? asInt(book['last_page']) : 1)) - 1;
    _chapters = await ReaderRepo.chapters(widget.bookId);
    await _reloadAnns(notify: false);
    if (!mounted) return;
    setState(() {
      _book = book;
      _info = info;
      _path = path;
      _mode = mode.clamp(0, 1).toInt();
      _filter = filter.clamp(0, 2).toInt();
      _awake = awake;
      _page = start.clamp(0, info.count - 1).toInt();
      _fromPage = _page + 1;
      _sessionStart = DateTime.now();
      _loading = false;
    });
    PdfBridge.keepAwake(awake);
    WidgetsBinding.instance.addPostFrameCallback((_) => _jumpScroll(_page));
  }

  void _fail(String msg) {
    if (!mounted) return;
    setState(() {
      _error = msg;
      _loading = false;
    });
  }

  Future<void> _reloadAnns({bool notify = true}) async {
    final rows = await ReaderRepo.annotations(widget.bookId);
    final list = [for (final r in rows) ReaderAnn.fromRow(r)];
    final by = <int, List<ReaderAnn>>{};
    for (final a in list) {
      by.putIfAbsent(a.page, () => <ReaderAnn>[]).add(a);
    }
    _anns = list;
    _byPage = by;
    if (notify && mounted) setState(() {});
  }

  void _flushSession() {
    final secs = DateTime.now().difference(_sessionStart).inSeconds;
    if (_info == null || secs < 15) return;
    ReaderRepo.addSession(widget.bookId, _sessionStart, DateTime.now(), _fromPage, _page + 1);
  }

  void _saveProgressSoon() {
    _saveTimer?.cancel();
    _saveTimer = Timer(const Duration(milliseconds: 900), () => ReaderRepo.saveProgress(widget.bookId, _page + 1));
  }

  // ───────────────────────── اندازه و اسکرول ─────────────────────────

  double get _vw => MediaQuery.of(context).size.width;

  double _pageW() => _vw * _zoom;

  double _pageH(int i) => _pageW() * _info!.ratios[i] + _gap;

  double _offsetOf(int i) {
    var o = 0.0;
    for (var k = 0; k < i; k++) {
      o += _pageH(k);
    }
    return o;
  }

  int _pageAtOffset(double off) {
    var acc = 0.0;
    for (var i = 0; i < _info!.count; i++) {
      acc += _pageH(i);
      if (off < acc) return i;
    }
    return _info!.count - 1;
  }

  void _onScroll() {
    if (_info == null || _mode != 0 || !_scroll.hasClients) return;
    final vh = _scroll.position.viewportDimension;
    final p = _pageAtOffset(_scroll.offset + vh * 0.3);
    if (p != _page) {
      setState(() => _page = p);
      _saveProgressSoon();
    }
  }

  void _jumpScroll(int i) {
    if (_mode != 0 || !_scroll.hasClients || _info == null) return;
    final target = _offsetOf(i).clamp(0.0, _scroll.position.maxScrollExtent).toDouble();
    _scroll.jumpTo(target);
  }

  void _goTo(int i) {
    if (_info == null) return;
    final p = i.clamp(0, _info!.count - 1).toInt();
    setState(() => _page = p);
    _saveProgressSoon();
    WidgetsBinding.instance.addPostFrameCallback((_) => _jumpScroll(p));
  }

  // ───────────────────────── حاشیه‌نویسی ─────────────────────────

  Future<void> _onDraw(int pageIndex, String kind, List<double> pts) async {
    final id = await ReaderRepo.addAnnotation(
      widget.bookId,
      pageIndex + 1,
      kind,
      data: jsonEncode(<String, Object?>{'p': pts}),
      color: kHlColors[_colorI],
    );
    _undo.add(id);
    Haptic.tap();
    await _reloadAnns();
  }

  Future<void> _onErase(int pageIndex, double nx, double ny, double w, double h) async {
    final list = _byPage[pageIndex + 1] ?? const <ReaderAnn>[];
    for (final a in list.reversed) {
      if (a.isDrawn && annHit(a, nx, ny, w, h)) {
        await ReaderRepo.deleteAnnotation(a.id);
        _undo.remove(a.id);
        Haptic.light();
        await _reloadAnns();
        return;
      }
    }
  }

  Future<void> _undoLast() async {
    if (_undo.isEmpty) {
      if (mounted) luxToast(context, 'چیزی برای برگرداندن نیست.');
      return;
    }
    final id = _undo.removeLast();
    await ReaderRepo.deleteAnnotation(id);
    await _reloadAnns();
  }

  ReaderAnn? _bookmarkOn(int page1) {
    for (final a in _byPage[page1] ?? const <ReaderAnn>[]) {
      if (a.kind == 'bookmark') return a;
    }
    return null;
  }

  String? _statusOn(int page1) {
    for (final a in _byPage[page1] ?? const <ReaderAnn>[]) {
      if (a.kind == 'status') return a.note;
    }
    return null;
  }

  String _chapterOf(int page1) {
    for (final c in _chapters) {
      final s = c['start_page'] == null ? null : asInt(c['start_page']);
      final e = c['end_page'] == null ? null : asInt(c['end_page']);
      if (s != null && page1 >= s && (e == null || page1 <= e)) return asStr(c['title']);
    }
    return '';
  }

  Future<void> _toggleBookmark() async {
    final p1 = _page + 1;
    final ex = _bookmarkOn(p1);
    if (ex != null) {
      await ReaderRepo.deleteAnnotation(ex.id);
    } else {
      final ch = _chapterOf(p1);
      await ReaderRepo.addAnnotation(widget.bookId, p1, 'bookmark', note: ch.isEmpty ? 'صفحه‌ی ${faDigits(p1)}' : '$ch · صفحه‌ی ${faDigits(p1)}', color: kHlColors[0]);
      Haptic.tap();
    }
    await _reloadAnns();
  }

  Future<void> _pageNote() async {
    final p1 = _page + 1;
    ReaderAnn? ex;
    for (final a in _byPage[p1] ?? const <ReaderAnn>[]) {
      if (a.kind == 'note') ex = a;
    }
    final c = TextEditingController(text: ex?.note ?? '');
    await showLuxSheet<void>(
      context,
      (ctx) => Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Text('یادداشتِ صفحه‌ی ${faDigits(p1)}', style: LuxText.title),
          const SizedBox(height: 14),
          LuxField(label: 'یادداشت', controller: c, maxLines: 5, hint: 'هرچه برای این صفحه می‌خواهی یادت بماند'),
          LuxButton(
            label: 'ذخیره',
            onPressed: () async {
              final t = c.text.trim();
              if (ex != null) {
                if (t.isEmpty) {
                  await ReaderRepo.deleteAnnotation(ex.id);
                } else {
                  await ReaderRepo.updateAnnotation(ex.id, note: t);
                }
              } else if (t.isNotEmpty) {
                await ReaderRepo.addAnnotation(widget.bookId, p1, 'note', note: t);
              }
              await _reloadAnns();
              if (ctx.mounted) Navigator.of(ctx).pop();
            },
          ),
        ],
      ),
    );
  }

  Future<void> _pageStatus() async {
    final p1 = _page + 1;
    final cur = _statusOn(p1);
    await showLuxSheet<void>(
      context,
      (ctx) => Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Text('وضعیتِ صفحه‌ی ${faDigits(p1)}', style: LuxText.title),
          const SizedBox(height: 14),
          Wrap(spacing: 8, runSpacing: 8, children: [
            for (var i = 0; i < kPageStatusKeys.length; i++)
              LuxChip(
                label: kPageStatusNames[i],
                selected: cur == kPageStatusKeys[i],
                onTap: () async {
                  await ReaderRepo.setStatus(widget.bookId, p1, cur == kPageStatusKeys[i] ? null : kPageStatusKeys[i]);
                  await _reloadAnns();
                  if (ctx.mounted) Navigator.of(ctx).pop();
                },
              ),
          ]),
          const SizedBox(height: 16),
          LuxButton(
            label: 'این صفحه و صفحه‌ی بعد را «مطالعه شد» کن',
            filled: false,
            onPressed: () async {
              for (var k = p1; k <= p1 + 1 && k <= _info!.count; k++) {
                await ReaderRepo.setStatus(widget.bookId, k, 'done');
              }
              await _reloadAnns();
              if (ctx.mounted) Navigator.of(ctx).pop();
            },
          ),
        ],
      ),
    );
  }

  // ───────────────────────── منو ─────────────────────────

  Future<void> _nextReviewPage() async {
    final pages = <int>{};
    for (final a in _anns) {
      if (a.kind == 'bookmark' || a.kind == 'hl' || a.kind == 'note') pages.add(a.page);
      if (a.kind == 'status' && (a.note == 'review' || a.note == 'hard')) pages.add(a.page);
    }
    if (pages.isEmpty) {
      luxToast(context, 'هنوز صفحه‌ای برای مرور علامت نزده‌ای.');
      return;
    }
    final sorted = pages.toList()..sort();
    final next = sorted.firstWhere((p) => p > _page + 1, orElse: () => sorted.first);
    _goTo(next - 1);
    luxToast(context, 'صفحه‌ی ${faDigits(next)} از ${faDigits(sorted.length)} صفحه‌ی مرور');
  }

  Future<void> _export() async {
    final txt = buildNotesExport(
      title: asStr(_book?['title']),
      course: asStr(_book?['course']),
      chapters: _chapters,
      anns: _anns,
    );
    try {
      final dir = await getTemporaryDirectory();
      final f = File('${dir.path}/lux_notes.txt');
      await f.writeAsString(txt);
      final safe = asStr(_book?['title']).replaceAll(RegExp(r'[^\w\u0600-\u06FF ]'), '_');
      final ok = await FileBridge.saveAs(f.path, 'یادداشت‌های $safe.txt', mime: 'text/plain');
      if (mounted && ok) luxToast(context, 'ذخیره شد.');
    } catch (_) {
      if (mounted) luxNotice(context, 'ذخیره نشد.');
    }
  }

  Future<void> _chaptersSheet() async {
    await showLuxSheet<void>(
      context,
      (ctx) => Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Text('فصل‌ها', style: LuxText.title),
          const SizedBox(height: 12),
          if (_chapters.isEmpty)
            const LuxEmpty(icon: Icons.menu_book_rounded, title: 'فصلی ثبت نشده', hint: 'فصل‌ها را از صفحه‌ی کتاب (تب درس‌ها) اضافه کن؛ بعد اینجا هم می‌آیند.')
          else
            ConstrainedBox(
              constraints: BoxConstraints(maxHeight: MediaQuery.of(ctx).size.height * 0.5),
              child: ListView(
                shrinkWrap: true,
                children: [
                  for (final c in _chapters)
                    LuxRow(
                      leading: Icon(asInt(c['done']) == 1 ? Icons.check_circle_rounded : Icons.menu_book_rounded, color: asInt(c['done']) == 1 ? LuxColors.ok : LuxColors.accent),
                      title: asStr(c['title']),
                      subtitle: c['start_page'] == null ? null : 'صفحه‌ی ${faDigits(c['start_page'])}${c['end_page'] == null ? '' : ' تا ${faDigits(c['end_page'])}'}',
                      onTap: c['start_page'] == null
                          ? null
                          : () {
                              Navigator.of(ctx).pop();
                              _goTo(asInt(c['start_page']) - 1);
                            },
                    ),
                ],
              ),
            ),
        ],
      ),
    );
  }

  Future<void> _display() async {
    await showLuxSheet<void>(
      context,
      (ctx) => StatefulBuilder(builder: (ctx, setS) {
        return Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Text('نمایش', style: LuxText.title),
            const SizedBox(height: 14),
            LuxChoice(
              label: 'حالتِ صفحه',
              options: const ['پیوسته (اسکرول)', 'تک‌صفحه'],
              selected: _mode,
              onChanged: (i) async {
                await LuxDb.instance.kvSet('reader_mode', '$i');
                setState(() {
                  _mode = i;
                  _zoom = 1.0;
                });
                setS(() {});
                WidgetsBinding.instance.addPostFrameCallback((_) => _jumpScroll(_page));
              },
            ),
            LuxChoice(
              label: 'رنگِ صفحه',
              options: const ['عادی', 'شب', 'کاغذی'],
              selected: _filter,
              onChanged: (i) async {
                await LuxDb.instance.kvSet('reader_filter', '$i');
                setState(() => _filter = i);
                setS(() {});
              },
            ),
            LuxChoice(
              label: 'روشن ماندنِ صفحه هنگام مطالعه',
              options: const ['بله', 'نه'],
              selected: _awake ? 0 : 1,
              onChanged: (i) async {
                await LuxDb.instance.kvSet('reader_awake', i == 0 ? '1' : '0');
                PdfBridge.keepAwake(i == 0);
                setState(() => _awake = i == 0);
                setS(() {});
              },
            ),
          ],
        );
      }),
    );
  }

  Future<void> _menu() async {
    Widget row(IconData icon, String title, String sub, VoidCallback act) => LuxRow(
          leading: Icon(icon, color: LuxColors.accent),
          title: title,
          subtitle: sub,
          onTap: () {
            Navigator.of(context).pop();
            act();
          },
        );
    await showLuxSheet<void>(
      context,
      (ctx) => ConstrainedBox(
        constraints: BoxConstraints(maxHeight: MediaQuery.of(ctx).size.height * 0.72),
        child: ListView(
          shrinkWrap: true,
          children: [
            Text(asStr(_book?['title']), style: LuxText.title),
            const SizedBox(height: 10),
            row(Icons.bookmarks_rounded, 'نشانک‌ها، یادداشت‌ها و هایلایت‌ها', 'فهرست، جست‌وجو و رفتن به محلِ اصلی', () {
              showReaderNotes(context, anns: _anns, onJump: _goTo, onChanged: _reloadAnns);
            }),
            row(Icons.grid_view_rounded, 'نقشه‌ی کتاب', 'وضعیتِ همه‌ی صفحه‌ها با رنگ', () {
              final st = <int, String>{};
              final marked = <int>{};
              for (final a in _anns) {
                if (a.kind == 'status') {
                  st[a.page] = a.note;
                } else {
                  marked.add(a.page);
                }
              }
              showBookMap(context, count: _info!.count, statusByPage: st, marked: marked, current: _page, onJump: _goTo);
            }),
            row(Icons.sticky_note_2_rounded, 'یادداشتِ این صفحه', 'متنی که به همین صفحه وصل می‌شود', _pageNote),
            row(Icons.flag_rounded, 'وضعیتِ این صفحه', 'در حال مطالعه، مطالعه شد، نیازمند مرور، دشوار', _pageStatus),
            row(Icons.error_outline_rounded, 'ثبتِ اشتباه از این صفحه', 'به دفترچه‌ی اشتباهات و مرورِ فاصله‌دار می‌رود', () {
              showMistakeEditor(
                context,
                courseId: _book?['course_id'] == null ? null : asInt(_book!['course_id']),
                bookId: widget.bookId,
                page: _page + 1,
              );
            }),
            row(Icons.skip_next_rounded, 'حالتِ مرور', 'رفتن به صفحه‌ی بعدیِ نشانک‌دار، هایلایت‌دار، دشوار یا نیازمند مرور', _nextReviewPage),
            row(Icons.list_alt_rounded, 'فصل‌ها', 'رفتن به ابتدای هر فصل', _chaptersSheet),
            row(Icons.insights_rounded, 'آمارِ این کتاب', 'زمان، پیشرفت، صفحه‌های باقی‌مانده', () {
              showReaderStats(context, bookId: widget.bookId, title: asStr(_book?['title']), count: _info!.count, anns: _anns);
            }),
            row(Icons.ios_share_rounded, 'خروجیِ یادداشت‌ها (TXT)', 'نشانک‌ها، یادداشت‌ها، هایلایت‌ها و صفحه‌های مرور', _export),
            row(Icons.tune_rounded, 'نمایش', 'حالتِ صفحه، رنگ، روشن ماندنِ صفحه', _display),
          ],
        ),
      ),
    );
  }

  // ───────────────────────── ساختِ صفحه ─────────────────────────

  Color get _bg => _filter == 1 ? Colors.black : (_filter == 2 ? const Color(0xFFE9DFC6) : LuxColors.bg);

  Widget _pageWidget(int i, double w, int px) => ReaderPageView(
        key: ValueKey<String>('pg$i|$px|$_filter'),
        path: _path,
        index: i,
        width: w,
        ratio: _info!.ratios[i],
        px: px,
        filter: _filter,
        anns: _byPage[i + 1] ?? const <ReaderAnn>[],
        tool: _tool,
        color: Color(kHlColors[_colorI]),
        onDraw: (k, pts) => _onDraw(i, k, pts),
        onErase: (nx, ny, w2, h2) => _onErase(i, nx, ny, w2, h2),
      );

  int _px(double w) {
    final dpr = MediaQuery.of(context).devicePixelRatio;
    final raw = w * dpr;
    return ((raw / 200).round() * 200).clamp(600, 2200).toInt();
  }

  Widget _continuous() {
    final w = _pageW();
    final px = _px(w);
    final topPad = _chrome ? 64.0 : 8.0;
    final bottomPad = _chrome ? 150.0 : 8.0;
    Widget list(double height) => SizedBox(
          width: w,
          height: height,
          child: ListView.builder(
            controller: _scroll,
            physics: _tool == 0 ? const ClampingScrollPhysics() : const NeverScrollableScrollPhysics(),
            padding: EdgeInsets.only(top: topPad, bottom: bottomPad),
            itemCount: _info!.count,
            itemBuilder: (ctx, i) => Padding(padding: const EdgeInsets.only(bottom: _gap), child: _pageWidget(i, w, px)),
          ),
        );
    return GestureDetector(
      behavior: HitTestBehavior.translucent,
      onTap: _tool == 0 ? () => setState(() => _chrome = !_chrome) : null,
      child: LayoutBuilder(
        builder: (ctx, c) {
          if (_zoom <= 1.001) return list(c.maxHeight);
          return SingleChildScrollView(scrollDirection: Axis.horizontal, child: list(c.maxHeight));
        },
      ),
    );
  }

  Widget _single() {
    return LayoutBuilder(
      builder: (ctx, c) {
        final ratio = _info!.ratios[_page];
        final top = _chrome ? 64.0 : 0.0;
        final bottom = _chrome ? 150.0 : 0.0;
        final availH = c.maxHeight - top - bottom;
        final w = (availH / ratio) < c.maxWidth ? availH / ratio : c.maxWidth;
        final px = _px(w * 2.0);
        return GestureDetector(
          behavior: HitTestBehavior.translucent,
          onTapUp: _tool != 0
              ? null
              : (d) {
                  final f = d.localPosition.dx / c.maxWidth;
                  // کتابِ فارسی: صفحه‌ی بعد سمتِ چپ است
                  if (f < 0.25) {
                    _goTo(_page + 1);
                  } else if (f > 0.75) {
                    _goTo(_page - 1);
                  } else {
                    setState(() => _chrome = !_chrome);
                  }
                },
          child: Padding(
            padding: EdgeInsets.only(top: top, bottom: bottom),
            child: Center(
              child: InteractiveViewer(
                minScale: 1,
                maxScale: 5,
                panEnabled: _tool == 0,
                scaleEnabled: _tool == 0,
                child: _pageWidget(_page, w, px),
              ),
            ),
          ),
        );
      },
    );
  }

  Widget _circle(IconData icon, VoidCallback onTap, {Color? color}) => GestureDetector(
        behavior: HitTestBehavior.opaque,
        onTap: () {
          Haptic.tap();
          onTap();
        },
        child: Container(
          width: 42,
          height: 42,
          decoration: BoxDecoration(color: LuxColors.alpha(Colors.black, 0.45), shape: BoxShape.circle),
          child: Icon(icon, color: color ?? Colors.white, size: 22),
        ),
      );

  Widget _topBar() {
    final p1 = _page + 1;
    final ch = _chapterOf(p1);
    final marked = _bookmarkOn(p1) != null;
    return Container(
      padding: const EdgeInsets.fromLTRB(10, 8, 10, 8),
      decoration: BoxDecoration(
        gradient: LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: [LuxColors.alpha(Colors.black, 0.7), Colors.transparent]),
      ),
      child: Row(
        children: [
          _circle(Icons.arrow_forward_rounded, () => Navigator.of(context).pop()),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(asStr(_book?['title']), maxLines: 1, overflow: TextOverflow.ellipsis, style: LuxText.label.copyWith(color: Colors.white)),
                if (ch.isNotEmpty) Text(ch, maxLines: 1, overflow: TextOverflow.ellipsis, style: LuxText.caption.copyWith(color: Colors.white70)),
              ],
            ),
          ),
          GestureDetector(
            onTap: () => showPageJump(context, count: _info!.count, current: _page, onJump: _goTo),
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 9),
              decoration: BoxDecoration(color: LuxColors.alpha(Colors.black, 0.45), borderRadius: BorderRadius.circular(18)),
              child: Text('${faDigits(p1)} / ${faDigits(_info!.count)}', style: LuxText.label.copyWith(color: Colors.white)),
            ),
          ),
          const SizedBox(width: 8),
          _circle(marked ? Icons.bookmark_rounded : Icons.bookmark_border_rounded, _toggleBookmark, color: marked ? const Color(0xFFFFD54F) : Colors.white),
          const SizedBox(width: 8),
          _circle(Icons.more_vert_rounded, _menu),
        ],
      ),
    );
  }

  Widget _toolBtn(IconData icon, bool active, VoidCallback onTap, {Color? tint}) => GestureDetector(
        behavior: HitTestBehavior.opaque,
        onTap: () {
          Haptic.tap();
          onTap();
        },
        child: Container(
          width: 46,
          height: 46,
          margin: const EdgeInsets.symmetric(horizontal: 3),
          decoration: BoxDecoration(
            color: active ? LuxColors.accent : LuxColors.alpha(Colors.white, 0.1),
            borderRadius: BorderRadius.circular(16),
          ),
          child: Icon(icon, color: active ? LuxColors.onAccent : (tint ?? Colors.white), size: 23),
        ),
      );

  Future<void> _pickColor() async {
    await showLuxSheet<void>(
      context,
      (ctx) => Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Text('رنگِ هایلایت و قلم', style: LuxText.title),
          const SizedBox(height: 14),
          for (var i = 0; i < kHlColors.length; i++)
            LuxRow(
              leading: Container(width: 26, height: 26, decoration: BoxDecoration(color: Color(kHlColors[i]), shape: BoxShape.circle)),
              title: kHlNames[i],
              trailing: _colorI == i ? Icon(Icons.check_rounded, color: LuxColors.accent) : null,
              onTap: () {
                setState(() => _colorI = i);
                Navigator.of(ctx).pop();
              },
            ),
        ],
      ),
    );
  }

  Widget _bottomBar() {
    final p1 = _page + 1;
    final st = _statusOn(p1);
    final si = st == null ? -1 : kPageStatusKeys.indexOf(st);
    final count = _info!.count;
    return Container(
      padding: const EdgeInsets.fromLTRB(12, 18, 12, 10),
      decoration: BoxDecoration(
        gradient: LinearGradient(begin: Alignment.bottomCenter, end: Alignment.topCenter, colors: [LuxColors.alpha(Colors.black, 0.78), Colors.transparent]),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          if (_tool != 0)
            Padding(
              padding: const EdgeInsets.only(bottom: 4),
              child: Text(
                _tool == 1 ? 'برای هایلایت، روی متن بکش (یک مستطیل)' : (_tool == 2 ? 'با انگشت روی صفحه بنویس' : 'روی یک هایلایت یا نوشته بزن تا پاک شود'),
                style: LuxText.caption.copyWith(color: Colors.white70),
              ),
            ),
          if (count > 1)
            Slider(
              value: (_dragPage ?? p1.toDouble()).clamp(1.0, count.toDouble()).toDouble(),
              min: 1,
              max: count.toDouble(),
              activeColor: LuxColors.accent,
              inactiveColor: Colors.white24,
              onChanged: (v) => setState(() => _dragPage = v),
              onChangeEnd: (v) {
                setState(() => _dragPage = null);
                _goTo(v.round() - 1);
              },
            ),
          SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            child: Row(
              children: [
                _toolBtn(Icons.pan_tool_alt_rounded, _tool == 0, () => setState(() => _tool = 0)),
                _toolBtn(Icons.highlight_rounded, _tool == 1, () => setState(() => _tool = _tool == 1 ? 0 : 1)),
                _toolBtn(Icons.draw_rounded, _tool == 2, () => setState(() => _tool = _tool == 2 ? 0 : 2)),
                _toolBtn(Icons.cleaning_services_rounded, _tool == 3, () => setState(() => _tool = _tool == 3 ? 0 : 3)),
                _toolBtn(Icons.undo_rounded, false, _undoLast),
                GestureDetector(
                  onTap: _pickColor,
                  child: Container(
                    width: 46,
                    height: 46,
                    margin: const EdgeInsets.symmetric(horizontal: 3),
                    decoration: BoxDecoration(color: LuxColors.alpha(Colors.white, 0.1), borderRadius: BorderRadius.circular(16)),
                    child: Center(child: Container(width: 24, height: 24, decoration: BoxDecoration(color: Color(kHlColors[_colorI]), shape: BoxShape.circle, border: Border.all(color: Colors.white, width: 2)))),
                  ),
                ),
                const SizedBox(width: 6),
                _toolBtn(Icons.flag_rounded, false, _pageStatus, tint: si < 0 ? null : Color(kPageStatusColors[si])),
                _toolBtn(Icons.sticky_note_2_rounded, false, _pageNote),
                if (_mode == 0) ...[
                  _toolBtn(Icons.zoom_out_rounded, false, () => _setZoom(_zoom - 0.25)),
                  _toolBtn(Icons.zoom_in_rounded, false, () => _setZoom(_zoom + 0.25)),
                ],
                _toolBtn(_mode == 0 ? Icons.view_agenda_rounded : Icons.crop_portrait_rounded, false, () async {
                  final m = _mode == 0 ? 1 : 0;
                  await LuxDb.instance.kvSet('reader_mode', '$m');
                  setState(() {
                    _mode = m;
                    _zoom = 1.0;
                  });
                  WidgetsBinding.instance.addPostFrameCallback((_) => _jumpScroll(_page));
                }),
                _toolBtn(Icons.brightness_6_rounded, false, () async {
                  final f = (_filter + 1) % 3;
                  await LuxDb.instance.kvSet('reader_filter', '$f');
                  setState(() => _filter = f);
                }),
              ],
            ),
          ),
        ],
      ),
    );
  }

  void _setZoom(double z) {
    final nz = z.clamp(1.0, 3.0).toDouble();
    if (nz == _zoom) return;
    final keep = _page;
    setState(() => _zoom = nz);
    WidgetsBinding.instance.addPostFrameCallback((_) => _jumpScroll(keep));
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) {
      return Scaffold(backgroundColor: LuxColors.bg, body: Center(child: CircularProgressIndicator(color: LuxColors.accent)));
    }
    if (_error != null || _info == null) {
      return Scaffold(
        backgroundColor: LuxColors.bg,
        body: SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Icon(Icons.picture_as_pdf_rounded, size: 56, color: LuxColors.silverDim),
                const SizedBox(height: 14),
                Text(_error ?? 'خطا', style: LuxText.heading, textAlign: TextAlign.center),
                const SizedBox(height: 20),
                LuxButton(label: 'بازگشت', onPressed: () => Navigator.of(context).pop()),
              ],
            ),
          ),
        ),
      );
    }
    return Scaffold(
        backgroundColor: _bg,
        body: SafeArea(
          child: Stack(
            children: [
              Positioned.fill(child: _mode == 0 ? _continuous() : _single()),
              if (_chrome) Positioned(top: 0, left: 0, right: 0, child: _topBar()),
              if (_chrome) Positioned(bottom: 0, left: 0, right: 0, child: _bottomBar()),
            ],
          ),
        ),
    );
  }
}
