import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:flutter/services.dart';
import 'package:path_provider/path_provider.dart';
import 'package:pdfrx/pdfrx.dart';

import '../../../core/jalali_utils.dart';
import '../../../core/palette.dart';
import '../../../core/theme.dart';
import '../../../core/util.dart';
import '../../../data/database.dart';
import '../../../data/reader_repo.dart';
import '../../../services/file_bridge.dart';
import '../../../services/pdf_bridge.dart';
import '../../widgets/haptic.dart';
import '../../widgets/lux_button.dart';
import '../../widgets/lux_chip.dart';
import '../../widgets/lux_kit.dart';
import '../../widgets/lux_section.dart';
import '../manage/review_pages.dart';
import 'pdf_text_tools.dart';
import 'reader_models.dart';
import 'reader_panels.dart';

const List<double> _nightMatrix = <double>[
  -1, 0, 0, 0, 255, //
  0, -1, 0, 0, 255,
  0, 0, -1, 0, 255,
  0, 0, 0, 1, 0,
];
const List<double> _sepiaMatrix = <double>[
  0.393, 0.769, 0.189, 0, 0, //
  0.349, 0.686, 0.168, 0, 0,
  0.272, 0.534, 0.131, 0, 0,
  0, 0, 0, 1, 0,
];

/// محیطِ مطالعه‌ی PDF (موتور PDFium): زومِ دوانگشتی، انتخاب و کپیِ متن، هایلایتِ دقیقِ متنی،
/// جست‌وجو در متنِ کتاب، فهرستِ مطالبِ خودِ PDF، حالتِ شب/کاغذی و حاشیه‌نویسی.
class StudyReaderPage extends StatefulWidget {
  final int bookId;
  final int? startPage; // از ۱
  const StudyReaderPage({super.key, required this.bookId, this.startPage});

  @override
  State<StudyReaderPage> createState() => _StudyReaderPageState();
}

class _StudyReaderPageState extends State<StudyReaderPage> with WidgetsBindingObserver {
  Map<String, Object?>? _book;
  String _path = '';
  String? _error;
  bool _loading = true;
  int _count = 0;

  List<ReaderAnn> _anns = <ReaderAnn>[];
  Map<int, List<ReaderAnn>> _byPage = <int, List<ReaderAnn>>{};
  List<Map<String, Object?>> _chapters = <Map<String, Object?>>[];

  int _page = 0; // از صفر
  int _startPage = 0;
  int _mode = 0; // ۰ عمودیِ پیوسته، ۱ افقی (راست‌به‌چپ)
  int _filter = 0; // ۰ عادی، ۱ شب، ۲ کاغذی
  int _tool = 0; // ۰ مطالعه و انتخابِ متن، ۱ هایلایتِ مستطیلی، ۲ قلم، ۳ پاک‌کن
  int _colorI = 0;
  bool _chrome = true;
  bool _awake = true;
  double? _dragPage;

  late PdfViewerController _ctl;
  late PdfTextSearcher _searcher;
  int _viewerGen = 0;

  bool _searchOn = false;
  final TextEditingController _q = TextEditingController();
  final FocusNode _qFocus = FocusNode();

  PdfTextSelection? _sel;
  bool _hasSel = false;

  Timer? _tapTimer;
  DateTime? _lastTapAt;

  final List<int> _undo = <int>[];
  DateTime _sessionStart = DateTime.now();
  int _fromPage = 1;
  Timer? _saveTimer;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _makeController();
    _init();
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _saveTimer?.cancel();
    _tapTimer?.cancel();
    _flushSession();
    PdfBridge.keepAwake(false);
    _searcher.removeListener(_onSearch);
    _searcher.dispose();
    _q.dispose();
    _qFocus.dispose();
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.paused || state == AppLifecycleState.inactive) {
      _flushSession();
      _sessionStart = DateTime.now();
      _fromPage = _page + 1;
    }
  }

  void _makeController() {
    _ctl = PdfViewerController();
    _searcher = PdfTextSearcher(_ctl)..addListener(_onSearch);
  }

  /// اجرای یک تغییرِ ظاهری با امنیت: اگر وسطِ ساخت/رسم باشیم، به فریمِ بعد می‌رود.
  void _later(VoidCallback f) {
    if (!mounted) return;
    final phase = SchedulerBinding.instance.schedulerPhase;
    if (phase == SchedulerPhase.persistentCallbacks || phase == SchedulerPhase.postFrameCallbacks) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (mounted) f();
      });
      WidgetsBinding.instance.scheduleFrame();
    } else {
      f();
    }
  }

  // ───────────────────────── بارگذاری ─────────────────────────

  Future<void> _init() async {
    final book = await ReaderRepo.book(widget.bookId);
    if (book == null) {
      _fail('این کتاب پیدا نشد.');
      return;
    }
    final path = asStr(book['file_path']);
    if (path.isEmpty || !File(path).existsSync()) {
      _fail('فایل PDF این کتاب پیدا نشد. آن را دوباره از کتابخانه اضافه کن.');
      return;
    }
    final db = LuxDb.instance;
    final mode = int.tryParse(await db.kvGet('reader_mode') ?? '') ?? 0;
    final filter = int.tryParse(await db.kvGet('reader_filter') ?? '') ?? 0;
    final awake = (await db.kvGet('reader_awake')) != '0';
    final start = (widget.startPage ?? (asInt(book['last_page']) > 0 ? asInt(book['last_page']) : 1)) - 1;
    _chapters = await ReaderRepo.chapters(widget.bookId);
    await _reloadAnns(notify: false);
    if (!mounted) return;
    setState(() {
      _book = book;
      _path = path;
      _mode = mode.clamp(0, 1).toInt();
      _filter = filter.clamp(0, 2).toInt();
      _awake = awake;
      _startPage = start < 0 ? 0 : start;
      _page = _startPage;
      _fromPage = _page + 1;
      _count = asInt(book['pages']);
      _sessionStart = DateTime.now();
      _loading = false;
    });
    PdfBridge.keepAwake(awake);
  }

  void _fail(String msg) {
    if (!mounted) return;
    setState(() {
      _error = msg;
      _loading = false;
    });
  }

  Future<void> _reloadAnns({bool notify = true}) async {
    final rows = await ReaderRepo.annotations(widget.bookId);
    final list = [for (final r in rows) ReaderAnn.fromRow(r)];
    final by = <int, List<ReaderAnn>>{};
    for (final a in list) {
      by.putIfAbsent(a.page, () => <ReaderAnn>[]).add(a);
    }
    _anns = list;
    _byPage = by;
    if (notify && mounted) {
      setState(() {});
      _refreshViewer();
    }
  }

  /// بعد از تغییرِ حاشیه‌نویسی‌ها یا ابزار، لایه‌های روی صفحه دوباره ساخته می‌شوند.
  void _refreshViewer() {
    try {
      if (_ctl.isReady) _ctl.invalidate();
    } catch (_) {}
  }

  void _flushSession() {
    final secs = DateTime.now().difference(_sessionStart).inSeconds;
    if (_count == 0 || secs < 15) return;
    ReaderRepo.addSession(widget.bookId, _sessionStart, DateTime.now(), _fromPage, _page + 1);
  }

  void _saveProgressSoon() {
    _saveTimer?.cancel();
    _saveTimer = Timer(const Duration(milliseconds: 900), () => ReaderRepo.saveProgress(widget.bookId, _page + 1));
  }

  // ───────────────────────── رویدادهای نمایشگر ─────────────────────────

  int? _initialPage(PdfDocument doc, PdfViewerController c) => _startPage + 1;

  void _onReady(PdfDocument doc, PdfViewerController c) {
    final n = doc.pages.length;
    _later(() {
      if (n != _count) setState(() => _count = n);
      if (asInt(_book?['pages']) != n) ReaderRepo.setPages(widget.bookId, n);
    });
  }

  void _onPage(int? number) {
    if (number == null) return;
    final p = number - 1;
    if (p == _page) return;
    _later(() {
      setState(() => _page = p);
      _saveProgressSoon();
    });
  }

  void _onSearch() => _later(() => setState(() {}));

  void _onSelChange(PdfTextSelection s) {
    final has = s.hasSelectedText;
    _sel = s;
    if (has != _hasSel) {
      _later(() => setState(() => _hasSel = has));
    }
  }

  Widget? _noMenu(BuildContext context, PdfViewerContextMenuBuilderParams params) => null;

  Widget _loadBanner(BuildContext context, int bytes, int? total) =>
      Center(child: CircularProgressIndicator(color: LuxColors.accent));

  Widget _errBanner(BuildContext context, Object error, StackTrace? st, PdfDocumentRef ref) {
    final msg = error is PdfPasswordException ? 'رمزِ این PDF درست نبود.' : 'این PDF باز نشد (شاید خراب است).';
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(Icons.picture_as_pdf_rounded, size: 56, color: LuxColors.silverDim),
            const SizedBox(height: 14),
            Text(msg, style: LuxText.heading.copyWith(color: Colors.white), textAlign: TextAlign.center),
            const SizedBox(height: 20),
            LuxButton(label: 'بازگشت', onPressed: () => Navigator.of(context).pop()),
          ],
        ),
      ),
    );
  }

  Future<String?> _askPassword() async {
    if (!mounted) return null;
    final c = TextEditingController();
    final r = await showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: LuxColors.card,
        title: Text('این PDF رمز دارد', style: LuxText.title),
        content: TextField(
          controller: c,
          obscureText: true,
          autofocus: true,
          style: LuxText.body,
          decoration: const InputDecoration(hintText: 'رمز'),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.of(ctx).pop(), child: const Text('انصراف')),
          TextButton(onPressed: () => Navigator.of(ctx).pop(c.text), child: const Text('باز کن')),
        ],
      ),
    );
    c.dispose();
    return r;
  }

  void _onLink(PdfLink link) {
    final l = link as dynamic;
    try {
      final dest = l.dest;
      if (dest != null) {
        _ctl.goToDest(dest as PdfDest?);
        return;
      }
    } catch (_) {}
    try {
      final url = l.url;
      if (url != null) {
        final s = url.toString();
        Clipboard.setData(ClipboardData(text: s));
        if (mounted) luxToast(context, 'لینک کپی شد: $s');
      }
    } catch (_) {}
  }

  String _tapKind(Object d) {
    try {
      final s = (d as dynamic).type.toString().toLowerCase();
      if (s.contains('double')) return 'double';
      if (s.contains('long') || s.contains('secondary') || s.contains('right')) return 'other';
    } catch (_) {}
    return 'tap';
  }

  void _zoomAt(Offset? pos) {
    try {
      if (pos != null) {
        _ctl.zoomUpOnLocalPosition(localPosition: pos, loop: true);
      } else {
        _ctl.zoomUp(loop: true);
      }
    } catch (_) {}
  }

  bool _onTap(BuildContext context, PdfViewerController c, PdfViewerGeneralTapHandlerDetails d) {
    final kind = _tapKind(d);
    if (kind == 'other' || _tool != 0 || _hasSel) return false;
    Offset? pos;
    try {
      pos = (d as dynamic).localPosition as Offset?;
    } catch (_) {}
    if (kind == 'double') {
      _tapTimer?.cancel();
      _lastTapAt = null;
      _zoomAt(pos);
      return true;
    }
    final now = DateTime.now();
    final last = _lastTapAt;
    if (last != null && now.difference(last).inMilliseconds < 320) {
      _tapTimer?.cancel();
      _lastTapAt = null;
      _zoomAt(pos);
      return true;
    }
    _lastTapAt = now;
    _tapTimer?.cancel();
    _tapTimer = Timer(const Duration(milliseconds: 300), () {
      if (mounted && _tool == 0) setState(() => _chrome = !_chrome);
    });
    return true;
  }

  // ───────────────────────── رسم و لایه‌های صفحه ─────────────────────────

  void _paintAnns(Canvas canvas, Rect pageRect, PdfPage page) {
    final list = _byPage[page.pageNumber];
    if (list == null || list.isEmpty) return;
    paintReaderAnns(canvas, pageRect, list, invert: _filter == 1);
  }

  List<Widget> _pageOverlays(BuildContext context, Rect pageRect, PdfPage page) {
    final n = page.pageNumber;
    final out = <Widget>[];
    if (_tool != 0) {
      out.add(SizedBox.expand(
        child: ReaderDrawLayer(
          key: ValueKey<String>('dl$n|$_tool'),
          tool: _tool,
          color: readerTint(kHlColors[_colorI], invert: _filter == 1),
          onDraw: (k, pts) => _onDraw(n - 1, k, pts),
          onErase: (nx, ny, w, h) => _onErase(n - 1, nx, ny, w, h),
        ),
      ));
      return out;
    }
    final list = _byPage[n] ?? const <ReaderAnn>[];
    final marks = [for (final a in list) if (a.kind == 'hl' && a.pts.length >= 4) a];
    if (marks.isEmpty) return out;
    out.add(SizedBox.expand(
      child: LayoutBuilder(builder: (context, cons) {
        final w = cons.maxWidth, h = cons.maxHeight;
        return Stack(
          children: [
            for (final a in marks)
              for (var i = 0; i + 3 < a.pts.length; i += 4)
                Positioned(
                  left: a.pts[i] * w,
                  top: a.pts[i + 1] * h,
                  width: math.max(8.0, (a.pts[i + 2] - a.pts[i]) * w),
                  height: math.max(8.0, (a.pts[i + 3] - a.pts[i + 1]) * h),
                  child: GestureDetector(
                    behavior: HitTestBehavior.translucent,
                    onTap: () => _annSheet(a),
                    child: const SizedBox.expand(),
                  ),
                ),
          ],
        );
      }),
    ));
    return out;
  }

  PdfPageLayout _rtlLayout(List<PdfPage> pages, PdfViewerParams params) {
    final height = pages.fold<double>(0.0, (p, e) => math.max(p, e.height)) + params.margin * 2;
    final rects = <Rect>[];
    var x = params.margin;
    for (final page in pages) {
      rects.add(Rect.fromLTWH(x, (height - page.height) / 2, page.width, page.height));
      x += page.width + params.margin;
    }
    final width = x;
    return PdfPageLayout(
      pageLayouts: [for (final r in rects) Rect.fromLTWH(width - r.right, r.top, r.width, r.height)],
      documentSize: Size(width, height),
    );
  }

  // ───────────────────────── حاشیه‌نویسی ─────────────────────────

  Future<void> _onDraw(int pageIndex, String kind, List<double> pts) async {
    final id = await ReaderRepo.addAnnotation(
      widget.bookId,
      pageIndex + 1,
      kind,
      data: jsonEncode(<String, Object?>{'p': pts}),
      color: kHlColors[_colorI],
    );
    _undo.add(id);
    Haptic.tap();
    await _reloadAnns();
  }

  Future<void> _onErase(int pageIndex, double nx, double ny, double w, double h) async {
    final list = _byPage[pageIndex + 1] ?? const <ReaderAnn>[];
    for (final a in list.reversed) {
      if (a.isDrawn && annHit(a, nx, ny, w, h)) {
        await ReaderRepo.deleteAnnotation(a.id);
        _undo.remove(a.id);
        Haptic.light();
        await _reloadAnns();
        return;
      }
    }
  }

  Future<void> _undoLast() async {
    if (_undo.isEmpty) {
      if (mounted) luxToast(context, 'چیزی برای برگرداندن نیست.');
      return;
    }
    final id = _undo.removeLast();
    await ReaderRepo.deleteAnnotation(id);
    await _reloadAnns();
  }

  ReaderAnn? _bookmarkOn(int page1) {
    for (final a in _byPage[page1] ?? const <ReaderAnn>[]) {
      if (a.kind == 'bookmark') return a;
    }
    return null;
  }

  String? _statusOn(int page1) {
    for (final a in _byPage[page1] ?? const <ReaderAnn>[]) {
      if (a.kind == 'status') return a.note;
    }
    return null;
  }

  String _chapterOf(int page1) {
    for (final c in _chapters) {
      final s = c['start_page'] == null ? null : asInt(c['start_page']);
      final e = c['end_page'] == null ? null : asInt(c['end_page']);
      if (s != null && page1 >= s && (e == null || page1 <= e)) return asStr(c['title']);
    }
    return '';
  }

  Future<void> _toggleBookmark() async {
    final p1 = _page + 1;
    final ex = _bookmarkOn(p1);
    if (ex != null) {
      await ReaderRepo.deleteAnnotation(ex.id);
    } else {
      final ch = _chapterOf(p1);
      await ReaderRepo.addAnnotation(widget.bookId, p1, 'bookmark', note: ch.isEmpty ? 'صفحه‌ی ${faDigits(p1)}' : '$ch · صفحه‌ی ${faDigits(p1)}', color: kHlColors[0]);
      Haptic.tap();
    }
    await _reloadAnns();
  }

  Future<void> _pageNote() async {
    final p1 = _page + 1;
    ReaderAnn? ex;
    for (final a in _byPage[p1] ?? const <ReaderAnn>[]) {
      if (a.kind == 'note') ex = a;
    }
    final c = TextEditingController(text: ex?.note ?? '');
    await showLuxSheet<void>(
      context,
      (ctx) => Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Text('یادداشتِ صفحه‌ی ${faDigits(p1)}', style: LuxText.title),
          const SizedBox(height: 14),
          LuxField(label: 'یادداشت', controller: c, maxLines: 5, hint: 'هرچه برای این صفحه می‌خواهی یادت بماند'),
          LuxButton(
            label: 'ذخیره',
            onPressed: () async {
              final t = c.text.trim();
              if (ex != null) {
                if (t.isEmpty) {
                  await ReaderRepo.deleteAnnotation(ex.id);
                } else {
                  await ReaderRepo.updateAnnotation(ex.id, note: t);
                }
              } else if (t.isNotEmpty) {
                await ReaderRepo.addAnnotation(widget.bookId, p1, 'note', note: t);
              }
              await _reloadAnns();
              if (ctx.mounted) Navigator.of(ctx).pop();
            },
          ),
        ],
      ),
    );
  }

  Future<void> _pageStatus() async {
    final p1 = _page + 1;
    final cur = _statusOn(p1);
    await showLuxSheet<void>(
      context,
      (ctx) => Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Text('وضعیتِ صفحه‌ی ${faDigits(p1)}', style: LuxText.title),
          const SizedBox(height: 14),
          Wrap(spacing: 8, runSpacing: 8, children: [
            for (var i = 0; i < kPageStatusKeys.length; i++)
              LuxChip(
                label: kPageStatusNames[i],
                selected: cur == kPageStatusKeys[i],
                onTap: () async {
                  await ReaderRepo.setStatus(widget.bookId, p1, cur == kPageStatusKeys[i] ? null : kPageStatusKeys[i]);
                  await _reloadAnns();
                  if (ctx.mounted) Navigator.of(ctx).pop();
                },
              ),
          ]),
          const SizedBox(height: 16),
          LuxButton(
            label: 'این صفحه و صفحه‌ی بعد را «مطالعه شد» کن',
            filled: false,
            onPressed: () async {
              for (var k = p1; k <= p1 + 1 && k <= _count; k++) {
                await ReaderRepo.setStatus(widget.bookId, k, 'done');
              }
              await _reloadAnns();
              if (ctx.mounted) Navigator.of(ctx).pop();
            },
          ),
        ],
      ),
    );
  }

  /// ویرایشِ یک هایلایت: متن، یادداشت، رنگ و حذف.
  Future<void> _annSheet(ReaderAnn a) async {
    final c = TextEditingController(text: a.note);
    var color = a.color;
    await showLuxSheet<void>(
      context,
      (ctx) => StatefulBuilder(builder: (ctx, setS) {
        return Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Text('هایلایتِ صفحه‌ی ${faDigits(a.page)}', style: LuxText.title),
            if (a.text.isNotEmpty) ...[
              const SizedBox(height: 10),
              ConstrainedBox(
                constraints: BoxConstraints(maxHeight: MediaQuery.of(ctx).size.height * 0.22),
                child: SingleChildScrollView(child: Text(a.text, style: LuxText.body)),
              ),
            ],
            const SizedBox(height: 14),
            Wrap(spacing: 10, runSpacing: 10, children: [
              for (var i = 0; i < kHlColors.length; i++)
                GestureDetector(
                  onTap: () => setS(() => color = kHlColors[i]),
                  child: Container(
                    width: 34,
                    height: 34,
                    decoration: BoxDecoration(
                      color: Color(kHlColors[i]),
                      shape: BoxShape.circle,
                      border: Border.all(color: color == kHlColors[i] ? LuxColors.text : Colors.transparent, width: 2.4),
                    ),
                  ),
                ),
            ]),
            const SizedBox(height: 14),
            LuxField(label: 'یادداشت', controller: c, maxLines: 4, hint: 'توضیحی برای این هایلایت'),
            LuxButton(
              label: 'ذخیره',
              onPressed: () async {
                await ReaderRepo.updateAnnotation(a.id, note: c.text.trim(), color: color);
                await _reloadAnns();
                if (ctx.mounted) Navigator.of(ctx).pop();
              },
            ),
            const SizedBox(height: 8),
            LuxButton(
              label: 'کپی متن',
              filled: false,
              onPressed: () async {
                if (a.text.isNotEmpty) await Clipboard.setData(ClipboardData(text: a.text));
                if (ctx.mounted) Navigator.of(ctx).pop();
                if (mounted) luxToast(context, a.text.isEmpty ? 'متنی برای کپی نیست.' : 'کپی شد.');
              },
            ),
            const SizedBox(height: 8),
            LuxButton(
              label: 'حذف هایلایت',
              filled: false,
              onPressed: () async {
                await ReaderRepo.deleteAnnotation(a.id);
                _undo.remove(a.id);
                await _reloadAnns();
                if (ctx.mounted) Navigator.of(ctx).pop();
              },
            ),
          ],
        );
      }),
    );
    c.dispose();
  }

  // ───────────────────────── انتخابِ متن ─────────────────────────

  Future<void> _clearSel() async {
    try {
      final d = _ctl.textSelectionDelegate as dynamic;
      await d.clearTextSelection();
    } catch (_) {}
    if (!mounted) return;
    setState(() {
      _hasSel = false;
      _sel = null;
    });
  }

  Future<void> _copySel() async {
    final s = _sel;
    if (s == null) return;
    try {
      final t = await s.getSelectedText();
      if (t.trim().isEmpty) {
        if (mounted) luxToast(context, 'متنی انتخاب نشده.');
        return;
      }
      await Clipboard.setData(ClipboardData(text: t));
      Haptic.tap();
      if (mounted) luxToast(context, 'کپی شد.');
    } catch (_) {
      if (mounted) luxToast(context, 'کپی نشد.');
    }
  }

  Future<void> _highlightSel({int? colorIndex, bool withNote = false}) async {
    final s = _sel;
    if (s == null) return;
    try {
      final ranges = await s.getSelectedTextRanges();
      final hls = await textHighlightsFromRanges(ranges, _ctl.document);
      if (hls.isEmpty) {
        if (mounted) luxToast(context, 'متنی برای هایلایت پیدا نشد.');
        return;
      }
      if (colorIndex != null) _colorI = colorIndex;
      int? lastId;
      for (final h in hls) {
        lastId = await ReaderRepo.addAnnotation(
          widget.bookId,
          h.pageNumber,
          'hl',
          data: jsonEncode(<String, Object?>{'p': h.rects, 't': h.text, 'v': 2}),
          color: kHlColors[_colorI],
        );
        _undo.add(lastId);
      }
      Haptic.tap();
      await _clearSel();
      await _reloadAnns();
      if (withNote && lastId != null && mounted) {
        final made = _anns.where((a) => a.id == lastId).toList();
        if (made.isNotEmpty) await _annSheet(made.first);
      }
    } catch (_) {
      if (mounted) luxToast(context, 'هایلایت نشد.');
    }
  }

  Future<void> _searchSel() async {
    final s = _sel;
    if (s == null) return;
    try {
      final t = (await s.getSelectedText()).trim();
      if (t.isEmpty) return;
      await _clearSel();
      _openSearch(text: t.length > 60 ? t.substring(0, 60) : t);
    } catch (_) {}
  }

  // ───────────────────────── جست‌وجو ─────────────────────────

  void _openSearch({String? text}) {
    setState(() {
      _searchOn = true;
      _chrome = true;
      if (text != null) _q.text = text;
    });
    if (text != null) _runSearch(text, now: true);
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) _qFocus.requestFocus();
    });
  }

  void _closeSearch() {
    _searcher.resetTextSearch();
    _qFocus.unfocus();
    setState(() => _searchOn = false);
  }

  void _runSearch(String text, {bool now = false}) {
    final t = text.trim();
    if (t.isEmpty) {
      _searcher.resetTextSearch();
      return;
    }
    _searcher.startTextSearch(persianSearchPattern(t), searchImmediately: now);
  }

  String _searchInfo() {
    final n = _searcher.matches.length;
    if (_q.text.trim().isEmpty) return '';
    if (_searcher.isSearching && n == 0) return 'در حال جست‌وجو…';
    if (n == 0) return 'نتیجه‌ای نیست';
    final cur = (_searcher.currentIndex ?? -1) + 1;
    return '${faDigits(cur < 1 ? 1 : cur)} از ${faDigits(n)}${_searcher.isSearching ? '+' : ''}';
  }

  String _snippet(Object m) {
    try {
      final d = m as dynamic;
      final full = d.pageText.fullText as String;
      final s = d.start as int;
      final e = d.end as int;
      final a = math.max(0, s - 30);
      final b = math.min(full.length, e + 30);
      return full.substring(a, b).replaceAll(RegExp(r'\s+'), ' ').trim();
    } catch (_) {
      try {
        return ((m as dynamic).text as String).trim();
      } catch (_) {
        return '';
      }
    }
  }

  int _matchPage(Object m) {
    try {
      return (m as dynamic).pageNumber as int;
    } catch (_) {
      return 0;
    }
  }

  Future<void> _resultsSheet() async {
    final matches = _searcher.matches;
    if (matches.isEmpty) {
      luxToast(context, 'نتیجه‌ای نیست.');
      return;
    }
    final shown = math.min(matches.length, 400);
    await showLuxSheet<void>(
      context,
      (ctx) => Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Text('نتایج جست‌وجو (${faDigits(matches.length)})', style: LuxText.title),
          const SizedBox(height: 10),
          ConstrainedBox(
            constraints: BoxConstraints(maxHeight: MediaQuery.of(ctx).size.height * 0.6),
            child: ListView.builder(
              shrinkWrap: true,
              itemCount: shown,
              itemBuilder: (c, i) {
                final m = matches[i];
                return LuxRow(
                  leading: Icon(Icons.find_in_page_rounded, color: LuxColors.accent),
                  title: _snippet(m),
                  subtitle: 'صفحه‌ی ${faDigits(_matchPage(m))}',
                  onTap: () {
                    Navigator.of(ctx).pop();
                    _searcher.goToMatchOfIndex(i);
                  },
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  // ───────────────────────── ناوبری ─────────────────────────

  void _goTo(int i) {
    if (!_ctl.isReady) return;
    final p = i.clamp(0, math.max(0, _count - 1)).toInt();
    _ctl.goToPage(pageNumber: p + 1, anchor: _mode == 1 ? PdfPageAnchor.all : PdfPageAnchor.top);
  }

  Future<void> _nextReviewPage() async {
    final pages = <int>{};
    for (final a in _anns) {
      if (a.kind == 'bookmark' || a.kind == 'hl' || a.kind == 'note') pages.add(a.page);
      if (a.kind == 'status' && (a.note == 'review' || a.note == 'hard')) pages.add(a.page);
    }
    if (pages.isEmpty) {
      luxToast(context, 'هنوز صفحه‌ای برای مرور علامت نزده‌ای.');
      return;
    }
    final sorted = pages.toList()..sort();
    final next = sorted.firstWhere((p) => p > _page + 1, orElse: () => sorted.first);
    _goTo(next - 1);
    luxToast(context, 'صفحه‌ی ${faDigits(next)} از ${faDigits(sorted.length)} صفحه‌ی مرور');
  }

  void _fitWidth() {
    try {
      final m = _ctl.calcMatrixFitWidthForPage(pageNumber: _page + 1);
      if (m != null) _ctl.goTo(m);
    } catch (_) {}
  }

  void _zoom(bool up) {
    try {
      if (up) {
        _ctl.zoomUp();
      } else {
        _ctl.zoomDown();
      }
    } catch (_) {}
  }

  Future<void> _outlineSheet() async {
    final items = <List<Object?>>[]; // [عنوان، عمق، صفحه]
    try {
      final nodes = await (_ctl.document as dynamic).loadOutline();
      void walk(List<dynamic> l, int depth) {
        for (final n in l) {
          int? pg;
          try {
            pg = n.dest?.pageNumber as int?;
          } catch (_) {}
          String title = '';
          try {
            title = n.title as String;
          } catch (_) {}
          items.add(<Object?>[title, depth, pg]);
          try {
            walk(n.children as List<dynamic>, depth + 1);
          } catch (_) {}
        }
      }

      walk(nodes as List<dynamic>, 0);
    } catch (_) {}
    if (!mounted) return;
    await showLuxSheet<void>(
      context,
      (ctx) => Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Text('فهرستِ مطالبِ PDF', style: LuxText.title),
          const SizedBox(height: 10),
          if (items.isEmpty)
            const LuxEmpty(icon: Icons.list_alt_rounded, title: 'این PDF فهرستِ مطالب ندارد', hint: 'برای رفتن به یک فصل، از «فصل‌ها» یا «نقشه‌ی کتاب» استفاده کن.')
          else
            ConstrainedBox(
              constraints: BoxConstraints(maxHeight: MediaQuery.of(ctx).size.height * 0.6),
              child: ListView.builder(
                shrinkWrap: true,
                itemCount: items.length,
                itemBuilder: (c, i) {
                  final it = items[i];
                  final depth = it[1] as int;
                  final pg = it[2] as int?;
                  return Padding(
                    padding: EdgeInsetsDirectional.only(start: 14.0 * depth),
                    child: LuxRow(
                      leading: Icon(depth == 0 ? Icons.bookmark_rounded : Icons.subdirectory_arrow_left_rounded, color: LuxColors.accent, size: 20),
                      title: (it[0] as String).isEmpty ? 'بدون عنوان' : it[0] as String,
                      subtitle: pg == null ? null : 'صفحه‌ی ${faDigits(pg)}',
                      onTap: pg == null
                          ? null
                          : () {
                              Navigator.of(ctx).pop();
                              _goTo(pg - 1);
                            },
                    ),
                  );
                },
              ),
            ),
        ],
      ),
    );
  }

  // ───────────────────────── منو و تنظیمات ─────────────────────────

  Future<void> _export() async {
    final txt = buildNotesExport(
      title: asStr(_book?['title']),
      course: asStr(_book?['course']),
      chapters: _chapters,
      anns: _anns,
    );
    try {
      final dir = await getTemporaryDirectory();
      final f = File('${dir.path}/lux_notes.txt');
      await f.writeAsString(txt);
      final safe = asStr(_book?['title']).replaceAll(RegExp(r'[^\w\u0600-\u06FF ]'), '_');
      final ok = await FileBridge.saveAs(f.path, 'یادداشت‌های $safe.txt', mime: 'text/plain');
      if (mounted && ok) luxToast(context, 'ذخیره شد.');
    } catch (_) {
      if (mounted) luxNotice(context, 'ذخیره نشد.');
    }
  }

  Future<void> _chaptersSheet() async {
    await showLuxSheet<void>(
      context,
      (ctx) => Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Text('فصل‌ها', style: LuxText.title),
          const SizedBox(height: 12),
          if (_chapters.isEmpty)
            const LuxEmpty(icon: Icons.menu_book_rounded, title: 'فصلی ثبت نشده', hint: 'فصل‌ها را از صفحه‌ی کتاب (تب درس‌ها) اضافه کن؛ بعد اینجا هم می‌آیند.')
          else
            ConstrainedBox(
              constraints: BoxConstraints(maxHeight: MediaQuery.of(ctx).size.height * 0.5),
              child: ListView(
                shrinkWrap: true,
                children: [
                  for (final c in _chapters)
                    LuxRow(
                      leading: Icon(asInt(c['done']) == 1 ? Icons.check_circle_rounded : Icons.menu_book_rounded, color: asInt(c['done']) == 1 ? LuxColors.ok : LuxColors.accent),
                      title: asStr(c['title']),
                      subtitle: c['start_page'] == null ? null : 'صفحه‌ی ${faDigits(c['start_page'])}${c['end_page'] == null ? '' : ' تا ${faDigits(c['end_page'])}'}',
                      onTap: c['start_page'] == null
                          ? null
                          : () {
                              Navigator.of(ctx).pop();
                              _goTo(asInt(c['start_page']) - 1);
                            },
                    ),
                ],
              ),
            ),
        ],
      ),
    );
  }

  /// تغییرِ حالتِ صفحه نمایشگر را از نو می‌سازد (چیدمانِ صفحه‌ها عوض می‌شود).
  void _setMode(int m) {
    if (m == _mode) return;
    LuxDb.instance.kvSet('reader_mode', '$m');
    _searcher.removeListener(_onSearch);
    _searcher.dispose();
    _makeController();
    setState(() {
      _mode = m;
      _startPage = _page;
      _viewerGen++;
      _hasSel = false;
      _sel = null;
    });
  }

  Future<void> _display() async {
    await showLuxSheet<void>(
      context,
      (ctx) => StatefulBuilder(builder: (ctx, setS) {
        return Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Text('نمایش', style: LuxText.title),
            const SizedBox(height: 14),
            LuxChoice(
              label: 'حالتِ صفحه',
              options: const ['عمودی (پیوسته)', 'افقی (راست‌به‌چپ)'],
              selected: _mode,
              onChanged: (i) {
                _setMode(i);
                setS(() {});
              },
            ),
            LuxChoice(
              label: 'رنگِ صفحه',
              options: const ['عادی', 'شب', 'کاغذی'],
              selected: _filter,
              onChanged: (i) async {
                await LuxDb.instance.kvSet('reader_filter', '$i');
                setState(() => _filter = i);
                setS(() {});
              },
            ),
            LuxChoice(
              label: 'روشن ماندنِ صفحه هنگام مطالعه',
              options: const ['بله', 'نه'],
              selected: _awake ? 0 : 1,
              onChanged: (i) async {
                await LuxDb.instance.kvSet('reader_awake', i == 0 ? '1' : '0');
                PdfBridge.keepAwake(i == 0);
                setState(() => _awake = i == 0);
                setS(() {});
              },
            ),
          ],
        );
      }),
    );
  }

  Future<void> _menu() async {
    Widget row(IconData icon, String title, String sub, VoidCallback act) => LuxRow(
          leading: Icon(icon, color: LuxColors.accent),
          title: title,
          subtitle: sub,
          onTap: () {
            Navigator.of(context).pop();
            act();
          },
        );
    await showLuxSheet<void>(
      context,
      (ctx) => ConstrainedBox(
        constraints: BoxConstraints(maxHeight: MediaQuery.of(ctx).size.height * 0.72),
        child: ListView(
          shrinkWrap: true,
          children: [
            Text(asStr(_book?['title']), style: LuxText.title),
            const SizedBox(height: 10),
            row(Icons.search_rounded, 'جست‌وجو در متنِ کتاب', 'پیدا کردنِ هر کلمه یا جمله، با پرش به نتیجه', () => _openSearch()),
            row(Icons.list_alt_rounded, 'فهرستِ مطالبِ PDF', 'سرفصل‌های خودِ فایل', _outlineSheet),
            row(Icons.bookmarks_rounded, 'نشانک‌ها، یادداشت‌ها و هایلایت‌ها', 'فهرست، جست‌وجو و رفتن به محلِ اصلی', () {
              showReaderNotes(context, anns: _anns, onJump: _goTo, onChanged: _reloadAnns);
            }),
            row(Icons.grid_view_rounded, 'نقشه‌ی کتاب', 'وضعیتِ همه‌ی صفحه‌ها با رنگ', () {
              final st = <int, String>{};
              final marked = <int>{};
              for (final a in _anns) {
                if (a.kind == 'status') {
                  st[a.page] = a.note;
                } else {
                  marked.add(a.page);
                }
              }
              showBookMap(context, count: _count, statusByPage: st, marked: marked, current: _page, onJump: _goTo);
            }),
            row(Icons.sticky_note_2_rounded, 'یادداشتِ این صفحه', 'متنی که به همین صفحه وصل می‌شود', _pageNote),
            row(Icons.flag_rounded, 'وضعیتِ این صفحه', 'در حال مطالعه، مطالعه شد، نیازمند مرور، دشوار', _pageStatus),
            row(Icons.error_outline_rounded, 'ثبتِ اشتباه از این صفحه', 'به دفترچه‌ی اشتباهات و مرورِ فاصله‌دار می‌رود', () {
              showMistakeEditor(
                context,
                courseId: _book?['course_id'] == null ? null : asInt(_book!['course_id']),
                bookId: widget.bookId,
                page: _page + 1,
              );
            }),
            row(Icons.skip_next_rounded, 'حالتِ مرور', 'رفتن به صفحه‌ی بعدیِ نشانک‌دار، هایلایت‌دار، دشوار یا نیازمند مرور', _nextReviewPage),
            row(Icons.menu_book_rounded, 'فصل‌ها', 'رفتن به ابتدای هر فصل', _chaptersSheet),
            row(Icons.insights_rounded, 'آمارِ این کتاب', 'زمان، پیشرفت، صفحه‌های باقی‌مانده', () {
              showReaderStats(context, bookId: widget.bookId, title: asStr(_book?['title']), count: _count, anns: _anns);
            }),
            row(Icons.ios_share_rounded, 'خروجیِ یادداشت‌ها (TXT)', 'نشانک‌ها، یادداشت‌ها، هایلایت‌ها (با متنِ کامل) و صفحه‌های مرور', _export),
            row(Icons.tune_rounded, 'نمایش', 'حالتِ صفحه، رنگ، روشن ماندنِ صفحه', _display),
          ],
        ),
      ),
    );
  }

  // ───────────────────────── ساختِ صفحه ─────────────────────────

  Color get _bg => _filter == 1 ? Colors.black : (_filter == 2 ? const Color(0xFFE9DFC6) : LuxColors.bg);

  Color _inv(Color c) => readerTint(c.toARGB32(), invert: _filter == 1);

  Widget _viewer() {
    final params = PdfViewerParams(
      margin: 6,
      backgroundColor: _bg,
      pageDropShadow: _filter == 1 ? null : const BoxShadow(color: Color(0x55000000), blurRadius: 5, spreadRadius: 1, offset: Offset(1, 2)),
      layoutPages: _mode == 1 ? _rtlLayout : null,
      pageAnchor: _mode == 1 ? PdfPageAnchor.all : PdfPageAnchor.top,
      calculateInitialPageNumber: _initialPage,
      onViewerReady: _onReady,
      onPageChanged: _onPage,
      onGeneralTap: _onTap,
      buildContextMenu: _noMenu,
      textSelectionParams: PdfTextSelectionParams(onTextSelectionChange: _onSelChange),
      linkHandlerParams: PdfLinkHandlerParams(onLinkTap: _onLink),
      pagePaintCallbacks: <PdfViewerPagePaintCallback>[_searcher.pageTextMatchPaintCallback, _paintAnns],
      pageOverlaysBuilder: _pageOverlays,
      matchTextColor: _inv(const Color(0x66FFEB3B)),
      activeMatchTextColor: _inv(const Color(0x99FF9800)),
      loadingBannerBuilder: _loadBanner,
      errorBannerBuilder: _errBanner,
    );
    Widget v = PdfViewer.file(
      _path,
      key: ValueKey<String>('viewer$_viewerGen'),
      controller: _ctl,
      params: params,
      passwordProvider: _askPassword,
    );
    if (_filter == 1) {
      v = ColorFiltered(colorFilter: const ColorFilter.matrix(_nightMatrix), child: v);
    } else if (_filter == 2) {
      v = ColorFiltered(colorFilter: const ColorFilter.matrix(_sepiaMatrix), child: v);
    }
    return v;
  }

  Widget _errorView(String msg) => ColoredBox(
        color: const Color(0xFF111111),
        child: SingleChildScrollView(
          padding: const EdgeInsets.fromLTRB(14, 60, 14, 20),
          child: Directionality(
            textDirection: TextDirection.ltr,
            child: Text('PDF viewer error (send a screenshot):\n\n$msg', style: const TextStyle(color: Color(0xFFFFB4AB), fontSize: 11, height: 1.35)),
          ),
        ),
      );

  Widget _circle(IconData icon, VoidCallback onTap, {Color? color}) => GestureDetector(
        behavior: HitTestBehavior.opaque,
        onTap: () {
          Haptic.tap();
          onTap();
        },
        child: Container(
          width: 42,
          height: 42,
          decoration: BoxDecoration(color: LuxColors.alpha(Colors.black, 0.45), shape: BoxShape.circle),
          child: Icon(icon, color: color ?? Colors.white, size: 22),
        ),
      );

  Widget _topBar() {
    final p1 = _page + 1;
    final ch = _chapterOf(p1);
    final marked = _bookmarkOn(p1) != null;
    return Container(
      padding: const EdgeInsets.fromLTRB(10, 8, 10, 8),
      decoration: BoxDecoration(
        gradient: LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: [LuxColors.alpha(Colors.black, 0.7), Colors.transparent]),
      ),
      child: Row(
        children: [
          _circle(Icons.arrow_forward_rounded, () => Navigator.of(context).pop()),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(asStr(_book?['title']), maxLines: 1, overflow: TextOverflow.ellipsis, style: LuxText.label.copyWith(color: Colors.white)),
                if (ch.isNotEmpty) Text(ch, maxLines: 1, overflow: TextOverflow.ellipsis, style: LuxText.caption.copyWith(color: Colors.white70)),
              ],
            ),
          ),
          GestureDetector(
            onTap: () => showPageJump(context, count: math.max(1, _count), current: _page, onJump: _goTo),
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 9),
              decoration: BoxDecoration(color: LuxColors.alpha(Colors.black, 0.45), borderRadius: BorderRadius.circular(LuxColors.r(18))),
              child: Text('${faDigits(p1)} / ${faDigits(_count)}', style: LuxText.label.copyWith(color: Colors.white)),
            ),
          ),
          const SizedBox(width: 8),
          _circle(Icons.search_rounded, () => _openSearch()),
          const SizedBox(width: 8),
          _circle(marked ? Icons.bookmark_rounded : Icons.bookmark_border_rounded, _toggleBookmark, color: marked ? const Color(0xFFFFD54F) : Colors.white),
          const SizedBox(width: 8),
          _circle(Icons.more_vert_rounded, _menu),
        ],
      ),
    );
  }

  Widget _searchBar() {
    final n = _searcher.matches.length;
    return Container(
      padding: const EdgeInsets.fromLTRB(10, 8, 10, 8),
      decoration: BoxDecoration(
        gradient: LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: [LuxColors.alpha(Colors.black, 0.78), Colors.transparent]),
      ),
      child: Row(
        children: [
          _circle(Icons.close_rounded, _closeSearch),
          const SizedBox(width: 8),
          Expanded(
            child: Container(
              height: 44,
              padding: const EdgeInsets.symmetric(horizontal: 12),
              decoration: BoxDecoration(color: LuxColors.alpha(Colors.black, 0.55), borderRadius: BorderRadius.circular(LuxColors.r(16))),
              child: Row(
                children: [
                  Expanded(
                    child: TextField(
                      controller: _q,
                      focusNode: _qFocus,
                      style: LuxText.body.copyWith(color: Colors.white),
                      cursorColor: LuxColors.accent,
                      textInputAction: TextInputAction.search,
                      decoration: InputDecoration(
                        border: InputBorder.none,
                        enabledBorder: InputBorder.none,
                        focusedBorder: InputBorder.none,
                        filled: false,
                        isDense: true,
                        hintText: 'جست‌وجو در متنِ کتاب…',
                        hintStyle: LuxText.body.copyWith(color: Colors.white54),
                      ),
                      onChanged: (t) => _runSearch(t),
                      onSubmitted: (t) {
                        _runSearch(t, now: true);
                        if (_searcher.matches.isNotEmpty) _searcher.goToNextMatch();
                      },
                    ),
                  ),
                  if (_searchInfo().isNotEmpty) Text(_searchInfo(), style: LuxText.caption.copyWith(color: Colors.white70)),
                ],
              ),
            ),
          ),
          const SizedBox(width: 8),
          _circle(Icons.keyboard_arrow_up_rounded, () => _searcher.goToPrevMatch()),
          const SizedBox(width: 6),
          _circle(Icons.keyboard_arrow_down_rounded, () => _searcher.goToNextMatch()),
          const SizedBox(width: 6),
          _circle(Icons.format_list_bulleted_rounded, _resultsSheet, color: n == 0 ? Colors.white38 : Colors.white),
        ],
      ),
    );
  }

  Widget _toolBtn(IconData icon, bool active, VoidCallback onTap, {Color? tint}) => GestureDetector(
        behavior: HitTestBehavior.opaque,
        onTap: () {
          Haptic.tap();
          onTap();
        },
        child: Container(
          width: 46,
          height: 46,
          margin: const EdgeInsets.symmetric(horizontal: 3),
          decoration: BoxDecoration(
            color: active ? LuxColors.accent : LuxColors.alpha(Colors.white, 0.1),
            borderRadius: BorderRadius.circular(LuxColors.r(16)),
          ),
          child: Icon(icon, color: active ? LuxColors.onAccent : (tint ?? Colors.white), size: 23),
        ),
      );

  Future<void> _pickColor() async {
    await showLuxSheet<void>(
      context,
      (ctx) => Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Text('رنگِ هایلایت و قلم', style: LuxText.title),
          const SizedBox(height: 14),
          for (var i = 0; i < kHlColors.length; i++)
            LuxRow(
              leading: Container(width: 26, height: 26, decoration: BoxDecoration(color: Color(kHlColors[i]), shape: BoxShape.circle)),
              title: kHlNames[i],
              trailing: _colorI == i ? Icon(Icons.check_rounded, color: LuxColors.accent) : null,
              onTap: () {
                setState(() => _colorI = i);
                Navigator.of(ctx).pop();
              },
            ),
        ],
      ),
    );
  }

  void _setTool(int t) {
    setState(() => _tool = t);
    _refreshViewer();
  }

  Widget _selBtn(IconData icon, String tip, VoidCallback onTap) => Tooltip(
        message: tip,
        child: GestureDetector(
          behavior: HitTestBehavior.opaque,
          onTap: () {
            Haptic.tap();
            onTap();
          },
          child: Container(
            width: 42,
            height: 42,
            margin: const EdgeInsets.symmetric(horizontal: 2),
            alignment: Alignment.center,
            child: Icon(icon, color: LuxColors.text, size: 23),
          ),
        ),
      );

  /// نوارِ شناور بعد از انتخابِ متن: کپی، هایلایت با رنگ، یادداشت، جست‌وجو.
  Widget _selBar() {
    return Container(
      margin: const EdgeInsets.fromLTRB(12, 0, 12, 8),
      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 4),
      decoration: BoxDecoration(
        color: LuxColors.card,
        borderRadius: BorderRadius.circular(LuxColors.r(24)),
        border: Border.all(color: LuxColors.strokeColor, width: LuxColors.strokeW),
        boxShadow: [BoxShadow(color: LuxColors.alpha(Colors.black, 0.35), blurRadius: 16, offset: const Offset(0, 4))],
      ),
      child: SingleChildScrollView(
        scrollDirection: Axis.horizontal,
        child: Row(
          children: [
            _selBtn(Icons.copy_rounded, 'کپی', _copySel),
            Container(width: 1, height: 24, margin: const EdgeInsets.symmetric(horizontal: 4), color: LuxColors.stroke),
            for (var i = 0; i < kHlColors.length; i++)
              GestureDetector(
                behavior: HitTestBehavior.opaque,
                onTap: () {
                  Haptic.tap();
                  _highlightSel(colorIndex: i);
                },
                child: Container(
                  width: 38,
                  height: 42,
                  alignment: Alignment.center,
                  child: Container(
                    width: 26,
                    height: 26,
                    decoration: BoxDecoration(
                      color: Color(kHlColors[i]),
                      shape: BoxShape.circle,
                      border: Border.all(color: i == _colorI ? LuxColors.text : Colors.transparent, width: 2),
                    ),
                  ),
                ),
              ),
            Container(width: 1, height: 24, margin: const EdgeInsets.symmetric(horizontal: 4), color: LuxColors.stroke),
            _selBtn(Icons.edit_note_rounded, 'هایلایت با یادداشت', () => _highlightSel(withNote: true)),
            _selBtn(Icons.search_rounded, 'جست‌وجو', _searchSel),
            _selBtn(Icons.close_rounded, 'لغو', _clearSel),
          ],
        ),
      ),
    );
  }

  Widget _bottomBar() {
    final p1 = _page + 1;
    final st = _statusOn(p1);
    final si = st == null ? -1 : kPageStatusKeys.indexOf(st);
    final count = _count;
    return Container(
      padding: const EdgeInsets.fromLTRB(12, 18, 12, 10),
      decoration: BoxDecoration(
        gradient: LinearGradient(begin: Alignment.bottomCenter, end: Alignment.topCenter, colors: [LuxColors.alpha(Colors.black, 0.78), Colors.transparent]),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          if (_tool != 0)
            Padding(
              padding: const EdgeInsets.only(bottom: 4),
              child: Text(
                _tool == 1
                    ? 'برای هایلایتِ مستطیلی (متنِ اسکن‌شده)، روی صفحه بکش'
                    : (_tool == 2 ? 'با انگشت روی صفحه بنویس' : 'روی یک هایلایت یا نوشته بزن تا پاک شود'),
                style: LuxText.caption.copyWith(color: Colors.white70),
              ),
            ),
          if (_tool == 0 && !_hasSel)
            Padding(
              padding: const EdgeInsets.only(bottom: 2),
              child: Text('برای انتخابِ متن، روی آن نگه دار؛ برای زوم، دو انگشت یا دو بار لمس', style: LuxText.caption.copyWith(color: Colors.white54)),
            ),
          if (count > 1)
            Slider(
              value: (_dragPage ?? p1.toDouble()).clamp(1.0, count.toDouble()).toDouble(),
              min: 1,
              max: count.toDouble(),
              activeColor: LuxColors.accent,
              inactiveColor: Colors.white24,
              onChanged: (v) => setState(() => _dragPage = v),
              onChangeEnd: (v) {
                setState(() => _dragPage = null);
                _goTo(v.round() - 1);
              },
            ),
          SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            child: Row(
              children: [
                _toolBtn(Icons.text_fields_rounded, _tool == 0, () => _setTool(0)),
                _toolBtn(Icons.highlight_alt_rounded, _tool == 1, () => _setTool(_tool == 1 ? 0 : 1)),
                _toolBtn(Icons.draw_rounded, _tool == 2, () => _setTool(_tool == 2 ? 0 : 2)),
                _toolBtn(Icons.cleaning_services_rounded, _tool == 3, () => _setTool(_tool == 3 ? 0 : 3)),
                _toolBtn(Icons.undo_rounded, false, _undoLast),
                GestureDetector(
                  onTap: _pickColor,
                  child: Container(
                    width: 46,
                    height: 46,
                    margin: const EdgeInsets.symmetric(horizontal: 3),
                    decoration: BoxDecoration(color: LuxColors.alpha(Colors.white, 0.1), borderRadius: BorderRadius.circular(LuxColors.r(16))),
                    child: Center(child: Container(width: 24, height: 24, decoration: BoxDecoration(color: Color(kHlColors[_colorI]), shape: BoxShape.circle, border: Border.all(color: Colors.white, width: 2)))),
                  ),
                ),
                const SizedBox(width: 6),
                _toolBtn(Icons.flag_rounded, false, _pageStatus, tint: si < 0 ? null : Color(kPageStatusColors[si])),
                _toolBtn(Icons.sticky_note_2_rounded, false, _pageNote),
                _toolBtn(Icons.zoom_out_rounded, false, () => _zoom(false)),
                _toolBtn(Icons.zoom_in_rounded, false, () => _zoom(true)),
                _toolBtn(Icons.fit_screen_rounded, false, _fitWidth),
                _toolBtn(_mode == 0 ? Icons.view_agenda_rounded : Icons.view_carousel_rounded, false, () => _setMode(_mode == 0 ? 1 : 0)),
                _toolBtn(Icons.brightness_6_rounded, false, () async {
                  final f = (_filter + 1) % 3;
                  await LuxDb.instance.kvSet('reader_filter', '$f');
                  setState(() => _filter = f);
                }),
              ],
            ),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) {
      return Scaffold(backgroundColor: LuxColors.bg, body: Center(child: CircularProgressIndicator(color: LuxColors.accent)));
    }
    if (_error != null) {
      return Scaffold(
        backgroundColor: LuxColors.bg,
        body: SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Icon(Icons.picture_as_pdf_rounded, size: 56, color: LuxColors.silverDim),
                const SizedBox(height: 14),
                Text(_error ?? 'خطا', style: LuxText.heading, textAlign: TextAlign.center),
                const SizedBox(height: 20),
                LuxButton(label: 'بازگشت', onPressed: () => Navigator.of(context).pop()),
              ],
            ),
          ),
        ),
      );
    }
    return Scaffold(
      backgroundColor: _bg,
      body: SafeArea(
        child: Stack(
          children: [
            Positioned.fill(
              child: Builder(builder: (context) {
                try {
                  return _viewer();
                } catch (e, st) {
                  return _errorView('$e\n\n${st.toString().split('\n').take(10).join('\n')}');
                }
              }),
            ),
            if (_chrome) Positioned(top: 0, left: 0, right: 0, child: _searchOn ? _searchBar() : _topBar()),
            Positioned(
              bottom: 0,
              left: 0,
              right: 0,
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  if (_hasSel && _tool == 0) _selBar(),
                  if (_chrome && !_searchOn) _bottomBar(),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
