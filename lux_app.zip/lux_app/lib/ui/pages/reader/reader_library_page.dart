import 'dart:io';

import 'package:flutter/material.dart';

import '../../../core/app_bus.dart';
import '../../../core/jalali_utils.dart';
import '../../../core/palette.dart';
import '../../../core/theme.dart';
import '../../../core/util.dart';
import '../../../data/database.dart';
import '../../../data/reader_repo.dart';
import '../../../services/file_bridge.dart';
import '../../../services/pdf_bridge.dart';
import '../../widgets/lux_button.dart';
import '../../widgets/lux_card.dart';
import '../../widgets/lux_chip.dart';
import '../../widgets/lux_kit.dart';
import '../../widgets/lux_section.dart';
import '../manage/editors.dart';
import '../study_stats_page.dart';
import 'study_reader_page.dart';

String _titleFromPath(String path) {
  var n = path.split('/').last;
  final us = n.indexOf('_');
  if (us > 0 && int.tryParse(n.substring(0, us)) != null) n = n.substring(us + 1);
  if (n.toLowerCase().endsWith('.pdf')) n = n.substring(0, n.length - 4);
  return n.replaceAll('_', ' ').trim();
}

/// افزودنِ یک PDF به کتابخانه (انتخابِ فایل، نام و درس). اگر [bookId] بدهی، به همان کتاب وصل می‌شود.
Future<int?> addPdfFlow(BuildContext context, {int? bookId, int? courseId}) async {
  final path = await FileBridge.pickPdf();
  if (path == null) return null;
  final info = await PdfBridge.open(path);
  await PdfBridge.close();
  if (info == null) {
    if (context.mounted) luxNotice(context, 'این PDF باز نشد؛ شاید رمز دارد یا خراب است.');
    try {
      File(path).deleteSync();
    } catch (_) {}
    return null;
  }
  if (bookId != null) {
    await ReaderRepo.attachPdf(bookId, path, info.count);
    return bookId;
  }
  if (!context.mounted) return null;
  final title = TextEditingController(text: _titleFromPath(path));
  int? cid = courseId;
  final ok = await showLuxSheet<bool>(
    context,
    (ctx) => StatefulBuilder(builder: (ctx, setS) {
      return Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Text('افزودن به کتابخانه', style: LuxText.title),
          const SizedBox(height: 4),
          Text('${faDigits(info.count)} صفحه', style: LuxText.caption),
          const SizedBox(height: 14),
          LuxField(label: 'نامِ کتاب', controller: title),
          LuxCourseChips(label: 'درس', selectedId: cid, allowNone: true, onChanged: (id) => setS(() => cid = id)),
          LuxButton(
            label: 'افزودن',
            onPressed: () {
              if (title.text.trim().isEmpty) {
                luxNotice(ctx, 'یک نام بنویس.');
                return;
              }
              Navigator.of(ctx).pop(true);
            },
          ),
        ],
      );
    }),
  );
  if (ok != true) {
    try {
      File(path).deleteSync();
    } catch (_) {}
    return null;
  }
  return ReaderRepo.addBook(path: path, title: title.text.trim(), courseId: cid, pages: info.count);
}

Future<void> openReader(BuildContext context, int bookId, {int? page}) =>
    pushPage<void>(context, StudyReaderPage(bookId: bookId, startPage: page));

class ReaderLibraryPage extends StatefulWidget {
  const ReaderLibraryPage({super.key});

  @override
  State<ReaderLibraryPage> createState() => _ReaderLibraryPageState();
}

class _ReaderLibraryPageState extends State<ReaderLibraryPage> {
  List<Map<String, Object?>> _books = <Map<String, Object?>>[];
  int _filter = 0; // ۰ همه، ۱ در حال مطالعه، ۲ تمام‌شده
  final TextEditingController _search = TextEditingController();
  bool _loaded = false;

  @override
  void initState() {
    super.initState();
    _load();
    AppBus.data.addListener(_load);
  }

  @override
  void dispose() {
    AppBus.data.removeListener(_load);
    _search.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    final b = await ReaderRepo.library();
    if (!mounted) return;
    setState(() {
      _books = b;
      _loaded = true;
    });
  }

  double _progress(Map<String, Object?> b) {
    final pages = asInt(b['pages']);
    if (pages <= 0) return 0;
    final done = asInt(b['done_pages']);
    final last = asInt(b['last_page']);
    final v = done > 0 ? done : last;
    return (v / pages).clamp(0.0, 1.0).toDouble();
  }

  bool _finished(Map<String, Object?> b) {
    final pages = asInt(b['pages']);
    return pages > 0 && asInt(b['done_pages']) >= pages;
  }

  Future<void> _editBook(Map<String, Object?> b) async {
    final title = TextEditingController(text: asStr(b['title']));
    int? cid = b['course_id'] == null ? null : asInt(b['course_id']);
    int? size;
    try {
      size = File(asStr(b['file_path'])).lengthSync();
    } catch (_) {}
    await showLuxSheet<void>(
      context,
      (ctx) => StatefulBuilder(builder: (ctx, setS) {
        return Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Text('ویرایش کتاب', style: LuxText.title),
            if (size != null) Text('حجمِ فایل: ${ReaderRepo.sizeLabel(size)} · نسخه‌ی مستقل در حافظه‌ی لوکس', style: LuxText.caption),
            const SizedBox(height: 14),
            LuxField(label: 'نام', controller: title),
            LuxCourseChips(label: 'درس', selectedId: cid, allowNone: true, onChanged: (id) => setS(() => cid = id)),
            LuxButton(
              label: 'ذخیره',
              onPressed: () async {
                if (title.text.trim().isEmpty) return;
                await ReaderRepo.updateBook(asInt(b['id']), title: title.text.trim(), courseId: cid);
                if (ctx.mounted) Navigator.of(ctx).pop();
              },
            ),
            const SizedBox(height: 10),
            LuxButton(
              label: 'حذف PDF از کتابخانه',
              filled: false,
              onPressed: () async {
                final ok = await luxConfirm(ctx, 'فایل PDF حذف شود؟', body: 'نشانک‌ها، یادداشت‌ها و هایلایت‌های این کتاب هم پاک می‌شوند. کتاب (فصل‌ها و مرور) می‌ماند.');
                if (!ok) return;
                final db = LuxDb.instance;
                await db.delete('annotations', where: 'book_id = ?', args: [asInt(b['id'])]);
                await db.update('books', <String, Object?>{'file_path': null, 'last_page': 0}, where: 'id = ?', args: [asInt(b['id'])]);
                try {
                  File(asStr(b['file_path'])).deleteSync();
                } catch (_) {}
                AppBus.bump();
                if (ctx.mounted) Navigator.of(ctx).pop();
              },
            ),
          ],
        );
      }),
    );
  }

  Widget _bookRow(Map<String, Object?> b) {
    final pages = asInt(b['pages']);
    final last = asInt(b['last_page']);
    final pr = _progress(b);
    final ms = asInt(b['read_ms']);
    return LuxRow(
      leading: SizedBox(
        width: 44,
        height: 44,
        child: Stack(
          alignment: Alignment.center,
          children: [
            CircularProgressIndicator(value: pr, strokeWidth: 3.5, backgroundColor: LuxColors.cardHi, valueColor: AlwaysStoppedAnimation<Color>(pr >= 1 ? LuxColors.ok : LuxColors.accent)),
            Icon(Icons.picture_as_pdf_rounded, size: 19, color: LuxColors.silver),
          ],
        ),
      ),
      title: asStr(b['title']),
      subtitle: [
        if (asStr(b['course']).isNotEmpty) asStr(b['course']),
        last > 0 ? 'صفحه‌ی ${faDigits(last)} از ${faDigits(pages)}' : '${faDigits(pages)} صفحه',
        if (ms > 0) fmtMinutes((ms / 60000).round()),
      ].join(' · '),
      trailing: GestureDetector(
        behavior: HitTestBehavior.opaque,
        onTap: () => _editBook(b),
        child: Padding(padding: const EdgeInsets.all(8), child: Icon(Icons.more_horiz_rounded, color: LuxColors.silverDim)),
      ),
      onTap: () => openReader(context, asInt(b['id'])),
    );
  }

  @override
  Widget build(BuildContext context) {
    final q = _search.text.trim();
    final shown = [
      for (final b in _books)
        if ((_filter == 0 || (_filter == 1 && !_finished(b) && asInt(b['last_page']) > 0) || (_filter == 2 && _finished(b))) &&
            (q.isEmpty || asStr(b['title']).contains(q) || asStr(b['course']).contains(q)))
          b,
    ];
    final recent = _books.isNotEmpty && asInt(_books.first['last_page']) > 0 && !_finished(_books.first) ? _books.first : null;

    final byCourse = <String, List<Map<String, Object?>>>{};
    for (final b in shown) {
      final k = asStr(b['course']).isEmpty ? 'بدون درس' : asStr(b['course']);
      byCourse.putIfAbsent(k, () => <Map<String, Object?>>[]).add(b);
    }

    var totalMs = 0;
    for (final b in _books) {
      totalMs += asInt(b['read_ms']);
    }

    return LuxSubPage(
      title: 'کتابخانه‌ی PDF',
      subtitle: _books.isEmpty ? 'کتاب و جزوه‌هات رو اینجا بخون و حاشیه‌نویسی کن' : '${faDigits(_books.length)} فایل · ${fmtMinutes((totalMs / 60000).round())} مطالعه',
      action: LuxAddButton(onTap: () => addPdfFlow(context).then((id) {
            if (id != null && mounted) openReader(context, id);
          })),
      children: [
        if (recent != null) ...[
          LuxCard(
            radius: 26,
            onTap: () => openReader(context, asInt(recent['id'])),
            child: Row(
              children: [
                Container(
                  width: 54,
                  height: 54,
                  decoration: BoxDecoration(color: LuxColors.alpha(LuxColors.accent, 0.14), borderRadius: BorderRadius.circular(18)),
                  child: Icon(Icons.auto_stories_rounded, color: LuxColors.accent, size: 28),
                ),
                const SizedBox(width: 14),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('ادامه‌ی مطالعه', style: LuxText.caption),
                      Text(asStr(recent['title']), style: LuxText.heading, maxLines: 1, overflow: TextOverflow.ellipsis),
                      Text('صفحه‌ی ${faDigits(asInt(recent['last_page']))} از ${faDigits(asInt(recent['pages']))}', style: LuxText.caption),
                    ],
                  ),
                ),
                Icon(Icons.play_circle_fill_rounded, color: LuxColors.accent, size: 34),
              ],
            ),
          ),
          const SizedBox(height: 16),
        ],
        if (_loaded && _books.isEmpty)
          LuxCard(
            child: Column(
              children: [
                const LuxEmpty(
                  icon: Icons.picture_as_pdf_rounded,
                  title: 'هنوز PDF‌ای نداری',
                  hint: 'کتاب درسی یا جزوه‌ات رو اضافه کن. هایلایت، یادداشت، نشانک، وضعیتِ صفحه و آمارِ مطالعه به درس‌هات وصل می‌شن.',
                ),
                LuxButton(
                  label: 'افزودنِ اولین PDF',
                  icon: Icons.add_rounded,
                  onPressed: () => addPdfFlow(context).then((id) {
                    if (id != null && mounted) openReader(context, id);
                  }),
                ),
              ],
            ),
          )
        else ...[
          LuxField(label: 'جست‌وجو در نامِ کتاب یا درس', controller: _search, onChanged: (_) => setState(() {})),
          Wrap(spacing: 8, runSpacing: 8, children: [
            LuxChip(label: 'همه', selected: _filter == 0, onTap: () => setState(() => _filter = 0)),
            LuxChip(label: 'در حال مطالعه', selected: _filter == 1, onTap: () => setState(() => _filter = 1)),
            LuxChip(label: 'تمام‌شده', selected: _filter == 2, onTap: () => setState(() => _filter = 2)),
          ]),
          const SizedBox(height: 16),
          if (shown.isEmpty)
            const LuxCard(child: LuxEmpty(icon: Icons.search_off_rounded, title: 'موردی پیدا نشد'))
          else
            for (final e in byCourse.entries) ...[
              LuxSection(title: e.key, children: [for (final b in e.value) _bookRow(b)]),
              const SizedBox(height: 14),
            ],
        ],
      ],
    );
  }
}
