import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:pdfrx/pdfrx.dart';

/// الگوی جست‌وجوی «فارسی‌پسند»: ی/ي/ى، ک/ك، رقم‌های فارسی/عربی/لاتین،
/// نیم‌فاصله و اِعراب بینِ حروف نادیده گرفته می‌شوند.
RegExp persianSearchPattern(String query) {
  final sb = StringBuffer();
  final runes = query.trim().runes.toList();
  const gap = r'[\u200c\u200d\u064b-\u0652]*';
  for (var i = 0; i < runes.length; i++) {
    final ch = String.fromCharCode(runes[i]);
    if (RegExp(r'\s').hasMatch(ch)) {
      sb.write(r'[\s\u200c]+');
      continue;
    }
    sb.write(_cls(runes[i], ch));
    if (i < runes.length - 1) sb.write(gap);
  }
  return RegExp(sb.toString(), caseSensitive: false);
}

String _cls(int code, String ch) {
  if (code == 0x06CC || code == 0x064A || code == 0x0649) return '[\u06CC\u064A\u0649]';
  if (code == 0x06A9 || code == 0x0643) return '[\u06A9\u0643]';
  int? d;
  if (code >= 48 && code <= 57) d = code - 48;
  if (code >= 0x06F0 && code <= 0x06F9) d = code - 0x06F0;
  if (code >= 0x0660 && code <= 0x0669) d = code - 0x0660;
  if (d != null) {
    return '[${String.fromCharCode(48 + d)}${String.fromCharCode(0x06F0 + d)}${String.fromCharCode(0x0660 + d)}]';
  }
  return RegExp.escape(ch);
}

/// مستطیل‌های هم‌خط را یکی می‌کند تا هایلایت تکه‌تکه نشود (مختصاتِ PDF).
List<PdfRect> mergeLineRects(List<PdfRect> rects) {
  final out = <PdfRect>[];
  for (final r in rects) {
    var merged = false;
    for (var i = 0; i < out.length; i++) {
      final o = out[i];
      final overlap = math.min(o.top, r.top) - math.max(o.bottom, r.bottom);
      final h = math.min(o.height, r.height);
      final gap = math.max(r.left, o.left) - math.min(r.right, o.right);
      if (h > 0 && overlap >= h * 0.5 && gap <= h * 1.3) {
        out[i] = o.merge(r);
        merged = true;
        break;
      }
    }
    if (!merged) out.add(r);
  }
  return out;
}

/// هایلایتِ یک صفحه: مستطیل‌های نرمال‌شده (هر ۴ عدد = یک مستطیل) + متنِ انتخاب‌شده.
class TextHl {
  final int pageNumber; // از ۱
  final List<double> rects;
  final String text;
  const TextHl(this.pageNumber, this.rects, this.text);
}

double _c01(double v) => v.isNaN ? 0.0 : v.clamp(0.0, 1.0).toDouble();

/// از بازه‌های متنِ انتخاب‌شده، مستطیل‌های دقیقِ هایلایت را (به‌تفکیک صفحه) می‌سازد.
Future<List<TextHl>> textHighlightsFromRanges(List<PdfPageTextRange> ranges, PdfDocument doc) async {
  final out = <TextHl>[];
  for (final pr in ranges) {
    if (pr.pageNumber < 1 || pr.pageNumber > doc.pages.length) continue;
    final page = doc.pages[pr.pageNumber - 1];
    final raw = <PdfRect>[];
    for (final f in pr.pageText.fragments) {
      final fs = f.index;
      final fe = f.index + f.length;
      final s = math.max(fs, pr.start);
      final e = math.min(fe, pr.end);
      if (e <= s) continue;
      final cr = f.charRects;
      if (cr != null && cr.length >= fe - fs) {
        PdfRect? u;
        for (var i = s; i < e; i++) {
          final c = cr[i - fs];
          u = u == null ? c : u.merge(c);
        }
        if (u != null) raw.add(u);
      } else {
        raw.add(f.bounds);
      }
    }
    final merged = mergeLineRects(raw);
    final w = page.width;
    final h = page.height;
    final flat = <double>[];
    for (final m in merged) {
      final r = m.toRect(page: page, scaledPageSize: Size(w, h));
      flat.addAll(<double>[_c01(r.left / w), _c01(r.top / h), _c01(r.right / w), _c01(r.bottom / h)]);
    }
    if (flat.isNotEmpty) out.add(TextHl(pr.pageNumber, flat, pr.text.trim()));
  }
  return out;
}
