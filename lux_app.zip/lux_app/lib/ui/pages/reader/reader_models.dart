import 'dart:convert';
import 'dart:math' as math;
import 'dart:typed_data';

import 'package:flutter/material.dart';

import '../../../core/palette.dart';
import '../../../core/util.dart';
import '../../../data/reader_repo.dart';
import '../../../services/pdf_bridge.dart';

/// یک حاشیه‌نویسی (نشانک، یادداشت، هایلایت، قلم یا وضعیتِ صفحه). صفحه‌ها از ۱ شماره‌گذاری می‌شوند.
class ReaderAnn {
  final int id;
  final int page;
  final String kind; // bookmark | note | hl | pen | status
  final List<double> pts; // مختصاتِ نرمال‌شده (۰..۱)
  final int color;
  final String note;

  const ReaderAnn({
    required this.id,
    required this.page,
    required this.kind,
    required this.pts,
    required this.color,
    required this.note,
  });

  factory ReaderAnn.fromRow(Map<String, Object?> r) {
    var pts = <double>[];
    final d = asStr(r['data']);
    if (d.isNotEmpty) {
      try {
        final j = jsonDecode(d);
        if (j is Map && j['p'] is List) {
          pts = (j['p'] as List).map((e) => (e as num).toDouble()).toList();
        }
      } catch (_) {}
    }
    return ReaderAnn(
      id: asInt(r['id']),
      page: asInt(r['page']),
      kind: asStr(r['kind']),
      pts: pts,
      color: r['color'] == null ? kHlColors[0] : asInt(r['color']),
      note: asStr(r['note']),
    );
  }

  bool get isDrawn => kind == 'hl' || kind == 'pen';
}

/// حافظه‌ی کوتاه‌مدتِ صفحه‌های رندرشده
class PageCache {
  PageCache._();
  static final Map<String, Uint8List> _mem = <String, Uint8List>{};
  static final List<String> _order = <String>[];
  static final Map<String, Future<Uint8List?>> _busy = <String, Future<Uint8List?>>{};

  static Future<Uint8List?> get(String path, int page, int px) {
    final k = '$path|$page|$px';
    final hit = _mem[k];
    if (hit != null) return Future<Uint8List?>.value(hit);
    final running = _busy[k];
    if (running != null) return running;
    final f = PdfBridge.render(path, page, px).then((b) {
      _busy.remove(k);
      if (b != null) {
        _mem[k] = b;
        _order.add(k);
        while (_order.length > 14) {
          _mem.remove(_order.removeAt(0));
        }
      }
      return b;
    });
    _busy[k] = f;
    return f;
  }

  static void clear() {
    _mem.clear();
    _order.clear();
    _busy.clear();
  }
}

class AnnPainter extends CustomPainter {
  final List<ReaderAnn> anns;
  final List<double>? liveRect;
  final List<double>? livePen;
  final Color liveColor;

  AnnPainter(this.anns, {this.liveRect, this.livePen, this.liveColor = const Color(0xFFFFD54F)});

  void _pen(Canvas canvas, Size size, List<double> pts, Color color) {
    if (pts.length < 4) {
      if (pts.length == 2) {
        canvas.drawCircle(Offset(pts[0] * size.width, pts[1] * size.height), 1.8, Paint()..color = color);
      }
      return;
    }
    final path = Path()..moveTo(pts[0] * size.width, pts[1] * size.height);
    for (var i = 2; i + 1 < pts.length; i += 2) {
      path.lineTo(pts[i] * size.width, pts[i + 1] * size.height);
    }
    canvas.drawPath(
      path,
      Paint()
        ..color = color
        ..style = PaintingStyle.stroke
        ..strokeWidth = 2.6
        ..strokeCap = StrokeCap.round
        ..strokeJoin = StrokeJoin.round,
    );
  }

  @override
  void paint(Canvas canvas, Size size) {
    for (final a in anns) {
      final c = Color(a.color);
      if (a.kind == 'hl' && a.pts.length >= 4) {
        canvas.drawRect(
          Rect.fromLTRB(a.pts[0] * size.width, a.pts[1] * size.height, a.pts[2] * size.width, a.pts[3] * size.height),
          Paint()..color = LuxColors.alpha(c, 0.38),
        );
      } else if (a.kind == 'pen') {
        _pen(canvas, size, a.pts, c);
      }
    }
    final r = liveRect;
    if (r != null && r.length >= 4) {
      canvas.drawRect(
        Rect.fromLTRB(r[0] * size.width, r[1] * size.height, r[2] * size.width, r[3] * size.height),
        Paint()..color = LuxColors.alpha(liveColor, 0.38),
      );
    }
    final p = livePen;
    if (p != null) _pen(canvas, size, p, liveColor);
  }

  @override
  bool shouldRepaint(covariant AnnPainter old) => true;
}

const List<double> _nightMatrix = <double>[
  -1, 0, 0, 0, 255, //
  0, -1, 0, 0, 255,
  0, 0, -1, 0, 255,
  0, 0, 0, 1, 0,
];
const List<double> _sepiaMatrix = <double>[
  0.393, 0.769, 0.189, 0, 0, //
  0.349, 0.686, 0.168, 0, 0,
  0.272, 0.534, 0.131, 0, 0,
  0, 0, 0, 1, 0,
];

/// یک صفحه‌ی PDF با لایه‌ی حاشیه‌نویسی. [filter]: ۰ عادی، ۱ شب، ۲ کاغذی.
class ReaderPageView extends StatefulWidget {
  final String path;
  final int index; // از صفر
  final double width;
  final double ratio;
  final int px;
  final int filter;
  final List<ReaderAnn> anns;
  final int tool; // ۰ مطالعه، ۱ هایلایت، ۲ قلم، ۳ پاک‌کن
  final Color color;
  final void Function(String kind, List<double> pts) onDraw;
  final void Function(double nx, double ny, double w, double h) onErase;

  const ReaderPageView({
    super.key,
    required this.path,
    required this.index,
    required this.width,
    required this.ratio,
    required this.px,
    required this.filter,
    required this.anns,
    required this.tool,
    required this.color,
    required this.onDraw,
    required this.onErase,
  });

  @override
  State<ReaderPageView> createState() => _ReaderPageViewState();
}

class _ReaderPageViewState extends State<ReaderPageView> {
  Future<Uint8List?>? _future;
  List<double>? _rect;
  List<double>? _pen;
  Offset? _start;

  @override
  void initState() {
    super.initState();
    _future = PageCache.get(widget.path, widget.index, widget.px);
  }

  @override
  void didUpdateWidget(covariant ReaderPageView old) {
    super.didUpdateWidget(old);
    if (old.px != widget.px || old.index != widget.index || old.path != widget.path) {
      _future = PageCache.get(widget.path, widget.index, widget.px);
    }
  }

  Offset _norm(Offset p, Size s) => Offset((p.dx / s.width).clamp(0.0, 1.0), (p.dy / s.height).clamp(0.0, 1.0));

  @override
  Widget build(BuildContext context) {
    final w = widget.width;
    final h = widget.width * widget.ratio;
    final size = Size(w, h);

    Widget image = FutureBuilder<Uint8List?>(
      future: _future,
      builder: (ctx, snap) {
        final b = snap.data;
        if (b != null) {
          Widget img = Image.memory(b, width: w, height: h, fit: BoxFit.fill, gaplessPlayback: true, filterQuality: FilterQuality.medium);
          if (widget.filter == 1) {
            img = ColorFiltered(colorFilter: const ColorFilter.matrix(_nightMatrix), child: img);
          } else if (widget.filter == 2) {
            img = ColorFiltered(colorFilter: const ColorFilter.matrix(_sepiaMatrix), child: img);
          }
          return img;
        }
        return Container(
          width: w,
          height: h,
          color: widget.filter == 1 ? const Color(0xFF1B1B1B) : Colors.white,
          alignment: Alignment.center,
          child: snap.connectionState == ConnectionState.done
              ? const Icon(Icons.broken_image_rounded, color: Colors.grey, size: 36)
              : const SizedBox(width: 26, height: 26, child: CircularProgressIndicator(strokeWidth: 2.4)),
        );
      },
    );

    final painter = CustomPaint(
      size: size,
      painter: AnnPainter(
        [for (final a in widget.anns) if (a.isDrawn) a],
        liveRect: _rect,
        livePen: _pen,
        liveColor: widget.color,
      ),
    );

    Widget layer = const SizedBox.shrink();
    if (widget.tool != 0) {
      layer = GestureDetector(
        behavior: HitTestBehavior.opaque,
        onPanStart: (d) {
          final n = _norm(d.localPosition, size);
          if (widget.tool == 1) {
            _start = n;
            setState(() => _rect = <double>[n.dx, n.dy, n.dx, n.dy]);
          } else if (widget.tool == 2) {
            setState(() => _pen = <double>[n.dx, n.dy]);
          } else {
            widget.onErase(n.dx, n.dy, w, h);
          }
        },
        onPanUpdate: (d) {
          final n = _norm(d.localPosition, size);
          if (widget.tool == 1 && _start != null) {
            setState(() => _rect = <double>[
                  math.min(_start!.dx, n.dx),
                  math.min(_start!.dy, n.dy),
                  math.max(_start!.dx, n.dx),
                  math.max(_start!.dy, n.dy),
                ]);
          } else if (widget.tool == 2 && _pen != null) {
            final last = Offset(_pen![_pen!.length - 2] * w, _pen![_pen!.length - 1] * h);
            if ((last - d.localPosition).distance >= 2.5) {
              setState(() => _pen!.addAll(<double>[n.dx, n.dy]));
            }
          } else if (widget.tool == 3) {
            widget.onErase(n.dx, n.dy, w, h);
          }
        },
        onPanEnd: (_) {
          if (widget.tool == 1 && _rect != null) {
            final r = _rect!;
            if ((r[2] - r[0]) * w >= 6 && (r[3] - r[1]) * h >= 4) {
              widget.onDraw('hl', List<double>.from(r));
            }
          } else if (widget.tool == 2 && _pen != null && _pen!.length >= 4) {
            widget.onDraw('pen', List<double>.from(_pen!));
          }
          setState(() {
            _rect = null;
            _pen = null;
            _start = null;
          });
        },
        onTapUp: (d) {
          if (widget.tool == 3) {
            final n = _norm(d.localPosition, size);
            widget.onErase(n.dx, n.dy, w, h);
          }
        },
      );
    }

    return SizedBox(
      width: w,
      height: h,
      child: Stack(fit: StackFit.expand, children: [image, IgnorePointer(child: painter), layer]),
    );
  }
}

/// آیا نقطه‌ی (nx, ny) روی این حاشیه‌نویسی است؟ (برای پاک‌کن)
bool annHit(ReaderAnn a, double nx, double ny, double w, double h) {
  if (a.kind == 'hl' && a.pts.length >= 4) {
    const m = 0.012;
    return nx >= a.pts[0] - m && nx <= a.pts[2] + m && ny >= a.pts[1] - m && ny <= a.pts[3] + m;
  }
  if (a.kind == 'pen') {
    final p = Offset(nx * w, ny * h);
    for (var i = 0; i + 3 < a.pts.length; i += 2) {
      final x1 = a.pts[i] * w, y1 = a.pts[i + 1] * h, x2 = a.pts[i + 2] * w, y2 = a.pts[i + 3] * h;
      final dx = x2 - x1, dy = y2 - y1;
      final len2 = dx * dx + dy * dy;
      var t = len2 == 0 ? 0.0 : (((p.dx - x1) * dx + (p.dy - y1) * dy) / len2);
      t = t.clamp(0.0, 1.0);
      final cx = x1 + t * dx, cy = y1 + t * dy;
      if ((Offset(cx, cy) - p).distance <= 16) return true;
    }
    if (a.pts.length >= 2 && a.pts.length < 4) {
      return (Offset(a.pts[0] * w, a.pts[1] * h) - p).distance <= 16;
    }
  }
  return false;
}
