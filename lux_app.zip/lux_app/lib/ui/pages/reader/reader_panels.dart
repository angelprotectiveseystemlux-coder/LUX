import 'package:flutter/material.dart';

import '../../../core/jalali_utils.dart';
import '../../../core/palette.dart';
import '../../../core/theme.dart';
import '../../../core/util.dart';
import '../../../data/database.dart';
import '../../../data/reader_repo.dart';
import '../../widgets/lux_button.dart';
import '../../widgets/lux_card.dart';
import '../../widgets/lux_chip.dart';
import '../../widgets/lux_kit.dart';
import '../../widgets/lux_section.dart';
import '../study_stats_page.dart';
import 'reader_models.dart';

int _hlIndex(int color) {
  final i = kHlColors.indexOf(color);
  return i < 0 ? 0 : i;
}

// ───────────────────────── فهرستِ نشانک‌ها، یادداشت‌ها و هایلایت‌ها ─────────────────────────

Future<void> showReaderNotes(
  BuildContext context, {
  required List<ReaderAnn> anns,
  required void Function(int pageIndex) onJump,
  required VoidCallback onChanged,
}) {
  final items = [for (final a in anns) if (a.kind != 'status') a];
  var kind = 0; // ۰ همه، ۱ نشانک، ۲ یادداشت، ۳ هایلایت
  int? color;
  final search = TextEditingController();

  return showLuxSheet<void>(
    context,
    (ctx) => StatefulBuilder(builder: (ctx, setS) {
      final q = search.text.trim();
      final shown = [
        for (final a in items)
          if ((kind == 0 ||
                  (kind == 1 && a.kind == 'bookmark') ||
                  (kind == 2 && a.kind == 'note') ||
                  (kind == 3 && (a.kind == 'hl' || a.kind == 'pen'))) &&
              (color == null || (a.isDrawn && a.color == color)) &&
              (q.isEmpty || a.note.contains(q) || faDigits(a.page).contains(q) || '${a.page}' == q))
            a,
      ];

      String title(ReaderAnn a) {
        switch (a.kind) {
          case 'bookmark':
            return a.note.isEmpty ? 'نشانک' : a.note;
          case 'note':
            return a.note.isEmpty ? 'یادداشت' : a.note;
          case 'hl':
            return 'هایلایت · ${kHlNames[_hlIndex(a.color)]}';
          default:
            return 'نوشته‌ی دستی';
        }
      }

      IconData icon(ReaderAnn a) {
        switch (a.kind) {
          case 'bookmark':
            return Icons.bookmark_rounded;
          case 'note':
            return Icons.sticky_note_2_rounded;
          case 'hl':
            return Icons.highlight_rounded;
          default:
            return Icons.draw_rounded;
        }
      }

      Future<void> editNote(ReaderAnn a) async {
        final c = TextEditingController(text: a.note);
        await showLuxSheet<void>(
          ctx,
          (c2) => Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Text('متنِ ${a.kind == 'bookmark' ? 'نشانک' : (a.kind == 'note' ? 'یادداشت' : 'توضیحِ هایلایت')}', style: LuxText.title),
              const SizedBox(height: 14),
              LuxField(label: 'متن', controller: c, maxLines: 4),
              LuxButton(
                label: 'ذخیره',
                onPressed: () async {
                  await ReaderRepo.updateAnnotation(a.id, note: c.text.trim());
                  onChanged();
                  if (c2.mounted) Navigator.of(c2).pop();
                },
              ),
            ],
          ),
        );
        if (ctx.mounted) Navigator.of(ctx).pop();
      }

      return Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Text('نشانک‌ها و یادداشت‌ها', style: LuxText.title),
          const SizedBox(height: 12),
          Wrap(spacing: 8, runSpacing: 8, children: [
            LuxChip(label: 'همه (${faDigits(items.length)})', selected: kind == 0, onTap: () => setS(() => kind = 0)),
            LuxChip(label: 'نشانک', selected: kind == 1, onTap: () => setS(() => kind = 1)),
            LuxChip(label: 'یادداشت', selected: kind == 2, onTap: () => setS(() => kind = 2)),
            LuxChip(label: 'هایلایت و قلم', selected: kind == 3, onTap: () => setS(() => kind = 3)),
          ]),
          if (kind == 3) ...[
            const SizedBox(height: 10),
            Wrap(spacing: 10, runSpacing: 8, children: [
              for (var i = 0; i < kHlColors.length; i++)
                GestureDetector(
                  onTap: () => setS(() => color = color == kHlColors[i] ? null : kHlColors[i]),
                  child: Container(
                    width: 34,
                    height: 34,
                    decoration: BoxDecoration(
                      color: Color(kHlColors[i]),
                      shape: BoxShape.circle,
                      border: Border.all(color: color == kHlColors[i] ? LuxColors.text : Colors.transparent, width: 2.4),
                    ),
                  ),
                ),
            ]),
          ],
          const SizedBox(height: 10),
          LuxField(label: 'جست‌وجو در یادداشت‌ها یا شماره‌ی صفحه', controller: search, onChanged: (_) => setS(() {})),
          ConstrainedBox(
            constraints: BoxConstraints(maxHeight: MediaQuery.of(ctx).size.height * 0.42),
            child: shown.isEmpty
                ? const Padding(padding: EdgeInsets.all(24), child: LuxEmpty(icon: Icons.bookmarks_rounded, title: 'موردی نیست'))
                : ListView(
                    shrinkWrap: true,
                    children: [
                      for (final a in shown)
                        LuxRow(
                          leading: Icon(icon(a), color: a.isDrawn ? Color(a.color) : LuxColors.accent),
                          title: title(a),
                          subtitle: 'صفحه‌ی ${faDigits(a.page)}${a.isDrawn && a.note.isNotEmpty ? ' · ${a.note}' : ''}',
                          trailing: Row(mainAxisSize: MainAxisSize.min, children: [
                            if (a.kind != 'pen')
                              GestureDetector(
                                behavior: HitTestBehavior.opaque,
                                onTap: () => editNote(a),
                                child: Padding(padding: const EdgeInsets.all(8), child: Icon(Icons.edit_rounded, size: 19, color: LuxColors.silverDim)),
                              ),
                            GestureDetector(
                              behavior: HitTestBehavior.opaque,
                              onTap: () async {
                                await ReaderRepo.deleteAnnotation(a.id);
                                items.remove(a);
                                onChanged();
                                setS(() {});
                              },
                              child: Padding(padding: const EdgeInsets.all(8), child: Icon(Icons.delete_outline_rounded, size: 20, color: LuxColors.danger)),
                            ),
                          ]),
                          onTap: () {
                            Navigator.of(ctx).pop();
                            onJump(a.page - 1);
                          },
                        ),
                    ],
                  ),
          ),
        ],
      );
    }),
  );
}

// ───────────────────────── نقشه‌ی کتاب ─────────────────────────

Future<void> showBookMap(
  BuildContext context, {
  required int count,
  required Map<int, String> statusByPage,
  required Set<int> marked,
  required int current,
  required void Function(int pageIndex) onJump,
}) {
  Widget legend(Color c, String t) => Padding(
        padding: const EdgeInsetsDirectional.only(end: 12),
        child: Row(mainAxisSize: MainAxisSize.min, children: [
          Container(width: 12, height: 12, decoration: BoxDecoration(color: c, borderRadius: BorderRadius.circular(LuxColors.r(4)))),
          const SizedBox(width: 5),
          Text(t, style: LuxText.caption),
        ]),
      );
  return showLuxSheet<void>(
    context,
    (ctx) => Column(
      mainAxisSize: MainAxisSize.min,
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Text('نقشه‌ی کتاب', style: LuxText.title),
        const SizedBox(height: 4),
        Text('هر خانه یک صفحه است. برای رفتن به صفحه، خانه‌اش را بزن.', style: LuxText.caption),
        const SizedBox(height: 12),
        Wrap(runSpacing: 6, children: [
          legend(LuxColors.cardHi, 'مطالعه نشده'),
          for (var i = 0; i < kPageStatusKeys.length; i++) legend(Color(kPageStatusColors[i]), kPageStatusNames[i]),
          legend(LuxColors.accent, 'نقطه = نشانک یا یادداشت'),
        ]),
        const SizedBox(height: 12),
        ConstrainedBox(
          constraints: BoxConstraints(maxHeight: MediaQuery.of(ctx).size.height * 0.5),
          child: GridView.builder(
            shrinkWrap: true,
            gridDelegate: const SliverGridDelegateWithMaxCrossAxisExtent(maxCrossAxisExtent: 44, mainAxisSpacing: 6, crossAxisSpacing: 6),
            itemCount: count,
            itemBuilder: (c, i) {
              final st = statusByPage[i + 1];
              final si = st == null ? -1 : kPageStatusKeys.indexOf(st);
              final bg = si < 0 ? LuxColors.cardHi : Color(kPageStatusColors[si]);
              return GestureDetector(
                onTap: () {
                  Navigator.of(ctx).pop();
                  onJump(i);
                },
                child: Container(
                  decoration: BoxDecoration(
                    color: si < 0 ? bg : LuxColors.alpha(bg, 0.85),
                    borderRadius: BorderRadius.circular(LuxColors.r(10)),
                    border: i == current ? Border.all(color: LuxColors.text, width: 2) : null,
                  ),
                  alignment: Alignment.center,
                  child: Stack(
                    alignment: Alignment.center,
                    children: [
                      Text(faDigits(i + 1), style: LuxText.caption.copyWith(fontSize: 11, color: si < 0 ? LuxColors.textDim : Colors.black87)),
                      if (marked.contains(i + 1))
                        PositionedDirectional(top: 3, end: 3, child: Container(width: 6, height: 6, decoration: BoxDecoration(color: LuxColors.accent, shape: BoxShape.circle))),
                    ],
                  ),
                ),
              );
            },
          ),
        ),
      ],
    ),
  );
}

// ───────────────────────── رفتن به صفحه ─────────────────────────

Future<void> showPageJump(BuildContext context, {required int count, required int current, required void Function(int pageIndex) onJump}) {
  final c = TextEditingController(text: '${current + 1}');
  return showLuxSheet<void>(
    context,
    (ctx) => Column(
      mainAxisSize: MainAxisSize.min,
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Text('رفتن به صفحه', style: LuxText.title),
        const SizedBox(height: 14),
        LuxField(label: 'شماره‌ی صفحه (۱ تا ${faDigits(count)})', controller: c, keyboard: TextInputType.number),
        LuxButton(
          label: 'برو',
          onPressed: () {
            final n = (parseNum(c.text) ?? 0).round();
            if (n < 1 || n > count) {
              luxNotice(ctx, 'عددی بین ۱ تا ${faDigits(count)} بنویس.');
              return;
            }
            Navigator.of(ctx).pop();
            onJump(n - 1);
          },
        ),
      ],
    ),
  );
}

// ───────────────────────── آمارِ کتاب ─────────────────────────

Future<void> showReaderStats(
  BuildContext context, {
  required int bookId,
  required String title,
  required int count,
  required List<ReaderAnn> anns,
}) async {
  final rows = await LuxDb.instance.query('reading_sessions', where: 'book_id = ?', args: [bookId]);
  var ms = 0;
  for (final r in rows) {
    ms += asInt(r['end_ts']) - asInt(r['start_ts']);
  }
  final minutes = (ms / 60000).round();
  final done = anns.where((a) => a.kind == 'status' && a.note == 'done').length;
  final reading = anns.where((a) => a.kind == 'status' && a.note == 'reading').length;
  final review = anns.where((a) => a.kind == 'status' && a.note == 'review').length;
  final hard = anns.where((a) => a.kind == 'status' && a.note == 'hard').length;
  final hl = anns.where((a) => a.kind == 'hl').length;
  final notes = anns.where((a) => a.kind == 'note').length;
  final marks = anns.where((a) => a.kind == 'bookmark').length;
  final pct = count == 0 ? 0 : (done / count * 100).round();
  final left = (count - done).clamp(0, count).toInt();
  final pace = minutes == 0 || done == 0 ? null : (done / (minutes / 60));

  Widget line(String k, String v) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 6),
        child: Row(children: [Expanded(child: Text(k, style: LuxText.body)), Text(v, style: LuxText.heading)]),
      );
  if (!context.mounted) return;
  await showLuxSheet<void>(
    context,
    (ctx) => Column(
      mainAxisSize: MainAxisSize.min,
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Text('آمارِ «$title»', style: LuxText.title),
        const SizedBox(height: 14),
        ClipRRect(
          borderRadius: BorderRadius.circular(LuxColors.r(8)),
          child: LinearProgressIndicator(
            value: count == 0 ? 0 : done / count,
            minHeight: 8,
            backgroundColor: LuxColors.cardHi,
            valueColor: AlwaysStoppedAnimation<Color>(LuxColors.ok),
          ),
        ),
        const SizedBox(height: 4),
        Text('${faDigits(pct)}٪ مطالعه‌شده', style: LuxText.caption),
        const SizedBox(height: 10),
        line('زمانِ مطالعه', fmtMinutes(minutes)),
        line('تعداد جلسه‌ها', faDigits(rows.length)),
        line('صفحه‌های تمام‌شده', '${faDigits(done)} از ${faDigits(count)}'),
        line('صفحه‌های باقی‌مانده', faDigits(left)),
        line('در حال مطالعه / نیازمند مرور / دشوار', '${faDigits(reading)} / ${faDigits(review)} / ${faDigits(hard)}'),
        line('هایلایت · یادداشت · نشانک', '${faDigits(hl)} · ${faDigits(notes)} · ${faDigits(marks)}'),
        if (pace != null) line('سرعتِ مطالعه', '${faDigits(pace.toStringAsFixed(1))} صفحه در ساعت'),
      ],
    ),
  );
}

// ───────────────────────── خروجیِ متنی ─────────────────────────

String buildNotesExport({
  required String title,
  required String course,
  required List<Map<String, Object?>> chapters,
  required List<ReaderAnn> anns,
}) {
  final b = StringBuffer();
  b.writeln('کتاب: $title');
  if (course.isNotEmpty) b.writeln('درس: $course');
  b.writeln('');
  if (chapters.isNotEmpty) {
    b.writeln('— فصل‌ها —');
    for (final c in chapters) {
      final s = c['start_page'] == null ? '' : ' (صفحه ${c['start_page']}${c['end_page'] == null ? '' : ' تا ${c['end_page']}'})';
      b.writeln('• ${asStr(c['title'])}$s${asInt(c['done']) == 1 ? ' ✓' : ''}');
    }
    b.writeln('');
  }
  void section(String head, bool Function(ReaderAnn) test, String Function(ReaderAnn) line) {
    final list = anns.where(test).toList();
    if (list.isEmpty) return;
    b.writeln('— $head —');
    for (final a in list) {
      b.writeln('صفحه ${a.page}: ${line(a)}');
    }
    b.writeln('');
  }

  section('نشانک‌ها', (a) => a.kind == 'bookmark', (a) => a.note.isEmpty ? 'نشانک' : a.note);
  section('یادداشت‌ها', (a) => a.kind == 'note', (a) => a.note);
  section('هایلایت‌ها', (a) => a.kind == 'hl', (a) => '${kHlNames[_hlIndex(a.color)]}${a.note.isEmpty ? '' : ' — ${a.note}'}');
  section('صفحه‌های نیازمند مرور یا دشوار', (a) => a.kind == 'status' && (a.note == 'review' || a.note == 'hard'), (a) => a.note == 'hard' ? 'دشوار' : 'نیازمند مرور');
  b.writeln('ساخته‌شده با لوکس · ${jalaliLabelWithDay(DateTime.now())}');
  return b.toString();
}
