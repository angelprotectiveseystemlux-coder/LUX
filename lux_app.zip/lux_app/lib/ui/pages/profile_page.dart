import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'package:shamsi_date/shamsi_date.dart';
import '../../core/app_bus.dart';
import '../../core/jalali_utils.dart';
import '../../core/palette.dart';
import '../../core/theme.dart';
import '../../data/backup.dart';
import '../../data/database.dart';
import '../../data/profile_repo.dart';
import '../../services/biometric_service.dart';
import '../../services/file_bridge.dart';
import '../../services/lock_service.dart';
import '../../services/notification_service.dart';
import '../lock/pin_pad.dart';
import 'appearance_page.dart';
import 'brief_pages.dart';
import 'manage/curriculum_sheet.dart';
import '../widgets/haptic.dart';
import '../widgets/jalali_picker.dart';
import '../widgets/lux_button.dart';
import '../widgets/lux_card.dart';
import '../widgets/lux_chip.dart';
import '../widgets/lux_kit.dart';
import '../widgets/lux_section.dart';
import '../widgets/lux_switch.dart';
import '../widgets/page_frame.dart';
import '../widgets/pishva_credit.dart';
import '../widgets/ruler_picker.dart';

class ProfilePage extends StatefulWidget {
  const ProfilePage({super.key});

  @override
  State<ProfilePage> createState() => _ProfilePageState();
}

class _ProfilePageState extends State<ProfilePage> {
  Profile? _p;
  bool _haptics = Haptic.enabled;
  bool _hasPin = false;
  bool _bioAvail = false;
  bool _bioOn = false;

  @override
  void initState() {
    super.initState();
    _load();
    AppBus.data.addListener(_load);
  }

  @override
  void dispose() {
    AppBus.data.removeListener(_load);
    super.dispose();
  }

  Future<void> _load() async {
    final pr = await ProfileRepo.get();
    final pin = await LockService.hasPin();
    final bioAvail = await BiometricService.available();
    final bioOn = await BiometricService.isEnabled();
    if (mounted) {
      setState(() {
        _p = pr;
        _hasPin = pin;
        _bioAvail = bioAvail;
        _bioOn = bioOn;
      });
    }
  }

  Future<void> _save(Profile np) async {
    await ProfileRepo.save(np);
    AppBus.bump();
  }

  Future<void> _pickPhoto() async {
    final pr = _p;
    if (pr == null) return;
    try {
      final x = await ImagePicker().pickImage(source: ImageSource.gallery, maxWidth: 900, imageQuality: 88);
      if (x == null) return;
      final dir = await getApplicationDocumentsDirectory();
      final dest = p.join(dir.path, 'profile_${DateTime.now().millisecondsSinceEpoch}.jpg');
      await File(x.path).copy(dest);
      await _save(pr.copyWith(photoPath: dest));
    } catch (_) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('انتخاب عکس انجام نشد.')));
      }
    }
  }

  void _sheet(Widget Function(BuildContext) builder) {
    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      backgroundColor: LuxColors.card,
      builder: (ctx) => Padding(
        padding: EdgeInsets.fromLTRB(22, 22, 22, 22 + MediaQuery.of(ctx).viewInsets.bottom),
        child: SingleChildScrollView(child: builder(ctx)),
      ),
    );
  }

  void _editName() {
    final pr = _p!;
    final ctl = TextEditingController(text: pr.name);
    var title = pr.titlePref;
    _sheet((ctx) => StatefulBuilder(builder: (ctx, setS) {
          return Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Text('نام و عنوان', style: LuxText.title),
              const SizedBox(height: 16),
              TextField(controller: ctl, style: LuxText.heading, decoration: LuxInput.decoration('نام')),
              const SizedBox(height: 14),
              Wrap(spacing: 10, children: [
                for (final t in const ['آقای', 'خانم', ''])
                  LuxChip(label: t.isEmpty ? 'بدون عنوان' : t, selected: title == t, onTap: () => setS(() => title = t)),
              ]),
              const SizedBox(height: 20),
              LuxButton(
                label: 'ذخیره',
                onPressed: () async {
                  final n = ctl.text.trim();
                  if (n.length < 2) return;
                  Navigator.of(ctx).pop();
                  await _save(pr.copyWith(name: n, titlePref: title));
                },
              ),
            ],
          );
        }));
  }

  void _editLevel() {
    final pr = _p!;
    var level = pr.level;
    var grade = pr.grade;
    var track = pr.track;
    _sheet((ctx) => StatefulBuilder(builder: (ctx, setS) {
          final grades = level == 'middle' ? const [7, 8, 9] : const [10, 11, 12];
          final ok = grade != 0 && (level == 'middle' || track.isNotEmpty);
          return SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Text('مقطع، پایه و رشته', style: LuxText.title),
                const SizedBox(height: 16),
                Wrap(spacing: 10, runSpacing: 10, children: [
                  LuxChip(
                      label: 'راهنمایی',
                      selected: level == 'middle',
                      onTap: () => setS(() {
                            if (level != 'middle') {
                              level = 'middle';
                              grade = 0;
                              track = '';
                            }
                          })),
                  LuxChip(
                      label: 'دبیرستان',
                      selected: level == 'high',
                      onTap: () => setS(() {
                            if (level != 'high') {
                              level = 'high';
                              grade = 0;
                              track = '';
                            }
                          })),
                ]),
                const SizedBox(height: 16),
                Wrap(spacing: 10, runSpacing: 10, children: [
                  for (final g in grades)
                    LuxChip(label: Profile.gradeNames[g]!, selected: grade == g, onTap: () => setS(() => grade = g)),
                ]),
                if (level == 'high') ...[
                  const SizedBox(height: 16),
                  Wrap(spacing: 10, runSpacing: 10, children: [
                    for (final t in const ['ریاضی', 'تجربی', 'انسانی', 'فنی‌حرفه‌ای', 'کاردانش'])
                      LuxChip(label: t, selected: track == t, onTap: () => setS(() => track = t)),
                  ]),
                ],
                const SizedBox(height: 20),
                LuxButton(
                  label: 'ذخیره',
                  onPressed: ok
                      ? () async {
                          Navigator.of(ctx).pop();
                          final newTrack = level == 'high' ? track : '';
                          final changed = newTrack != pr.track || grade != pr.grade;
                          await _save(pr.copyWith(level: level, grade: grade, track: newTrack));
                          // پایه یا رشته عوض شد → بپرس درس‌های تازه از روی فهرست اضافه شوند یا نه.
                          if (changed && mounted) await offerCurriculumOnce(context, force: true);
                        }
                      : null,
                ),
              ],
            ),
          );
        }));
  }

  void _editGpa() {
    final pr = _p!;
    var v = pr.prevGpa ?? 17.0;
    _sheet((ctx) => Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Text('معدل سال قبل', style: LuxText.title),
            const SizedBox(height: 18),
            RulerPicker(min: 0, max: 20, step: 0.25, initial: v, onChanged: (x) => v = x),
            const SizedBox(height: 22),
            LuxButton(
              label: 'ذخیره',
              onPressed: () async {
                Navigator.of(ctx).pop();
                await _save(pr.copyWith(prevGpa: v));
              },
            ),
            const SizedBox(height: 10),
            LuxButton(
              label: 'حذف معدل',
              filled: false,
              onPressed: () async {
                Navigator.of(ctx).pop();
                await _save(pr.copyWith(clearGpa: true));
              },
            ),
          ],
        ));
  }

  void _editBirth() {
    final pr = _p!;
    var j = Jalali(pr.birthY, pr.birthM, pr.birthD);
    final nowY = Jalali.now().year;
    _sheet((ctx) => Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Text('تاریخ تولد', style: LuxText.title),
            const SizedBox(height: 12),
            JalaliDatePicker(minYear: nowY - 30, maxYear: nowY - 5, initial: j, onChanged: (x) => j = x),
            const SizedBox(height: 16),
            LuxButton(
              label: 'ذخیره',
              onPressed: () async {
                Navigator.of(ctx).pop();
                await _save(pr.copyWith(birthY: j.year, birthM: j.month, birthD: j.day));
              },
            ),
          ],
        ));
  }

  Future<void> _testReminder() async {
    final r = await NotificationService.instance.runCheck(seconds: 10);
    if (!mounted) return;
    String msg;
    if (r.error != null) {
      msg = 'خطا در اعلان: ${r.error}';
    } else if (!r.notificationsAllowed) {
      msg = 'اجازه‌ی اعلان داده نشده. از تنظیمات گوشی ← برنامه‌ها ← LUX ← اعلان‌ها را روشن کن.';
    } else if (!r.exactAlarmAllowed) {
      msg = 'اعلان فوری نمایش داده شد، ولی «آلارم دقیق» مجاز نیست؛ یادآورها ممکن است کمی دیر برسند.';
    } else {
      msg = 'اعلان فوری نمایش داده شد و یادآور زمان‌دار تا ۱۰ ثانیه‌ی دیگر می‌رسد.';
    }
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg)));
  }



  // ───────── رمز ورود ─────────
  /// از کاربر رمزِ فعلی را می‌پرسد؛ true یعنی درست وارد شد.
  Future<bool> _askCurrentPin(String title) async {
    final len = await LockService.pinLength();
    var attempt = 0;
    String? msg;
    final ok = await showLuxSheet<bool>(
      context,
      (ctx) => StatefulBuilder(builder: (ctx, setS) {
        return Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Text(title, style: LuxText.title),
            const SizedBox(height: 6),
            Text(msg ?? 'رمز فعلی را وارد کن.', style: LuxText.caption.copyWith(color: msg == null ? LuxColors.textDim : LuxColors.danger)),
            const SizedBox(height: 20),
            PinPad(
              key: ValueKey<int>(attempt),
              length: len,
              onCompleted: (v) async {
                final good = await LockService.verify(v);
                if (good) {
                  if (ctx.mounted) Navigator.of(ctx).pop(true);
                } else {
                  Haptic.alert();
                  final wait = LockService.blockedSeconds();
                  setS(() {
                    attempt++;
                    msg = wait > 0 ? 'چند بار اشتباه شد. ${faDigits(wait)} ثانیه صبر کن.' : 'رمز درست نیست.';
                  });
                }
              },
            ),
          ],
        );
      }),
    );
    return ok == true;
  }

  /// رمزِ جدید را دو بار می‌گیرد و ذخیره می‌کند؛ true یعنی ذخیره شد.
  Future<bool> _askNewPin() async {
    var len = 4;
    var stage = 0;
    var attempt = 0;
    var first = '';
    String? msg;
    final ok = await showLuxSheet<bool>(
      context,
      (ctx) => StatefulBuilder(builder: (ctx, setS) {
        return Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Text(stage == 0 ? 'رمز جدید' : 'تکرار رمز', style: LuxText.title),
            const SizedBox(height: 6),
            Text(
              msg ?? (stage == 0 ? 'طولِ رمز را انتخاب و رمز را وارد کن.' : 'رمز را یک بار دیگر وارد کن.'),
              style: LuxText.caption.copyWith(color: msg == null ? LuxColors.textDim : LuxColors.danger),
            ),
            const SizedBox(height: 16),
            if (stage == 0)
              LuxChoice(
                label: 'طول رمز',
                options: const ['۴ رقم', '۶ رقم'],
                selected: len == 4 ? 0 : 1,
                onChanged: (i) => setS(() => len = i == 0 ? 4 : 6),
              ),
            PinPad(
              key: ValueKey<String>('$len-$stage-$attempt'),
              length: len,
              onCompleted: (v) async {
                if (stage == 0) {
                  setS(() {
                    first = v;
                    stage = 1;
                    msg = null;
                  });
                } else if (v == first) {
                  await LockService.setPin(v);
                  if (ctx.mounted) Navigator.of(ctx).pop(true);
                } else {
                  Haptic.alert();
                  setS(() {
                    stage = 0;
                    first = '';
                    attempt++;
                    msg = 'دو رمز یکی نبود. دوباره از اول وارد کن.';
                  });
                }
              },
            ),
          ],
        );
      }),
    );
    return ok == true;
  }

  Future<void> _togglePin(bool want) async {
    if (want) {
      final ok = await _askNewPin();
      if (ok && mounted) {
        setState(() => _hasPin = true);
        luxToast(context, 'رمز ورود فعال شد. اگر فراموشش کنی راهی برای بازیابی‌اش نیست؛ از داده‌هایت فایل پشتیبان بگیر.');
        final bio = await luxConfirm(
          context,
          'ورود با اثر انگشت هم فعال شود؟',
          body: 'دفعه‌ی بعد به‌جای رمز، با اثر انگشت وارد می‌شوی.',
          yes: 'فعال کن',
        );
        if (bio && mounted) await _toggleBio(true);
      }
    } else {
      final ok = await _askCurrentPin('خاموش‌کردن رمز');
      if (!ok) return;
      await LockService.clear();
      if (mounted) {
        setState(() => _hasPin = false);
        luxToast(context, 'رمز ورود برداشته شد.');
      }
    }
  }

  Future<void> _toggleBio(bool want) async {
    if (want) {
      final r = await BiometricService.authenticate('برای فعال‌کردن ورود با اثر انگشت، یک بار تأیید کن');
      if (!r.$1) {
        if (mounted) luxNotice(context, BiometricService.explain(r.$2));
        return;
      }
      await BiometricService.setEnabled(true);
    } else {
      await BiometricService.setEnabled(false);
    }
    if (mounted) setState(() => _bioOn = want);
  }

  Future<void> _changePin() async {
    final ok = await _askCurrentPin('تغییر رمز');
    if (!ok || !mounted) return;
    final done = await _askNewPin();
    if (done && mounted) luxToast(context, 'رمز تغییر کرد.');
  }

  // ───────── فایل داده و پشتیبان ─────────
  Future<void> _exportFile() async {
    try {
      final f = await Backup.writeTemp();
      final ok = await FileBridge.saveAs(f.path, 'lux_data.json');
      if (!mounted) return;
      luxToast(context, ok ? 'فایل داده ذخیره شد.' : 'ذخیره انجام نشد.');
    } catch (e) {
      if (mounted) luxToast(context, 'خطا در ساخت فایل: $e');
    }
  }

  Future<void> _importFile() async {
    final path = await FileBridge.pick();
    if (path == null || !mounted) return;
    final ok = await luxConfirm(
      context,
      'جایگزینی همه‌ی داده‌ها؟',
      body: 'همه‌ی اطلاعات فعلی با محتوای این فایل عوض می‌شود.',
      yes: 'بازیابی',
    );
    if (!ok || !mounted) return;
    try {
      final text = await File(path).readAsString();
      await Backup.importJson(text);
      Haptic.enabled = (await LuxDb.instance.kvGet('haptics') ?? '1') == '1';
      AppBus.bump();
      final pin = await LockService.hasPin();
      if (!mounted) return;
      setState(() {
        _haptics = Haptic.enabled;
        _hasPin = pin;
      });
      luxToast(context, 'داده‌ها بازیابی شد.');
    } catch (e) {
      if (mounted) luxNotice(context, 'بازیابی نشد: $e');
    }
  }

  Future<void> _autoNow() async {
    final f = await Backup.autoSave();
    if (!mounted) return;
    if (f == null) {
      luxNotice(context, 'ساختن فایل خودکار ممکن نشد.');
    } else {
      luxNotice(context, 'فایل داده به‌روز شد:\n${f.path}\n\nاین فایل هر بار که از برنامه بیرون می‌روی دوباره نوشته می‌شود.');
    }
  }

  @override
  Widget build(BuildContext context) {
    final pr = _p;
    if (pr == null) {
      return Center(child: CircularProgressIndicator(color: LuxColors.accent));
    }
    final photo = pr.photoPath;
    final hasPhoto = photo != null && File(photo).existsSync();
    return PageFrame(
      title: 'پروفایل',
      children: [
        LuxCard(
          radius: 28,
          child: Row(
            children: [
              GestureDetector(
                onTap: _pickPhoto,
                child: Stack(
                  children: [
                    Container(
                      width: 78,
                      height: 78,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: LuxColors.cardHi,
                        border: Border.all(color: LuxColors.accent, width: 2),
                        image: hasPhoto ? DecorationImage(image: FileImage(File(photo)), fit: BoxFit.cover) : null,
                      ),
                      child: hasPhoto ? null : Icon(Icons.person_rounded, size: 40, color: LuxColors.silverDim),
                    ),
                    PositionedDirectional(
                      bottom: 0,
                      end: 0,
                      child: Container(
                        padding: const EdgeInsets.all(5),
                        decoration: BoxDecoration(color: LuxColors.accent, shape: BoxShape.circle),
                        child: Icon(Icons.edit_rounded, size: 14, color: LuxColors.onAccent),
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(pr.greetingName, style: LuxText.title),
                    const SizedBox(height: 4),
                    Text(
                      '${Profile.gradeNames[pr.grade] ?? pr.grade}${pr.track.isEmpty ? '' : ' · ${pr.track}'}',
                      style: LuxText.caption,
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 22),
        LuxSection(title: 'سطح تحصیلی من', children: [
          LuxRow(title: 'نام و عنوان', subtitle: pr.greetingName, trailing: const Icon(Icons.chevron_left_rounded), onTap: _editName),
          LuxRow(
              title: 'مقطع، پایه و رشته',
              subtitle: '${pr.levelLabel} · ${pr.gradeLabel}${pr.track.isEmpty ? '' : ' · ${pr.track}'}',
              trailing: const Icon(Icons.chevron_left_rounded),
              onTap: _editLevel),
          LuxRow(
              title: 'معدل سال قبل',
              subtitle: pr.prevGpa == null ? 'ثبت نشده' : fmtNum(pr.prevGpa!, dec: 2),
              trailing: const Icon(Icons.chevron_left_rounded),
              onTap: _editGpa),
          LuxRow(
              title: 'تاریخ تولد',
              subtitle: '${faDigits(pr.birthD)} ${jalaliMonths[pr.birthM - 1]} ${faDigits(pr.birthY)}',
              trailing: const Icon(Icons.chevron_left_rounded),
              onTap: _editBirth),
        ]),
        LuxSection(title: 'ظاهر', children: [
          LuxRow(
            title: 'ظاهر و شخصی‌سازی',
            subtitle: 'تم‌های رنگی، حالت روشن و تیره، اندازه‌ی متن، ویبره',
            trailing: const Icon(Icons.chevron_left_rounded),
            onTap: () => pushPage<void>(context, const AppearancePage()),
          ),
        ]),
        LuxSection(title: 'اعلان‌ها', children: [
          LuxRow(
            title: 'خلاصه روزانه',
            subtitle: 'خلاصه‌ی برنامه‌ی هر روز؛ روشن/خاموش و ساعت ارسال',
            trailing: const Icon(Icons.chevron_left_rounded),
            onTap: () => pushPage<void>(context, const DailyBriefPage()),
          ),
          LuxRow(
            title: 'یادآور آزمایشی',
            subtitle: 'یک اعلان فوری و یکی ۱۰ ثانیه‌ی بعد می‌فرستد',
            trailing: Icon(Icons.notifications_active_rounded, color: LuxColors.accent),
            onTap: _testReminder,
          ),
        ]),
        LuxSection(title: 'امنیت', children: [
          LuxRow(
            title: 'رمز ورود',
            subtitle: _hasPin ? 'برنامه با رمز قفل می‌شود' : 'برای باز کردن LUX رمز بخواه',
            trailing: LuxSwitch(value: _hasPin, onChanged: _togglePin),
          ),
          if (_hasPin)
            LuxRow(
              title: 'ورود با اثر انگشت',
              subtitle: _bioAvail ? 'به‌جای وارد کردن رمز، با اثر انگشت باز کن' : 'برای فعال‌کردن، روشن کن و اثر انگشتت را تأیید کن',
              trailing: LuxSwitch(value: _bioOn, onChanged: _toggleBio),
            ),
          if (_hasPin)
            LuxRow(
              title: 'تغییر رمز',
              trailing: const Icon(Icons.chevron_left_rounded),
              onTap: _changePin,
            ),
        ]),
        LuxSection(title: 'داده‌ها و پشتیبان', children: [
          LuxRow(
            title: 'ذخیره‌ی فایل داده',
            subtitle: 'همه‌ی اطلاعات در یک فایل JSON؛ جایش را خودت انتخاب می‌کنی',
            trailing: Icon(Icons.save_alt_rounded, color: LuxColors.accent),
            onTap: _exportFile,
          ),
          LuxRow(
            title: 'بازیابی از فایل',
            subtitle: 'فایلِ داده‌ی قبلی را انتخاب کن',
            trailing: Icon(Icons.upload_file_rounded, color: LuxColors.accent),
            onTap: _importFile,
          ),
          LuxRow(
            title: 'فایل داده‌ی خودکار',
            subtitle: 'هر بار که از برنامه بیرون می‌روی به‌روز می‌شود؛ برای دیدن مسیرش بزن',
            trailing: Icon(Icons.folder_rounded, color: LuxColors.accent),
            onTap: _autoNow,
          ),
        ]),
        const PishvaCredit(versionLine: 'LUX ۱٫۴'),
      ],
    );
  }
}
