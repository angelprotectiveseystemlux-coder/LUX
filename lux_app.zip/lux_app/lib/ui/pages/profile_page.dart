import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'package:shamsi_date/shamsi_date.dart';
import '../../core/app_bus.dart';
import '../../core/jalali_utils.dart';
import '../../core/palette.dart';
import '../../core/theme.dart';
import '../../data/database.dart';
import '../../data/profile_repo.dart';
import '../../services/notification_service.dart';
import '../widgets/haptic.dart';
import '../widgets/jalali_picker.dart';
import '../widgets/lux_button.dart';
import '../widgets/lux_card.dart';
import '../widgets/lux_chip.dart';
import '../widgets/lux_section.dart';
import '../widgets/lux_switch.dart';
import '../widgets/page_frame.dart';
import '../widgets/ruler_picker.dart';

class ProfilePage extends StatefulWidget {
  const ProfilePage({super.key});

  @override
  State<ProfilePage> createState() => _ProfilePageState();
}

class _ProfilePageState extends State<ProfilePage> {
  Profile? _p;
  bool _haptics = Haptic.enabled;

  @override
  void initState() {
    super.initState();
    _load();
    AppBus.data.addListener(_load);
  }

  @override
  void dispose() {
    AppBus.data.removeListener(_load);
    super.dispose();
  }

  Future<void> _load() async {
    final pr = await ProfileRepo.get();
    if (mounted) setState(() => _p = pr);
  }

  Future<void> _save(Profile np) async {
    await ProfileRepo.save(np);
    AppBus.bump();
  }

  Future<void> _pickPhoto() async {
    final pr = _p;
    if (pr == null) return;
    try {
      final x = await ImagePicker().pickImage(source: ImageSource.gallery, maxWidth: 900, imageQuality: 88);
      if (x == null) return;
      final dir = await getApplicationDocumentsDirectory();
      final dest = p.join(dir.path, 'profile_${DateTime.now().millisecondsSinceEpoch}.jpg');
      await File(x.path).copy(dest);
      await _save(pr.copyWith(photoPath: dest));
    } catch (_) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('انتخاب عکس انجام نشد.')));
      }
    }
  }

  void _sheet(Widget Function(BuildContext) builder) {
    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      backgroundColor: LuxColors.card,
      builder: (ctx) => Padding(
        padding: EdgeInsets.fromLTRB(22, 22, 22, 22 + MediaQuery.of(ctx).viewInsets.bottom),
        child: builder(ctx),
      ),
    );
  }

  void _editName() {
    final pr = _p!;
    final ctl = TextEditingController(text: pr.name);
    var title = pr.titlePref;
    _sheet((ctx) => StatefulBuilder(builder: (ctx, setS) {
          return Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Text('نام و عنوان', style: LuxText.title),
              const SizedBox(height: 16),
              TextField(controller: ctl, style: LuxText.heading, decoration: LuxInput.decoration('نام')),
              const SizedBox(height: 14),
              Wrap(spacing: 10, children: [
                for (final t in const ['آقای', 'خانم', ''])
                  LuxChip(label: t.isEmpty ? 'بدون عنوان' : t, selected: title == t, onTap: () => setS(() => title = t)),
              ]),
              const SizedBox(height: 20),
              LuxButton(
                label: 'ذخیره',
                onPressed: () async {
                  final n = ctl.text.trim();
                  if (n.length < 2) return;
                  Navigator.of(ctx).pop();
                  await _save(pr.copyWith(name: n, titlePref: title));
                },
              ),
            ],
          );
        }));
  }

  void _editLevel() {
    final pr = _p!;
    var level = pr.level;
    var grade = pr.grade;
    var track = pr.track;
    _sheet((ctx) => StatefulBuilder(builder: (ctx, setS) {
          final grades = level == 'middle' ? const [7, 8, 9] : const [10, 11, 12];
          final ok = grade != 0 && (level == 'middle' || track.isNotEmpty);
          return SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Text('مقطع، پایه و رشته', style: LuxText.title),
                const SizedBox(height: 16),
                Wrap(spacing: 10, runSpacing: 10, children: [
                  LuxChip(
                      label: 'راهنمایی',
                      selected: level == 'middle',
                      onTap: () => setS(() {
                            if (level != 'middle') {
                              level = 'middle';
                              grade = 0;
                              track = '';
                            }
                          })),
                  LuxChip(
                      label: 'دبیرستان',
                      selected: level == 'high',
                      onTap: () => setS(() {
                            if (level != 'high') {
                              level = 'high';
                              grade = 0;
                              track = '';
                            }
                          })),
                ]),
                const SizedBox(height: 16),
                Wrap(spacing: 10, runSpacing: 10, children: [
                  for (final g in grades)
                    LuxChip(label: Profile.gradeNames[g]!, selected: grade == g, onTap: () => setS(() => grade = g)),
                ]),
                if (level == 'high') ...[
                  const SizedBox(height: 16),
                  Wrap(spacing: 10, runSpacing: 10, children: [
                    for (final t in const ['ریاضی', 'تجربی', 'انسانی', 'فنی‌حرفه‌ای', 'کاردانش'])
                      LuxChip(label: t, selected: track == t, onTap: () => setS(() => track = t)),
                  ]),
                ],
                const SizedBox(height: 20),
                LuxButton(
                  label: 'ذخیره',
                  onPressed: ok
                      ? () async {
                          Navigator.of(ctx).pop();
                          await _save(pr.copyWith(level: level, grade: grade, track: level == 'high' ? track : ''));
                        }
                      : null,
                ),
              ],
            ),
          );
        }));
  }

  void _editGpa() {
    final pr = _p!;
    var v = pr.prevGpa ?? 17.0;
    _sheet((ctx) => Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Text('معدل سال قبل', style: LuxText.title),
            const SizedBox(height: 18),
            RulerPicker(min: 0, max: 20, step: 0.25, initial: v, onChanged: (x) => v = x),
            const SizedBox(height: 22),
            LuxButton(
              label: 'ذخیره',
              onPressed: () async {
                Navigator.of(ctx).pop();
                await _save(pr.copyWith(prevGpa: v));
              },
            ),
            const SizedBox(height: 10),
            LuxButton(
              label: 'حذف معدل',
              filled: false,
              onPressed: () async {
                Navigator.of(ctx).pop();
                await _save(pr.copyWith(clearGpa: true));
              },
            ),
          ],
        ));
  }

  void _editBirth() {
    final pr = _p!;
    var j = Jalali(pr.birthY, pr.birthM, pr.birthD);
    final nowY = Jalali.now().year;
    _sheet((ctx) => Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Text('تاریخ تولد', style: LuxText.title),
            const SizedBox(height: 12),
            JalaliDatePicker(minYear: nowY - 30, maxYear: nowY - 5, initial: j, onChanged: (x) => j = x),
            const SizedBox(height: 16),
            LuxButton(
              label: 'ذخیره',
              onPressed: () async {
                Navigator.of(ctx).pop();
                await _save(pr.copyWith(birthY: j.year, birthM: j.month, birthD: j.day));
              },
            ),
          ],
        ));
  }

  Future<void> _testReminder() async {
    final exact = await NotificationService.instance.scheduleTest(seconds: 10);
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text(exact
          ? 'یادآور آزمایشی تا ۱۰ ثانیه‌ی دیگر می‌رسد. اگر نیامد، دسترسی‌ها را چک کن.'
          : 'مجوز «آلارم دقیق» نیست؛ یادآور تقریبی زمان‌بندی شد.'),
    ));
  }

  @override
  Widget build(BuildContext context) {
    final pr = _p;
    if (pr == null) {
      return const Center(child: CircularProgressIndicator(color: LuxColors.accent));
    }
    final photo = pr.photoPath;
    final hasPhoto = photo != null && File(photo).existsSync();
    return PageFrame(
      title: 'پروفایل',
      children: [
        LuxCard(
          radius: 28,
          child: Row(
            children: [
              GestureDetector(
                onTap: _pickPhoto,
                child: Stack(
                  children: [
                    Container(
                      width: 78,
                      height: 78,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: LuxColors.cardHi,
                        border: Border.all(color: LuxColors.accent, width: 2),
                        image: hasPhoto ? DecorationImage(image: FileImage(File(photo)), fit: BoxFit.cover) : null,
                      ),
                      child: hasPhoto ? null : const Icon(Icons.person_rounded, size: 40, color: LuxColors.silverDim),
                    ),
                    PositionedDirectional(
                      bottom: 0,
                      end: 0,
                      child: Container(
                        padding: const EdgeInsets.all(5),
                        decoration: const BoxDecoration(color: LuxColors.accent, shape: BoxShape.circle),
                        child: const Icon(Icons.edit_rounded, size: 14, color: LuxColors.onAccent),
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(pr.greetingName, style: LuxText.title),
                    const SizedBox(height: 4),
                    Text(
                      '${Profile.gradeNames[pr.grade] ?? pr.grade}${pr.track.isEmpty ? '' : ' · ${pr.track}'}',
                      style: LuxText.caption,
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 22),
        LuxSection(title: 'سطح تحصیلی من', children: [
          LuxRow(title: 'نام و عنوان', subtitle: pr.greetingName, trailing: const Icon(Icons.chevron_left_rounded), onTap: _editName),
          LuxRow(
              title: 'مقطع، پایه و رشته',
              subtitle: '${pr.levelLabel} · ${pr.gradeLabel}${pr.track.isEmpty ? '' : ' · ${pr.track}'}',
              trailing: const Icon(Icons.chevron_left_rounded),
              onTap: _editLevel),
          LuxRow(
              title: 'معدل سال قبل',
              subtitle: pr.prevGpa == null ? 'ثبت نشده' : fmtNum(pr.prevGpa!, dec: 2),
              trailing: const Icon(Icons.chevron_left_rounded),
              onTap: _editGpa),
          LuxRow(
              title: 'تاریخ تولد',
              subtitle: '${faDigits(pr.birthD)} ${jalaliMonths[pr.birthM - 1]} ${faDigits(pr.birthY)}',
              trailing: const Icon(Icons.chevron_left_rounded),
              onTap: _editBirth),
        ]),
        LuxSection(title: 'ظاهر و حس لمس', children: [
          LuxRow(
            title: 'ویبره‌ی لمسی',
            subtitle: 'لرزش ملایم هنگام کار با رابط',
            trailing: LuxSwitch(
              value: _haptics,
              onChanged: (v) async {
                setState(() => _haptics = v);
                Haptic.enabled = v;
                await LuxDb.instance.kvSet('haptics', v ? '1' : '0');
              },
            ),
          ),
        ]),
        LuxSection(title: 'اعلان‌ها', children: [
          LuxRow(
            title: 'یادآور آزمایشی',
            subtitle: 'یک اعلان ۱۰ ثانیه‌ی دیگر می‌فرستد',
            trailing: const Icon(Icons.notifications_active_rounded, color: LuxColors.accent),
            onTap: _testReminder,
          ),
        ]),
        LuxSection(title: 'داده', children: [
          LuxRow(title: 'محل پایگاه‌داده', subtitle: LuxDb.instance.path.isEmpty ? '—' : LuxDb.instance.path),
          const LuxRow(title: 'نسخه', subtitle: 'LUX ۱٫۰ — ساخت پایه'),
        ]),
      ],
    );
  }
}
