import 'package:flutter/material.dart';
import 'package:shamsi_date/shamsi_date.dart';

import '../../core/app_bus.dart';
import '../../core/jalali_utils.dart';
import '../../core/palette.dart';
import '../../core/theme.dart';
import '../../core/util.dart';
import '../../data/calendar_repo.dart';
import '../../data/holidays.dart';
import '../../data/reminders.dart';
import '../widgets/day_picker.dart';
import '../widgets/haptic.dart';
import '../widgets/lux_button.dart';
import '../widgets/lux_card.dart';
import '../widgets/lux_chip.dart';
import '../widgets/lux_kit.dart';
import '../widgets/lux_section.dart';
import 'attendance_page.dart';
import 'manage/task_pages.dart';

Color _kindColor(EntryKind k) {
  switch (k) {
    case EntryKind.holiday:
    case EntryKind.userHoliday:
      return LuxColors.danger;
    case EntryKind.occasion:
    case EntryKind.world:
      return LuxColors.silverDim;
    case EntryKind.birthday:
      return const Color(0xFFE58FB0);
    case EntryKind.exam:
      return LuxColors.warn;
    case EntryKind.task:
      return LuxColors.accent;
    case EntryKind.reminder:
    case EntryKind.event:
      return LuxColors.ok;
    case EntryKind.attendance:
      return LuxColors.warn;
  }
}

String _kindLabel(CalEntry e) {
  switch (e.kind) {
    case EntryKind.holiday:
      return 'تعطیل رسمی';
    case EntryKind.userHoliday:
      return 'تعطیلی من';
    case EntryKind.occasion:
      return 'مناسبت';
    case EntryKind.world:
      return 'مناسبت جهانی';
    case EntryKind.birthday:
      return 'تولد';
    case EntryKind.exam:
      return 'امتحان';
    case EntryKind.task:
      return 'تکلیف';
    case EntryKind.reminder:
      return 'یادآور';
    case EntryKind.event:
      return 'رویداد';
    case EntryKind.attendance:
      return 'حضور و غیاب';
  }
}

class CalendarPage extends StatefulWidget {
  final DateTime? initial;
  const CalendarPage({super.key, this.initial});

  @override
  State<CalendarPage> createState() => _CalendarPageState();
}

class _CalendarPageState extends State<CalendarPage> {
  late final int _minY;
  late final int _maxY;
  late int _jy;
  late int _jm;
  late DateTime _sel;
  int _mode = 0; // ۰ ماه، ۱ سال، ۲ تعطیلات
  int _filter = 0; // ۰ همه، ۱ تعطیل رسمی، ۲ مناسبت‌ها، ۳ مال من
  Map<String, List<CalEntry>> _map = <String, List<CalEntry>>{};

  @override
  void initState() {
    super.initState();
    final now = DateTime.now();
    final nj = Jalali.fromDateTime(now);
    _minY = nj.year - 1;
    _maxY = nj.year + 5;
    var j = Jalali.fromDateTime(widget.initial ?? now);
    if (j.year < _minY) j = Jalali(_minY, 1, 1);
    if (j.year > _maxY) j = Jalali(_maxY, 12, 1);
    _jy = j.year;
    _jm = j.month;
    _sel = dateOnly(widget.initial ?? now);
    if (Jalali.fromDateTime(_sel).year != _jy || Jalali.fromDateTime(_sel).month != _jm) {
      _sel = dateOnly(Jalali(_jy, _jm, 1).toDateTime());
    }
    _load();
    AppBus.data.addListener(_load);
  }

  @override
  void dispose() {
    AppBus.data.removeListener(_load);
    super.dispose();
  }

  Future<void> _load() async {
    final DateTime from;
    final DateTime to;
    if (_mode == 0) {
      from = Jalali(_jy, _jm, 1).toDateTime();
      to = Jalali(_jy, _jm, jalaliMonthLength(_jy, _jm)).toDateTime();
    } else {
      from = Jalali(_jy, 1, 1).toDateTime();
      to = Jalali(_jy, 12, jalaliMonthLength(_jy, 12)).toDateTime();
    }
    final m = await CalendarRepo.load(from, to);
    if (!mounted) return;
    setState(() => _map = m);
  }

  DateTime get _today => dateOnly(DateTime.now());

  void _setMonth(int y, int m, {DateTime? select}) {
    setState(() {
      _jy = y;
      _jm = m;
      final t = _today;
      final jt = Jalali.fromDateTime(t);
      _sel = select ?? ((jt.year == y && jt.month == m) ? t : dateOnly(Jalali(y, m, 1).toDateTime()));
    });
    _load();
  }

  void _go(int delta) {
    final idx = _jy * 12 + (_jm - 1) + delta;
    if (idx < _minY * 12 || idx > _maxY * 12 + 11) {
      luxToast(context, 'تقویم از ${faDigits(_minY)} تا ${faDigits(_maxY)} را نشان می‌دهد.');
      return;
    }
    _setMonth(idx ~/ 12, idx % 12 + 1);
  }

  void _setYear(int y) {
    setState(() {
      _jy = y;
      final t = _today;
      final jt = Jalali.fromDateTime(t);
      _sel = jt.year == y ? t : dateOnly(Jalali(y, _jm, 1).toDateTime());
    });
    _load();
  }

  void _setMode(int m) {
    if (_mode == m) return;
    setState(() => _mode = m);
    _load();
  }

  void _jumpTo(DateTime d) {
    final j = Jalali.fromDateTime(d);
    setState(() => _mode = 0);
    _setMonth(j.year, j.month, select: dateOnly(d));
  }

  List<CalEntry> _entriesOf(DateTime d) => _map[CalendarRepo.key(d)] ?? const <CalEntry>[];

  // ───────────────────────── انتخابِ ماه و سال ─────────────────────────

  Future<void> _pickMonth() async {
    var y = _jy;
    await showLuxSheet<void>(
      context,
      (ctx) => StatefulBuilder(builder: (ctx, setS) {
        return Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Text('رفتن به…', style: LuxText.title),
            const SizedBox(height: 14),
            Text('سال', style: LuxText.caption),
            const SizedBox(height: 8),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: [
                for (var yy = _minY; yy <= _maxY; yy++) LuxChip(label: faDigits(yy), selected: yy == y, onTap: () => setS(() => y = yy)),
              ],
            ),
            const SizedBox(height: 16),
            Text('ماه', style: LuxText.caption),
            const SizedBox(height: 8),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: [
                for (var m = 1; m <= 12; m++)
                  LuxChip(
                    label: jalaliMonths[m - 1],
                    selected: y == _jy && m == _jm,
                    onTap: () {
                      Navigator.of(ctx).pop();
                      _setMonth(y, m);
                    },
                  ),
              ],
            ),
          ],
        );
      }),
    );
  }

  // ───────────────────────── افزودن و ویرایش ─────────────────────────

  Future<void> _addMenu(DateTime day) async {
    Widget row(IconData icon, String title, String sub, VoidCallback onTap) => LuxRow(
          leading: Icon(icon, color: LuxColors.accent),
          title: title,
          subtitle: sub,
          onTap: () {
            Navigator.of(context).pop();
            onTap();
          },
        );
    await showLuxSheet<void>(
      context,
      (ctx) => Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Text('افزودن به ${jalaliLabelWithDay(day)}', style: LuxText.title),
          const SizedBox(height: 12),
          row(Icons.checklist_rounded, 'تسک', 'یک کارِ باموعد (با یادآور)', () {
            showTaskEditor(context, initialDue: DateTime(day.year, day.month, day.day, 18));
          }),
          row(Icons.notifications_active_rounded, 'یادآور', 'یک اعلان در ساعتِ دلخواه', () {
            showCalItemEditor(context, day: day, kind: 'reminder');
          }),
          row(Icons.event_rounded, 'رویداد', 'جلسه، مهمانی، سفر، کلاس…', () {
            showCalItemEditor(context, day: day, kind: 'event');
          }),
          row(Icons.cake_rounded, 'تولد', 'هر سال یادآوری می‌شود', () {
            showCalItemEditor(context, day: day, kind: 'birthday');
          }),
          row(Icons.beach_access_rounded, 'تعطیلی شخصی', 'یک روزِ تعطیل که خودت می‌خواهی علامت بزنی', () {
            showCalItemEditor(context, day: day, kind: 'holiday');
          }),
          row(Icons.school_rounded, 'غیبت / حضور در مدرسه', 'ثبت در تقویم و فهرستِ غیبت‌ها', () {
            showAttendanceEditor(context, day: day);
          }),
        ],
      ),
    );
  }

  void _openEntry(CalEntry e) {
    final raw = e.raw;
    if (raw == null) return;
    switch (e.table) {
      case 'tasks':
        showTaskEditor(context, task: raw);
        break;
      case 'cal_items':
        showCalItemEditor(context, item: raw);
        break;
      case 'attendance':
        showAttendanceEditor(context, record: raw);
        break;
    }
  }

  // ───────────────────────── ساختِ صفحه ─────────────────────────

  @override
  Widget build(BuildContext context) {
    return LuxSubPage(
      title: 'تقویم',
      subtitle: 'از ${faDigits(_minY)} تا ${faDigits(_maxY)} · تعطیلات، مناسبت‌ها و کارهای تو',
      action: LuxAddButton(onTap: () => _addMenu(_sel)),
      children: [
        Wrap(
          spacing: 8,
          runSpacing: 8,
          children: [
            LuxChip(label: 'ماه', selected: _mode == 0, onTap: () => _setMode(0)),
            LuxChip(label: 'سال', selected: _mode == 1, onTap: () => _setMode(1)),
            LuxChip(label: 'تعطیلات و مناسبت‌ها', selected: _mode == 2, onTap: () => _setMode(2)),
          ],
        ),
        const SizedBox(height: 16),
        if (_mode == 0) ..._monthView(),
        if (_mode == 1) ..._yearView(),
        if (_mode == 2) ..._holidayView(),
      ],
    );
  }

  // ───────────────────────── نمای ماه ─────────────────────────

  Widget _arrow(IconData icon, VoidCallback onTap) => GestureDetector(
        behavior: HitTestBehavior.opaque,
        onTap: () {
          Haptic.tap();
          onTap();
        },
        child: Container(
          width: 44,
          height: 44,
          decoration: BoxDecoration(
            color: LuxColors.cardHi,
            shape: BoxShape.circle,
            border: Border.all(color: LuxColors.stroke),
          ),
          child: Icon(icon, color: LuxColors.silver, size: 24),
        ),
      );

  String _gregRange() {
    final a = Jalali(_jy, _jm, 1).toDateTime();
    final b = Jalali(_jy, _jm, jalaliMonthLength(_jy, _jm)).toDateTime();
    if (a.month == b.month) return '${gregorianMonthsEn[a.month - 1]} ${a.year}';
    if (a.year == b.year) return '${gregorianMonthsEn[a.month - 1]} – ${gregorianMonthsEn[b.month - 1]} ${a.year}';
    return '${gregorianMonthsEn[a.month - 1]} ${a.year} – ${gregorianMonthsEn[b.month - 1]} ${b.year}';
  }

  List<Widget> _monthView() {
    return [
      Directionality(
        textDirection: TextDirection.ltr,
        child: Row(
          children: [
            _arrow(Icons.chevron_left_rounded, () => _go(1)),
            Expanded(
              child: GestureDetector(
                behavior: HitTestBehavior.opaque,
                onTap: _pickMonth,
                child: Column(
                  children: [
                    Text('${jalaliMonths[_jm - 1]} ${faDigits(_jy)}', style: LuxText.title, textAlign: TextAlign.center),
                    Text(_gregRange(), style: LuxText.caption, textAlign: TextAlign.center),
                  ],
                ),
              ),
            ),
            _arrow(Icons.chevron_right_rounded, () => _go(-1)),
          ],
        ),
      ),
      const SizedBox(height: 14),
      Row(
        children: [
          for (var i = 0; i < 7; i++)
            Expanded(
              child: Text(
                jalaliWeekdays[i].substring(0, 1),
                textAlign: TextAlign.center,
                style: LuxText.caption.copyWith(color: i == 6 ? LuxColors.danger : LuxColors.textDim),
              ),
            ),
        ],
      ),
      const SizedBox(height: 6),
      _grid(),
      const SizedBox(height: 14),
      ..._dayCard(),
    ];
  }

  Widget _grid() {
    final first = Jalali(_jy, _jm, 1);
    final len = first.monthLength;
    final lead = weekdayIndex(first.toDateTime());
    final rows = <Widget>[];
    var day = 1 - lead;
    while (day <= len) {
      final cells = <Widget>[];
      for (var c = 0; c < 7; c++) {
        if (day < 1 || day > len) {
          cells.add(const Expanded(child: SizedBox(height: 58)));
        } else {
          cells.add(Expanded(child: _cell(day, c)));
        }
        day++;
      }
      rows.add(Row(children: cells));
    }
    return Column(children: rows);
  }

  Widget _dot(Color c) => Container(
        width: 5,
        height: 5,
        margin: const EdgeInsets.symmetric(horizontal: 1.2),
        decoration: BoxDecoration(color: c, shape: BoxShape.circle),
      );

  Widget _cell(int d, int col) {
    final date = dateOnly(Jalali(_jy, _jm, d).toDateTime());
    final entries = _entriesOf(date);
    final off = col == 6 || entries.any((e) => e.kind == EntryKind.holiday || e.kind == EntryKind.userHoliday);
    final isSel = date == _sel;
    final isToday = date == _today;

    final kinds = <EntryKind>{};
    for (final e in entries) {
      if (e.kind == EntryKind.world) continue;
      kinds.add(e.kind == EntryKind.userHoliday ? EntryKind.holiday : e.kind);
    }
    final dotColors = <Color>[];
    for (final k in kinds) {
      if (dotColors.length >= 4) break;
      if (k == EntryKind.holiday && off) {
        // روزِ تعطیل با عددِ قرمز نشان داده می‌شود؛ نقطه فقط برای مناسبت‌های دیگر.
        continue;
      }
      dotColors.add(_kindColor(k));
    }

    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTap: () {
        Haptic.tap();
        setState(() => _sel = date);
      },
      child: Container(
        height: 58,
        margin: const EdgeInsets.all(2),
        decoration: BoxDecoration(
          color: isSel ? LuxColors.alpha(LuxColors.accent, 0.18) : null,
          borderRadius: BorderRadius.circular(LuxColors.r(16)),
          border: isSel
              ? Border.all(color: LuxColors.accent, width: 1.4)
              : (isToday ? Border.all(color: LuxColors.accentDim, width: 1.2) : null),
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              faDigits(d),
              style: LuxText.heading.copyWith(
                fontSize: 17,
                color: off ? LuxColors.danger : LuxColors.text,
                fontWeight: isToday ? FontWeight.w800 : FontWeight.w600,
              ),
            ),
            Text('${date.day}', style: LuxText.caption.copyWith(fontSize: 9, color: LuxColors.textDim)),
            const SizedBox(height: 3),
            SizedBox(height: 5, child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [for (final c in dotColors) _dot(c)])),
          ],
        ),
      ),
    );
  }

  List<Widget> _dayCard() {
    final entries = _entriesOf(_sel);
    final isToday = _sel == _today;
    final diff = daysBetween(_today, _sel);
    String when = '';
    if (isToday) {
      when = 'امروز';
    } else if (diff == 1) {
      when = 'فردا';
    } else if (diff == -1) {
      when = 'دیروز';
    } else if (diff > 0) {
      when = '${faDigits(diff)} روز دیگر';
    } else {
      when = '${faDigits(-diff)} روز پیش';
    }
    return [
      LuxCard(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Row(
              children: [
                Expanded(
                  child: Text('${jalaliLabelWithDay(_sel)} ${faDigits(Jalali.fromDateTime(_sel).year)}', style: LuxText.title),
                ),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                  decoration: BoxDecoration(
                    color: LuxColors.alpha(LuxColors.accent, 0.14),
                    borderRadius: BorderRadius.circular(LuxColors.r(14)),
                  ),
                  child: Text(when, style: LuxText.caption.copyWith(color: LuxColors.accent)),
                ),
              ],
            ),
            const SizedBox(height: 4),
            Text('${HolidayData.gregorianLabel(_sel)} · ${HolidayData.hijriLabel(_sel)}', style: LuxText.caption),
            const SizedBox(height: 10),
            if (entries.isEmpty)
              Padding(
                padding: const EdgeInsets.symmetric(vertical: 14),
                child: Text('برای این روز چیزی ثبت نشده.', style: LuxText.caption, textAlign: TextAlign.center),
              )
            else
              for (final e in entries) _entryRow(e),
          ],
        ),
      ),
      const SizedBox(height: 12),
      LuxButton(label: 'افزودن به این روز', icon: Icons.add_rounded, filled: false, onPressed: () => _addMenu(_sel)),
    ];
  }

  Widget _entryRow(CalEntry e) {
    final color = _kindColor(e.kind);
    final subParts = <String>[
      if (e.sub != null && e.sub!.isNotEmpty) e.sub!,
      if (e.kind == EntryKind.holiday || e.kind == EntryKind.occasion || e.kind == EntryKind.world || e.kind == EntryKind.userHoliday)
        _kindLabel(e),
      if (e.tentative) 'تخمینی (ممکن است ±۱ روز جابه‌جا شود)',
    ];
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTap: e.editable ? () => _openEntry(e) : null,
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 8),
        child: Row(
          children: [
            Container(width: 4, height: 40, decoration: BoxDecoration(color: color, borderRadius: BorderRadius.circular(LuxColors.r(4)))),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    e.title,
                    style: LuxText.heading.copyWith(
                      fontSize: 15,
                      decoration: e.done ? TextDecoration.lineThrough : null,
                      color: e.done ? LuxColors.textDim : LuxColors.text,
                    ),
                  ),
                  if (subParts.isNotEmpty) Text(subParts.join(' · '), style: LuxText.caption),
                ],
              ),
            ),
            if (e.kind == EntryKind.task && e.raw != null)
              GestureDetector(
                behavior: HitTestBehavior.opaque,
                onTap: () => toggleTask(e.raw!),
                child: Padding(
                  padding: const EdgeInsets.all(6),
                  child: Icon(
                    e.done ? Icons.check_circle_rounded : Icons.radio_button_unchecked_rounded,
                    color: e.done ? LuxColors.ok : LuxColors.silverDim,
                  ),
                ),
              )
            else if (e.editable)
              Icon(Icons.edit_rounded, size: 18, color: LuxColors.silverDim),
          ],
        ),
      ),
    );
  }

  // ───────────────────────── نمای سال ─────────────────────────

  Widget _yearChips() => SingleChildScrollView(
        scrollDirection: Axis.horizontal,
        child: Row(
          children: [
            for (var y = _minY; y <= _maxY; y++)
              Padding(
                padding: const EdgeInsetsDirectional.only(end: 8),
                child: LuxChip(label: faDigits(y), selected: y == _jy, onTap: () => _setYear(y)),
              ),
          ],
        ),
      );

  List<Widget> _yearView() {
    final pairs = <Widget>[];
    for (var m = 1; m <= 12; m += 2) {
      pairs.add(Padding(
        padding: const EdgeInsets.only(bottom: 12),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Expanded(child: _miniMonth(m)),
            const SizedBox(width: 12),
            Expanded(child: _miniMonth(m + 1)),
          ],
        ),
      ));
    }
    return [
      _yearChips(),
      const SizedBox(height: 16),
      Text('روی هر ماه بزن تا باز شود. عددِ قرمز یعنی تعطیل.', style: LuxText.caption),
      const SizedBox(height: 12),
      ...pairs,
    ];
  }

  Widget _miniMonth(int m) {
    final first = Jalali(_jy, m, 1);
    final len = first.monthLength;
    final lead = weekdayIndex(first.toDateTime());
    final rows = <Widget>[];
    var day = 1 - lead;
    while (day <= len) {
      final cells = <Widget>[];
      for (var c = 0; c < 7; c++) {
        if (day < 1 || day > len) {
          cells.add(const Expanded(child: SizedBox(height: 22)));
        } else {
          final date = dateOnly(Jalali(_jy, m, day).toDateTime());
          final es = _entriesOf(date);
          final off = c == 6 || es.any((e) => e.kind == EntryKind.holiday || e.kind == EntryKind.userHoliday);
          final isToday = date == _today;
          final mine = es.any((e) => e.isMine && e.kind != EntryKind.attendance);
          cells.add(
            Expanded(
              child: Container(
                height: 22,
                alignment: Alignment.center,
                decoration: BoxDecoration(
                  color: isToday ? LuxColors.accent : null,
                  shape: BoxShape.circle,
                ),
                child: Text(
                  faDigits(day),
                  style: LuxText.caption.copyWith(
                    fontSize: 10,
                    color: isToday ? LuxColors.onAccent : (off ? LuxColors.danger : (mine ? LuxColors.accent : LuxColors.text)),
                    fontWeight: (mine || isToday) ? FontWeight.w800 : FontWeight.w500,
                  ),
                ),
              ),
            ),
          );
        }
        day++;
      }
      rows.add(Row(children: cells));
    }
    final jt = Jalali.fromDateTime(_today);
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTap: () {
        setState(() => _mode = 0);
        _setMonth(_jy, m, select: (jt.year == _jy && jt.month == m) ? _today : null);
      },
      child: LuxCard(
        padding: const EdgeInsets.all(10),
        radius: 18,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Text(jalaliMonths[m - 1], style: LuxText.label.copyWith(color: LuxColors.accent), textAlign: TextAlign.center),
            const SizedBox(height: 6),
            ...rows,
          ],
        ),
      ),
    );
  }

  // ───────────────────────── فهرستِ تعطیلات ─────────────────────────

  List<Widget> _holidayView() {
    final days = _map.keys.toList()..sort();
    final all = <_HolRow>[];
    for (final k in days) {
      final d = CalendarRepo.parseKey(k);
      for (final e in _map[k]!) {
        all.add(_HolRow(d, e));
      }
    }

    // خلاصه‌ی سال
    final offDays = <String>{};
    var fridays = 0;
    for (final r in all) {
      if (!r.e.isOfficialHoliday) continue;
      if (offDays.add(CalendarRepo.key(r.d)) && weekdayIndex(r.d) == 6) fridays++;
    }

    // تعطیلیِ بعدی
    _HolRow? next;
    for (final r in all) {
      if (r.e.isOfficialHoliday && !r.d.isBefore(_today)) {
        next = r;
        break;
      }
    }

    bool pass(CalEntry e) {
      switch (_filter) {
        case 1:
          return e.kind == EntryKind.holiday || e.kind == EntryKind.userHoliday;
        case 2:
          return e.kind == EntryKind.occasion || e.kind == EntryKind.world;
        case 3:
          return e.isMine;
        default:
          return true;
      }
    }

    final sections = <Widget>[];
    for (var m = 1; m <= 12; m++) {
      final rows = [for (final r in all) if (Jalali.fromDateTime(r.d).month == m && pass(r.e)) r];
      if (rows.isEmpty) continue;
      sections.add(LuxSection(
        title: '${jalaliMonths[m - 1]} ${faDigits(_jy)}',
        children: [for (final r in rows) _holRow(r)],
      ));
      sections.add(const SizedBox(height: 14));
    }

    return [
      _yearChips(),
      const SizedBox(height: 14),
      LuxCard(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Text('تعطیلات رسمی ${faDigits(_jy)}', style: LuxText.heading),
            const SizedBox(height: 4),
            Text(
              '${faDigits(offDays.length)} روز تعطیل رسمی'
              '${fridays > 0 ? ' (${faDigits(fridays)} تا جمعه)' : ''}'
              ' · جمعه‌ها جدا حساب می‌شوند',
              style: LuxText.caption,
            ),
            if (next != null) ...[
              const SizedBox(height: 12),
              GestureDetector(
                behavior: HitTestBehavior.opaque,
                onTap: () => _jumpTo(next!.d),
                child: Row(
                  children: [
                    Icon(Icons.beach_access_rounded, color: LuxColors.danger),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Text(
                        'تعطیلیِ بعدی: ${next.e.title} — ${jalaliLabelWithDay(next.d)}'
                        ' (${daysBetween(_today, next.d) == 0 ? 'امروز' : '${faDigits(daysBetween(_today, next.d))} روز دیگر'})',
                        style: LuxText.body,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ],
        ),
      ),
      const SizedBox(height: 14),
      Wrap(
        spacing: 8,
        runSpacing: 8,
        children: [
          LuxChip(label: 'همه', selected: _filter == 0, onTap: () => setState(() => _filter = 0)),
          LuxChip(label: 'تعطیل رسمی', selected: _filter == 1, onTap: () => setState(() => _filter = 1)),
          LuxChip(label: 'مناسبت‌ها', selected: _filter == 2, onTap: () => setState(() => _filter = 2)),
          LuxChip(label: 'مال من', selected: _filter == 3, onTap: () => setState(() => _filter = 3)),
        ],
      ),
      const SizedBox(height: 14),
      if (sections.isEmpty)
        const LuxCard(child: LuxEmpty(icon: Icons.event_busy_rounded, title: 'موردی پیدا نشد'))
      else
        ...sections,
      Padding(
        padding: const EdgeInsets.only(top: 4),
        child: Text(
          'تعطیلاتِ قمری تا مرداد ۱۴۰۵ مطابق تقویم رسمی است؛ بقیه‌ی تاریخ‌های قمری «تخمینی» هستند و ممکن است بعد از اعلام رسمی یک روز جابه‌جا شوند. '
          'اگر روزی را خودت تعطیل می‌دانی، از «افزودن ← تعطیلی شخصی» علامتش بزن.',
          style: LuxText.caption,
        ),
      ),
    ];
  }

  Widget _holRow(_HolRow r) {
    final color = _kindColor(r.e.kind);
    final wd = jalaliWeekdays[weekdayIndex(r.d)];
    final sub = <String>[
      _kindLabel(r.e),
      if (r.e.tentative) 'تخمینی',
      if (r.e.sub != null && r.e.sub!.isNotEmpty) r.e.sub!,
    ].join(' · ');
    return LuxRow(
      leading: Container(
        width: 48,
        padding: const EdgeInsets.symmetric(vertical: 6),
        decoration: BoxDecoration(color: LuxColors.alpha(color, 0.14), borderRadius: BorderRadius.circular(LuxColors.r(14))),
        child: Column(
          children: [
            Text(faDigits(Jalali.fromDateTime(r.d).day), style: LuxText.heading.copyWith(color: color, fontSize: 17)),
            Text(wd, style: LuxText.caption.copyWith(fontSize: 9)),
          ],
        ),
      ),
      title: r.e.title,
      subtitle: sub,
      onTap: () => _jumpTo(r.d),
    );
  }
}

class _HolRow {
  final DateTime d;
  final CalEntry e;
  const _HolRow(this.d, this.e);
}

// ───────────────────────── ویرایشگرِ یادآور، رویداد، تولد و تعطیلی ─────────────────────────

const List<String> _kItemKeys = <String>['reminder', 'event', 'birthday', 'holiday'];
const List<int> _kRemindOptions = <int>[0, 60, 1440, 10080];

Future<void> showCalItemEditor(BuildContext context, {Map<String, Object?>? item, DateTime? day, String kind = 'reminder'}) {
  final isNew = item == null;
  var k = isNew ? kind : asStr(item['kind'], 'reminder');
  var date = isNew ? dateOnly(day ?? DateTime.now()) : CalendarRepo.parseKey(asStr(item['day']));
  int? timeMin = isNew ? null : (item['time_min'] == null ? null : asInt(item['time_min']));
  var yearly = isNew ? kind == 'birthday' : asInt(item['yearly']) == 1;
  final remind = isNew ? <int>[0] : CalendarRepo.parseOffsets(item['remind_json']);
  final title = TextEditingController(text: isNew ? '' : asStr(item['title']));
  final note = TextEditingController(text: isNew ? '' : asStr(item['note']));

  return showLuxSheet<void>(
    context,
    (ctx) => StatefulBuilder(builder: (ctx, setS) {
      final hasTime = k == 'reminder' || k == 'event';
      return Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Text(isNew ? 'افزودن به تقویم' : 'ویرایش', style: LuxText.title),
          const SizedBox(height: 16),
          if (isNew)
            LuxChoice(
              label: 'چه چیزی؟',
              options: [for (final x in _kItemKeys) CalendarRepo.itemKinds[x]!],
              selected: _kItemKeys.indexOf(k),
              onChanged: (i) => setS(() {
                k = _kItemKeys[i];
                if (k == 'birthday') yearly = true;
                if (k == 'reminder' || k == 'event') yearly = false;
              }),
            ),
          LuxField(
            label: k == 'birthday' ? 'تولدِ چه کسی؟' : (k == 'holiday' ? 'نامِ تعطیلی' : 'عنوان'),
            controller: title,
            hint: k == 'birthday' ? 'مثلاً مامان' : (k == 'holiday' ? 'مثلاً تعطیلیِ مدرسه' : 'مثلاً دندان‌پزشکی'),
          ),
          LuxPickField(
            label: 'تاریخ',
            value: '${jalaliLabelWithDay(date)} ${faDigits(Jalali.fromDateTime(date).year)}',
            icon: Icons.calendar_month_rounded,
            onTap: () async {
              final r = await pickJalaliDay(ctx, initial: date);
              if (r != null) setS(() => date = r);
            },
          ),
          if (hasTime)
            LuxChoice(
              label: 'ساعت',
              options: const ['تمام‌روز', 'ساعت مشخص'],
              selected: timeMin == null ? 0 : 1,
              onChanged: (i) => setS(() => timeMin = i == 0 ? null : (timeMin ?? 8 * 60)),
            ),
          if (hasTime && timeMin != null)
            LuxPickField(
              label: 'چه ساعتی؟',
              value: CalendarRepo.clock(timeMin!),
              icon: Icons.schedule_rounded,
              onTap: () async {
                final r = await pickTimeOfDayMinutes(ctx, timeMin!);
                if (r != null) setS(() => timeMin = r);
              },
            ),
          if (k == 'birthday' || k == 'holiday')
            LuxChoice(
              label: 'تکرار',
              options: const ['فقط همین بار', 'هر سال'],
              selected: yearly ? 1 : 0,
              onChanged: (i) => setS(() => yearly = i == 1),
            ),
          if (k != 'holiday') ...[
            Padding(
              padding: const EdgeInsetsDirectional.only(start: 4, bottom: 8),
              child: Text(
                k == 'birthday' || timeMin == null ? 'یادآور (ساعت ${k == 'birthday' ? '۹' : '۸'} صبح)' : 'یادآور',
                style: LuxText.caption,
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(bottom: 14),
              child: Wrap(
                spacing: 8,
                runSpacing: 8,
                children: [
                  for (final m in _kRemindOptions)
                    LuxChip(
                      label: Reminders.label(m),
                      selected: remind.contains(m),
                      onTap: () => setS(() {
                        if (remind.contains(m)) {
                          remind.remove(m);
                        } else {
                          remind.add(m);
                        }
                      }),
                    ),
                ],
              ),
            ),
          ],
          LuxField(label: 'یادداشت (اختیاری)', controller: note, maxLines: 2),
          LuxButton(
            label: 'ذخیره',
            onPressed: () async {
              final t = title.text.trim();
              if (t.isEmpty) {
                luxNotice(ctx, 'یک عنوان بنویس.');
                return;
              }
              await CalendarRepo.saveItem(
                id: isNew ? null : asInt(item['id']),
                kind: k,
                title: t,
                day: date,
                timeMin: hasTime ? timeMin : null,
                yearly: yearly && (k == 'birthday' || k == 'holiday'),
                remind: k == 'holiday' ? <int>[] : remind,
                note: note.text.trim(),
              );
              if (ctx.mounted) Navigator.of(ctx).pop();
            },
          ),
          if (!isNew) ...[
            const SizedBox(height: 10),
            LuxButton(
              label: 'حذف',
              filled: false,
              onPressed: () async {
                final ok = await luxConfirm(ctx, 'این مورد حذف شود؟');
                if (!ok) return;
                await CalendarRepo.deleteItem(asInt(item['id']));
                if (ctx.mounted) Navigator.of(ctx).pop();
              },
            ),
          ],
        ],
      );
    }),
  );
}
