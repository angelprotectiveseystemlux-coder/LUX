import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import '../../core/account.dart';
import '../../core/palette.dart';
import '../../core/server.dart';
import '../../core/theme.dart';
import '../../services/rahgosha.dart';
import '../widgets/haptic.dart';
import '../widgets/lux_button.dart';
import '../widgets/lux_card.dart';
import '../widgets/rahgosha_mascot.dart';

/// صفحه‌ی گفتگو با رهگشا.
class RahgoshaPage extends StatefulWidget {
  const RahgoshaPage({super.key});

  @override
  State<RahgoshaPage> createState() => _RahgoshaPageState();
}

class _RahgoshaPageState extends State<RahgoshaPage> {
  final TextEditingController _ctl = TextEditingController();
  bool _sending = false;
  String? _error; // offline | quota | other

  bool get _ready => Rahgosha.serverReady && Account.token != null;

  @override
  void initState() {
    super.initState();
    Rahgosha.chatOpen.value = true;
    Rahgosha.unread.value = false;
    Rahgosha.bubble.value = null;
    Rahgosha.load().then((_) {
      if (mounted) setState(() {});
    });
  }

  @override
  void dispose() {
    Rahgosha.chatOpen.value = false;
    _ctl.dispose();
    super.dispose();
  }

  Future<void> _send(String raw) async {
    final text = raw.trim();
    if (_sending || text.isEmpty || !_ready) return;
    _ctl.clear();
    Haptic.light();
    setState(() {
      _sending = true;
      _error = null;
    });
    try {
      final f = Rahgosha.send(text);
      setState(() {});
      await f;
    } catch (e) {
      if (Rahgosha.history.isNotEmpty && Rahgosha.history.last.user) {
        Rahgosha.history.removeLast();
        await Rahgosha.saveHistory();
      }
      _ctl.text = text;
      final code = e is ApiError ? e.code : 'other';
      _error = code == 'offline' ? 'offline' : (code == 'quota' ? 'quota' : 'other');
    }
    if (mounted) setState(() => _sending = false);
  }

  Widget _banner() {
    String? msg;
    Widget? action;
    if (!Rahgosha.serverReady || Account.token == null) {
      msg = 'رهگشا برای کار کردن به حساب آنلاین و اتصال به سرور نیاز دارد. فعلاً خاموش است؛ بقیه‌ی لوکس مثل همیشه کار می‌کند.';
    } else if (_error == 'offline') {
      msg = 'اینترنت یا سرور در دسترس نیست، برای همین رهگشا فعلاً خاموش است. بقیه‌ی لوکس کار می‌کند؛ وقتی اتصال برگشت دوباره امتحان کن.';
      action = TextButton(onPressed: () => setState(() => _error = null), child: Text('تلاش دوباره', style: LuxText.caption.copyWith(color: LuxColors.accent)));
    } else if (_error == 'quota') {
      msg = 'سهمیه‌ی امروزِ رهگشا تمام شد؛ فردا دوباره برمی‌گردد.';
    } else if (_error == 'other') {
      msg = 'رهگشا این بار جواب نداد. چند لحظه بعد دوباره بفرست.';
    }
    if (msg == null) return const SizedBox.shrink();
    return Container(
      margin: const EdgeInsets.fromLTRB(16, 4, 16, 8),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(color: LuxColors.alpha(LuxColors.danger, 0.1), borderRadius: BorderRadius.circular(LuxColors.r(16)), border: Border.all(color: LuxColors.alpha(LuxColors.danger, 0.4))),
      child: Column(children: [Text(msg, style: LuxText.caption.copyWith(color: LuxColors.text, height: 1.7), textAlign: TextAlign.center), if (action != null) action]),
    );
  }

  @override
  Widget build(BuildContext context) {
    final msgs = Rahgosha.history.reversed.toList();
    final blocked = !_ready || _error == 'offline' || _error == 'quota';
    final nick = Rahgosha.cfg.nick.trim();
    return Scaffold(
      backgroundColor: LuxColors.bg,
      resizeToAvoidBottomInset: true,
      body: SafeArea(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(6, 6, 6, 0),
              child: Row(
                children: [
                  IconButton(icon: Icon(Icons.arrow_forward_rounded, color: LuxColors.text), onPressed: () => Navigator.of(context).pop()),
                  ValueListenableBuilder<bool>(
                    valueListenable: Rahgosha.thinking,
                    builder: (_, th, __) => RgMascot(size: 44, mood: th ? RgMood.think : RgMood.idle, color: Rahgosha.color(LuxColors.accent)),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('رهگشا', style: LuxText.title.copyWith(fontSize: 19)),
                        Text(blocked ? 'خاموش' : (_sending ? 'در حال فکر کردن…' : 'آماده'), style: LuxText.caption.copyWith(color: blocked ? LuxColors.textDim : LuxColors.accent)),
                      ],
                    ),
                  ),
                  IconButton(
                    icon: Icon(Icons.tune_rounded, color: LuxColors.text),
                    onPressed: () async {
                      await Navigator.of(context).push(MaterialPageRoute<void>(builder: (_) => const RahgoshaSettingsPage()));
                      if (mounted) setState(() {});
                    },
                  ),
                ],
              ),
            ),
            Expanded(
              child: ListView.builder(
                reverse: true,
                padding: const EdgeInsets.fromLTRB(16, 8, 16, 8),
                physics: const BouncingScrollPhysics(),
                itemCount: msgs.length + 1 + (_sending ? 1 : 0),
                itemBuilder: (context, i) {
                  if (_sending && i == 0) return const _Typing();
                  final k = i - (_sending ? 1 : 0);
                  if (k == msgs.length) {
                    return msgs.isEmpty ? _welcome(nick) : const SizedBox.shrink();
                  }
                  return _Bubble(msg: msgs[k]);
                },
              ),
            ),
            _banner(),
            Padding(
              padding: const EdgeInsets.fromLTRB(14, 4, 14, 12),
              child: Row(
                children: [
                  Expanded(
                    child: TextField(
                      controller: _ctl,
                      enabled: !blocked && !_sending,
                      minLines: 1,
                      maxLines: 4,
                      textInputAction: TextInputAction.send,
                      onSubmitted: _send,
                      style: LuxText.body,
                      decoration: LuxInput.decoration(blocked ? 'رهگشا فعلاً خاموش است' : 'از رهگشا بپرس…'),
                    ),
                  ),
                  const SizedBox(width: 10),
                  GestureDetector(
                    onTap: (blocked || _sending) ? null : () => _send(_ctl.text),
                    child: Container(
                      width: 50,
                      height: 50,
                      decoration: BoxDecoration(shape: BoxShape.circle, color: (blocked || _sending) ? LuxColors.cardHi : LuxColors.accent),
                      child: Icon(Icons.arrow_upward_rounded, color: (blocked || _sending) ? LuxColors.textDim : LuxColors.onAccent),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _welcome(String nick) {
    const prompts = ['وضعیت درس‌هام چطوره؟', 'نمودار نمره‌هام رو بکش', 'برای آزمون بعدی چیکار کنم؟', 'رقیب‌هام چطورن؟'];
    return Padding(
      padding: const EdgeInsets.only(top: 24, bottom: 8),
      child: Column(
        children: [
          RgMascot(size: 96, mood: RgMood.happy, color: Rahgosha.color(LuxColors.accent)),
          const SizedBox(height: 12),
          Text(nick.isEmpty ? 'سلام! من رهگشام' : 'سلام $nick! من رهگشام', style: LuxText.title.copyWith(fontSize: 22)),
          const SizedBox(height: 6),
          Text('درس‌ها و نمره‌ها و رقبات رو می‌شناسم و کنارتم.', style: LuxText.caption, textAlign: TextAlign.center),
          const SizedBox(height: 16),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            alignment: WrapAlignment.center,
            children: [for (final p in prompts) _Pill(label: p, selected: false, onTap: _ready ? () => _send(p) : () {})],
          ),
        ],
      ),
    );
  }
}

class _Pill extends StatelessWidget {
  final String label;
  final bool selected;
  final VoidCallback onTap;
  const _Pill({required this.label, required this.selected, required this.onTap});

  @override
  Widget build(BuildContext context) => GestureDetector(
        onTap: onTap,
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 180),
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 9),
          decoration: BoxDecoration(
            color: selected ? LuxColors.accent : LuxColors.cardHi,
            borderRadius: BorderRadius.circular(LuxColors.r(20)),
          ),
          child: Text(label, style: LuxText.caption.copyWith(color: selected ? LuxColors.onAccent : LuxColors.text)),
        ),
      );
}

class _Typing extends StatefulWidget {
  const _Typing();

  @override
  State<_Typing> createState() => _TypingState();
}

class _TypingState extends State<_Typing> with SingleTickerProviderStateMixin {
  late final AnimationController _c = AnimationController(vsync: this, duration: const Duration(milliseconds: 1000))..repeat();

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => Align(
        alignment: AlignmentDirectional.centerEnd,
        child: Container(
          margin: const EdgeInsets.symmetric(vertical: 6),
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
          decoration: BoxDecoration(color: LuxColors.card, borderRadius: BorderRadius.circular(LuxColors.r(18))),
          child: AnimatedBuilder(
            animation: _c,
            builder: (_, __) => Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                for (var i = 0; i < 3; i++)
                  Container(
                    margin: const EdgeInsets.symmetric(horizontal: 3),
                    width: 8,
                    height: 8 + 4 * ((_c.value * 3 - i).clamp(0.0, 1.0) * (1 - (_c.value * 3 - i).clamp(0.0, 1.0)) * 4),
                    decoration: BoxDecoration(color: LuxColors.accent, borderRadius: BorderRadius.circular(5)),
                  ),
              ],
            ),
          ),
        ),
      );
}

class _Bubble extends StatelessWidget {
  final RgMsg msg;
  const _Bubble({required this.msg});

  static final RegExp _chart = RegExp(r'```chart\s*([\s\S]*?)```');

  List<Widget> _blocks(String text) {
    final out = <Widget>[];
    var last = 0;
    for (final m in _chart.allMatches(text)) {
      final before = text.substring(last, m.start).trim();
      if (before.isNotEmpty) out.add(_rich(before));
      try {
        final spec = jsonDecode(m.group(1)!.trim()) as Map<String, dynamic>;
        out.add(_ChartCard(spec: spec));
      } catch (_) {}
      last = m.end;
    }
    final rest = text.substring(last).trim();
    if (rest.isNotEmpty) out.add(_rich(rest));
    return out;
  }

  Widget _rich(String t) {
    final lines = t.split('\n');
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        for (final l in lines)
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 1.5),
            child: Text.rich(TextSpan(children: _spans(l.replaceFirst(RegExp(r'^\s*[-*]\s+'), '• '))), style: LuxText.body.copyWith(height: 1.75)),
          ),
      ],
    );
  }

  List<InlineSpan> _spans(String l) {
    final out = <InlineSpan>[];
    final re = RegExp(r'\*\*(.+?)\*\*');
    var last = 0;
    for (final m in re.allMatches(l)) {
      if (m.start > last) out.add(TextSpan(text: l.substring(last, m.start)));
      out.add(TextSpan(text: m.group(1), style: const TextStyle(fontWeight: FontWeight.w800)));
      last = m.end;
    }
    if (last < l.length) out.add(TextSpan(text: l.substring(last)));
    return out;
  }

  @override
  Widget build(BuildContext context) {
    final u = msg.user;
    return Align(
      alignment: u ? AlignmentDirectional.centerStart : AlignmentDirectional.centerEnd,
      child: Container(
        margin: const EdgeInsets.symmetric(vertical: 5),
        constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * 0.84),
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 11),
        decoration: BoxDecoration(
          color: u ? LuxColors.alpha(LuxColors.accent, 0.16) : LuxColors.card,
          borderRadius: BorderRadius.circular(LuxColors.r(18)),
          border: u ? Border.all(color: LuxColors.alpha(LuxColors.accent, 0.4)) : null,
        ),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisSize: MainAxisSize.min, children: _blocks(msg.text)),
      ),
    );
  }
}

class _ChartCard extends StatelessWidget {
  final Map<String, dynamic> spec;
  const _ChartCard({required this.spec});

  @override
  Widget build(BuildContext context) {
    final vals = ((spec['values'] ?? <dynamic>[]) as List).whereType<num>().map((e) => e.toDouble()).take(14).toList();
    final labels = ((spec['labels'] ?? <dynamic>[]) as List).map((e) => e.toString()).toList();
    if (vals.isEmpty) return const SizedBox.shrink();
    final bar = spec['type'] == 'bar';
    return Container(
      margin: const EdgeInsets.symmetric(vertical: 8),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(color: LuxColors.cardHi, borderRadius: BorderRadius.circular(LuxColors.r(16))),
      child: Column(
        children: [
          if ((spec['title'] ?? '').toString().isNotEmpty) Text(spec['title'].toString(), style: LuxText.body.copyWith(fontWeight: FontWeight.w800)),
          const SizedBox(height: 10),
          SizedBox(height: 150, width: double.infinity, child: CustomPaint(painter: _ChartPainter(vals, bar, LuxColors.accent, LuxColors.textDim, LuxColors.stroke))),
          const SizedBox(height: 6),
          Directionality(
            textDirection: TextDirection.ltr,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [for (var i = 0; i < vals.length; i++) Expanded(child: Text(i < labels.length ? labels[i] : '', style: LuxText.caption.copyWith(fontSize: 9), textAlign: TextAlign.center, maxLines: 1, overflow: TextOverflow.ellipsis))],
            ),
          ),
        ],
      ),
    );
  }
}

class _ChartPainter extends CustomPainter {
  final List<double> v;
  final bool bar;
  final Color c;
  final Color dim;
  final Color grid;
  _ChartPainter(this.v, this.bar, this.c, this.dim, this.grid);

  @override
  void paint(Canvas canvas, Size s) {
    final maxV = v.reduce((a, b) => a > b ? a : b);
    final minV = bar ? 0.0 : v.reduce((a, b) => a < b ? a : b);
    final span = (maxV - minV).abs() < 1e-6 ? 1.0 : (maxV - minV);
    final top = 16.0, bottom = s.height - 6;
    for (var i = 0; i < 4; i++) {
      final y = top + (bottom - top) * i / 3;
      canvas.drawLine(Offset(0, y), Offset(s.width, y), Paint()..color = grid..strokeWidth = 1);
    }
    final n = v.length;
    final slot = s.width / n;
    final pts = <Offset>[
      for (var i = 0; i < n; i++) Offset(slot * i + slot / 2, bottom - (v[i] - minV) / span * (bottom - top) * 0.92),
    ];
    final tp = TextPainter(textDirection: TextDirection.ltr);
    if (bar) {
      for (var i = 0; i < n; i++) {
        final r = RRect.fromRectAndRadius(Rect.fromLTRB(pts[i].dx - slot * 0.28, pts[i].dy, pts[i].dx + slot * 0.28, bottom), const Radius.circular(6));
        canvas.drawRRect(r, Paint()..color = c.withOpacity(0.85));
      }
    } else {
      final path = Path()..moveTo(pts.first.dx, pts.first.dy);
      for (var i = 1; i < n; i++) {
        final mid = (pts[i - 1].dx + pts[i].dx) / 2;
        path.cubicTo(mid, pts[i - 1].dy, mid, pts[i].dy, pts[i].dx, pts[i].dy);
      }
      canvas.drawPath(path, Paint()..style = PaintingStyle.stroke..strokeWidth = 3..strokeCap = StrokeCap.round..color = c);
      for (final p in pts) {
        canvas.drawCircle(p, 4.5, Paint()..color = c);
        canvas.drawCircle(p, 2, Paint()..color = Colors.white);
      }
    }
    for (var i = 0; i < n; i++) {
      tp.text = TextSpan(text: v[i] == v[i].roundToDouble() ? v[i].toStringAsFixed(0) : v[i].toStringAsFixed(1), style: TextStyle(color: dim, fontSize: 10));
      tp.layout();
      tp.paint(canvas, Offset(pts[i].dx - tp.width / 2, pts[i].dy - tp.height - 5));
    }
  }

  @override
  bool shouldRepaint(covariant _ChartPainter old) => true;
}

// ───────────────────────── تنظیمات ─────────────────────────

class RahgoshaSettingsPage extends StatefulWidget {
  const RahgoshaSettingsPage({super.key});

  @override
  State<RahgoshaSettingsPage> createState() => _RahgoshaSettingsPageState();
}

class _RahgoshaSettingsPageState extends State<RahgoshaSettingsPage> {
  late final TextEditingController _nick = TextEditingController(text: Rahgosha.cfg.nick);
  late final TextEditingController _custom = TextEditingController(text: Rahgosha.cfg.custom);
  final TextEditingController _mem = TextEditingController();
  Timer? _t;

  RgConfig get c => Rahgosha.cfg;

  void _save() {
    _t?.cancel();
    _t = Timer(const Duration(milliseconds: 400), () => Rahgosha.saveCfg());
  }

  @override
  void dispose() {
    _t?.cancel();
    Rahgosha.saveCfg();
    _nick.dispose();
    _custom.dispose();
    _mem.dispose();
    super.dispose();
  }

  Widget _title(String t) => Padding(padding: const EdgeInsets.fromLTRB(4, 22, 4, 10), child: Text(t, style: LuxText.title.copyWith(fontSize: 16)));

  Widget _slider(String label, double v, List<String> ends, ValueChanged<double> onC) => Padding(
        padding: const EdgeInsets.only(bottom: 4),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(label, style: LuxText.body),
            Slider(value: v, activeColor: LuxColors.accent, inactiveColor: LuxColors.stroke, onChanged: (x) => setState(() => onC(x)), onChangeEnd: (_) => _save()),
            Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [Text(ends[0], style: LuxText.caption), Text(ends[1], style: LuxText.caption)]),
          ],
        ),
      );

  @override
  Widget build(BuildContext context) {
    final accent = LuxColors.accent;
    return Scaffold(
      backgroundColor: LuxColors.bg,
      body: SafeArea(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(8, 8, 8, 0),
              child: Row(children: [
                IconButton(icon: Icon(Icons.arrow_forward_rounded, color: LuxColors.text), onPressed: () => Navigator.of(context).pop()),
                Text('شخصی‌سازی رهگشا', style: LuxText.title.copyWith(fontSize: 20)),
              ]),
            ),
            Expanded(
              child: ListView(
                padding: const EdgeInsets.fromLTRB(20, 0, 20, 40),
                physics: const BouncingScrollPhysics(),
                children: [
                  Center(child: Padding(padding: const EdgeInsets.only(top: 10), child: RgMascot(size: 90, mood: RgMood.happy, color: Rahgosha.color(accent)))),
                  _title('اسمی که صدات بزنه'),
                  TextField(
                    controller: _nick,
                    style: LuxText.body,
                    decoration: LuxInput.decoration('مثلاً: علی'),
                    onChanged: (v) {
                      c.nick = v;
                      _save();
                    },
                  ),
                  _title('شخصیت'),
                  Wrap(
                    spacing: 8,
                    runSpacing: 8,
                    children: [for (var i = 0; i < kRgPresets.length; i++) _Pill(label: kRgPresets[i], selected: c.preset == i, onTap: () => setState(() {
                      c.preset = i;
                      _save();
                    }))],
                  ),
                  _title('سبک گفتگو'),
                  _slider('گرمی', c.warmth, ['جدی', 'پرانرژی'], (x) => c.warmth = x),
                  _slider('شوخ‌طبعی', c.humor, ['کم', 'زیاد'], (x) => c.humor = x),
                  _slider('ایموجی', c.emoji, ['هیچ', 'زیاد'], (x) => c.emoji = x),
                  _slider('طولِ جواب', c.length, ['کوتاه', 'مفصل'], (x) => c.length = x),
                  _slider('لحن', c.formality, ['خودمانی', 'رسمی'], (x) => c.formality = x),
                  _title('ظاهر'),
                  Row(
                    children: [
                      for (var i = 0; i < kRgColors.length; i++)
                        GestureDetector(
                          onTap: () => setState(() {
                            c.colorIdx = i;
                            _save();
                          }),
                          child: Container(
                            margin: const EdgeInsets.only(left: 10),
                            width: 38,
                            height: 38,
                            decoration: BoxDecoration(shape: BoxShape.circle, color: kRgColors[i] ?? accent, border: Border.all(color: c.colorIdx == i ? LuxColors.text : Colors.transparent, width: 2.4)),
                          ),
                        ),
                    ],
                  ),
                  const SizedBox(height: 14),
                  Wrap(
                    spacing: 8,
                    children: [for (final s in kRgSignatures) _Pill(label: s, selected: c.signature == s, onTap: () => setState(() {
                      c.signature = s;
                      _save();
                    }))],
                  ),
                  _title('دستورِ سفارشی'),
                  TextField(
                    controller: _custom,
                    minLines: 3,
                    maxLines: 6,
                    style: LuxText.body,
                    decoration: LuxInput.decoration('مثلاً: همیشه برای مطالعه برنامه‌ی ۲۵ دقیقه‌ای پیشنهاد بده'),
                    onChanged: (v) {
                      c.custom = v;
                      _save();
                    },
                  ),
                  _title('چیزهایی که باید به خاطر بسپارد'),
                  for (var i = 0; i < c.memories.length; i++)
                    LuxCard(
                      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
                      child: Row(children: [
                        Expanded(child: Text(c.memories[i], style: LuxText.body)),
                        IconButton(icon: Icon(Icons.close_rounded, color: LuxColors.textDim), onPressed: () => setState(() {
                          c.memories.removeAt(i);
                          _save();
                        })),
                      ]),
                    ),
                  const SizedBox(height: 8),
                  Row(children: [
                    Expanded(child: TextField(controller: _mem, style: LuxText.body, decoration: LuxInput.decoration('مثلاً: شب‌ها بهتر درس می‌خونم'))),
                    const SizedBox(width: 10),
                    IconButton(
                      icon: Icon(Icons.add_circle_rounded, color: accent, size: 34),
                      onPressed: () {
                        final t = _mem.text.trim();
                        if (t.isEmpty) return;
                        setState(() {
                          c.memories.add(t);
                          _mem.clear();
                        });
                        _save();
                      },
                    ),
                  ]),
                  _title('پیام دادنِ خودش'),
                  SwitchListTile.adaptive(
                    contentPadding: EdgeInsets.zero,
                    activeColor: accent,
                    title: Text('رهگشا گاهی اول پیام بدهد', style: LuxText.body),
                    value: c.proactive,
                    onChanged: (v) => setState(() {
                      c.proactive = v;
                      _save();
                    }),
                  ),
                  if (c.proactive)
                    Wrap(
                      spacing: 8,
                      children: [for (final h in const [6, 12, 24]) _Pill(label: 'هر $h ساعت', selected: c.proactiveHours == h, onTap: () => setState(() {
                        c.proactiveHours = h;
                        _save();
                      }))],
                    ),
                  const SizedBox(height: 26),
                  LuxButton(
                    label: 'پاک کردنِ گفتگوها',
                    filled: false,
                    onPressed: () async {
                      await Rahgosha.clearHistory();
                      if (context.mounted) Navigator.of(context).pop();
                    },
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
