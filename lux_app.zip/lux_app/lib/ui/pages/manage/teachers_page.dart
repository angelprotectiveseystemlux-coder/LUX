import 'package:flutter/material.dart';
import '../../../core/app_bus.dart';
import '../../../core/palette.dart';
import '../../../core/theme.dart';
import '../../../core/util.dart';
import '../../../data/database.dart';
import '../../widgets/lux_card.dart';
import '../../widgets/lux_kit.dart';
import '../../widgets/lux_section.dart';
import 'editors.dart';

class TeachersPage extends StatefulWidget {
  const TeachersPage({super.key});

  @override
  State<TeachersPage> createState() => _TeachersPageState();
}

class _TeachersPageState extends State<TeachersPage> {
  List<Map<String, Object?>> _rows = <Map<String, Object?>>[];
  bool _loaded = false;

  @override
  void initState() {
    super.initState();
    _load();
    AppBus.data.addListener(_load);
  }

  @override
  void dispose() {
    AppBus.data.removeListener(_load);
    super.dispose();
  }

  Future<void> _load() async {
    final r = await LuxDb.instance.rawQuery(
      'SELECT t.*, (SELECT GROUP_CONCAT(c.name, '
      "'، ') FROM courses c WHERE c.teacher_id = t.id AND c.archived = 0) AS course_names "
      'FROM teachers t ORDER BY t.id',
    );
    if (!mounted) return;
    setState(() {
      _rows = r;
      _loaded = true;
    });
  }

  Future<void> _delete(Map<String, Object?> t) async {
    final ok = await luxConfirm(context, 'حذف ${asStr(t['name'])}؟', body: 'درس‌های این معلم حذف نمی‌شوند، فقط بدون معلم می‌مانند.');
    if (!ok) return;
    await LuxDb.instance.delete('teachers', where: 'id = ?', args: [asInt(t['id'])]);
    AppBus.bump();
  }

  @override
  Widget build(BuildContext context) {
    return LuxSubPage(
      title: 'معلم‌ها',
      subtitle: 'سبک تدریس و یادداشت‌ها',
      action: LuxAddButton(onTap: () => showTeacherEditor(context)),
      children: [
        if (_loaded && _rows.isEmpty)
          const LuxCard(child: LuxEmpty(icon: Icons.person_rounded, title: 'معلمی ثبت نشده', hint: 'با دکمه‌ی + معلم‌هایت را اضافه کن و در هر درس انتخابشان کن.'))
        else
          LuxSection(title: 'همه‌ی معلم‌ها', children: [
            for (final t in _rows)
              LuxRow(
                leading: Icon(Icons.person_rounded, color: LuxColors.silver),
                title: asStr(t['name']),
                subtitle: [
                  if (asStr(t['course_names']).isNotEmpty) asStr(t['course_names']),
                  if (asStr(t['style_note']).isNotEmpty) asStr(t['style_note']),
                ].join(' · '),
                trailing: GestureDetector(
                  onTap: () => _delete(t),
                  child: Icon(Icons.delete_outline_rounded, color: LuxColors.silverDim),
                ),
                onTap: () => showTeacherEditor(context, teacher: t),
              ),
          ]),
        Text('برای ویرایش روی هر معلم بزن.', style: LuxText.caption, textAlign: TextAlign.center),
      ],
    );
  }
}
