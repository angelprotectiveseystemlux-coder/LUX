import 'package:flutter/material.dart';
import '../../../core/app_bus.dart';
import '../../../core/jalali_utils.dart';
import '../../../core/palette.dart';
import '../../../core/theme.dart';
import '../../../core/util.dart';
import '../../../data/database.dart';
import '../../../data/study_repo.dart';
import '../../widgets/lux_button.dart';
import '../../widgets/lux_kit.dart';

const List<String> kDifficulty = <String>['خیلی آسان', 'آسان', 'متوسط', 'سخت', 'خیلی سخت'];

const List<String> kCourseSuggestions = <String>[
  'ریاضی', 'فیزیک', 'شیمی', 'زیست‌شناسی', 'ادبیات فارسی', 'عربی', 'دین و زندگی',
  'زبان انگلیسی', 'تاریخ', 'جغرافیا', 'علوم', 'هندسه', 'آمار و احتمال', 'منطق', 'اجتماعی',
];

Widget _pickRow({
  required Widget leading,
  required String title,
  String? sub,
  required bool selected,
  required VoidCallback onTap,
}) {
  return GestureDetector(
    behavior: HitTestBehavior.opaque,
    onTap: onTap,
    child: Padding(
      padding: const EdgeInsets.symmetric(vertical: 12),
      child: Row(
        children: [
          leading,
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title, style: LuxText.heading),
                if (sub != null) Text(sub, style: LuxText.caption),
              ],
            ),
          ),
          if (selected) Icon(Icons.check_rounded, color: LuxColors.accent),
        ],
      ),
    ),
  );
}

/// انتخاب درس. نتیجه: شناسه‌ی درس، یا -1 برای «بدون درس»، یا null اگر بسته شد.
Future<int?> pickCourse(BuildContext context, {int? selectedId, bool allowNone = false}) async {
  final list = await StudyRepo.courses();
  if (!context.mounted) return null;
  if (list.isEmpty) {
    luxNotice(context, 'اول از تب «درس‌ها» یک درس اضافه کن.');
    return null;
  }
  return showLuxSheet<int>(
    context,
    (ctx) => Column(
      mainAxisSize: MainAxisSize.min,
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Text('انتخاب درس', style: LuxText.title),
        const SizedBox(height: 8),
        if (allowNone)
          _pickRow(
            leading: Icon(Icons.block_rounded, color: LuxColors.silverDim),
            title: 'بدون درس',
            selected: selectedId == null || selectedId < 0,
            onTap: () => Navigator.of(ctx).pop(-1),
          ),
        for (final c in list)
          _pickRow(
            leading: LuxDot(color: courseColor(c['color'])),
            title: asStr(c['name']),
            sub: asStr(c['teacher_name']).isEmpty ? null : 'معلم: ${asStr(c['teacher_name'])}',
            selected: asInt(c['id']) == selectedId,
            onTap: () => Navigator.of(ctx).pop(asInt(c['id'])),
          ),
      ],
    ),
  );
}

/// انتخاب معلم. نتیجه: شناسه، -1 برای «بدون معلم»، یا null.
Future<int?> pickTeacher(BuildContext context, {int? selectedId}) async {
  final list = await StudyRepo.teachers();
  if (!context.mounted) return null;
  return showLuxSheet<int>(
    context,
    (ctx) => Column(
      mainAxisSize: MainAxisSize.min,
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Text('انتخاب معلم', style: LuxText.title),
        const SizedBox(height: 8),
        _pickRow(
          leading: Icon(Icons.block_rounded, color: LuxColors.silverDim),
          title: 'بدون معلم',
          selected: selectedId == null || selectedId < 0,
          onTap: () => Navigator.of(ctx).pop(-1),
        ),
        for (final t in list)
          _pickRow(
            leading: Icon(Icons.person_rounded, color: LuxColors.silver),
            title: asStr(t['name']),
            selected: asInt(t['id']) == selectedId,
            onTap: () => Navigator.of(ctx).pop(asInt(t['id'])),
          ),
        const SizedBox(height: 10),
        LuxButton(
          label: 'معلم جدید',
          icon: Icons.add_rounded,
          filled: false,
          onPressed: () async {
            final id = await showTeacherEditor(ctx);
            if (id != null && ctx.mounted) Navigator.of(ctx).pop(id);
          },
        ),
      ],
    ),
  );
}

Future<String> teacherName(int? id) async {
  if (id == null || id < 0) return '';
  final r = await LuxDb.instance.query('teachers', where: 'id = ?', args: [id], limit: 1);
  return r.isEmpty ? '' : asStr(r.first['name']);
}

Future<String> courseNameOf(int? id) async {
  if (id == null || id < 0) return '';
  final r = await LuxDb.instance.query('courses', where: 'id = ?', args: [id], limit: 1);
  return r.isEmpty ? '' : asStr(r.first['name']);
}

// ───────────────────────── درس ─────────────────────────

/// ساخت/ویرایش درس. شناسه‌ی درسِ ذخیره‌شده را برمی‌گرداند.
Future<int?> showCourseEditor(BuildContext context, {Map<String, Object?>? course}) {
  final isNew = course == null;
  final name = TextEditingController(text: asStr(course?['name']));
  final coef = TextEditingController(text: latinNum(asDouble(course?['coef'], 1)));
  final maxS = TextEditingController(text: latinNum(asDouble(course?['max_score'], 20)));
  final passS = TextEditingController(text: latinNum(asDouble(course?['pass_score'], 10)));
  final notes = TextEditingController(text: asStr(course?['notes']));
  final bookTitle = TextEditingController();
  var difficulty = asInt(course?['difficulty'], 3).clamp(1, 5);
  var color = asInt(course?['color'], 0);
  int? teacherId = course == null ? null : (course['teacher_id'] == null ? null : asInt(course['teacher_id']));
  var teacherLabel = '';
  var loadedTeacher = false;

  return showLuxSheet<int>(
    context,
    (ctx) => StatefulBuilder(builder: (ctx, setS) {
      if (!loadedTeacher) {
        loadedTeacher = true;
        teacherName(teacherId).then((n) {
          if (ctx.mounted) setS(() => teacherLabel = n);
        });
      }
      return Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Text(isNew ? 'درس جدید' : 'ویرایش درس', style: LuxText.title),
          const SizedBox(height: 16),
          LuxField(label: 'نام درس', controller: name, hint: 'مثلاً ریاضی'),
          if (isNew)
            Padding(
              padding: const EdgeInsets.only(bottom: 14),
              child: Wrap(
                spacing: 8,
                runSpacing: 8,
                children: [
                  for (final s in kCourseSuggestions)
                    GestureDetector(
                      onTap: () => setS(() => name.text = s),
                      child: Container(
                        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
                        decoration: BoxDecoration(
                          color: LuxColors.alpha(LuxColors.accent, 0.10),
                          borderRadius: BorderRadius.circular(14),
                        ),
                        child: Text(s, style: LuxText.caption.copyWith(color: LuxColors.accent)),
                      ),
                    ),
                ],
              ),
            ),
          LuxField(label: 'ضریب (تعداد واحد)', controller: coef, keyboard: TextInputType.number),
          LuxChoice(
            label: 'سختی',
            options: kDifficulty,
            selected: difficulty - 1,
            onChanged: (i) => setS(() => difficulty = i + 1),
          ),
          Row(
            children: [
              Expanded(child: LuxField(label: 'بیشینه‌ی نمره', controller: maxS, keyboard: TextInputType.number)),
              const SizedBox(width: 12),
              Expanded(child: LuxField(label: 'حدِ قبولی', controller: passS, keyboard: TextInputType.number)),
            ],
          ),
          LuxPickField(
            label: 'معلم',
            value: teacherLabel.isEmpty ? 'انتخاب نشده' : teacherLabel,
            placeholder: teacherLabel.isEmpty,
            onTap: () async {
              final r = await pickTeacher(ctx, selectedId: teacherId);
              if (r == null) return;
              final n = await teacherName(r);
              setS(() {
                teacherId = r < 0 ? null : r;
                teacherLabel = n;
              });
            },
          ),
          LuxColorPicker(selected: color, onChanged: (i) => setS(() => color = i)),
          if (isNew) LuxField(label: 'کتاب درسی (اختیاری)', controller: bookTitle, hint: 'مثلاً ریاضی ۱'),
          LuxField(label: 'یادداشت', controller: notes, maxLines: 3),
          const SizedBox(height: 4),
          LuxButton(
            label: 'ذخیره',
            onPressed: () async {
              final n = name.text.trim();
              if (n.isEmpty) {
                luxNotice(ctx, 'نام درس را بنویس.');
                return;
              }
              final values = <String, Object?>{
                'name': n,
                'coef': parseNum(coef.text) ?? 1.0,
                'difficulty': difficulty,
                'max_score': parseNum(maxS.text) ?? 20.0,
                'pass_score': parseNum(passS.text) ?? 10.0,
                'teacher_id': teacherId,
                'color': color,
                'notes': notes.text.trim(),
              };
              int id;
              if (isNew) {
                values['created_at'] = DateTime.now().millisecondsSinceEpoch;
                id = await LuxDb.instance.insert('courses', values);
                final bt = bookTitle.text.trim();
                if (bt.isNotEmpty) {
                  await LuxDb.instance.insert('books', <String, Object?>{
                    'course_id': id,
                    'title': bt,
                    'added_at': DateTime.now().millisecondsSinceEpoch,
                  });
                }
              } else {
                id = asInt(course!['id']);
                await LuxDb.instance.update('courses', values, where: 'id = ?', args: [id]);
              }
              AppBus.bump();
              if (ctx.mounted) Navigator.of(ctx).pop(id);
            },
          ),
        ],
      );
    }),
  );
}

// ───────────────────────── معلم ─────────────────────────

Future<int?> showTeacherEditor(BuildContext context, {Map<String, Object?>? teacher}) {
  final isNew = teacher == null;
  final name = TextEditingController(text: asStr(teacher?['name']));
  final style = TextEditingController(text: asStr(teacher?['style_note']));
  final notes = TextEditingController(text: asStr(teacher?['notes']));
  return showLuxSheet<int>(
    context,
    (ctx) => Column(
      mainAxisSize: MainAxisSize.min,
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Text(isNew ? 'معلم جدید' : 'ویرایش معلم', style: LuxText.title),
        const SizedBox(height: 16),
        LuxField(label: 'نام معلم', controller: name),
        LuxField(
          label: 'سبک تدریس',
          controller: style,
          hint: 'مثلاً سریع درس می‌دهد، تمرین زیاد می‌دهد',
          maxLines: 2,
        ),
        LuxField(label: 'یادداشت و سؤال‌های بی‌جواب', controller: notes, maxLines: 3),
        LuxButton(
          label: 'ذخیره',
          onPressed: () async {
            final n = name.text.trim();
            if (n.isEmpty) {
              luxNotice(ctx, 'نام معلم را بنویس.');
              return;
            }
            final values = <String, Object?>{
              'name': n,
              'style_note': style.text.trim(),
              'notes': notes.text.trim(),
            };
            int id;
            if (isNew) {
              id = await LuxDb.instance.insert('teachers', values);
            } else {
              id = asInt(teacher!['id']);
              await LuxDb.instance.update('teachers', values, where: 'id = ?', args: [id]);
            }
            AppBus.bump();
            if (ctx.mounted) Navigator.of(ctx).pop(id);
          },
        ),
      ],
    ),
  );
}

// ───────────────────────── ساعت کلاس ─────────────────────────

Future<bool?> showSlotEditor(BuildContext context, {int? courseId, Map<String, Object?>? slot}) {
  final isNew = slot == null;
  int? cid = courseId ?? (slot == null ? null : asInt(slot['course_id']));
  var cname = '';
  var loaded = false;
  var weekday = asInt(slot?['weekday'], 0).clamp(0, 6);
  var start = asInt(slot?['start_min'], 8 * 60);
  var end = asInt(slot?['end_min'], 9 * 60 + 30);
  final room = TextEditingController(text: asStr(slot?['room']));
  return showLuxSheet<bool>(
    context,
    (ctx) => StatefulBuilder(builder: (ctx, setS) {
      if (!loaded) {
        loaded = true;
        courseNameOf(cid).then((n) {
          if (ctx.mounted) setS(() => cname = n);
        });
      }
      return Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Text(isNew ? 'ساعت کلاس جدید' : 'ویرایش ساعت کلاس', style: LuxText.title),
          const SizedBox(height: 16),
          LuxPickField(
            label: 'درس',
            value: cname.isEmpty ? 'انتخاب کن' : cname,
            placeholder: cname.isEmpty,
            onTap: () async {
              final r = await pickCourse(ctx, selectedId: cid);
              if (r == null || r < 0) return;
              final n = await courseNameOf(r);
              setS(() {
                cid = r;
                cname = n;
              });
            },
          ),
          LuxChoice(label: 'روز هفته', options: jalaliWeekdays, selected: weekday, onChanged: (i) => setS(() => weekday = i)),
          Row(
            children: [
              Expanded(
                child: LuxPickField(
                  label: 'شروع',
                  value: minutesLabel(start),
                  icon: Icons.schedule_rounded,
                  onTap: () async {
                    final r = await pickTimeOfDayMinutes(ctx, start);
                    if (r != null) setS(() => start = r);
                  },
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: LuxPickField(
                  label: 'پایان',
                  value: minutesLabel(end),
                  icon: Icons.schedule_rounded,
                  onTap: () async {
                    final r = await pickTimeOfDayMinutes(ctx, end);
                    if (r != null) setS(() => end = r);
                  },
                ),
              ),
            ],
          ),
          LuxField(label: 'کلاس / مکان', controller: room, hint: 'اختیاری'),
          LuxButton(
            label: 'ذخیره',
            onPressed: () async {
              if (cid == null) {
                luxNotice(ctx, 'درس را انتخاب کن.');
                return;
              }
              if (end <= start) {
                luxNotice(ctx, 'ساعت پایان باید بعد از شروع باشد.');
                return;
              }
              final values = <String, Object?>{
                'course_id': cid,
                'weekday': weekday,
                'start_min': start,
                'end_min': end,
                'room': room.text.trim(),
              };
              if (isNew) {
                await LuxDb.instance.insert('class_slots', values);
              } else {
                await LuxDb.instance.update('class_slots', values, where: 'id = ?', args: [asInt(slot!['id'])]);
              }
              AppBus.bump();
              if (ctx.mounted) Navigator.of(ctx).pop(true);
            },
          ),
          if (!isNew) ...[
            const SizedBox(height: 10),
            LuxButton(
              label: 'حذف این ساعت',
              filled: false,
              onPressed: () async {
                final ok = await luxConfirm(ctx, 'این ساعت کلاس حذف شود؟');
                if (!ok) return;
                await LuxDb.instance.delete('class_slots', where: 'id = ?', args: [asInt(slot!['id'])]);
                AppBus.bump();
                if (ctx.mounted) Navigator.of(ctx).pop(true);
              },
            ),
          ],
        ],
      );
    }),
  );
}

// ───────────────────────── نمره ─────────────────────────

Future<bool?> showGradeEditor(BuildContext context, {required int courseId, Map<String, Object?>? grade}) {
  final isNew = grade == null;
  final name = TextEditingController(text: asStr(grade?['name']));
  final score = TextEditingController(text: grade == null ? '' : latinNum(asDouble(grade['score'])));
  final maxS = TextEditingController(text: latinNum(asDouble(grade?['max_score'], 20)));
  final weight = TextEditingController(text: latinNum(asDouble(grade?['weight'], 1)));
  var at = grade == null ? DateTime.now() : fromTs(grade['at_ts']);
  return showLuxSheet<bool>(
    context,
    (ctx) => StatefulBuilder(builder: (ctx, setS) {
      return Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Text(isNew ? 'نمره‌ی جدید' : 'ویرایش نمره', style: LuxText.title),
          const SizedBox(height: 16),
          LuxField(label: 'عنوان', controller: name, hint: 'مثلاً میان‌ترم، کوییز ۲'),
          Row(
            children: [
              Expanded(child: LuxField(label: 'نمره', controller: score, keyboard: TextInputType.number)),
              const SizedBox(width: 12),
              Expanded(child: LuxField(label: 'از', controller: maxS, keyboard: TextInputType.number)),
              const SizedBox(width: 12),
              Expanded(child: LuxField(label: 'وزن', controller: weight, keyboard: TextInputType.number)),
            ],
          ),
          LuxPickField(
            label: 'تاریخ',
            value: jalaliLabel(at),
            icon: Icons.event_rounded,
            onTap: () async {
              final d = await pickJalaliDateTime(ctx, initial: at, withTime: false);
              if (d != null) setS(() => at = d);
            },
          ),
          LuxButton(
            label: 'ذخیره',
            onPressed: () async {
              final sc = parseNum(score.text);
              final mx = parseNum(maxS.text) ?? 20.0;
              if (sc == null) {
                luxNotice(ctx, 'نمره را وارد کن.');
                return;
              }
              if (mx <= 0 || sc < 0 || sc > mx) {
                luxNotice(ctx, 'نمره باید بین صفر و بیشینه باشد.');
                return;
              }
              final values = <String, Object?>{
                'course_id': courseId,
                'name': name.text.trim(),
                'score': sc,
                'max_score': mx,
                'weight': parseNum(weight.text) ?? 1.0,
                'at_ts': at.millisecondsSinceEpoch,
                'kind': 'manual',
              };
              if (isNew) {
                await LuxDb.instance.insert('grades', values);
              } else {
                await LuxDb.instance.update('grades', values, where: 'id = ?', args: [asInt(grade!['id'])]);
              }
              AppBus.bump();
              if (ctx.mounted) Navigator.of(ctx).pop(true);
            },
          ),
          if (!isNew) ...[
            const SizedBox(height: 10),
            LuxButton(
              label: 'حذف نمره',
              filled: false,
              onPressed: () async {
                final ok = await luxConfirm(ctx, 'این نمره حذف شود؟');
                if (!ok) return;
                await LuxDb.instance.delete('grades', where: 'id = ?', args: [asInt(grade!['id'])]);
                AppBus.bump();
                if (ctx.mounted) Navigator.of(ctx).pop(true);
              },
            ),
          ],
        ],
      );
    }),
  );
}
