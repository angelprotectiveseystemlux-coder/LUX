import 'dart:async';

import 'package:flutter/material.dart';

import '../../../core/app_bus.dart';
import '../../../core/jalali_utils.dart';
import '../../../core/palette.dart';
import '../../../core/theme.dart';
import '../../../core/util.dart';
import '../../../data/database.dart';
import '../../../services/focus_timer.dart';
import '../../../services/pdf_bridge.dart';
import '../../widgets/focus_clocks.dart';
import '../../widgets/haptic.dart';
import '../../widgets/lux_button.dart';
import '../../widgets/lux_card.dart';
import '../../widgets/lux_chip.dart';
import '../../widgets/lux_kit.dart';
import '../../widgets/lux_section.dart';
import '../../widgets/lux_switch.dart';
import 'editors.dart';

/// پومودوروی کامل: با بستنِ صفحه/برنامه ادامه می‌دهد، ساعتِ آنالوگ، صدا، اعلانِ زنده و جزیره‌ی شیائومی.
class PomodoroPage extends StatefulWidget {
  /// وقتی از «برنامه‌ی هوشمند» باز می‌شود: درس و مدتِ همان بلوک را می‌گیرد و (با autoStart) فوراً شروع می‌کند.
  final int? courseId;
  final int? minutes;
  final bool autoStart;
  const PomodoroPage({super.key, this.courseId, this.minutes, this.autoStart = false});

  @override
  State<PomodoroPage> createState() => _PomodoroPageState();
}

class _PomodoroPageState extends State<PomodoroPage> with WidgetsBindingObserver {
  final FocusTimer _t = FocusTimer.instance;
  Timer? _ui;
  int _uiMs = 0;
  String _idlePhase = 'focus';
  int? _courseId;
  String _courseName = '';
  int _todayMin = 0;
  int _todayCount = 0;
  int _weekMin = 0;
  bool _qualityOpen = false;
  int _lastPending = 0;

  FocusSettings get _s => _t.settings;
  FocusState get _st => _t.state;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _t.addListener(_onTimer);
    _boot();
  }

  Future<void> _boot() async {
    await _t.init();
    await _t.refresh();
    await _t.drain();
    await _t.loadInfo();
    final cid = int.tryParse(await LuxDb.instance.kvGet('pomo_course') ?? '');
    if (cid != null && cid > 0) {
      _courseId = cid;
      _courseName = await courseNameOf(cid);
    }
    if (_st.active && _st.courseId > 0) {
      _courseId = _st.courseId;
      _courseName = _st.label.isNotEmpty ? _st.label : await courseNameOf(_st.courseId);
    }
    if (widget.courseId != null && !_st.active) {
      _courseId = widget.courseId;
      _courseName = await courseNameOf(widget.courseId);
    }
    await _loadToday();
    _retime();
    _syncAwake();
    if (mounted) setState(() {});
    _checkQuality();
    if (widget.autoStart && !_st.active && mounted) {
      await _t.settings.save();
      await _t.start(phase: 'focus', label: _courseName, courseId: _courseId ?? -1, cycle: _st.cycle, minutes: widget.minutes);
    }
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _t.removeListener(_onTimer);
    _ui?.cancel();
    _t.stopPreview();
    PdfBridge.keepAwake(false);
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) {
      _t.refresh();
      _t.drain();
    }
  }

  void _onTimer() {
    if (!mounted) return;
    setState(() {});
    _retime();
    _syncAwake();
    if (_t.pendingQuality.length != _lastPending) {
      _lastPending = _t.pendingQuality.length;
      _loadToday();
      _checkQuality();
    }
  }

  void _syncAwake() {
    PdfBridge.keepAwake(_s.keepAwake && _st.running);
  }

  /// نرخِ به‌روزرسانی: برای ساعت‌های آنالوگ نرم‌تر.
  void _retime() {
    _ui?.cancel();
    final analog = _s.clock >= 1 && _s.clock <= 3;
    final ms = (_st.running && analog) ? 66 : (_st.running ? 250 : 1000);
    _ui = Timer.periodic(Duration(milliseconds: ms), (_) {
      if (mounted) setState(() => _uiMs = DateTime.now().millisecondsSinceEpoch);
    });
  }

  Future<void> _loadToday() async {
    final db = LuxDb.instance;
    final now = DateTime.now();
    final start = dateOnly(now).millisecondsSinceEpoch;
    final weekStart = dateOnly(now).subtract(Duration(days: (now.weekday + 1) % 7)).millisecondsSinceEpoch;
    final r = await db.rawQuery(
      'SELECT COUNT(*) AS n, COALESCE(SUM(end_ts - start_ts), 0) AS ms FROM study_sessions '
      "WHERE kind = 'pomodoro' AND completed = 1 AND start_ts >= ?",
      [start],
    );
    final w = await db.rawQuery(
      'SELECT COALESCE(SUM(end_ts - start_ts), 0) AS ms FROM study_sessions '
      "WHERE kind = 'pomodoro' AND completed = 1 AND start_ts >= ?",
      [weekStart],
    );
    if (!mounted) return;
    setState(() {
      _todayCount = asInt(r.first['n']);
      _todayMin = (asInt(r.first['ms']) / 60000).round();
      _weekMin = (asInt(w.first['ms']) / 60000).round();
    });
  }

  // ───────── کنترل‌ها ─────────

  int _phaseMinutes(String ph) => ph == 'short' ? _s.shortMin : (ph == 'long' ? _s.longMin : _s.focusMin);

  int get _nowMs => DateTime.now().millisecondsSinceEpoch;

  Future<void> _primary() async {
    Haptic.light();
    if (!_st.active) {
      await _t.settings.save();
      await _t.start(phase: _idlePhase, label: _courseName, courseId: _courseId ?? -1, cycle: _st.cycle);
    } else if (_st.running) {
      await _t.pause();
    } else {
      await _t.resume();
    }
  }

  Future<void> _stopAsk() async {
    final ok = await luxConfirm(context, 'پایان دادن به این جلسه؟', body: 'جلسه‌ی نیمه‌تمام ثبت نمی‌شود. اگر فقط می‌خواهی ردش کنی، «رد کردن» را بزن.', yes: 'پایان');
    if (!ok) return;
    await _t.stop();
    setState(() => _idlePhase = 'focus');
  }

  void _checkQuality() {
    if (!mounted || _qualityOpen || _t.pendingQuality.isEmpty) return;
    final sid = _t.pendingQuality.removeAt(0);
    _lastPending = _t.pendingQuality.length;
    _qualityOpen = true;
    unawaited(_quality(sid).whenComplete(() {
      _qualityOpen = false;
      if (mounted) _checkQuality();
    }));
  }

  Future<void> _quality(int sid) async {
    const labels = <String>['خیلی کم', 'کم', 'معمولی', 'خوب', 'عالی'];
    await showLuxSheet<void>(
      context,
      (ctx) => Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Text('تمرکزت چطور بود؟', style: LuxText.title),
          const SizedBox(height: 6),
          Text('این عدد توی آمارِ مطالعه می‌آید.', style: LuxText.caption),
          const SizedBox(height: 16),
          Wrap(spacing: 8, runSpacing: 8, children: [
            for (var i = 0; i < labels.length; i++)
              LuxChip(
                label: labels[i],
                selected: false,
                onTap: () async {
                  await LuxDb.instance.update('study_sessions', <String, Object?>{'quality': i + 1}, where: 'id = ?', args: [sid]);
                  AppBus.bump();
                  if (ctx.mounted) Navigator.of(ctx).pop();
                },
              ),
          ]),
        ],
      ),
    );
  }

  Future<void> _pickCourse() async {
    final r = await pickCourse(context, selectedId: _courseId, allowNone: true);
    if (r == null) return;
    final n = await courseNameOf(r);
    setState(() {
      _courseId = r < 0 ? null : r;
      _courseName = n;
    });
    await LuxDb.instance.kvSet('pomo_course', r < 0 ? '0' : '$r');
  }

  Future<void> _customMinutes(String which) async {
    final cur = which == 'focus' ? _s.focusMin : (which == 'short' ? _s.shortMin : _s.longMin);
    final c = TextEditingController(text: '$cur');
    await showLuxSheet<void>(
      context,
      (ctx) => Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Text('مدتِ دلخواه (دقیقه)', style: LuxText.title),
          const SizedBox(height: 14),
          LuxField(label: 'دقیقه', controller: c, keyboard: TextInputType.number),
          LuxButton(
            label: 'ثبت',
            onPressed: () async {
              final v = parseNum(c.text)?.round();
              if (v == null || v < 1 || v > 240) {
                luxNotice(ctx, 'عددی بین ۱ تا ۲۴۰ بنویس.');
                return;
              }
              setState(() {
                if (which == 'focus') {
                  _s.focusMin = v;
                } else if (which == 'short') {
                  _s.shortMin = v;
                } else {
                  _s.longMin = v;
                }
              });
              await _t.pushSettings();
              if (ctx.mounted) Navigator.of(ctx).pop();
            },
          ),
        ],
      ),
    );
    c.dispose();
  }

  Future<void> _apply(VoidCallback change) async {
    setState(change);
    await _t.pushSettings();
    _retime();
    _syncAwake();
  }

  // ───────── ساخت صفحه ─────────

  Widget _chips(List<String> names, List<int> values, int selected, void Function(int) on, {bool custom = false, VoidCallback? onCustom}) {
    final isCustom = custom && !values.contains(selected);
    return Wrap(spacing: 8, runSpacing: 8, children: [
      for (var i = 0; i < values.length; i++)
        LuxChip(label: names[i], selected: selected == values[i], onTap: () => on(values[i])),
      if (custom) LuxChip(label: isCustom ? '${faDigits(selected)} (دلخواه)' : 'دلخواه…', selected: isCustom, onTap: onCustom ?? () {}),
    ]);
  }

  Widget _label(String t, {String? sub}) => Padding(
        padding: const EdgeInsets.only(top: 14, bottom: 8),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(t, style: LuxText.label),
          if (sub != null) Text(sub, style: LuxText.caption),
        ]),
      );

  String _phaseName(String ph) => ph == 'short' ? 'استراحت کوتاه' : (ph == 'long' ? 'استراحت بلند' : 'تمرکز');

  @override
  Widget build(BuildContext context) {
    final st = _st;
    final active = st.active;
    final phase = active ? st.phase : _idlePhase;
    final now = _uiMs == 0 ? _nowMs : DateTime.now().millisecondsSinceEpoch;
    final total = active ? st.totalMs : _phaseMinutes(phase) * 60000;
    final left = active ? st.leftAt(now) : total;
    final isBreak = phase != 'focus';
    final width = MediaQuery.of(context).size.width;
    final clockSize = (width - 96).clamp(200.0, 300.0).toDouble();
    final every = _s.longEvery;

    return LuxSubPage(
      title: 'پومودورو',
      subtitle: active ? (st.running ? _phaseName(phase) : '${_phaseName(phase)} · متوقف') : 'آماده',
      children: [
        // انتخابِ فاز (وقتی جلسه‌ای در جریان نیست)
        if (!active) ...[
          Wrap(spacing: 8, runSpacing: 8, children: [
            for (final p in const <String>['focus', 'short', 'long'])
              LuxChip(label: _phaseName(p), selected: _idlePhase == p, onTap: () => setState(() => _idlePhase = p)),
          ]),
          const SizedBox(height: 14),
        ],
        LuxCard(
          radius: 32,
          padding: const EdgeInsets.symmetric(vertical: 26, horizontal: 14),
          child: Column(
            children: [
              Center(
                child: FocusClock(style: _s.clock, leftMs: left, totalMs: total, isBreak: isBreak, size: clockSize),
              ),
              if (_s.clock != 0 && _s.clock != 4) ...[
                const SizedBox(height: 14),
                Directionality(
                  textDirection: TextDirection.ltr,
                  child: Text(
                    '${two((left + 999) ~/ 60000)}:${two(((left + 999) ~/ 1000) % 60)}',
                    style: LuxText.dot(30, color: isBreak ? LuxColors.ok : LuxColors.accent),
                  ),
                ),
              ],
              if (every > 0) ...[
                const SizedBox(height: 14),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    for (var i = 0; i < every; i++)
                      Container(
                        width: 10,
                        height: 10,
                        margin: const EdgeInsets.symmetric(horizontal: 4),
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: i < st.cycle ? LuxColors.accent : LuxColors.cardHi,
                          border: Border.all(color: LuxColors.alpha(LuxColors.accent, 0.5)),
                        ),
                      ),
                  ],
                ),
              ],
              if (_courseName.isNotEmpty && !isBreak) ...[
                const SizedBox(height: 10),
                Text(_courseName, style: LuxText.caption),
              ],
              const SizedBox(height: 20),
              Row(
                children: [
                  Expanded(
                    child: LuxButton(
                      label: !active ? 'شروع' : (st.running ? 'توقف' : 'ادامه'),
                      icon: st.running ? Icons.pause_rounded : Icons.play_arrow_rounded,
                      onPressed: _primary,
                    ),
                  ),
                ],
              ),
              if (active) ...[
                const SizedBox(height: 10),
                Row(
                  children: [
                    Expanded(child: LuxButton(label: '+۵ دقیقه', filled: false, compact: true, onPressed: _t.addFive)),
                    const SizedBox(width: 8),
                    Expanded(child: LuxButton(label: 'رد کردن', filled: false, compact: true, onPressed: _t.skip)),
                    const SizedBox(width: 8),
                    Expanded(child: LuxButton(label: 'پایان', filled: false, compact: true, onPressed: _stopAsk)),
                  ],
                ),
              ],
            ],
          ),
        ),
        const SizedBox(height: 14),
        LuxCard(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('ظاهرِ ساعت', style: LuxText.heading),
              const SizedBox(height: 10),
              Wrap(spacing: 8, runSpacing: 8, children: [
                for (var i = 0; i < kClockNames.length; i++)
                  LuxChip(
                    label: kClockNames[i],
                    selected: _s.clock == i,
                    onTap: () => _apply(() => _s.clock = i),
                  ),
              ]),
            ],
          ),
        ),
        const SizedBox(height: 14),
        LuxCard(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('مدت‌ها', style: LuxText.heading),
              _label('تمرکز (دقیقه)'),
              _chips(
                [for (final m in const [15, 25, 45, 50, 60, 90]) faDigits(m)],
                const [15, 25, 45, 50, 60, 90],
                _s.focusMin,
                (v) => _apply(() => _s.focusMin = v),
                custom: true,
                onCustom: () => _customMinutes('focus'),
              ),
              _label('استراحتِ کوتاه'),
              _chips(
                [for (final m in const [3, 5, 10]) faDigits(m)],
                const [3, 5, 10],
                _s.shortMin,
                (v) => _apply(() => _s.shortMin = v),
                custom: true,
                onCustom: () => _customMinutes('short'),
              ),
              _label('استراحتِ بلند'),
              _chips(
                [for (final m in const [15, 20, 30]) faDigits(m)],
                const [15, 20, 30],
                _s.longMin,
                (v) => _apply(() => _s.longMin = v),
                custom: true,
                onCustom: () => _customMinutes('long'),
              ),
              _label('استراحتِ بلند بعد از چند جلسه؟', sub: 'صفر یعنی هیچ‌وقت'),
              _chips(
                [for (final m in const [0, 2, 3, 4, 5, 6]) faDigits(m)],
                const [0, 2, 3, 4, 5, 6],
                _s.longEvery,
                (v) => _apply(() => _s.longEvery = v),
              ),
              const SizedBox(height: 10),
              LuxPickField(
                label: 'درسِ در حال مطالعه',
                value: _courseName.isEmpty ? 'بدون درس' : _courseName,
                placeholder: _courseName.isEmpty,
                onTap: _pickCourse,
              ),
              LuxRow(
                title: 'شروعِ خودکارِ فازِ بعد',
                subtitle: 'بعد از تمام شدنِ تمرکز یا استراحت، خودش ادامه می‌دهد',
                trailing: LuxSwitch(value: _s.autoNext, onChanged: (v) => _apply(() => _s.autoNext = v)),
              ),
              LuxRow(
                title: 'لرزش در پایانِ هر فاز',
                trailing: LuxSwitch(value: _s.vibrate, onChanged: (v) => _apply(() => _s.vibrate = v)),
              ),
              LuxRow(
                title: 'روشن ماندنِ صفحه هنگامِ تمرکز',
                trailing: LuxSwitch(value: _s.keepAwake, onChanged: (v) => _apply(() => _s.keepAwake = v)),
              ),
            ],
          ),
        ),
        const SizedBox(height: 14),
        LuxCard(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('صدا', style: LuxText.heading),
              _label('صدای پایانِ جلسه', sub: 'لمس کن تا بشنوی'),
              Wrap(spacing: 8, runSpacing: 8, children: [
                for (var i = 0; i < FocusSettings.endSounds.length; i++)
                  LuxChip(
                    label: FocusSettings.endSoundNames[i],
                    selected: _s.endSound == FocusSettings.endSounds[i],
                    onTap: () {
                      _apply(() => _s.endSound = FocusSettings.endSounds[i]);
                      _t.preview(FocusSettings.endSounds[i]);
                    },
                  ),
              ]),
              _label('صدای محیطی هنگامِ تمرکز', sub: 'فقط وقتی تمرکز در جریان است پخش می‌شود؛ با بستن برنامه هم می‌ماند'),
              Wrap(spacing: 8, runSpacing: 8, children: [
                for (var i = 0; i < FocusSettings.ambients.length; i++)
                  LuxChip(
                    label: FocusSettings.ambientNames[i],
                    selected: _s.ambient == FocusSettings.ambients[i],
                    onTap: () {
                      _apply(() => _s.ambient = FocusSettings.ambients[i]);
                      if (FocusSettings.ambients[i].isEmpty) {
                        _t.stopPreview();
                      } else if (!(_st.active && _st.running)) {
                        _t.preview(FocusSettings.ambients[i], ambient: true);
                      }
                    },
                  ),
              ]),
              if (_s.ambient.isNotEmpty) ...[
                _label('بلندیِ صدای محیطی'),
                _chips(
                  [for (final v in const [30, 60, 100]) '${faDigits(v)}٪'],
                  const [30, 60, 100],
                  (_s.ambVol * 100).round(),
                  (v) => _apply(() => _s.ambVol = v / 100.0),
                ),
              ],
            ],
          ),
        ),
        if (_t.info.xiaomi) ...[
          const SizedBox(height: 14),
          LuxCard(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('جزیره‌ی شیائومی (Super Island)', style: LuxText.heading),
                const SizedBox(height: 4),
                Text(
                  _t.info.protocol >= 3
                      ? 'گوشی‌ات از جزیره پشتیبانی می‌کند. تایمر در جزیره‌ی بالای صفحه هم نشان داده می‌شود.'
                      : 'نسخه‌ی سیستمِ این گوشی کامل از جزیره پشتیبانی نمی‌کند؛ تایمر در اعلانِ زنده و نوارِ وضعیت نشان داده می‌شود.',
                  style: LuxText.caption,
                ),
                LuxRow(
                  title: 'نمایش در جزیره',
                  trailing: LuxSwitch(value: _s.island != 0, onChanged: (v) => _apply(() => _s.island = v ? 1 : 0)),
                ),
                if (!_t.info.focusPerm)
                  LuxRow(
                    leading: Icon(Icons.warning_amber_rounded, color: LuxColors.warn),
                    title: 'اجازه‌ی «اعلان‌های کانونی» خاموش است',
                    subtitle: 'برای دیدنِ تایمر در جزیره، در تنظیماتِ اعلانِ LUX گزینه‌ی «کانونی/جزیره» را روشن کن.',
                    onTap: _t.openNotifSettings,
                  )
                else
                  Padding(
                    padding: const EdgeInsets.only(top: 6),
                    child: Text('اجازه‌ی نمایش در جزیره روشن است.', style: LuxText.caption.copyWith(color: LuxColors.ok)),
                  ),
                const SizedBox(height: 4),
                LuxButton(label: 'تنظیماتِ اعلانِ LUX', filled: false, compact: true, onPressed: _t.openNotifSettings),
              ],
            ),
          ),
        ],
        const SizedBox(height: 14),
        LuxSection(title: 'امروز', children: [
          LuxRow(title: 'جلسه‌های کامل', trailing: Text(faDigits(_todayCount), style: LuxText.heading.copyWith(color: LuxColors.accent))),
          LuxRow(title: 'مجموعِ مطالعه', trailing: Text('${faDigits(_todayMin)} دقیقه', style: LuxText.heading.copyWith(color: LuxColors.accent))),
          LuxRow(title: 'این هفته', trailing: Text('${faDigits(_weekMin)} دقیقه', style: LuxText.heading.copyWith(color: LuxColors.accent))),
        ]),
        LuxRow(
          leading: Icon(Icons.battery_saver_rounded, color: LuxColors.silverDim),
          title: 'تایمر با بستنِ برنامه هم ادامه دارد',
          subtitle: 'اگر گوشی (به‌ویژه شیائومی) تایمر را می‌بندد: تنظیماتِ برنامه ← باتری ← «بدون محدودیت».',
          onTap: _t.openAppSettings,
        ),
      ],
    );
  }
}
