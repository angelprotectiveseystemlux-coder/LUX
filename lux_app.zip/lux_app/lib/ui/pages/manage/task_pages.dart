import 'package:flutter/material.dart';
import '../../../core/app_bus.dart';
import '../../../core/jalali_utils.dart';
import '../../../core/palette.dart';
import '../../../core/theme.dart';
import '../../../core/util.dart';
import '../../../data/database.dart';
import '../../../data/reminders.dart';
import '../../widgets/haptic.dart';
import '../../widgets/lux_button.dart';
import '../../widgets/lux_card.dart';
import '../../widgets/lux_chip.dart';
import '../../widgets/lux_kit.dart';
import '../../widgets/lux_section.dart';
import 'editors.dart';

const List<String> kPriorities = <String>['کم', 'متوسط', 'زیاد'];
const List<int> kTaskRemindOptions = <int>[0, 60, 1440];

Color priorityColor(int p) => p >= 3 ? LuxColors.danger : (p == 2 ? LuxColors.warn : LuxColors.silverDim);

/// تیک‌زدن / برداشتنِ تیکِ یک تکلیف
Future<void> toggleTask(Map<String, Object?> t) async {
  final id = asInt(t['id']);
  final done = asStr(t['status']) == 'done';
  Haptic.light();
  await LuxDb.instance.update(
    'tasks',
    <String, Object?>{
      'status': done ? 'open' : 'done',
      'done_at': done ? null : DateTime.now().millisecondsSinceEpoch,
    },
    where: 'id = ?',
    args: [id],
  );
  if (done) {
    await Reminders.syncTask(id);
  } else {
    await Reminders.cancelTask(id);
  }
  AppBus.bump();
}

Future<void> showTaskEditor(BuildContext context, {Map<String, Object?>? task, int? courseId}) {
  final isNew = task == null;
  int? cid = task == null ? courseId : (task['course_id'] == null ? null : asInt(task['course_id']));
  DateTime? due = task == null || task['due_ts'] == null ? null : fromTs(task['due_ts']);
  var priority = asInt(task?['priority'], 2).clamp(1, 3);
  final title = TextEditingController(text: asStr(task?['title']));
  final notes = TextEditingController(text: asStr(task?['notes']));
  final remind = task == null ? <int>[60] : Reminders.parse(task['remind_json']);

  return showLuxSheet<void>(
    context,
    (ctx) => StatefulBuilder(builder: (ctx, setS) {
      return Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Text(isNew ? 'تکلیف جدید' : 'ویرایش تکلیف', style: LuxText.title),
          const SizedBox(height: 16),
          LuxField(label: 'چه کاری؟', controller: title, hint: 'مثلاً حل تمرین‌های فصل ۲'),
          if (courseId == null || !isNew)
            LuxCourseChips(selectedId: cid, allowNone: true, label: 'مربوط به کدام درس؟ (اختیاری)', onChanged: (id) => setS(() => cid = id)),
          LuxDateChips(
            label: 'موعد',
            value: due,
            allowNone: true,
            defaultHour: 18,
            onChanged: (d) => setS(() => due = d),
          ),
          if (due != null)
            LuxPickField(
              label: 'تا چه ساعتی؟',
              value: clockLabel(due!),
              icon: Icons.schedule_rounded,
              onTap: () async {
                final cur = due!;
                final r = await pickTimeOfDayMinutes(ctx, cur.hour * 60 + cur.minute);
                if (r != null) setS(() => due = DateTime(cur.year, cur.month, cur.day, r ~/ 60, r % 60));
              },
            ),
          LuxChoice(label: 'اولویت', options: kPriorities, selected: priority - 1, onChanged: (i) => setS(() => priority = i + 1)),
          LuxMore(children: [
            if (due != null) ...[
              Padding(
                padding: const EdgeInsetsDirectional.only(start: 4, bottom: 8),
                child: Text('یادآور', style: LuxText.caption),
              ),
              Padding(
                padding: const EdgeInsets.only(bottom: 14),
                child: Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: [
                    for (final m in kTaskRemindOptions)
                      LuxChip(
                        label: Reminders.label(m),
                        selected: remind.contains(m),
                        onTap: () => setS(() {
                          if (remind.contains(m)) {
                            remind.remove(m);
                          } else {
                            remind.add(m);
                          }
                        }),
                      ),
                  ],
                ),
              ),
            ],
            LuxField(label: 'یادداشت', controller: notes, maxLines: 2),
          ]),
          LuxButton(
            label: 'ذخیره',
            onPressed: () async {
              final t = title.text.trim();
              if (t.isEmpty) {
                luxNotice(ctx, 'بنویس چه کاری باید انجام شود.');
                return;
              }
              final values = <String, Object?>{
                'title': t,
                'course_id': cid,
                'notes': notes.text.trim(),
                'due_ts': due?.millisecondsSinceEpoch,
                'priority': priority,
                'remind_json': Reminders.encode(due == null ? <int>[] : remind),
              };
              int id;
              if (isNew) {
                values['status'] = 'open';
                values['created_at'] = DateTime.now().millisecondsSinceEpoch;
                id = await LuxDb.instance.insert('tasks', values);
              } else {
                id = asInt(task!['id']);
                await LuxDb.instance.update('tasks', values, where: 'id = ?', args: [id]);
              }
              await Reminders.syncTask(id);
              AppBus.bump();
              if (ctx.mounted) Navigator.of(ctx).pop();
            },
          ),
          if (!isNew) ...[
            const SizedBox(height: 10),
            LuxButton(
              label: 'حذف تکلیف',
              filled: false,
              onPressed: () async {
                final ok = await luxConfirm(ctx, 'این تکلیف حذف شود؟');
                if (!ok) return;
                final tid = asInt(task!['id']);
                await Reminders.cancelTask(tid);
                await LuxDb.instance.delete('tasks', where: 'id = ?', args: [tid]);
                AppBus.bump();
                if (ctx.mounted) Navigator.of(ctx).pop();
              },
            ),
          ],
        ],
      );
    }),
  );
}

/// فهرستِ تکالیف (باز / انجام‌شده) برای تبِ برنامه و صفحه‌ی مستقل
class TasksBody extends StatefulWidget {
  final int? courseId;
  const TasksBody({super.key, this.courseId});

  @override
  State<TasksBody> createState() => _TasksBodyState();
}

class _TasksBodyState extends State<TasksBody> {
  int _tab = 0; // 0 باز، 1 انجام‌شده
  List<Map<String, Object?>> _rows = <Map<String, Object?>>[];
  bool _loaded = false;

  @override
  void initState() {
    super.initState();
    _load();
    AppBus.data.addListener(_load);
  }

  @override
  void dispose() {
    AppBus.data.removeListener(_load);
    super.dispose();
  }

  Future<void> _load() async {
    final args = <Object?>[_tab == 0 ? 'open' : 'done'];
    var where = 't.status = ?';
    if (widget.courseId != null) {
      where += ' AND t.course_id = ?';
      args.add(widget.courseId);
    }
    final r = await LuxDb.instance.rawQuery(
      'SELECT t.*, c.name AS course_name FROM tasks t LEFT JOIN courses c ON c.id = t.course_id '
      'WHERE $where ORDER BY ${_tab == 0 ? 't.due_ts IS NULL, t.due_ts ASC, t.priority DESC' : 't.done_at DESC'}',
      args,
    );
    if (!mounted) return;
    setState(() {
      _rows = r;
      _loaded = true;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Wrap(spacing: 8, runSpacing: 8, children: [
          LuxChip(label: 'باز', selected: _tab == 0, onTap: () {
            setState(() => _tab = 0);
            _load();
          }),
          LuxChip(label: 'انجام‌شده', selected: _tab == 1, onTap: () {
            setState(() => _tab = 1);
            _load();
          }),
        ]),
        const SizedBox(height: 16),
        if (_loaded && _rows.isEmpty)
          LuxCard(
            child: LuxEmpty(
              icon: Icons.checklist_rounded,
              title: _tab == 0 ? 'تکلیفِ بازی نداری' : 'هنوز تکلیفی تمام نشده',
              hint: _tab == 0 ? 'با دکمه‌ی + تکلیف اضافه کن.' : null,
            ),
          )
        else
          LuxSection(title: _tab == 0 ? 'تکالیف باز' : 'انجام‌شده‌ها', children: [
            for (final t in _rows)
              LuxRow(
                leading: GestureDetector(
                  onTap: () => toggleTask(t),
                  child: Icon(
                    asStr(t['status']) == 'done' ? Icons.check_circle_rounded : Icons.radio_button_unchecked_rounded,
                    color: asStr(t['status']) == 'done' ? LuxColors.ok : priorityColor(asInt(t['priority'], 2)),
                    size: 28,
                  ),
                ),
                title: asStr(t['title']),
                subtitle: [
                  if (asStr(t['course_name']).isNotEmpty) asStr(t['course_name']),
                  if (t['due_ts'] != null) '${relativeDay(fromTs(t['due_ts']))} · ${clockLabel(fromTs(t['due_ts']))}',
                ].join(' · '),
                onTap: () => showTaskEditor(context, task: t),
              ),
          ]),
      ],
    );
  }
}

class TasksPage extends StatelessWidget {
  const TasksPage({super.key});

  @override
  Widget build(BuildContext context) {
    return LuxSubPage(
      title: 'تکالیف',
      subtitle: 'موعد، اولویت و یادآور',
      action: LuxAddButton(onTap: () => showTaskEditor(context)),
      children: const [TasksBody()],
    );
  }
}
