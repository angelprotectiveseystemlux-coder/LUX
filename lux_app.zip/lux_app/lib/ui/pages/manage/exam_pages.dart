import 'package:flutter/material.dart';
import '../../../core/app_bus.dart';
import '../../../core/jalali_utils.dart';
import '../../../core/palette.dart';
import '../../../core/theme.dart';
import '../../../core/util.dart';
import '../../../data/database.dart';
import '../../../data/reminders.dart';
import '../../../data/rivalry_repo.dart';
import '../../widgets/lux_button.dart';
import '../../widgets/lux_card.dart';
import '../../widgets/lux_chip.dart';
import '../../widgets/lux_kit.dart';
import '../../widgets/lux_section.dart';
import 'editors.dart';

const List<String> kExamTypes = <String>['میان‌ترم', 'پایان‌ترم', 'کوییز', 'ماهانه', 'شفاهی', 'سایر'];
const List<int> kExamRemindOptions = <int>[10080, 1440, 120, 0];

String examTitle(Map<String, Object?> e) {
  final course = asStr(e['course_name']);
  final t = asStr(e['title']).isNotEmpty ? asStr(e['title']) : asStr(e['type_name']);
  return t.isEmpty ? course : '$course · $t';
}

/// ساخت/ویرایش امتحان: درس، نوع، تاریخ و ساعت کافی است؛ بقیه زیرِ «گزینه‌های بیشتر».
Future<void> showExamEditor(BuildContext context, {Map<String, Object?>? exam, int? courseId}) {
  final isNew = exam == null;
  int? cid = courseId ?? (exam == null ? null : asInt(exam['course_id']));
  var typeIdx = kExamTypes.indexOf(asStr(exam?['type_name'], 'میان‌ترم'));
  if (typeIdx < 0) typeIdx = kExamTypes.length - 1;
  DateTime at;
  if (exam == null) {
    final d = DateTime.now().add(const Duration(days: 7));
    at = DateTime(d.year, d.month, d.day, 8, 0);
  } else {
    at = fromTs(exam['at_ts']);
  }
  var difficulty = asInt(exam?['difficulty'], 3).clamp(1, 5);
  final title = TextEditingController(text: asStr(exam?['title']));
  final place = TextEditingController(text: asStr(exam?['location']));
  final scope = TextEditingController(text: asStr(exam?['scope_note']));
  final weight = TextEditingController(text: latinNum(asDouble(exam?['weight'], 1)));
  final maxS = TextEditingController(text: latinNum(asDouble(exam?['max_score'], 20)));
  final remind = exam == null ? <int>[1440, 120] : Reminders.parse(exam['remind_json']);

  return showLuxSheet<void>(
    context,
    (ctx) => StatefulBuilder(builder: (ctx, setS) {
      return Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Text(isNew ? 'امتحان جدید' : 'ویرایش امتحان', style: LuxText.title),
          const SizedBox(height: 16),
          if (courseId == null) LuxCourseChips(selectedId: cid, onChanged: (id) => setS(() => cid = id)),
          LuxChoice(label: 'نوع امتحان', options: kExamTypes, selected: typeIdx, onChanged: (i) => setS(() => typeIdx = i)),
          LuxDateChips(
            label: 'چه روزی؟',
            value: at,
            defaultHour: 8,
            onChanged: (d) {
              if (d != null) setS(() => at = d);
            },
          ),
          LuxPickField(
            label: 'ساعت شروع',
            value: clockLabel(at),
            icon: Icons.schedule_rounded,
            onTap: () async {
              final r = await pickTimeOfDayMinutes(ctx, at.hour * 60 + at.minute);
              if (r != null) setS(() => at = DateTime(at.year, at.month, at.day, r ~/ 60, r % 60));
            },
          ),
          LuxMore(children: [
            LuxField(label: 'عنوان', controller: title, hint: 'مثلاً فصل ۱ تا ۳'),
            LuxField(label: 'محدوده‌ی امتحان', controller: scope, hint: 'مثلاً درس ۱ تا ۴ و تمرین‌ها', maxLines: 2),
            LuxField(label: 'مکان', controller: place),
            Row(
              children: [
                Expanded(child: LuxField(label: 'وزن (ضریب)', controller: weight, keyboard: TextInputType.number)),
                const SizedBox(width: 12),
                Expanded(child: LuxField(label: 'بیشینه‌ی نمره', controller: maxS, keyboard: TextInputType.number)),
              ],
            ),
            LuxChoice(label: 'سختی', options: kDifficulty, selected: difficulty - 1, onChanged: (i) => setS(() => difficulty = i + 1)),
            Padding(
              padding: const EdgeInsetsDirectional.only(start: 4, bottom: 8),
              child: Text('یادآورها', style: LuxText.caption),
            ),
            Padding(
              padding: const EdgeInsets.only(bottom: 14),
              child: Wrap(
                spacing: 8,
                runSpacing: 8,
                children: [
                  for (final m in kExamRemindOptions)
                    LuxChip(
                      label: Reminders.label(m),
                      selected: remind.contains(m),
                      onTap: () => setS(() {
                        if (remind.contains(m)) {
                          remind.remove(m);
                        } else {
                          remind.add(m);
                        }
                      }),
                    ),
                ],
              ),
            ),
          ]),
          LuxButton(
            label: 'ذخیره',
            onPressed: () async {
              if (cid == null) {
                luxNotice(ctx, 'درس را انتخاب کن.');
                return;
              }
              final values = <String, Object?>{
                'course_id': cid,
                'type_name': kExamTypes[typeIdx],
                'title': title.text.trim(),
                'at_ts': at.millisecondsSinceEpoch,
                'location': place.text.trim(),
                'scope_note': scope.text.trim(),
                'weight': parseNum(weight.text) ?? 1.0,
                'max_score': parseNum(maxS.text) ?? 20.0,
                'difficulty': difficulty,
                'remind_json': Reminders.encode(remind),
              };
              int id;
              if (isNew) {
                values['status'] = 'planned';
                values['created_at'] = DateTime.now().millisecondsSinceEpoch;
                id = await LuxDb.instance.insert('exams', values);
              } else {
                id = asInt(exam!['id']);
                await LuxDb.instance.update('exams', values, where: 'id = ?', args: [id]);
              }
              await Reminders.syncExam(id);
              AppBus.bump();
              if (ctx.mounted) Navigator.of(ctx).pop();
            },
          ),
        ],
      );
    }),
  );
}

/// ثبتِ نمره‌ی امتحان (و ساخت/به‌روزرسانی نمره‌ی درس).
/// اگر «رقابت» روشن باشد، زیرِ نمره‌ی خودت نمره‌ی هر رقیب هم (اختیاری) نوشته می‌شود.
Future<void> showExamResult(BuildContext context, Map<String, Object?> exam) {
  final maxScore = asDouble(exam['max_score'], 20);
  final ctl = TextEditingController(text: exam['score'] == null ? '' : latinNum(asDouble(exam['score'])));
  final examId = asInt(exam['id']);
  var loaded = false;
  var rivals = <Map<String, Object?>>[];
  final rctl = <int, TextEditingController>{};

  Future<void> loadRivals(void Function() refresh) async {
    if (await RivalryRepo.enabled()) {
      rivals = await RivalryRepo.rivals();
      final sc = await RivalryRepo.scoresForExam(examId);
      for (final r in rivals) {
        final id = asInt(r['id']);
        final v = sc[id];
        rctl[id] = TextEditingController(text: v == null ? '' : latinNum(v));
      }
    }
    refresh();
  }

  return showLuxSheet<void>(
    context,
    (ctx) => StatefulBuilder(builder: (ctx, setS) {
      if (!loaded) {
        loaded = true;
        loadRivals(() {
          if (ctx.mounted) setS(() {});
        });
      }
      return Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Text('نمره‌ی امتحان', style: LuxText.title),
          const SizedBox(height: 6),
          Text(examTitle(exam), style: LuxText.caption),
          const SizedBox(height: 16),
          LuxField(label: 'نمره (از ${fmtNum(maxScore)})', controller: ctl, keyboard: TextInputType.number),
          if (rivals.isNotEmpty) ...[
            const SizedBox(height: 4),
            Text('نمره‌ی رقبا (اختیاری)', style: LuxText.label),
            const SizedBox(height: 4),
            Text('اگر نمره‌ی کسی را نمی‌دانی، خالی بگذار.', style: LuxText.caption),
            const SizedBox(height: 12),
            for (final r in rivals)
              LuxField(
                label: asStr(r['name']),
                controller: rctl[asInt(r['id'])]!,
                keyboard: TextInputType.number,
                hint: 'از ${fmtNum(maxScore)}',
              ),
          ],
          LuxButton(
            label: 'ذخیره',
            onPressed: () async {
              final sc = parseNum(ctl.text);
              if (sc == null || sc < 0 || sc > maxScore) {
                luxNotice(ctx, 'نمره باید بین صفر و ${fmtNum(maxScore)} باشد.');
                return;
              }
              // نمره‌ی رقبا: خالی = ثبت نشده؛ پیش از هر نوشتنی بررسی می‌شود.
              final rivalScores = <int, double?>{};
              for (final r in rivals) {
                final id = asInt(r['id']);
                final text = rctl[id]?.text.trim() ?? '';
                if (text.isEmpty) {
                  rivalScores[id] = null;
                  continue;
                }
                final v = parseNum(text);
                if (v == null || v < 0 || v > maxScore) {
                  luxNotice(ctx, 'نمره‌ی ${asStr(r['name'])} باید بین صفر و ${fmtNum(maxScore)} باشد.');
                  return;
                }
                rivalScores[id] = v;
              }
              final id = examId;
              final db = LuxDb.instance;
              await db.update('exams', <String, Object?>{'status': 'done', 'score': sc}, where: 'id = ?', args: [id]);
              final gvals = <String, Object?>{
                'course_id': asInt(exam['course_id']),
                'exam_id': id,
                'name': asStr(exam['title']).isNotEmpty ? asStr(exam['title']) : asStr(exam['type_name'], 'امتحان'),
                'score': sc,
                'max_score': maxScore,
                'weight': asDouble(exam['weight'], 1),
                'at_ts': asInt(exam['at_ts']),
                'kind': 'exam',
              };
              final existing = await db.query('grades', where: 'exam_id = ?', args: [id], limit: 1);
              if (existing.isEmpty) {
                await db.insert('grades', gvals);
              } else {
                await db.update('grades', gvals, where: 'exam_id = ?', args: [id]);
              }
              if (rivalScores.isNotEmpty) await RivalryRepo.saveExamScores(id, rivalScores);
              await Reminders.cancelExam(id);
              AppBus.bump();
              if (ctx.mounted) Navigator.of(ctx).pop();
            },
          ),
        ],
      );
    }),
  );
}

Widget _actionRow(IconData icon, String label, VoidCallback onTap, {Color? color}) {
  return GestureDetector(
    behavior: HitTestBehavior.opaque,
    onTap: onTap,
    child: Padding(
      padding: const EdgeInsets.symmetric(vertical: 14),
      child: Row(
        children: [
          Icon(icon, color: color ?? LuxColors.silver),
          const SizedBox(width: 14),
          Text(label, style: LuxText.heading.copyWith(color: color ?? LuxColors.text)),
        ],
      ),
    ),
  );
}

/// کارهایی که روی یک امتحان می‌شود کرد: ثبت نمره، ویرایش، لغو، حذف
Future<void> showExamActions(BuildContext context, Map<String, Object?> e) {
  final id = asInt(e['id']);
  final planned = asStr(e['status']) == 'planned';
  return showLuxSheet<void>(
    context,
    (ctx) => Column(
      mainAxisSize: MainAxisSize.min,
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Text(examTitle(e), style: LuxText.title),
        const SizedBox(height: 4),
        Text('${jalaliLabelWithDay(fromTs(e['at_ts']))} · ساعت ${clockLabel(fromTs(e['at_ts']))}', style: LuxText.caption),
        if (asStr(e['scope_note']).isNotEmpty) ...[
          const SizedBox(height: 8),
          Text('محدوده: ${asStr(e['scope_note'])}', style: LuxText.body),
        ],
        const SizedBox(height: 8),
        _actionRow(Icons.grade_rounded, planned ? 'ثبت نمره (امتحان داده شد)' : 'ویرایش نمره', () {
          Navigator.of(ctx).pop();
          showExamResult(context, e);
        }),
        _actionRow(Icons.edit_rounded, 'ویرایش / تغییر تاریخ', () {
          Navigator.of(ctx).pop();
          showExamEditor(context, exam: e);
        }),
        if (planned)
          _actionRow(Icons.event_busy_rounded, 'لغو امتحان', () async {
            Navigator.of(ctx).pop();
            await LuxDb.instance.update('exams', <String, Object?>{'status': 'canceled'}, where: 'id = ?', args: [id]);
            await Reminders.cancelExam(id);
            AppBus.bump();
          })
        else
          _actionRow(Icons.restore_rounded, 'برگرداندن به پیش‌رو', () async {
            Navigator.of(ctx).pop();
            await LuxDb.instance.update('exams', <String, Object?>{'status': 'planned'}, where: 'id = ?', args: [id]);
            await Reminders.syncExam(id);
            AppBus.bump();
          }),
        _actionRow(Icons.delete_outline_rounded, 'حذف امتحان', () async {
          final ok = await luxConfirm(ctx, 'این امتحان حذف شود؟');
          if (!ok) return;
          await Reminders.cancelExam(id);
          await LuxDb.instance.delete('exams', where: 'id = ?', args: [id]);
          AppBus.bump();
          if (ctx.mounted) Navigator.of(ctx).pop();
        }, color: LuxColors.danger),
      ],
    ),
  );
}

/// فهرستِ امتحان‌ها (پیش‌رو / انجام‌شده / لغوشده) که هم در تبِ برنامه و هم در صفحه‌ی مستقل استفاده می‌شود.
class ExamsBody extends StatefulWidget {
  final int? courseId;
  const ExamsBody({super.key, this.courseId});

  @override
  State<ExamsBody> createState() => _ExamsBodyState();
}

class _ExamsBodyState extends State<ExamsBody> {
  int _tab = 0; // 0 پیش‌رو، 1 انجام‌شده، 2 لغوشده
  List<Map<String, Object?>> _rows = <Map<String, Object?>>[];
  bool _loaded = false;

  static const List<String> _status = <String>['planned', 'done', 'canceled'];

  @override
  void initState() {
    super.initState();
    _load();
    AppBus.data.addListener(_load);
  }

  @override
  void dispose() {
    AppBus.data.removeListener(_load);
    super.dispose();
  }

  Future<void> _load() async {
    final args = <Object?>[_status[_tab]];
    var where = 'e.status = ?';
    if (widget.courseId != null) {
      where += ' AND e.course_id = ?';
      args.add(widget.courseId);
    }
    final r = await LuxDb.instance.rawQuery(
      'SELECT e.*, c.name AS course_name, c.color AS course_color FROM exams e '
      'JOIN courses c ON c.id = e.course_id WHERE $where ORDER BY e.at_ts ${_tab == 0 ? 'ASC' : 'DESC'}',
      args,
    );
    if (!mounted) return;
    setState(() {
      _rows = r;
      _loaded = true;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Wrap(spacing: 8, runSpacing: 8, children: [
          for (var i = 0; i < 3; i++)
            LuxChip(
              label: const ['پیش‌رو', 'انجام‌شده', 'لغوشده'][i],
              selected: _tab == i,
              onTap: () {
                setState(() => _tab = i);
                _load();
              },
            ),
        ]),
        const SizedBox(height: 16),
        if (_loaded && _rows.isEmpty)
          LuxCard(
            child: LuxEmpty(
              icon: Icons.event_note_rounded,
              title: _tab == 0 ? 'امتحانِ پیش‌رویی نداری' : 'موردی نیست',
              hint: _tab == 0 ? 'با دکمه‌ی + امتحان اضافه کن؛ شمارش معکوسش در صفحه‌ی «امروز» می‌آید.' : null,
            ),
          )
        else
          LuxSection(title: const ['امتحان‌های پیش‌رو', 'امتحان‌های انجام‌شده', 'امتحان‌های لغوشده'][_tab], children: [
            for (final e in _rows)
              LuxRow(
                leading: LuxDot(color: courseColor(e['course_color']), size: 14),
                title: examTitle(e),
                subtitle: [
                  jalaliLabelWithDay(fromTs(e['at_ts'])),
                  clockLabel(fromTs(e['at_ts'])),
                  if (asStr(e['location']).isNotEmpty) asStr(e['location']),
                ].join(' · '),
                trailing: _tab == 1
                    ? Text(
                        e['score'] == null ? '—' : fmtNum(asDouble(e['score']), dec: 2),
                        style: LuxText.heading.copyWith(color: LuxColors.accent),
                      )
                    : (_tab == 0
                        ? Text(relativeDay(fromTs(e['at_ts'])), style: LuxText.caption.copyWith(color: LuxColors.accent))
                        : null),
                onTap: () => showExamActions(context, e),
              ),
          ]),
      ],
    );
  }
}

class ExamsListPage extends StatelessWidget {
  const ExamsListPage({super.key});

  @override
  Widget build(BuildContext context) {
    return LuxSubPage(
      title: 'امتحان‌ها',
      subtitle: 'تاریخ، محدوده، یادآور و نمره',
      action: LuxAddButton(onTap: () => showExamEditor(context)),
      children: const [ExamsBody()],
    );
  }
}
