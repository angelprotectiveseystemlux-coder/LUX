import 'package:flutter/material.dart';
import '../../../core/app_bus.dart';
import '../../../core/jalali_utils.dart';
import '../../../core/palette.dart';
import '../../../core/theme.dart';
import '../../../core/util.dart';
import '../../../data/database.dart';
import '../../../data/reminders.dart';
import '../../widgets/lux_button.dart';
import '../../widgets/lux_card.dart';
import '../../widgets/lux_chip.dart';
import '../../widgets/lux_kit.dart';
import '../../widgets/lux_section.dart';
import 'editors.dart';

const List<String> kExamTypes = <String>['میان‌ترم', 'پایان‌ترم', 'کوییز', 'ماهانه', 'شفاهی', 'سایر'];
const List<int> kExamRemindOptions = <int>[10080, 1440, 120, 0];

String examTitle(Map<String, Object?> e) {
  final course = asStr(e['course_name']);
  final t = asStr(e['title']).isNotEmpty ? asStr(e['title']) : asStr(e['type_name']);
  return t.isEmpty ? course : '$course · $t';
}

/// ساخت/ویرایش امتحان
Future<void> showExamEditor(BuildContext context, {Map<String, Object?>? exam}) {
  final isNew = exam == null;
  int? cid = exam == null ? null : asInt(exam['course_id']);
  var cname = '';
  var loaded = false;
  var typeIdx = kExamTypes.indexOf(asStr(exam?['type_name'], 'میان‌ترم'));
  if (typeIdx < 0) typeIdx = kExamTypes.length - 1;
  var at = exam == null ? DateTime.now().add(const Duration(days: 7)) : fromTs(exam['at_ts']);
  if (exam == null) at = DateTime(at.year, at.month, at.day, 8, 0);
  var difficulty = asInt(exam?['difficulty'], 3).clamp(1, 5);
  final title = TextEditingController(text: asStr(exam?['title']));
  final place = TextEditingController(text: asStr(exam?['location']));
  final scope = TextEditingController(text: asStr(exam?['scope_note']));
  final weight = TextEditingController(text: latinNum(asDouble(exam?['weight'], 1)));
  final maxS = TextEditingController(text: latinNum(asDouble(exam?['max_score'], 20)));
  final remind = exam == null ? <int>[1440, 120] : Reminders.parse(exam['remind_json']);

  return showLuxSheet<void>(
    context,
    (ctx) => StatefulBuilder(builder: (ctx, setS) {
      if (!loaded) {
        loaded = true;
        courseNameOf(cid).then((n) {
          if (ctx.mounted) setS(() => cname = n);
        });
      }
      return Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Text(isNew ? 'امتحان جدید' : 'ویرایش امتحان', style: LuxText.title),
          const SizedBox(height: 16),
          LuxPickField(
            label: 'درس',
            value: cname.isEmpty ? 'انتخاب کن' : cname,
            placeholder: cname.isEmpty,
            onTap: () async {
              final r = await pickCourse(ctx, selectedId: cid);
              if (r == null || r < 0) return;
              final n = await courseNameOf(r);
              setS(() {
                cid = r;
                cname = n;
              });
            },
          ),
          LuxChoice(label: 'نوع', options: kExamTypes, selected: typeIdx, onChanged: (i) => setS(() => typeIdx = i)),
          LuxField(label: 'عنوان (اختیاری)', controller: title, hint: 'مثلاً فصل ۱ تا ۳'),
          LuxPickField(
            label: 'تاریخ و ساعت',
            value: '${jalaliLabelWithDay(at)} · ساعت ${clockLabel(at)}',
            icon: Icons.event_rounded,
            onTap: () async {
              final d = await pickJalaliDateTime(ctx, initial: at);
              if (d != null) setS(() => at = d);
            },
          ),
          LuxField(label: 'مکان', controller: place, hint: 'اختیاری'),
          LuxField(label: 'محدوده‌ی امتحان', controller: scope, hint: 'مثلاً درس ۱ تا ۴ و تمرین‌ها', maxLines: 2),
          Row(
            children: [
              Expanded(child: LuxField(label: 'وزن (ضریب)', controller: weight, keyboard: TextInputType.number)),
              const SizedBox(width: 12),
              Expanded(child: LuxField(label: 'بیشینه‌ی نمره', controller: maxS, keyboard: TextInputType.number)),
            ],
          ),
          LuxChoice(label: 'سختی', options: kDifficulty, selected: difficulty - 1, onChanged: (i) => setS(() => difficulty = i + 1)),
          Padding(
            padding: const EdgeInsetsDirectional.only(start: 4, bottom: 8),
            child: Text('یادآورها', style: LuxText.caption),
          ),
          Padding(
            padding: const EdgeInsets.only(bottom: 18),
            child: Wrap(
              spacing: 8,
              runSpacing: 8,
              children: [
                for (final m in kExamRemindOptions)
                  LuxChip(
                    label: Reminders.label(m),
                    selected: remind.contains(m),
                    onTap: () => setS(() {
                      if (remind.contains(m)) {
                        remind.remove(m);
                      } else {
                        remind.add(m);
                      }
                    }),
                  ),
              ],
            ),
          ),
          LuxButton(
            label: 'ذخیره',
            onPressed: () async {
              if (cid == null) {
                luxNotice(ctx, 'درس را انتخاب کن.');
                return;
              }
              final values = <String, Object?>{
                'course_id': cid,
                'type_name': kExamTypes[typeIdx],
                'title': title.text.trim(),
                'at_ts': at.millisecondsSinceEpoch,
                'location': place.text.trim(),
                'scope_note': scope.text.trim(),
                'weight': parseNum(weight.text) ?? 1.0,
                'max_score': parseNum(maxS.text) ?? 20.0,
                'difficulty': difficulty,
                'remind_json': Reminders.encode(remind),
              };
              int id;
              if (isNew) {
                values['status'] = 'planned';
                values['created_at'] = DateTime.now().millisecondsSinceEpoch;
                id = await LuxDb.instance.insert('exams', values);
              } else {
                id = asInt(exam!['id']);
                await LuxDb.instance.update('exams', values, where: 'id = ?', args: [id]);
              }
              await Reminders.syncExam(id);
              AppBus.bump();
              if (ctx.mounted) Navigator.of(ctx).pop();
            },
          ),
        ],
      );
    }),
  );
}

/// ثبتِ نمره‌ی امتحان (و ساخت/به‌روزرسانی نمره‌ی درس)
Future<void> showExamResult(BuildContext context, Map<String, Object?> exam) {
  final maxScore = asDouble(exam['max_score'], 20);
  final ctl = TextEditingController(text: exam['score'] == null ? '' : latinNum(asDouble(exam['score'])));
  return showLuxSheet<void>(
    context,
    (ctx) => Column(
      mainAxisSize: MainAxisSize.min,
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Text('نمره‌ی امتحان', style: LuxText.title),
        const SizedBox(height: 6),
        Text(examTitle(exam), style: LuxText.caption),
        const SizedBox(height: 16),
        LuxField(label: 'نمره (از ${fmtNum(maxScore)})', controller: ctl, keyboard: TextInputType.number),
        LuxButton(
          label: 'ذخیره',
          onPressed: () async {
            final sc = parseNum(ctl.text);
            if (sc == null || sc < 0 || sc > maxScore) {
              luxNotice(ctx, 'نمره باید بین صفر و ${fmtNum(maxScore)} باشد.');
              return;
            }
            final id = asInt(exam['id']);
            final db = LuxDb.instance;
            await db.update('exams', <String, Object?>{'status': 'done', 'score': sc}, where: 'id = ?', args: [id]);
            final gvals = <String, Object?>{
              'course_id': asInt(exam['course_id']),
              'exam_id': id,
              'name': asStr(exam['title']).isNotEmpty ? asStr(exam['title']) : asStr(exam['type_name'], 'امتحان'),
              'score': sc,
              'max_score': maxScore,
              'weight': asDouble(exam['weight'], 1),
              'at_ts': asInt(exam['at_ts']),
              'kind': 'exam',
            };
            final existing = await db.query('grades', where: 'exam_id = ?', args: [id], limit: 1);
            if (existing.isEmpty) {
              await db.insert('grades', gvals);
            } else {
              await db.update('grades', gvals, where: 'exam_id = ?', args: [id]);
            }
            await Reminders.cancelExam(id);
            AppBus.bump();
            if (ctx.mounted) Navigator.of(ctx).pop();
          },
        ),
      ],
    ),
  );
}

class ExamsListPage extends StatefulWidget {
  const ExamsListPage({super.key});

  @override
  State<ExamsListPage> createState() => _ExamsListPageState();
}

class _ExamsListPageState extends State<ExamsListPage> {
  int _tab = 0; // 0 پیش‌رو، 1 انجام‌شده، 2 لغوشده
  List<Map<String, Object?>> _rows = <Map<String, Object?>>[];
  bool _loaded = false;

  static const List<String> _status = <String>['planned', 'done', 'canceled'];

  @override
  void initState() {
    super.initState();
    _load();
    AppBus.data.addListener(_load);
  }

  @override
  void dispose() {
    AppBus.data.removeListener(_load);
    super.dispose();
  }

  Future<void> _load() async {
    final r = await LuxDb.instance.rawQuery(
      'SELECT e.*, c.name AS course_name, c.color AS course_color FROM exams e '
      'JOIN courses c ON c.id = e.course_id WHERE e.status = ? ORDER BY e.at_ts ${_tab == 0 ? 'ASC' : 'DESC'}',
      [_status[_tab]],
    );
    if (!mounted) return;
    setState(() {
      _rows = r;
      _loaded = true;
    });
  }

  Widget _action(BuildContext ctx, IconData icon, String label, VoidCallback onTap, {Color? color}) {
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTap: onTap,
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 14),
        child: Row(
          children: [
            Icon(icon, color: color ?? LuxColors.silver),
            const SizedBox(width: 14),
            Text(label, style: LuxText.heading.copyWith(color: color ?? LuxColors.text)),
          ],
        ),
      ),
    );
  }

  Future<void> _openActions(Map<String, Object?> e) {
    final id = asInt(e['id']);
    final planned = asStr(e['status']) == 'planned';
    return showLuxSheet<void>(
      context,
      (ctx) => Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Text(examTitle(e), style: LuxText.title),
          const SizedBox(height: 4),
          Text('${jalaliLabelWithDay(fromTs(e['at_ts']))} · ساعت ${clockLabel(fromTs(e['at_ts']))}', style: LuxText.caption),
          if (asStr(e['scope_note']).isNotEmpty) ...[
            const SizedBox(height: 8),
            Text('محدوده: ${asStr(e['scope_note'])}', style: LuxText.body),
          ],
          const SizedBox(height: 8),
          _action(ctx, Icons.grade_rounded, planned ? 'ثبت نمره (امتحان داده شد)' : 'ویرایش نمره', () {
            Navigator.of(ctx).pop();
            showExamResult(context, e);
          }),
          _action(ctx, Icons.edit_rounded, 'ویرایش / تغییر تاریخ', () {
            Navigator.of(ctx).pop();
            showExamEditor(context, exam: e);
          }),
          if (planned)
            _action(ctx, Icons.event_busy_rounded, 'لغو امتحان', () async {
              Navigator.of(ctx).pop();
              await LuxDb.instance.update('exams', <String, Object?>{'status': 'canceled'}, where: 'id = ?', args: [id]);
              await Reminders.cancelExam(id);
              AppBus.bump();
            })
          else
            _action(ctx, Icons.restore_rounded, 'برگرداندن به پیش‌رو', () async {
              Navigator.of(ctx).pop();
              await LuxDb.instance.update('exams', <String, Object?>{'status': 'planned'}, where: 'id = ?', args: [id]);
              await Reminders.syncExam(id);
              AppBus.bump();
            }),
          _action(ctx, Icons.delete_outline_rounded, 'حذف امتحان', () async {
            final ok = await luxConfirm(ctx, 'این امتحان حذف شود؟');
            if (!ok) return;
            await Reminders.cancelExam(id);
            await LuxDb.instance.delete('exams', where: 'id = ?', args: [id]);
            AppBus.bump();
            if (ctx.mounted) Navigator.of(ctx).pop();
          }, color: LuxColors.danger),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return LuxSubPage(
      title: 'امتحان‌ها',
      subtitle: 'تاریخ، محدوده، یادآور و نمره',
      action: LuxAddButton(onTap: () => showExamEditor(context)),
      children: [
        Wrap(spacing: 8, runSpacing: 8, children: [
          for (var i = 0; i < 3; i++)
            LuxChip(
              label: const ['پیش‌رو', 'انجام‌شده', 'لغوشده'][i],
              selected: _tab == i,
              onTap: () {
                setState(() => _tab = i);
                _load();
              },
            ),
        ]),
        const SizedBox(height: 18),
        if (_loaded && _rows.isEmpty)
          LuxCard(
            child: LuxEmpty(
              icon: Icons.event_note_rounded,
              title: _tab == 0 ? 'امتحانِ پیش‌رویی نداری' : 'موردی نیست',
              hint: _tab == 0 ? 'با دکمه‌ی + امتحان اضافه کن؛ شمارش معکوسش در صفحه‌ی «امروز» می‌آید.' : null,
            ),
          )
        else
          LuxSection(title: const ['امتحان‌های پیش‌رو', 'امتحان‌های انجام‌شده', 'امتحان‌های لغوشده'][_tab], children: [
            for (final e in _rows)
              LuxRow(
                leading: LuxDot(color: courseColor(e['course_color']), size: 14),
                title: examTitle(e),
                subtitle: [
                  jalaliLabelWithDay(fromTs(e['at_ts'])),
                  clockLabel(fromTs(e['at_ts'])),
                  if (asStr(e['location']).isNotEmpty) asStr(e['location']),
                ].join(' · '),
                trailing: _tab == 1
                    ? Text(
                        e['score'] == null ? '—' : fmtNum(asDouble(e['score']), dec: 2),
                        style: LuxText.heading.copyWith(color: LuxColors.accent),
                      )
                    : (_tab == 0
                        ? Text(relativeDay(fromTs(e['at_ts'])), style: LuxText.caption.copyWith(color: LuxColors.accent))
                        : null),
                onTap: () => _openActions(e),
              ),
          ]),
      ],
    );
  }
}
