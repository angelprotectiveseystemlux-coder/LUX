import 'dart:io';

import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';

import '../../../core/app_bus.dart';
import '../../../core/jalali_utils.dart';
import '../../../core/palette.dart';
import '../../../core/theme.dart';
import '../../../core/util.dart';
import '../../../data/review_repo.dart';
import '../../widgets/haptic.dart';
import '../../widgets/lux_button.dart';
import '../../widgets/lux_card.dart';
import '../../widgets/lux_chip.dart';
import '../../widgets/lux_kit.dart';
import '../../widgets/lux_section.dart';
import 'editors.dart';

String _dueLabel(Map<String, Object?> m) {
  if (asStr(m['status']) == 'mastered') return 'مسلط شدی ✅';
  if (m['due_ts'] == null) return 'مرور: امروز';
  final d = daysBetween(dateOnly(DateTime.now()), dateOnly(fromTs(m['due_ts'])));
  if (d <= 0) return 'مرور: امروز';
  if (d == 1) return 'مرور: فردا';
  return 'مرور: ${faDigits(d)} روز دیگر';
}

// ───────────────────────── دفترچه‌ی اشتباهات ─────────────────────────

class MistakesPage extends StatefulWidget {
  const MistakesPage({super.key});

  @override
  State<MistakesPage> createState() => _MistakesPageState();
}

class _MistakesPageState extends State<MistakesPage> {
  List<Map<String, Object?>> _all = <Map<String, Object?>>[];
  int _dueCount = 0;
  int _filter = 0; // ۰ همه، ۱ باز، ۲ مسلط‌شده
  String? _cause;
  int? _courseId;
  bool _loaded = false;

  @override
  void initState() {
    super.initState();
    _load();
    AppBus.data.addListener(_load);
  }

  @override
  void dispose() {
    AppBus.data.removeListener(_load);
    super.dispose();
  }

  Future<void> _load() async {
    final all = await ReviewRepo.mistakes();
    final due = await ReviewRepo.dueCount();
    if (!mounted) return;
    setState(() {
      _all = all;
      _dueCount = due;
      _loaded = true;
    });
  }

  @override
  Widget build(BuildContext context) {
    final courses = <int, String>{};
    for (final m in _all) {
      if (m['course_id'] != null) courses[asInt(m['course_id'])] = asStr(m['course']);
    }
    final shown = [
      for (final m in _all)
        if ((_filter == 0 || (_filter == 1 && asStr(m['status']) == 'open') || (_filter == 2 && asStr(m['status']) == 'mastered')) &&
            (_cause == null || asStr(m['cause']) == _cause) &&
            (_courseId == null || (m['course_id'] != null && asInt(m['course_id']) == _courseId)))
          m,
    ];
    final open = _all.where((m) => asStr(m['status']) == 'open').length;

    return LuxSubPage(
      title: 'دفترچه‌ی اشتباهات',
      subtitle: _all.isEmpty ? 'اشتباه‌هات رو جمع کن تا دیگه تکرار نشن' : '${faDigits(open)} اشتباهِ باز از ${faDigits(_all.length)}',
      action: LuxAddButton(onTap: () => showMistakeEditor(context)),
      children: [
        LuxCard(
          radius: 24,
          child: Row(
            children: [
              Container(
                width: 52,
                height: 52,
                decoration: BoxDecoration(color: LuxColors.alpha(LuxColors.accent, 0.14), shape: BoxShape.circle),
                child: Icon(Icons.replay_circle_filled_rounded, color: LuxColors.accent, size: 28),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(_dueCount == 0 ? 'مرورِ امروز تمومه 🎉' : '${faDigits(_dueCount)} مورد برای مرور امروز', style: LuxText.heading),
                    Text('اشتباه‌ها و فصل‌های تمام‌شده، با مرورِ فاصله‌دار', style: LuxText.caption),
                  ],
                ),
              ),
            ],
          ),
        ),
        if (_dueCount > 0) ...[
          const SizedBox(height: 12),
          LuxButton(
            label: 'شروع مرور',
            icon: Icons.play_arrow_rounded,
            onPressed: () => pushPage<void>(context, const ReviewPage()),
          ),
        ],
        const SizedBox(height: 16),
        Wrap(spacing: 8, runSpacing: 8, children: [
          LuxChip(label: 'همه', selected: _filter == 0, onTap: () => setState(() => _filter = 0)),
          LuxChip(label: 'باز', selected: _filter == 1, onTap: () => setState(() => _filter = 1)),
          LuxChip(label: 'مسلط شدم', selected: _filter == 2, onTap: () => setState(() => _filter = 2)),
        ]),
        if (courses.length > 1) ...[
          const SizedBox(height: 10),
          Wrap(spacing: 8, runSpacing: 8, children: [
            for (final e in courses.entries)
              LuxChip(label: e.value, selected: _courseId == e.key, onTap: () => setState(() => _courseId = _courseId == e.key ? null : e.key)),
          ]),
        ],
        const SizedBox(height: 10),
        Wrap(spacing: 8, runSpacing: 8, children: [
          for (final c in ReviewRepo.causes)
            LuxChip(label: c, selected: _cause == c, onTap: () => setState(() => _cause = _cause == c ? null : c)),
        ]),
        const SizedBox(height: 16),
        if (_loaded && _all.isEmpty)
          const LuxCard(
            child: LuxEmpty(
              icon: Icons.menu_book_rounded,
              title: 'هنوز اشتباهی ننوشتی',
              hint: 'هر سؤالی که غلط زدی یا دشوار بود رو با «+» بنویس. لوکس در زمان‌های درست ازت می‌پرسه تا یادت بمونه.',
            ),
          )
        else if (_loaded && shown.isEmpty)
          const LuxCard(child: LuxEmpty(icon: Icons.filter_alt_off_rounded, title: 'با این فیلتر موردی نیست'))
        else
          LuxSection(
            title: 'اشتباه‌ها',
            children: [
              for (final m in shown)
                LuxRow(
                  leading: Icon(
                    asStr(m['status']) == 'mastered' ? Icons.verified_rounded : Icons.error_outline_rounded,
                    color: asStr(m['status']) == 'mastered' ? LuxColors.ok : LuxColors.warn,
                  ),
                  title: asStr(m['title']),
                  subtitle: [
                    if (asStr(m['course']).isNotEmpty) asStr(m['course']),
                    if (asStr(m['cause']).isNotEmpty) asStr(m['cause']),
                    _dueLabel(m),
                  ].join(' · '),
                  onTap: () => showMistakeEditor(context, mistake: m),
                ),
            ],
          ),
      ],
    );
  }
}

// ───────────────────────── ثبت و ویرایشِ اشتباه ─────────────────────────

Future<void> showMistakeEditor(BuildContext context, {Map<String, Object?>? mistake, int? courseId, int? bookId, int? page}) {
  final isNew = mistake == null;
  int? cid = isNew ? courseId : (mistake['course_id'] == null ? null : asInt(mistake['course_id']));
  final bid = isNew ? bookId : (mistake['book_id'] == null ? null : asInt(mistake['book_id']));
  var cause = isNew ? '' : asStr(mistake['cause']);
  var status = isNew ? 'open' : asStr(mistake['status'], 'open');
  String? photo = isNew || asStr(mistake['photo_path']).isEmpty ? null : asStr(mistake['photo_path']);
  final title = TextEditingController(text: isNew ? '' : asStr(mistake['title']));
  final answer = TextEditingController(text: isNew ? '' : asStr(mistake['answer']));
  final pageCtl = TextEditingController(text: isNew ? (page?.toString() ?? '') : (mistake['page'] == null ? '' : asInt(mistake['page']).toString()));

  return showLuxSheet<void>(
    context,
    (ctx) => StatefulBuilder(builder: (ctx, setS) {
      return Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Text(isNew ? 'اشتباهِ جدید' : 'ویرایش اشتباه', style: LuxText.title),
          const SizedBox(height: 16),
          LuxCourseChips(label: 'درس', selectedId: cid, allowNone: true, onChanged: (id) => setS(() => cid = id)),
          LuxField(label: 'سؤال یا مبحث', controller: title, hint: 'مثلاً مشتق تابع مرکب', maxLines: 2),
          LuxField(label: 'پاسخ درست / توضیح', controller: answer, hint: 'چرا غلط زدی و درستش چیه؟', maxLines: 3),
          Padding(
            padding: const EdgeInsetsDirectional.only(start: 4, bottom: 8),
            child: Text('علتِ اشتباه', style: LuxText.caption),
          ),
          Padding(
            padding: const EdgeInsets.only(bottom: 14),
            child: Wrap(spacing: 8, runSpacing: 8, children: [
              for (final c in ReviewRepo.causes) LuxChip(label: c, selected: cause == c, onTap: () => setS(() => cause = cause == c ? '' : c)),
            ]),
          ),
          LuxField(label: 'شماره‌ی صفحه (اختیاری)', controller: pageCtl, keyboard: TextInputType.number),
          if (photo != null)
            Padding(
              padding: const EdgeInsets.only(bottom: 12),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(LuxColors.r(16)),
                child: ConstrainedBox(
                  constraints: const BoxConstraints(maxHeight: 180),
                  child: Image.file(File(photo!), fit: BoxFit.cover),
                ),
              ),
            ),
          LuxButton(
            label: photo == null ? 'افزودن عکس' : 'تغییر عکس',
            icon: Icons.photo_camera_rounded,
            filled: false,
            onPressed: () async {
              try {
                final x = await ImagePicker().pickImage(source: ImageSource.gallery, maxWidth: 1400, imageQuality: 85);
                if (x == null) return;
                final dir = await getApplicationDocumentsDirectory();
                final folder = Directory(p.join(dir.path, 'mistakes'));
                await folder.create(recursive: true);
                final dst = p.join(folder.path, '${DateTime.now().millisecondsSinceEpoch}.jpg');
                await File(x.path).copy(dst);
                setS(() => photo = dst);
              } catch (_) {
                if (ctx.mounted) luxNotice(ctx, 'عکس انتخاب نشد.');
              }
            },
          ),
          const SizedBox(height: 10),
          if (!isNew) ...[
            LuxChoice(
              label: 'وضعیت',
              options: const ['در حال مرور', 'مسلط شدم'],
              selected: status == 'mastered' ? 1 : 0,
              onChanged: (i) => setS(() => status = i == 1 ? 'mastered' : 'open'),
            ),
          ],
          LuxButton(
            label: 'ذخیره',
            onPressed: () async {
              final t = title.text.trim();
              if (t.isEmpty) {
                luxNotice(ctx, 'سؤال یا مبحث رو بنویس.');
                return;
              }
              await ReviewRepo.saveMistake(
                id: isNew ? null : asInt(mistake['id']),
                courseId: cid,
                bookId: bid,
                page: parseNum(pageCtl.text)?.round(),
                title: t,
                answer: answer.text.trim(),
                cause: cause,
                photoPath: photo,
                status: status,
              );
              if (ctx.mounted) Navigator.of(ctx).pop();
            },
          ),
          if (!isNew) ...[
            const SizedBox(height: 10),
            LuxButton(
              label: 'حذف',
              filled: false,
              onPressed: () async {
                final ok = await luxConfirm(ctx, 'این اشتباه حذف شود؟');
                if (!ok) return;
                await ReviewRepo.deleteMistake(asInt(mistake['id']));
                if (ctx.mounted) Navigator.of(ctx).pop();
              },
            ),
          ],
        ],
      );
    }),
  );
}

// ───────────────────────── جلسه‌ی مرور ─────────────────────────

class ReviewPage extends StatefulWidget {
  const ReviewPage({super.key});

  @override
  State<ReviewPage> createState() => _ReviewPageState();
}

class _ReviewPageState extends State<ReviewPage> {
  List<ReviewItem> _queue = <ReviewItem>[];
  int _i = 0;
  bool _reveal = false;
  bool _loaded = false;
  int _good = 0;
  int _again = 0;

  @override
  void initState() {
    super.initState();
    _init();
  }

  Future<void> _init() async {
    final q = await ReviewRepo.due();
    if (!mounted) return;
    setState(() {
      _queue = q;
      _loaded = true;
    });
  }

  Future<void> _rate(int q) async {
    final it = _queue[_i];
    Haptic.light();
    await ReviewRepo.review(it, q);
    if (!mounted) return;
    setState(() {
      if (q < 3) {
        _again++;
      } else {
        _good++;
      }
      _i++;
      _reveal = false;
    });
  }

  Widget _rateBtn(String label, int q, Color color) => Expanded(
        child: GestureDetector(
          behavior: HitTestBehavior.opaque,
          onTap: () => _rate(q),
          child: Container(
            padding: const EdgeInsets.symmetric(vertical: 14),
            margin: const EdgeInsets.symmetric(horizontal: 4),
            decoration: BoxDecoration(
              color: LuxColors.alpha(color, 0.14),
              borderRadius: BorderRadius.circular(LuxColors.r(18)),
              border: Border.all(color: LuxColors.alpha(color, 0.5)),
            ),
            child: Text(label, textAlign: TextAlign.center, style: LuxText.label.copyWith(color: color)),
          ),
        ),
      );

  @override
  Widget build(BuildContext context) {
    if (!_loaded) {
      return LuxSubPage(title: 'مرور', children: [Center(child: CircularProgressIndicator(color: LuxColors.accent))]);
    }
    if (_queue.isEmpty || _i >= _queue.length) {
      return LuxSubPage(
        title: 'مرور',
        children: [
          LuxCard(
            radius: 28,
            child: Column(
              children: [
                const SizedBox(height: 8),
                const Text('🎉', style: TextStyle(fontSize: 48)),
                const SizedBox(height: 8),
                Text(_queue.isEmpty ? 'امروز چیزی برای مرور نداری' : 'مرورِ امروز تموم شد!', style: LuxText.title),
                const SizedBox(height: 8),
                if (_queue.isNotEmpty)
                  Text('${faDigits(_good)} مورد یادت بود · ${faDigits(_again)} مورد دوباره می‌آد', style: LuxText.caption),
                const SizedBox(height: 16),
                LuxButton(label: 'بستن', onPressed: () => Navigator.of(context).pop()),
              ],
            ),
          ),
        ],
      );
    }
    final it = _queue[_i];
    return LuxSubPage(
      title: 'مرور',
      subtitle: '${faDigits(_i + 1)} از ${faDigits(_queue.length)}',
      children: [
        ClipRRect(
          borderRadius: BorderRadius.circular(LuxColors.r(8)),
          child: LinearProgressIndicator(
            value: _i / _queue.length,
            minHeight: 6,
            backgroundColor: LuxColors.cardHi,
            valueColor: AlwaysStoppedAnimation<Color>(LuxColors.accent),
          ),
        ),
        const SizedBox(height: 16),
        LuxCard(
          radius: 28,
          padding: const EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Wrap(spacing: 8, runSpacing: 6, children: [
                LuxChip(label: it.isMistake ? 'اشتباه' : 'مرورِ فصل', selected: true, onTap: () {}),
                if (it.course.isNotEmpty) LuxChip(label: it.course, selected: false, onTap: () {}),
                if (it.cause != null) LuxChip(label: it.cause!, selected: false, onTap: () {}),
              ]),
              const SizedBox(height: 16),
              Text(it.title, style: LuxText.title),
              if (it.photoPath != null && File(it.photoPath!).existsSync()) ...[
                const SizedBox(height: 14),
                ClipRRect(
                  borderRadius: BorderRadius.circular(LuxColors.r(16)),
                  child: ConstrainedBox(constraints: const BoxConstraints(maxHeight: 240), child: Image.file(File(it.photoPath!), fit: BoxFit.contain)),
                ),
              ],
              if (!it.isMistake && !_reveal) ...[
                const SizedBox(height: 12),
                Text('مباحثِ این فصل رو توی ذهنت مرور کن، بعد جواب بده.', style: LuxText.caption),
              ],
              if (_reveal) ...[
                const SizedBox(height: 16),
                Container(
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(color: LuxColors.alpha(LuxColors.ok, 0.1), borderRadius: BorderRadius.circular(LuxColors.r(16))),
                  child: Text(it.answer ?? 'پاسخی ننوشته بودی.', style: LuxText.body),
                ),
              ],
            ],
          ),
        ),
        const SizedBox(height: 16),
        if (!_reveal)
          LuxButton(label: 'نمایش پاسخ', icon: Icons.visibility_rounded, onPressed: () => setState(() => _reveal = true))
        else ...[
          Text('چقدر یادت بود؟', style: LuxText.caption, textAlign: TextAlign.center),
          const SizedBox(height: 10),
          Row(
            children: [
              _rateBtn('فراموش کردم', 1, LuxColors.danger),
              _rateBtn('سخت بود', 3, LuxColors.warn),
              _rateBtn('خوب', 4, LuxColors.accent),
              _rateBtn('آسان', 5, LuxColors.ok),
            ],
          ),
        ],
      ],
    );
  }
}
