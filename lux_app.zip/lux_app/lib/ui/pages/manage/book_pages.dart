import 'package:flutter/material.dart';
import '../../../core/app_bus.dart';
import '../../../core/jalali_utils.dart';
import '../../../core/palette.dart';
import '../../../core/theme.dart';
import '../../../core/util.dart';
import '../../../data/database.dart';
import '../../widgets/haptic.dart';
import '../../widgets/lux_button.dart';
import '../../widgets/lux_card.dart';
import '../../widgets/lux_kit.dart';
import '../../widgets/lux_section.dart';
import 'editors.dart';

Future<int?> _showBookEditor(BuildContext context, {Map<String, Object?>? book}) {
  final isNew = book == null;
  final title = TextEditingController(text: asStr(book?['title']));
  final pages = TextEditingController(text: book == null || book['pages'] == null ? '' : asInt(book['pages']).toString());
  int? cid = book == null || book['course_id'] == null ? null : asInt(book['course_id']);
  var cname = '';
  var loaded = false;
  return showLuxSheet<int>(
    context,
    (ctx) => StatefulBuilder(builder: (ctx, setS) {
      if (!loaded) {
        loaded = true;
        courseNameOf(cid).then((n) {
          if (ctx.mounted) setS(() => cname = n);
        });
      }
      return Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Text(isNew ? 'کتاب جدید' : 'ویرایش کتاب', style: LuxText.title),
          const SizedBox(height: 16),
          LuxField(label: 'عنوان کتاب', controller: title),
          LuxPickField(
            label: 'درس',
            value: cname.isEmpty ? 'بدون درس' : cname,
            placeholder: cname.isEmpty,
            onTap: () async {
              final r = await pickCourse(ctx, selectedId: cid, allowNone: true);
              if (r == null) return;
              final n = await courseNameOf(r);
              setS(() {
                cid = r < 0 ? null : r;
                cname = n;
              });
            },
          ),
          LuxField(label: 'تعداد صفحه‌ها', controller: pages, keyboard: TextInputType.number),
          LuxButton(
            label: 'ذخیره',
            onPressed: () async {
              final t = title.text.trim();
              if (t.isEmpty) {
                luxNotice(ctx, 'عنوان کتاب را بنویس.');
                return;
              }
              final pg = parseNum(pages.text);
              final values = <String, Object?>{
                'title': t,
                'course_id': cid,
                'pages': pg?.round(),
              };
              int id;
              if (isNew) {
                values['added_at'] = DateTime.now().millisecondsSinceEpoch;
                id = await LuxDb.instance.insert('books', values);
              } else {
                id = asInt(book!['id']);
                await LuxDb.instance.update('books', values, where: 'id = ?', args: [id]);
              }
              AppBus.bump();
              if (ctx.mounted) Navigator.of(ctx).pop(id);
            },
          ),
        ],
      );
    }),
  );
}

class BooksPage extends StatefulWidget {
  const BooksPage({super.key});

  @override
  State<BooksPage> createState() => _BooksPageState();
}

class _BooksPageState extends State<BooksPage> {
  List<Map<String, Object?>> _rows = <Map<String, Object?>>[];
  bool _loaded = false;

  @override
  void initState() {
    super.initState();
    _load();
    AppBus.data.addListener(_load);
  }

  @override
  void dispose() {
    AppBus.data.removeListener(_load);
    super.dispose();
  }

  Future<void> _load() async {
    final r = await LuxDb.instance.rawQuery(
      'SELECT b.*, c.name AS course_name, '
      '(SELECT COUNT(*) FROM chapters h WHERE h.book_id = b.id) AS ch_total, '
      '(SELECT COUNT(*) FROM chapters h WHERE h.book_id = b.id AND h.done = 1) AS ch_done '
      'FROM books b LEFT JOIN courses c ON c.id = b.course_id ORDER BY b.id',
    );
    if (!mounted) return;
    setState(() {
      _rows = r;
      _loaded = true;
    });
  }

  @override
  Widget build(BuildContext context) {
    return LuxSubPage(
      title: 'کتاب‌ها',
      subtitle: 'فصل‌ها و پیشرفت مطالعه',
      action: LuxAddButton(onTap: () => _showBookEditor(context)),
      children: [
        if (_loaded && _rows.isEmpty)
          const LuxCard(child: LuxEmpty(icon: Icons.auto_stories_rounded, title: 'کتابی ثبت نشده', hint: 'با دکمه‌ی + کتاب‌هایت را اضافه کن و فصل‌هایشان را تیک بزن.'))
        else
          LuxSection(title: 'همه‌ی کتاب‌ها', children: [
            for (final b in _rows)
              LuxRow(
                leading: const Icon(Icons.menu_book_rounded, color: LuxColors.silver),
                title: asStr(b['title']),
                subtitle: [
                  if (asStr(b['course_name']).isNotEmpty) asStr(b['course_name']),
                  if (asInt(b['ch_total']) > 0) 'فصل ${faDigits(asInt(b['ch_done']))} از ${faDigits(asInt(b['ch_total']))}',
                  if (b['pages'] != null) 'صفحه ${faDigits(asInt(b['last_page']))} از ${faDigits(asInt(b['pages']))}',
                ].join(' · '),
                trailing: const Icon(Icons.chevron_left_rounded, color: LuxColors.silverDim),
                onTap: () => pushPage<void>(context, BookDetailPage(bookId: asInt(b['id']))),
              ),
          ]),
      ],
    );
  }
}

class BookDetailPage extends StatefulWidget {
  final int bookId;
  const BookDetailPage({super.key, required this.bookId});

  @override
  State<BookDetailPage> createState() => _BookDetailPageState();
}

class _BookDetailPageState extends State<BookDetailPage> {
  Map<String, Object?>? _book;
  List<Map<String, Object?>> _chapters = <Map<String, Object?>>[];
  String _course = '';
  bool _gone = false;

  @override
  void initState() {
    super.initState();
    _load();
    AppBus.data.addListener(_load);
  }

  @override
  void dispose() {
    AppBus.data.removeListener(_load);
    super.dispose();
  }

  Future<void> _load() async {
    final db = LuxDb.instance;
    final rows = await db.query('books', where: 'id = ?', args: [widget.bookId], limit: 1);
    if (rows.isEmpty) {
      if (mounted) setState(() => _gone = true);
      return;
    }
    final b = rows.first;
    final ch = await db.query('chapters', where: 'book_id = ?', args: [widget.bookId], orderBy: 'id');
    final cn = await courseNameOf(b['course_id'] == null ? null : asInt(b['course_id']));
    if (!mounted) return;
    setState(() {
      _book = b;
      _chapters = ch;
      _course = cn;
    });
  }

  Future<void> _chapterEditor({Map<String, Object?>? chapter}) {
    final isNew = chapter == null;
    final title = TextEditingController(text: asStr(chapter?['title']));
    final from = TextEditingController(text: chapter == null || chapter['start_page'] == null ? '' : asInt(chapter['start_page']).toString());
    final to = TextEditingController(text: chapter == null || chapter['end_page'] == null ? '' : asInt(chapter['end_page']).toString());
    return showLuxSheet<void>(
      context,
      (ctx) => Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Text(isNew ? 'فصل جدید' : 'ویرایش فصل', style: LuxText.title),
          const SizedBox(height: 16),
          LuxField(label: 'عنوان فصل', controller: title, hint: 'مثلاً فصل ۱: تابع'),
          Row(
            children: [
              Expanded(child: LuxField(label: 'از صفحه', controller: from, keyboard: TextInputType.number)),
              const SizedBox(width: 12),
              Expanded(child: LuxField(label: 'تا صفحه', controller: to, keyboard: TextInputType.number)),
            ],
          ),
          LuxButton(
            label: 'ذخیره',
            onPressed: () async {
              final t = title.text.trim();
              if (t.isEmpty) {
                luxNotice(ctx, 'عنوان فصل را بنویس.');
                return;
              }
              final values = <String, Object?>{
                'book_id': widget.bookId,
                'title': t,
                'start_page': parseNum(from.text)?.round(),
                'end_page': parseNum(to.text)?.round(),
              };
              if (isNew) {
                await LuxDb.instance.insert('chapters', values);
              } else {
                await LuxDb.instance.update('chapters', values, where: 'id = ?', args: [asInt(chapter!['id'])]);
              }
              AppBus.bump();
              if (ctx.mounted) Navigator.of(ctx).pop();
            },
          ),
          if (!isNew) ...[
            const SizedBox(height: 10),
            LuxButton(
              label: 'حذف فصل',
              filled: false,
              onPressed: () async {
                final ok = await luxConfirm(ctx, 'این فصل حذف شود؟');
                if (!ok) return;
                await LuxDb.instance.delete('chapters', where: 'id = ?', args: [asInt(chapter!['id'])]);
                AppBus.bump();
                if (ctx.mounted) Navigator.of(ctx).pop();
              },
            ),
          ],
        ],
      ),
    );
  }

  Future<void> _toggle(Map<String, Object?> ch) async {
    final done = asInt(ch['done']) == 1;
    Haptic.light();
    await LuxDb.instance.update(
      'chapters',
      <String, Object?>{
        'done': done ? 0 : 1,
        'reps': done ? asInt(ch['reps']) : asInt(ch['reps']) + 1,
        'due_ts': done ? null : DateTime.now().add(const Duration(days: 1)).millisecondsSinceEpoch,
      },
      where: 'id = ?',
      args: [asInt(ch['id'])],
    );
    AppBus.bump();
  }

  Future<void> _editLastPage() {
    final b = _book!;
    final ctl = TextEditingController(text: asInt(b['last_page']).toString());
    return showLuxSheet<void>(
      context,
      (ctx) => Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Text('تا کدام صفحه خواندی؟', style: LuxText.title),
          const SizedBox(height: 16),
          LuxField(label: 'شماره‌ی صفحه', controller: ctl, keyboard: TextInputType.number),
          LuxButton(
            label: 'ذخیره',
            onPressed: () async {
              var v = (parseNum(ctl.text) ?? 0).round();
              if (v < 0) v = 0;
              final total = b['pages'] == null ? null : asInt(b['pages']);
              if (total != null && v > total) v = total;
              await LuxDb.instance.update('books', <String, Object?>{'last_page': v}, where: 'id = ?', args: [widget.bookId]);
              AppBus.bump();
              if (ctx.mounted) Navigator.of(ctx).pop();
            },
          ),
        ],
      ),
    );
  }

  Future<void> _deleteBook() async {
    final ok = await luxConfirm(context, 'حذف این کتاب؟', body: 'فصل‌هایش هم پاک می‌شوند.');
    if (!ok) return;
    await LuxDb.instance.delete('books', where: 'id = ?', args: [widget.bookId]);
    AppBus.bump();
    if (mounted) Navigator.of(context).pop();
  }

  @override
  Widget build(BuildContext context) {
    final b = _book;
    if (_gone) {
      return const LuxSubPage(title: 'کتاب', children: [LuxEmpty(icon: Icons.menu_book_rounded, title: 'این کتاب دیگر وجود ندارد')]);
    }
    if (b == null) {
      return const LuxSubPage(title: 'کتاب', children: [Center(child: CircularProgressIndicator(color: LuxColors.accent))]);
    }
    final total = _chapters.length;
    final done = _chapters.where((c) => asInt(c['done']) == 1).length;
    final pages = b['pages'] == null ? 0 : asInt(b['pages']);
    final last = asInt(b['last_page']);
    final progress = total > 0 ? done / total : (pages > 0 ? last / pages : 0.0);

    return LuxSubPage(
      title: asStr(b['title']),
      subtitle: _course.isEmpty ? 'بدون درس' : _course,
      action: LuxAddButton(icon: Icons.edit_rounded, onTap: () => _showBookEditor(context, book: b)),
      children: [
        LuxCard(
          radius: 28,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Expanded(child: Text('پیشرفت', style: LuxText.heading)),
                  Text('${faDigits((progress * 100).round())}٪', style: LuxText.heading.copyWith(color: LuxColors.accent)),
                ],
              ),
              const SizedBox(height: 12),
              ClipRRect(
                borderRadius: BorderRadius.circular(8),
                child: LinearProgressIndicator(
                  value: progress.clamp(0.0, 1.0),
                  minHeight: 8,
                  backgroundColor: LuxColors.cardHi,
                  valueColor: const AlwaysStoppedAnimation<Color>(LuxColors.accent),
                ),
              ),
              const SizedBox(height: 10),
              Text(
                total > 0 ? '${faDigits(done)} فصل از ${faDigits(total)} تمام شده' : 'هنوز فصلی اضافه نکرده‌ای',
                style: LuxText.caption,
              ),
            ],
          ),
        ),
        const SizedBox(height: 16),
        LuxSection(title: 'صفحه‌ی فعلی', children: [
          LuxRow(
            title: pages > 0 ? 'صفحه ${faDigits(last)} از ${faDigits(pages)}' : 'صفحه ${faDigits(last)}',
            subtitle: 'برای تغییر بزن',
            trailing: const Icon(Icons.edit_rounded, color: LuxColors.accent, size: 20),
            onTap: _editLastPage,
          ),
        ]),
        LuxSection(title: 'فصل‌ها', children: [
          if (_chapters.isEmpty) const LuxEmpty(icon: Icons.list_alt_rounded, title: 'فصلی ثبت نشده'),
          for (final ch in _chapters)
            LuxRow(
              leading: GestureDetector(
                onTap: () => _toggle(ch),
                child: Icon(
                  asInt(ch['done']) == 1 ? Icons.check_circle_rounded : Icons.radio_button_unchecked_rounded,
                  color: asInt(ch['done']) == 1 ? LuxColors.ok : LuxColors.silverDim,
                  size: 28,
                ),
              ),
              title: asStr(ch['title']),
              subtitle: ch['start_page'] == null
                  ? null
                  : 'صفحه ${faDigits(asInt(ch['start_page']))}${ch['end_page'] == null ? '' : ' تا ${faDigits(asInt(ch['end_page']))}'}',
              onTap: () => _chapterEditor(chapter: ch),
            ),
          LuxRow(
            leading: const Icon(Icons.add_circle_outline_rounded, color: LuxColors.accent),
            title: 'افزودن فصل',
            onTap: _chapterEditor,
          ),
        ]),
        GestureDetector(
          onTap: _deleteBook,
          child: Padding(
            padding: const EdgeInsets.all(14),
            child: Text('حذف این کتاب', textAlign: TextAlign.center, style: LuxText.label.copyWith(color: LuxColors.danger)),
          ),
        ),
      ],
    );
  }
}
