import 'package:flutter/material.dart';
import '../../../core/app_bus.dart';
import '../../../core/jalali_utils.dart';
import '../../../core/palette.dart';
import '../../../core/theme.dart';
import '../../../core/util.dart';
import '../../../data/database.dart';
import '../../widgets/haptic.dart';
import '../../widgets/lux_button.dart';
import '../../widgets/lux_card.dart';
import '../../widgets/lux_kit.dart';
import '../../widgets/lux_section.dart';
import '../reader/reader_library_page.dart';
import 'editors.dart';

Future<int?> showBookEditor(BuildContext context, {Map<String, Object?>? book, int? courseId}) {
  final isNew = book == null;
  final title = TextEditingController(text: asStr(book?['title']));
  final pages = TextEditingController(text: book == null || book['pages'] == null ? '' : asInt(book['pages']).toString());
  int? cid = book == null ? courseId : (book['course_id'] == null ? null : asInt(book['course_id']));
  return showLuxSheet<int>(
    context,
    (ctx) => StatefulBuilder(builder: (ctx, setS) {
      return Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Text(isNew ? 'کتاب جدید' : 'ویرایش کتاب', style: LuxText.title),
          const SizedBox(height: 16),
          LuxField(label: 'عنوان کتاب', controller: title),
          if (courseId == null) LuxCourseChips(selectedId: cid, onChanged: (id) => setS(() => cid = id)),
          LuxField(label: 'تعداد صفحه‌ها (اختیاری)', controller: pages, keyboard: TextInputType.number),
          LuxButton(
            label: 'ذخیره',
            onPressed: () async {
              final t = title.text.trim();
              if (t.isEmpty) {
                luxNotice(ctx, 'عنوان کتاب را بنویس.');
                return;
              }
              if (cid == null) {
                luxNotice(ctx, 'درس این کتاب را انتخاب کن.');
                return;
              }
              final pg = parseNum(pages.text);
              final values = <String, Object?>{
                'title': t,
                'course_id': cid,
                'pages': pg?.round(),
              };
              int id;
              if (isNew) {
                values['added_at'] = DateTime.now().millisecondsSinceEpoch;
                id = await LuxDb.instance.insert('books', values);
              } else {
                id = asInt(book!['id']);
                await LuxDb.instance.update('books', values, where: 'id = ?', args: [id]);
              }
              AppBus.bump();
              if (ctx.mounted) Navigator.of(ctx).pop(id);
            },
          ),
        ],
      );
    }),
  );
}

class BookDetailPage extends StatefulWidget {
  final int bookId;
  const BookDetailPage({super.key, required this.bookId});

  @override
  State<BookDetailPage> createState() => _BookDetailPageState();
}

class _BookDetailPageState extends State<BookDetailPage> {
  Map<String, Object?>? _book;
  List<Map<String, Object?>> _chapters = <Map<String, Object?>>[];
  String _course = '';
  bool _gone = false;

  @override
  void initState() {
    super.initState();
    _load();
    AppBus.data.addListener(_load);
  }

  @override
  void dispose() {
    AppBus.data.removeListener(_load);
    super.dispose();
  }

  Future<void> _load() async {
    final db = LuxDb.instance;
    final rows = await db.query('books', where: 'id = ?', args: [widget.bookId], limit: 1);
    if (rows.isEmpty) {
      if (mounted) setState(() => _gone = true);
      return;
    }
    final b = rows.first;
    final ch = await db.query('chapters', where: 'book_id = ?', args: [widget.bookId], orderBy: 'id');
    final cn = await courseNameOf(b['course_id'] == null ? null : asInt(b['course_id']));
    if (!mounted) return;
    setState(() {
      _book = b;
      _chapters = ch;
      _course = cn;
    });
  }

  Future<void> _chapterEditor({Map<String, Object?>? chapter}) {
    final isNew = chapter == null;
    final title = TextEditingController(text: asStr(chapter?['title']));
    final from = TextEditingController(text: chapter == null || chapter['start_page'] == null ? '' : asInt(chapter['start_page']).toString());
    final to = TextEditingController(text: chapter == null || chapter['end_page'] == null ? '' : asInt(chapter['end_page']).toString());
    return showLuxSheet<void>(
      context,
      (ctx) => Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Text(isNew ? 'فصل جدید' : 'ویرایش فصل', style: LuxText.title),
          const SizedBox(height: 16),
          LuxField(label: 'عنوان فصل', controller: title, hint: 'مثلاً فصل ۱: تابع'),
          Row(
            children: [
              Expanded(child: LuxField(label: 'از صفحه', controller: from, keyboard: TextInputType.number)),
              const SizedBox(width: 12),
              Expanded(child: LuxField(label: 'تا صفحه', controller: to, keyboard: TextInputType.number)),
            ],
          ),
          LuxButton(
            label: 'ذخیره',
            onPressed: () async {
              final t = title.text.trim();
              if (t.isEmpty) {
                luxNotice(ctx, 'عنوان فصل را بنویس.');
                return;
              }
              final values = <String, Object?>{
                'book_id': widget.bookId,
                'title': t,
                'start_page': parseNum(from.text)?.round(),
                'end_page': parseNum(to.text)?.round(),
              };
              if (isNew) {
                await LuxDb.instance.insert('chapters', values);
              } else {
                await LuxDb.instance.update('chapters', values, where: 'id = ?', args: [asInt(chapter!['id'])]);
              }
              AppBus.bump();
              if (ctx.mounted) Navigator.of(ctx).pop();
            },
          ),
          if (!isNew) ...[
            const SizedBox(height: 10),
            LuxButton(
              label: 'حذف فصل',
              filled: false,
              onPressed: () async {
                final ok = await luxConfirm(ctx, 'این فصل حذف شود؟');
                if (!ok) return;
                await LuxDb.instance.delete('chapters', where: 'id = ?', args: [asInt(chapter!['id'])]);
                AppBus.bump();
                if (ctx.mounted) Navigator.of(ctx).pop();
              },
            ),
          ],
        ],
      ),
    );
  }

  Future<void> _toggle(Map<String, Object?> ch) async {
    final done = asInt(ch['done']) == 1;
    Haptic.light();
    await LuxDb.instance.update(
      'chapters',
      <String, Object?>{
        'done': done ? 0 : 1,
        'reps': done ? asInt(ch['reps']) : asInt(ch['reps']) + 1,
        'due_ts': done ? null : DateTime.now().add(const Duration(days: 1)).millisecondsSinceEpoch,
      },
      where: 'id = ?',
      args: [asInt(ch['id'])],
    );
    AppBus.bump();
  }

  Future<void> _editLastPage() {
    final b = _book!;
    final ctl = TextEditingController(text: asInt(b['last_page']).toString());
    return showLuxSheet<void>(
      context,
      (ctx) => Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Text('تا کدام صفحه خواندی؟', style: LuxText.title),
          const SizedBox(height: 16),
          LuxField(label: 'شماره‌ی صفحه', controller: ctl, keyboard: TextInputType.number),
          LuxButton(
            label: 'ذخیره',
            onPressed: () async {
              var v = (parseNum(ctl.text) ?? 0).round();
              if (v < 0) v = 0;
              final total = b['pages'] == null ? null : asInt(b['pages']);
              if (total != null && v > total) v = total;
              await LuxDb.instance.update('books', <String, Object?>{'last_page': v}, where: 'id = ?', args: [widget.bookId]);
              AppBus.bump();
              if (ctx.mounted) Navigator.of(ctx).pop();
            },
          ),
        ],
      ),
    );
  }

  Future<void> _deleteBook() async {
    final ok = await luxConfirm(context, 'حذف این کتاب؟', body: 'فصل‌هایش هم پاک می‌شوند.');
    if (!ok) return;
    await LuxDb.instance.delete('books', where: 'id = ?', args: [widget.bookId]);
    AppBus.bump();
    if (mounted) Navigator.of(context).pop();
  }

  @override
  Widget build(BuildContext context) {
    final b = _book;
    if (_gone) {
      return const LuxSubPage(title: 'کتاب', children: [LuxEmpty(icon: Icons.menu_book_rounded, title: 'این کتاب دیگر وجود ندارد')]);
    }
    if (b == null) {
      return LuxSubPage(title: 'کتاب', children: [Center(child: CircularProgressIndicator(color: LuxColors.accent))]);
    }
    final total = _chapters.length;
    final done = _chapters.where((c) => asInt(c['done']) == 1).length;
    final pages = b['pages'] == null ? 0 : asInt(b['pages']);
    final last = asInt(b['last_page']);
    final progress = total > 0 ? done / total : (pages > 0 ? last / pages : 0.0);

    return LuxSubPage(
      title: asStr(b['title']),
      subtitle: _course.isEmpty ? 'بدون درس' : _course,
      action: LuxAddButton(icon: Icons.edit_rounded, onTap: () => showBookEditor(context, book: b)),
      children: [
        LuxCard(
          radius: 28,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Expanded(child: Text('پیشرفت', style: LuxText.heading)),
                  Text('${faDigits((progress * 100).round())}٪', style: LuxText.heading.copyWith(color: LuxColors.accent)),
                ],
              ),
              const SizedBox(height: 12),
              ClipRRect(
                borderRadius: BorderRadius.circular(LuxColors.r(8)),
                child: LinearProgressIndicator(
                  value: progress.clamp(0.0, 1.0),
                  minHeight: 8,
                  backgroundColor: LuxColors.cardHi,
                  valueColor: AlwaysStoppedAnimation<Color>(LuxColors.accent),
                ),
              ),
              const SizedBox(height: 10),
              Text(
                total > 0 ? '${faDigits(done)} فصل از ${faDigits(total)} تمام شده' : 'هنوز فصلی اضافه نکرده‌ای',
                style: LuxText.caption,
              ),
            ],
          ),
        ),
        const SizedBox(height: 16),
        LuxCard(
          radius: 24,
          child: asStr(b['file_path']).isEmpty
              ? Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Text('فایل PDF', style: LuxText.heading),
                    const SizedBox(height: 4),
                    Text('PDF این کتاب رو اضافه کن تا توی لوکس بخونی، هایلایت و یادداشت بزنی و پیشرفتت ثبت بشه.', style: LuxText.caption),
                    const SizedBox(height: 12),
                    LuxButton(
                      label: 'افزودن PDF',
                      icon: Icons.picture_as_pdf_rounded,
                      filled: false,
                      onPressed: () => addPdfFlow(context, bookId: widget.bookId),
                    ),
                  ],
                )
              : Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    LuxButton(
                      label: last > 0 ? 'ادامه‌ی مطالعه (صفحه‌ی ${faDigits(last)})' : 'شروعِ مطالعه',
                      icon: Icons.auto_stories_rounded,
                      onPressed: () => openReader(context, widget.bookId),
                    ),
                  ],
                ),
        ),
        const SizedBox(height: 16),
        LuxSection(title: 'صفحه‌ی فعلی', children: [
          LuxRow(
            title: pages > 0 ? 'صفحه ${faDigits(last)} از ${faDigits(pages)}' : 'صفحه ${faDigits(last)}',
            subtitle: 'برای تغییر بزن',
            trailing: Icon(Icons.edit_rounded, color: LuxColors.accent, size: 20),
            onTap: _editLastPage,
          ),
        ]),
        LuxSection(title: 'فصل‌ها', children: [
          if (_chapters.isEmpty) const LuxEmpty(icon: Icons.list_alt_rounded, title: 'فصلی ثبت نشده'),
          for (final ch in _chapters)
            LuxRow(
              leading: GestureDetector(
                onTap: () => _toggle(ch),
                child: Icon(
                  asInt(ch['done']) == 1 ? Icons.check_circle_rounded : Icons.radio_button_unchecked_rounded,
                  color: asInt(ch['done']) == 1 ? LuxColors.ok : LuxColors.silverDim,
                  size: 28,
                ),
              ),
              title: asStr(ch['title']),
              subtitle: ch['start_page'] == null
                  ? null
                  : 'صفحه ${faDigits(asInt(ch['start_page']))}${ch['end_page'] == null ? '' : ' تا ${faDigits(asInt(ch['end_page']))}'}',
              onTap: () => _chapterEditor(chapter: ch),
            ),
          LuxRow(
            leading: Icon(Icons.add_circle_outline_rounded, color: LuxColors.accent),
            title: 'افزودن فصل',
            onTap: _chapterEditor,
          ),
        ]),
        GestureDetector(
          onTap: _deleteBook,
          child: Padding(
            padding: const EdgeInsets.all(14),
            child: Text('حذف این کتاب', textAlign: TextAlign.center, style: LuxText.label.copyWith(color: LuxColors.danger)),
          ),
        ),
      ],
    );
  }
}
