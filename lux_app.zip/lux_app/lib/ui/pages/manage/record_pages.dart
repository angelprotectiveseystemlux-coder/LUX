import 'package:flutter/material.dart';
import '../../../core/app_bus.dart';
import '../../../core/jalali_utils.dart';
import '../../../core/palette.dart';
import '../../../core/theme.dart';
import '../../../core/util.dart';
import '../../../data/database.dart';
import '../../widgets/lux_button.dart';
import '../../widgets/lux_card.dart';
import '../../widgets/lux_kit.dart';
import '../../widgets/lux_section.dart';
import 'editors.dart';

// ───────────────────────── مثبت‌های سر کلاس ─────────────────────────

class PositivesPage extends StatefulWidget {
  const PositivesPage({super.key});

  @override
  State<PositivesPage> createState() => _PositivesPageState();
}

class _PositivesPageState extends State<PositivesPage> {
  List<Map<String, Object?>> _rows = <Map<String, Object?>>[];
  List<Map<String, Object?>> _byCourse = <Map<String, Object?>>[];
  bool _loaded = false;

  @override
  void initState() {
    super.initState();
    _load();
    AppBus.data.addListener(_load);
  }

  @override
  void dispose() {
    AppBus.data.removeListener(_load);
    super.dispose();
  }

  Future<void> _load() async {
    final db = LuxDb.instance;
    final rows = await db.rawQuery(
      'SELECT p.*, c.name AS course_name FROM class_positives p '
      'LEFT JOIN courses c ON c.id = p.course_id ORDER BY p.at_ts DESC',
    );
    final by = await db.rawQuery(
      'SELECT c.name AS name, SUM(p.count) AS total FROM class_positives p '
      'JOIN courses c ON c.id = p.course_id GROUP BY c.id ORDER BY total DESC',
    );
    if (!mounted) return;
    setState(() {
      _rows = rows;
      _byCourse = by;
      _loaded = true;
    });
  }

  Future<void> _editor({Map<String, Object?>? item}) {
    final isNew = item == null;
    int? cid = item == null || item['course_id'] == null ? null : asInt(item['course_id']);
    var count = asInt(item?['count'], 1).clamp(1, 10);
    var at = item == null ? DateTime.now() : fromTs(item['at_ts']);
    final note = TextEditingController(text: asStr(item?['note']));
    return showLuxSheet<void>(
      context,
      (ctx) => StatefulBuilder(builder: (ctx, setS) {
        return Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Text(isNew ? 'مثبتِ جدید' : 'ویرایش مثبت', style: LuxText.title),
            const SizedBox(height: 16),
            LuxCourseChips(selectedId: cid, onChanged: (id) => setS(() => cid = id)),
            LuxChoice(
              label: 'تعداد مثبت',
              options: [for (var i = 1; i <= 5; i++) faDigits(i)],
              selected: count - 1,
              onChanged: (i) => setS(() => count = i + 1),
            ),
            LuxPickField(
              label: 'تاریخ',
              value: jalaliLabelWithDay(at),
              icon: Icons.event_rounded,
              onTap: () async {
                final d = await pickJalaliDateTime(ctx, initial: at, withTime: false);
                if (d != null) setS(() => at = d);
              },
            ),
            LuxField(label: 'یادداشت', controller: note, hint: 'اختیاری'),
            LuxButton(
              label: 'ذخیره',
              onPressed: () async {
                if (cid == null) {
                  luxNotice(ctx, 'درس را انتخاب کن.');
                  return;
                }
                int? teacherId;
                final cr = await LuxDb.instance.query('courses', where: 'id = ?', args: [cid], limit: 1);
                if (cr.isNotEmpty && cr.first['teacher_id'] != null) teacherId = asInt(cr.first['teacher_id']);
                final values = <String, Object?>{
                  'course_id': cid,
                  'teacher_id': teacherId,
                  'at_ts': at.millisecondsSinceEpoch,
                  'count': count,
                  'note': note.text.trim(),
                };
                if (isNew) {
                  await LuxDb.instance.insert('class_positives', values);
                } else {
                  await LuxDb.instance.update('class_positives', values, where: 'id = ?', args: [asInt(item!['id'])]);
                }
                AppBus.bump();
                if (ctx.mounted) Navigator.of(ctx).pop();
              },
            ),
            if (!isNew) ...[
              const SizedBox(height: 10),
              LuxButton(
                label: 'حذف',
                filled: false,
                onPressed: () async {
                  final ok = await luxConfirm(ctx, 'این مورد حذف شود؟');
                  if (!ok) return;
                  await LuxDb.instance.delete('class_positives', where: 'id = ?', args: [asInt(item!['id'])]);
                  AppBus.bump();
                  if (ctx.mounted) Navigator.of(ctx).pop();
                },
              ),
            ],
          ],
        );
      }),
    );
  }

  @override
  Widget build(BuildContext context) {
    var total = 0;
    for (final r in _rows) {
      total += asInt(r['count'], 1);
    }
    return LuxSubPage(
      title: 'مثبت‌ها',
      subtitle: 'مجموع: ${faDigits(total)}',
      action: LuxAddButton(onTap: () => _editor()),
      children: [
        if (_loaded && _rows.isEmpty)
          const LuxCard(child: LuxEmpty(icon: Icons.thumb_up_alt_rounded, title: 'مثبتی ثبت نشده', hint: 'هر وقت سر کلاس مثبت گرفتی با دکمه‌ی + ثبتش کن.'))
        else ...[
          if (_byCourse.isNotEmpty)
            LuxSection(title: 'به تفکیک درس', children: [
              for (final c in _byCourse)
                LuxRow(
                  title: asStr(c['name']),
                  trailing: Text(faDigits(asInt(c['total'])), style: LuxText.heading.copyWith(color: LuxColors.accent)),
                ),
            ]),
          LuxSection(title: 'سابقه', children: [
            for (final r in _rows)
              LuxRow(
                title: '${asStr(r['course_name'], 'بدون درس')} · ${faDigits(asInt(r['count'], 1))} مثبت',
                subtitle: [jalaliLabelWithDay(fromTs(r['at_ts'])), if (asStr(r['note']).isNotEmpty) asStr(r['note'])].join(' · '),
                onTap: () => _editor(item: r),
              ),
          ]),
        ],
      ],
    );
  }
}

// ───────────────────────── اخطارها ─────────────────────────

const List<String> _kWarnTypes = <String>['انضباطی', 'امنیتی', 'تحصیلی', 'سایر'];
const List<String> _kSeverity = <String>['سبک', 'متوسط', 'جدی'];

class WarningsPage extends StatefulWidget {
  const WarningsPage({super.key});

  @override
  State<WarningsPage> createState() => _WarningsPageState();
}

class _WarningsPageState extends State<WarningsPage> {
  List<Map<String, Object?>> _rows = <Map<String, Object?>>[];
  bool _loaded = false;

  @override
  void initState() {
    super.initState();
    _load();
    AppBus.data.addListener(_load);
  }

  @override
  void dispose() {
    AppBus.data.removeListener(_load);
    super.dispose();
  }

  Future<void> _load() async {
    final r = await LuxDb.instance.query('discipline_warnings', orderBy: 'resolved ASC, at_ts DESC');
    if (!mounted) return;
    setState(() {
      _rows = r;
      _loaded = true;
    });
  }

  Future<void> _editor({Map<String, Object?>? item}) {
    final isNew = item == null;
    var type = _kWarnTypes.indexOf(asStr(item?['type'], 'انضباطی'));
    if (type < 0) type = 0;
    var severity = asInt(item?['severity'], 1).clamp(1, 3);
    var at = item == null ? DateTime.now() : fromTs(item['at_ts']);
    DateTime? follow = item == null || item['followup_ts'] == null ? null : fromTs(item['followup_ts']);
    var resolved = asInt(item?['resolved']) == 1;
    final issuer = TextEditingController(text: asStr(item?['issuer']));
    final reason = TextEditingController(text: asStr(item?['reason']));
    final points = TextEditingController(text: item == null || item['points'] == null ? '' : latinNum(asDouble(item['points'])));
    final note = TextEditingController(text: asStr(item?['note']));
    return showLuxSheet<void>(
      context,
      (ctx) => StatefulBuilder(builder: (ctx, setS) {
        return Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Text(isNew ? 'اخطار جدید' : 'ویرایش اخطار', style: LuxText.title),
            const SizedBox(height: 16),
            LuxChoice(label: 'نوع', options: _kWarnTypes, selected: type, onChanged: (i) => setS(() => type = i)),
            LuxField(label: 'صادرکننده', controller: issuer, hint: 'مثلاً ناظم، معاون'),
            LuxField(label: 'دلیل', controller: reason, maxLines: 2),
            LuxChoice(label: 'شدت', options: _kSeverity, selected: severity - 1, onChanged: (i) => setS(() => severity = i + 1)),
            LuxField(label: 'نمره‌ی منفیِ انضباطی', controller: points, keyboard: TextInputType.number, hint: 'اختیاری'),
            LuxPickField(
              label: 'تاریخ اخطار',
              value: jalaliLabelWithDay(at),
              icon: Icons.event_rounded,
              onTap: () async {
                final d = await pickJalaliDateTime(ctx, initial: at, withTime: false);
                if (d != null) setS(() => at = d);
              },
            ),
            LuxPickField(
              label: 'تاریخ پیگیری',
              value: follow == null ? 'ندارد' : jalaliLabelWithDay(follow!),
              placeholder: follow == null,
              icon: Icons.event_available_rounded,
              onTap: () async {
                final d = await pickJalaliDateTime(ctx, initial: follow ?? DateTime.now(), withTime: false);
                if (d != null) setS(() => follow = d);
              },
            ),
            LuxChoice(
              label: 'وضعیت',
              options: const ['در حال پیگیری', 'حل شد'],
              selected: resolved ? 1 : 0,
              onChanged: (i) => setS(() => resolved = i == 1),
            ),
            LuxField(label: 'یادداشت', controller: note, maxLines: 2),
            LuxButton(
              label: 'ذخیره',
              onPressed: () async {
                if (reason.text.trim().isEmpty) {
                  luxNotice(ctx, 'دلیل اخطار را بنویس.');
                  return;
                }
                final values = <String, Object?>{
                  'at_ts': at.millisecondsSinceEpoch,
                  'type': _kWarnTypes[type],
                  'issuer': issuer.text.trim(),
                  'reason': reason.text.trim(),
                  'severity': severity,
                  'points': parseNum(points.text),
                  'followup_ts': follow?.millisecondsSinceEpoch,
                  'resolved': resolved ? 1 : 0,
                  'note': note.text.trim(),
                };
                if (isNew) {
                  await LuxDb.instance.insert('discipline_warnings', values);
                } else {
                  await LuxDb.instance.update('discipline_warnings', values, where: 'id = ?', args: [asInt(item!['id'])]);
                }
                AppBus.bump();
                if (ctx.mounted) Navigator.of(ctx).pop();
              },
            ),
            if (!isNew) ...[
              const SizedBox(height: 10),
              LuxButton(
                label: 'حذف',
                filled: false,
                onPressed: () async {
                  final ok = await luxConfirm(ctx, 'این اخطار حذف شود؟');
                  if (!ok) return;
                  await LuxDb.instance.delete('discipline_warnings', where: 'id = ?', args: [asInt(item!['id'])]);
                  AppBus.bump();
                  if (ctx.mounted) Navigator.of(ctx).pop();
                },
              ),
            ],
          ],
        );
      }),
    );
  }

  @override
  Widget build(BuildContext context) {
    final open = _rows.where((r) => asInt(r['resolved']) == 0).length;
    return LuxSubPage(
      title: 'اخطارها',
      subtitle: _rows.isEmpty ? 'اخطار انضباطی و پیگیری' : '${faDigits(open)} مورد در حال پیگیری',
      action: LuxAddButton(onTap: () => _editor()),
      children: [
        if (_loaded && _rows.isEmpty)
          const LuxCard(child: LuxEmpty(icon: Icons.report_gmailerrorred_rounded, title: 'اخطاری ثبت نشده', hint: 'اگر اخطاری گرفتی، اینجا ثبت و پیگیری‌اش کن.'))
        else
          LuxSection(title: 'همه‌ی اخطارها', children: [
            for (final r in _rows)
              LuxRow(
                leading: Icon(
                  asInt(r['resolved']) == 1 ? Icons.check_circle_rounded : Icons.error_outline_rounded,
                  color: asInt(r['resolved']) == 1 ? LuxColors.ok : (asInt(r['severity']) >= 3 ? LuxColors.danger : LuxColors.warn),
                ),
                title: asStr(r['reason']),
                subtitle: [
                  asStr(r['type']),
                  jalaliLabel(fromTs(r['at_ts'])),
                  if (asStr(r['issuer']).isNotEmpty) asStr(r['issuer']),
                  if (r['followup_ts'] != null && asInt(r['resolved']) == 0) 'پیگیری ${relativeDay(fromTs(r['followup_ts']))}',
                ].join(' · '),
                onTap: () => _editor(item: r),
              ),
          ]),
      ],
    );
  }
}
