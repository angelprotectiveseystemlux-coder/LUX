import 'package:flutter/material.dart';
import '../../../core/app_bus.dart';
import '../../../core/jalali_utils.dart';
import '../../../core/palette.dart';
import '../../../core/theme.dart';
import '../../../core/util.dart';
import '../../../data/database.dart';
import '../../../data/study_repo.dart';
import '../../../engine/grades.dart';
import '../../widgets/lux_button.dart';
import '../../widgets/lux_card.dart';
import '../../widgets/lux_kit.dart';
import '../../widgets/lux_section.dart';
import 'editors.dart';

// ───────────────────────── مثبت و منفی سر کلاس ─────────────────────────

String _signed(double v) => '${v < 0 ? '−' : '+'}${fmtNum(v.abs(), dec: 2)}';

class PositivesPage extends StatefulWidget {
  const PositivesPage({super.key});

  @override
  State<PositivesPage> createState() => _PositivesPageState();
}

class _PositivesPageState extends State<PositivesPage> {
  List<Map<String, Object?>> _rows = <Map<String, Object?>>[];
  List<Map<String, Object?>> _byCourse = <Map<String, Object?>>[];
  BehaviorRule _rule = const BehaviorRule();
  bool _loaded = false;

  @override
  void initState() {
    super.initState();
    _load();
    AppBus.data.addListener(_load);
  }

  @override
  void dispose() {
    AppBus.data.removeListener(_load);
    super.dispose();
  }

  Future<void> _load() async {
    final db = LuxDb.instance;
    final rows = await db.rawQuery(
      'SELECT p.*, c.name AS course_name FROM class_positives p '
      'LEFT JOIN courses c ON c.id = p.course_id ORDER BY p.at_ts DESC',
    );
    final by = await db.rawQuery(
      'SELECT c.name AS name, c.max_score AS max_score, '
      'SUM(CASE WHEN p.sign >= 0 THEN p.count ELSE 0 END) AS pos, '
      'SUM(CASE WHEN p.sign < 0 THEN p.count ELSE 0 END) AS neg '
      'FROM class_positives p JOIN courses c ON c.id = p.course_id GROUP BY c.id ORDER BY (pos - neg) DESC',
    );
    final rule = await StudyRepo.behaviorRule();
    if (!mounted) return;
    setState(() {
      _rows = rows;
      _byCourse = by;
      _rule = rule;
      _loaded = true;
    });
  }

  Future<void> _ruleEditor() {
    final pos = TextEditingController(text: latinNum(_rule.positiveValue));
    final neg = TextEditingController(text: latinNum(_rule.negativeValue));
    final cap = TextEditingController(text: latinNum(_rule.cap));
    return showLuxSheet<void>(
      context,
      (ctx) => Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Text('اثر روی نمره‌ی مستمر', style: LuxText.title),
          const SizedBox(height: 6),
          Text(
            'مثبت‌ها به نمره‌ی مستمرِ همان درس اضافه و منفی‌ها از آن کم می‌شوند (روی مقیاس ۲۰). نمره‌ی نهایی تحت‌تأثیر نیست.',
            style: LuxText.caption,
          ),
          const SizedBox(height: 16),
          Row(
            children: [
              Expanded(child: LuxField(label: 'هر مثبت (+)', controller: pos, keyboard: TextInputType.number)),
              const SizedBox(width: 12),
              Expanded(child: LuxField(label: 'هر منفی (−)', controller: neg, keyboard: TextInputType.number)),
            ],
          ),
          LuxField(
            label: 'سقفِ اثر در هر درس (±)',
            controller: cap,
            keyboard: TextInputType.number,
            hint: 'مثلاً ۲',
          ),
          LuxButton(
            label: 'ذخیره',
            onPressed: () async {
              final pv = parseNum(pos.text);
              final nv = parseNum(neg.text);
              final cv = parseNum(cap.text);
              if (pv == null || nv == null || cv == null || pv < 0 || nv < 0 || cv < 0) {
                luxNotice(ctx, 'همه‌ی مقدارها باید عددِ صفر یا بیشتر باشند.');
                return;
              }
              await StudyRepo.saveBehaviorRule(BehaviorRule(positiveValue: pv, negativeValue: nv, cap: cv));
              AppBus.bump();
              if (ctx.mounted) Navigator.of(ctx).pop();
            },
          ),
        ],
      ),
    );
  }

  Future<void> _editor({Map<String, Object?>? item}) {
    final isNew = item == null;
    int? cid = item == null || item['course_id'] == null ? null : asInt(item['course_id']);
    var count = asInt(item?['count'], 1).clamp(1, 10);
    var negative = asInt(item?['sign'], 1) < 0;
    var at = item == null ? DateTime.now() : fromTs(item['at_ts']);
    final note = TextEditingController(text: asStr(item?['note']));
    return showLuxSheet<void>(
      context,
      (ctx) => StatefulBuilder(builder: (ctx, setS) {
        final word = negative ? 'منفی' : 'مثبت';
        return Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Text(isNew ? 'ثبتِ مورد جدید' : 'ویرایش مورد', style: LuxText.title),
            const SizedBox(height: 16),
            LuxChoice(
              label: 'نوع',
              options: const ['مثبت', 'منفی'],
              selected: negative ? 1 : 0,
              onChanged: (i) => setS(() => negative = i == 1),
            ),
            LuxCourseChips(selectedId: cid, onChanged: (id) => setS(() => cid = id)),
            LuxChoice(
              label: 'تعداد $word',
              options: [for (var i = 1; i <= 5; i++) faDigits(i)],
              selected: count - 1,
              onChanged: (i) => setS(() => count = i + 1),
            ),
            LuxPickField(
              label: 'تاریخ',
              value: jalaliLabelWithDay(at),
              icon: Icons.event_rounded,
              onTap: () async {
                final d = await pickJalaliDateTime(ctx, initial: at, withTime: false);
                if (d != null) setS(() => at = d);
              },
            ),
            LuxField(label: 'یادداشت', controller: note, hint: 'اختیاری'),
            LuxButton(
              label: 'ذخیره',
              onPressed: () async {
                if (cid == null) {
                  luxNotice(ctx, 'درس را انتخاب کن.');
                  return;
                }
                int? teacherId;
                final cr = await LuxDb.instance.query('courses', where: 'id = ?', args: [cid], limit: 1);
                if (cr.isNotEmpty && cr.first['teacher_id'] != null) teacherId = asInt(cr.first['teacher_id']);
                final values = <String, Object?>{
                  'course_id': cid,
                  'teacher_id': teacherId,
                  'at_ts': at.millisecondsSinceEpoch,
                  'count': count,
                  'sign': negative ? -1 : 1,
                  'note': note.text.trim(),
                };
                if (isNew) {
                  await LuxDb.instance.insert('class_positives', values);
                } else {
                  await LuxDb.instance.update('class_positives', values, where: 'id = ?', args: [asInt(item!['id'])]);
                }
                AppBus.bump();
                if (ctx.mounted) Navigator.of(ctx).pop();
              },
            ),
            if (!isNew) ...[
              const SizedBox(height: 10),
              LuxButton(
                label: 'حذف',
                filled: false,
                onPressed: () async {
                  final ok = await luxConfirm(ctx, 'این مورد حذف شود؟');
                  if (!ok) return;
                  await LuxDb.instance.delete('class_positives', where: 'id = ?', args: [asInt(item!['id'])]);
                  AppBus.bump();
                  if (ctx.mounted) Navigator.of(ctx).pop();
                },
              ),
            ],
          ],
        );
      }),
    );
  }

  @override
  Widget build(BuildContext context) {
    var pos = 0;
    var neg = 0;
    for (final r in _rows) {
      if (asInt(r['sign'], 1) < 0) {
        neg += asInt(r['count'], 1);
      } else {
        pos += asInt(r['count'], 1);
      }
    }
    return LuxSubPage(
      title: 'مثبت و منفی',
      subtitle: 'مثبت ${faDigits(pos)} · منفی ${faDigits(neg)}',
      action: LuxAddButton(onTap: () => _editor()),
      children: [
        LuxCard(
          onTap: _ruleEditor,
          child: Row(
            children: [
              Icon(Icons.tune_rounded, color: LuxColors.accent),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('اثر روی نمره‌ی مستمر', style: LuxText.heading),
                    const SizedBox(height: 2),
                    Text(
                      'هر مثبت ${_signed(_rule.positiveValue)} · هر منفی ${_signed(-_rule.negativeValue)} · سقف ±${fmtNum(_rule.cap, dec: 2)}',
                      style: LuxText.caption,
                    ),
                  ],
                ),
              ),
              Icon(Icons.chevron_left_rounded, color: LuxColors.silverDim),
            ],
          ),
        ),
        const SizedBox(height: 16),
        if (_loaded && _rows.isEmpty)
          const LuxCard(
            child: LuxEmpty(
              icon: Icons.thumb_up_alt_rounded,
              title: 'موردی ثبت نشده',
              hint: 'هر وقت سر کلاس مثبت یا منفی گرفتی با دکمه‌ی + ثبتش کن.',
            ),
          )
        else ...[
          if (_byCourse.isNotEmpty)
            LuxSection(title: 'اثر روی هر درس', children: [
              for (final c in _byCourse)
                LuxRow(
                  title: asStr(c['name']),
                  subtitle: 'مثبت ${faDigits(asInt(c['pos']))} · منفی ${faDigits(asInt(c['neg']))}',
                  trailing: Builder(builder: (_) {
                    final d = _rule.delta(asInt(c['pos']), asInt(c['neg']), scale: asDouble(c['max_score'], 20));
                    return Text(
                      _signed(d),
                      style: LuxText.heading.copyWith(color: d < 0 ? LuxColors.danger : (d > 0 ? LuxColors.accent : LuxColors.textDim)),
                    );
                  }),
                ),
            ]),
          LuxSection(title: 'سابقه', children: [
            for (final r in _rows)
              LuxRow(
                leading: Icon(
                  asInt(r['sign'], 1) < 0 ? Icons.thumb_down_alt_rounded : Icons.thumb_up_alt_rounded,
                  color: asInt(r['sign'], 1) < 0 ? LuxColors.danger : LuxColors.accent,
                ),
                title: '${asStr(r['course_name'], 'بدون درس')} · ${faDigits(asInt(r['count'], 1))} ${asInt(r['sign'], 1) < 0 ? 'منفی' : 'مثبت'}',
                subtitle: [jalaliLabelWithDay(fromTs(r['at_ts'])), if (asStr(r['note']).isNotEmpty) asStr(r['note'])].join(' · '),
                onTap: () => _editor(item: r),
              ),
          ]),
        ],
      ],
    );
  }
}

// ───────────────────────── اخطارها ─────────────────────────

const List<String> _kWarnTypes = <String>['انضباطی', 'امنیتی', 'تحصیلی', 'سایر'];
const List<String> _kSeverity = <String>['سبک', 'متوسط', 'جدی'];

class WarningsPage extends StatefulWidget {
  const WarningsPage({super.key});

  @override
  State<WarningsPage> createState() => _WarningsPageState();
}

class _WarningsPageState extends State<WarningsPage> {
  List<Map<String, Object?>> _rows = <Map<String, Object?>>[];
  bool _loaded = false;

  @override
  void initState() {
    super.initState();
    _load();
    AppBus.data.addListener(_load);
  }

  @override
  void dispose() {
    AppBus.data.removeListener(_load);
    super.dispose();
  }

  Future<void> _load() async {
    final r = await LuxDb.instance.query('discipline_warnings', orderBy: 'resolved ASC, at_ts DESC');
    if (!mounted) return;
    setState(() {
      _rows = r;
      _loaded = true;
    });
  }

  Future<void> _editor({Map<String, Object?>? item}) {
    final isNew = item == null;
    var type = _kWarnTypes.indexOf(asStr(item?['type'], 'انضباطی'));
    if (type < 0) type = 0;
    var severity = asInt(item?['severity'], 1).clamp(1, 3);
    var at = item == null ? DateTime.now() : fromTs(item['at_ts']);
    DateTime? follow = item == null || item['followup_ts'] == null ? null : fromTs(item['followup_ts']);
    var resolved = asInt(item?['resolved']) == 1;
    final issuer = TextEditingController(text: asStr(item?['issuer']));
    final reason = TextEditingController(text: asStr(item?['reason']));
    final points = TextEditingController(text: item == null || item['points'] == null ? '' : latinNum(asDouble(item['points'])));
    final note = TextEditingController(text: asStr(item?['note']));
    return showLuxSheet<void>(
      context,
      (ctx) => StatefulBuilder(builder: (ctx, setS) {
        return Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Text(isNew ? 'اخطار جدید' : 'ویرایش اخطار', style: LuxText.title),
            const SizedBox(height: 16),
            LuxChoice(label: 'نوع', options: _kWarnTypes, selected: type, onChanged: (i) => setS(() => type = i)),
            LuxField(label: 'صادرکننده', controller: issuer, hint: 'مثلاً ناظم، معاون'),
            LuxField(label: 'دلیل', controller: reason, maxLines: 2),
            LuxChoice(label: 'شدت', options: _kSeverity, selected: severity - 1, onChanged: (i) => setS(() => severity = i + 1)),
            LuxField(label: 'نمره‌ی منفیِ انضباطی', controller: points, keyboard: TextInputType.number, hint: 'اختیاری'),
            LuxPickField(
              label: 'تاریخ اخطار',
              value: jalaliLabelWithDay(at),
              icon: Icons.event_rounded,
              onTap: () async {
                final d = await pickJalaliDateTime(ctx, initial: at, withTime: false);
                if (d != null) setS(() => at = d);
              },
            ),
            LuxPickField(
              label: 'تاریخ پیگیری',
              value: follow == null ? 'ندارد' : jalaliLabelWithDay(follow!),
              placeholder: follow == null,
              icon: Icons.event_available_rounded,
              onTap: () async {
                final d = await pickJalaliDateTime(ctx, initial: follow ?? DateTime.now(), withTime: false);
                if (d != null) setS(() => follow = d);
              },
            ),
            LuxChoice(
              label: 'وضعیت',
              options: const ['در حال پیگیری', 'حل شد'],
              selected: resolved ? 1 : 0,
              onChanged: (i) => setS(() => resolved = i == 1),
            ),
            LuxField(label: 'یادداشت', controller: note, maxLines: 2),
            LuxButton(
              label: 'ذخیره',
              onPressed: () async {
                if (reason.text.trim().isEmpty) {
                  luxNotice(ctx, 'دلیل اخطار را بنویس.');
                  return;
                }
                final values = <String, Object?>{
                  'at_ts': at.millisecondsSinceEpoch,
                  'type': _kWarnTypes[type],
                  'issuer': issuer.text.trim(),
                  'reason': reason.text.trim(),
                  'severity': severity,
                  'points': parseNum(points.text),
                  'followup_ts': follow?.millisecondsSinceEpoch,
                  'resolved': resolved ? 1 : 0,
                  'note': note.text.trim(),
                };
                if (isNew) {
                  await LuxDb.instance.insert('discipline_warnings', values);
                } else {
                  await LuxDb.instance.update('discipline_warnings', values, where: 'id = ?', args: [asInt(item!['id'])]);
                }
                AppBus.bump();
                if (ctx.mounted) Navigator.of(ctx).pop();
              },
            ),
            if (!isNew) ...[
              const SizedBox(height: 10),
              LuxButton(
                label: 'حذف',
                filled: false,
                onPressed: () async {
                  final ok = await luxConfirm(ctx, 'این اخطار حذف شود؟');
                  if (!ok) return;
                  await LuxDb.instance.delete('discipline_warnings', where: 'id = ?', args: [asInt(item!['id'])]);
                  AppBus.bump();
                  if (ctx.mounted) Navigator.of(ctx).pop();
                },
              ),
            ],
          ],
        );
      }),
    );
  }

  @override
  Widget build(BuildContext context) {
    final open = _rows.where((r) => asInt(r['resolved']) == 0).length;
    return LuxSubPage(
      title: 'اخطارها',
      subtitle: _rows.isEmpty ? 'اخطار انضباطی و پیگیری' : '${faDigits(open)} مورد در حال پیگیری',
      action: LuxAddButton(onTap: () => _editor()),
      children: [
        if (_loaded && _rows.isEmpty)
          const LuxCard(child: LuxEmpty(icon: Icons.report_gmailerrorred_rounded, title: 'اخطاری ثبت نشده', hint: 'اگر اخطاری گرفتی، اینجا ثبت و پیگیری‌اش کن.'))
        else
          LuxSection(title: 'همه‌ی اخطارها', children: [
            for (final r in _rows)
              LuxRow(
                leading: Icon(
                  asInt(r['resolved']) == 1 ? Icons.check_circle_rounded : Icons.error_outline_rounded,
                  color: asInt(r['resolved']) == 1 ? LuxColors.ok : (asInt(r['severity']) >= 3 ? LuxColors.danger : LuxColors.warn),
                ),
                title: asStr(r['reason']),
                subtitle: [
                  asStr(r['type']),
                  jalaliLabel(fromTs(r['at_ts'])),
                  if (asStr(r['issuer']).isNotEmpty) asStr(r['issuer']),
                  if (r['followup_ts'] != null && asInt(r['resolved']) == 0) 'پیگیری ${relativeDay(fromTs(r['followup_ts']))}',
                ].join(' · '),
                onTap: () => _editor(item: r),
              ),
          ]),
      ],
    );
  }
}
