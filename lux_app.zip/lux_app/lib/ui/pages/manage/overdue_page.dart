import 'package:flutter/material.dart';

import '../../../core/app_bus.dart';
import '../../../core/jalali_utils.dart';
import '../../../core/palette.dart';
import '../../../core/theme.dart';
import '../../../core/util.dart';
import '../../../data/database.dart';
import '../../../data/reminders.dart';
import '../../widgets/day_picker.dart';
import '../../widgets/lux_button.dart';
import '../../widgets/lux_card.dart';
import '../../widgets/lux_kit.dart';
import '../../widgets/lux_section.dart';
import 'task_pages.dart';

/// تعدادِ تکلیف‌های بازِ عقب‌افتاده (موعدشان گذشته)
Future<int> overdueTaskCount() async {
  final r = await LuxDb.instance.rawQuery(
    "SELECT COUNT(*) AS n FROM tasks WHERE status = 'open' AND due_ts IS NOT NULL AND due_ts < ?",
    [DateTime.now().millisecondsSinceEpoch],
  );
  return asInt(r.first['n']);
}

class OverduePage extends StatefulWidget {
  const OverduePage({super.key});

  @override
  State<OverduePage> createState() => _OverduePageState();
}

class _OverduePageState extends State<OverduePage> {
  static const List<int> _caps = <int>[2, 3, 4, 6];

  List<Map<String, Object?>> _tasks = <Map<String, Object?>>[];
  int _cap = 4;
  int _compDay = 6; // جمعه
  bool _loaded = false;

  @override
  void initState() {
    super.initState();
    _load();
    AppBus.data.addListener(_load);
  }

  @override
  void dispose() {
    AppBus.data.removeListener(_load);
    super.dispose();
  }

  Future<void> _load() async {
    final db = LuxDb.instance;
    final rows = await db.rawQuery(
      'SELECT t.*, c.name AS course FROM tasks t LEFT JOIN courses c ON c.id = t.course_id '
      "WHERE t.status = 'open' AND t.due_ts IS NOT NULL AND t.due_ts < ? ORDER BY t.due_ts",
      [DateTime.now().millisecondsSinceEpoch],
    );
    final cap = int.tryParse(await db.kvGet('cap_tasks_day') ?? '') ?? 4;
    final comp = int.tryParse(await db.kvGet('comp_weekday') ?? '') ?? 6;
    if (!mounted) return;
    setState(() {
      _tasks = rows;
      _cap = cap;
      _compDay = comp.clamp(0, 6).toInt();
      _loaded = true;
    });
  }

  Future<void> _setDue(Map<String, Object?> t, DateTime due) async {
    final id = asInt(t['id']);
    await LuxDb.instance.update('tasks', <String, Object?>{'due_ts': due.millisecondsSinceEpoch}, where: 'id = ?', args: [id]);
    try {
      await Reminders.syncTask(id);
    } catch (_) {}
  }

  DateTime _evening(DateTime day) => DateTime(day.year, day.month, day.day, 17);

  DateTime _nextWeekday(int w) {
    final today = dateOnly(DateTime.now());
    for (var i = 1; i <= 7; i++) {
      final d = DateTime(today.year, today.month, today.day + i);
      if (weekdayIndex(d) == w) return d;
    }
    return DateTime(today.year, today.month, today.day + 1);
  }

  Future<void> _moveAllToCompDay() async {
    final d = _nextWeekday(_compDay);
    for (final t in _tasks) {
      await _setDue(t, _evening(d));
    }
    AppBus.bump();
    if (mounted) luxToast(context, 'همه به ${jalaliWeekdays[_compDay]} رفتن.');
  }

  /// کارها را بر اساس اولویت و قدمت، بین روزهای آینده پخش می‌کند؛ هر روز حداکثر [_cap] کار.
  Future<void> _distribute() async {
    final db = LuxDb.instance;
    final now = DateTime.now();
    var start = dateOnly(now);
    if (now.hour >= 20) start = DateTime(start.year, start.month, start.day + 1);

    // کارهای بازِ موجود در ۶۰ روز آینده، تا ظرفیتِ هر روز درست حساب شود
    final endMs = DateTime(start.year, start.month, start.day + 60).millisecondsSinceEpoch;
    final existing = await db.rawQuery(
      "SELECT due_ts FROM tasks WHERE status = 'open' AND due_ts >= ? AND due_ts < ?",
      [start.millisecondsSinceEpoch, endMs],
    );
    final load = <String, int>{};
    for (final r in existing) {
      final k = _key(fromTs(r['due_ts']));
      load[k] = (load[k] ?? 0) + 1;
    }

    final sorted = List<Map<String, Object?>>.from(_tasks)
      ..sort((a, b) {
        final pr = asInt(b['priority'], 2).compareTo(asInt(a['priority'], 2));
        if (pr != 0) return pr;
        return asInt(a['due_ts']).compareTo(asInt(b['due_ts']));
      });

    final usedDays = <String>{};
    var day = start;
    for (final t in sorted) {
      var guard = 0;
      while (guard < 120) {
        final k = _key(day);
        final off = weekdayIndex(day) == 6;
        if (!off && (load[k] ?? 0) < _cap) break;
        day = DateTime(day.year, day.month, day.day + 1);
        guard++;
      }
      final k = _key(day);
      load[k] = (load[k] ?? 0) + 1;
      usedDays.add(k);
      await _setDue(t, _evening(day));
    }
    AppBus.bump();
    if (mounted) luxToast(context, '${faDigits(sorted.length)} کار توی ${faDigits(usedDays.length)} روز پخش شد.');
  }

  String _key(DateTime d) => '${d.year}-${two(d.month)}-${two(d.day)}';

  Future<void> _taskActions(Map<String, Object?> t) async {
    final now = DateTime.now();
    Widget row(IconData icon, String title, String sub, Future<void> Function() act) => LuxRow(
          leading: Icon(icon, color: LuxColors.accent),
          title: title,
          subtitle: sub,
          onTap: () async {
            Navigator.of(context).pop();
            await act();
            AppBus.bump();
          },
        );
    final plus1 = now.add(const Duration(hours: 1));
    final base = DateTime(now.year, now.month, now.day, 18);
    final tonight = plus1.isAfter(base) ? plus1 : base;
    final tomorrow = DateTime(now.year, now.month, now.day + 1);
    final comp = _nextWeekday(_compDay);

    await showLuxSheet<void>(
      context,
      (ctx) => Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Text(asStr(t['title']), style: LuxText.title),
          const SizedBox(height: 12),
          row(Icons.check_circle_rounded, 'انجام شده بود', 'از لیستِ عقب‌افتاده‌ها بیرون می‌ره', () => toggleTask(t)),
          if (tonight.day == now.day)
            row(Icons.nights_stay_rounded, 'امروز', 'ساعت ${two(tonight.hour)}:${two(tonight.minute)}', () => _setDue(t, tonight)),
          row(Icons.wb_sunny_rounded, 'فردا', jalaliLabelWithDay(tomorrow), () => _setDue(t, _evening(tomorrow))),
          row(Icons.event_repeat_rounded, 'روز جبرانی (${jalaliWeekdays[_compDay]})', jalaliLabelWithDay(comp), () => _setDue(t, _evening(comp))),
          row(Icons.calendar_month_rounded, 'یک تاریخِ دیگر…', 'خودت انتخاب کن', () async {
            final d = await pickJalaliDay(context, initial: tomorrow);
            if (d != null) await _setDue(t, _evening(d));
          }),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final today = dateOnly(DateTime.now());
    return LuxSubPage(
      title: 'عقب‌افتاده‌ها',
      subtitle: _tasks.isEmpty ? 'هیچ کاری عقب نیفتاده' : '${faDigits(_tasks.length)} کارِ موعد‌گذشته',
      children: [
        if (_loaded && _tasks.isEmpty)
          const LuxCard(
            child: LuxEmpty(icon: Icons.verified_rounded, title: 'همه‌چی سر وقته 🎉', hint: 'کارهایی که موعدشون بگذره و انجام نشن، اینجا جمع می‌شن.'),
          )
        else ...[
          LuxCard(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Text('جبرانِ عقب‌افتادگی', style: LuxText.heading),
                const SizedBox(height: 4),
                Text('لوکس کارها رو بر اساس اولویت و قدمت، بین روزهای آینده پخش می‌کنه تا هیچ روزی سنگین نشه.', style: LuxText.caption),
                const SizedBox(height: 14),
                LuxChoice(
                  label: 'حداکثر کار در هر روز',
                  options: [for (final c in _caps) faDigits(c)],
                  selected: _caps.indexOf(_cap).clamp(0, _caps.length - 1).toInt(),
                  onChanged: (i) async {
                    await LuxDb.instance.kvSet('cap_tasks_day', _caps[i].toString());
                    setState(() => _cap = _caps[i]);
                  },
                ),
                LuxChoice(
                  label: 'روز جبرانی هفتگی',
                  options: jalaliWeekdays,
                  selected: _compDay,
                  onChanged: (i) async {
                    await LuxDb.instance.kvSet('comp_weekday', i.toString());
                    setState(() => _compDay = i);
                  },
                ),
                LuxButton(label: 'پخشِ خودکار در روزهای آینده', icon: Icons.auto_fix_high_rounded, onPressed: _distribute),
                const SizedBox(height: 10),
                LuxButton(
                  label: 'همه رو بفرست به ${jalaliWeekdays[_compDay]}',
                  icon: Icons.event_repeat_rounded,
                  filled: false,
                  onPressed: _moveAllToCompDay,
                ),
              ],
            ),
          ),
          const SizedBox(height: 16),
          LuxSection(
            title: 'لیست',
            children: [
              for (final t in _tasks)
                LuxRow(
                  leading: Icon(Icons.schedule_rounded, color: priorityColor(asInt(t['priority'], 2))),
                  title: asStr(t['title']),
                  subtitle: [
                    if (asStr(t['course']).isNotEmpty) asStr(t['course']),
                    '${faDigits(daysBetween(dateOnly(fromTs(t['due_ts'])), today))} روز عقب',
                  ].join(' · '),
                  onTap: () => _taskActions(t),
                ),
            ],
          ),
        ],
      ],
    );
  }
}
