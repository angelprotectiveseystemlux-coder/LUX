import 'dart:async';

import 'package:flutter/material.dart';

import '../../../core/app_bus.dart';
import '../../../core/jalali_utils.dart';
import '../../../core/palette.dart';
import '../../../core/theme.dart';
import '../../../core/util.dart';
import '../../../data/database.dart';
import '../../../data/exam_ask_store.dart';
import '../../../data/reminders.dart';
import '../../widgets/haptic.dart';
import '../../widgets/lux_button.dart';
import '../../widgets/lux_chip.dart';
import '../../widgets/lux_kit.dart';
import 'exam_pages.dart';

/// بعد از امتحان (مثلاً ساعت ۲ که از مدرسه برگشتی) می‌پرسد «امتحان چطور بود؟».
class ExamAskPrompt {
  ExamAskPrompt._();

  static bool _showing = false;

  static const List<String> feels = <String>['عالی', 'خوب', 'معمولی', 'بد', 'خیلی بد'];

  static Future<void> maybeAsk(BuildContext context) async {
    if (_showing) return;
    List<Map<String, Object?>> due;
    try {
      due = await ExamAskStore.due();
    } catch (_) {
      return;
    }
    if (due.isEmpty || !context.mounted) return;
    _showing = true;
    try {
      await _ask(context, due.first);
    } finally {
      _showing = false;
    }
  }

  static Future<void> _ask(BuildContext context, Map<String, Object?> exam) async {
    final id = asInt(exam['id']);
    final db = LuxDb.instance;
    int? picked;

    Future<void> markDone() => db.kvSet(ExamAskStore.doneKey(id), '1');

    await showLuxSheet<void>(
      context,
      (ctx) => StatefulBuilder(builder: (ctx, setS) {
        return Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Text('امتحان ${asStr(exam['course_name'])} چطور بود؟', style: LuxText.title),
            const SizedBox(height: 4),
            Text('${examTitle(<String, Object?>{...exam, 'course_name': exam['course_name']})} · ${jalaliLabelWithDay(fromTs(exam['at_ts']))}', style: LuxText.caption),
            const SizedBox(height: 16),
            Text('حالِ خودت بعد از امتحان', style: LuxText.label),
            const SizedBox(height: 10),
            Wrap(spacing: 8, runSpacing: 8, children: [
              for (var i = 0; i < feels.length; i++)
                LuxChip(
                  label: feels[i],
                  selected: picked == i,
                  onTap: () async {
                    Haptic.tap();
                    setS(() => picked = i);
                    await db.kvSet(ExamAskStore.feelKey(id), '$i');
                  },
                ),
            ]),
            const SizedBox(height: 18),
            LuxButton(
              label: 'نمره‌اش را ثبت کن',
              icon: Icons.grade_rounded,
              onPressed: () async {
                await markDone();
                if (ctx.mounted) Navigator.of(ctx).pop();
                if (context.mounted) unawaited(showExamResult(context, exam));
              },
            ),
            const SizedBox(height: 8),
            LuxButton(
              label: 'هنوز نمره نیامده',
              filled: false,
              onPressed: () async {
                await markDone();
                AppBus.bump();
                if (ctx.mounted) Navigator.of(ctx).pop();
              },
            ),
            const SizedBox(height: 8),
            Row(
              children: [
                Expanded(
                  child: LuxButton(
                    label: 'دو ساعت بعد',
                    filled: false,
                    compact: true,
                    onPressed: () async {
                      await db.kvSet(ExamAskStore.snoozeKey(id), '${DateTime.now().add(const Duration(hours: 2)).millisecondsSinceEpoch}');
                      if (ctx.mounted) Navigator.of(ctx).pop();
                    },
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: LuxButton(
                    label: 'امتحان لغو شد',
                    filled: false,
                    compact: true,
                    onPressed: () async {
                      await db.update('exams', <String, Object?>{'status': 'canceled'}, where: 'id = ?', args: [id]);
                      await Reminders.cancelExam(id);
                      await markDone();
                      AppBus.bump();
                      if (ctx.mounted) Navigator.of(ctx).pop();
                    },
                  ),
                ),
              ],
            ),
          ],
        );
      }),
    );
    // اگر کاربر بدون جواب بستش، تا ۲ ساعت دیگر نمی‌پرسیم.
    final stillDue = await db.kvGet(ExamAskStore.doneKey(id)) != '1' && await db.kvGet(ExamAskStore.snoozeKey(id)) == null;
    if (stillDue) {
      await db.kvSet(ExamAskStore.snoozeKey(id), '${DateTime.now().add(const Duration(hours: 2)).millisecondsSinceEpoch}');
    }
  }
}
