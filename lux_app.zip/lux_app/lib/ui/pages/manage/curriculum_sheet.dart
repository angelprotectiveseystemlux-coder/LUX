import 'package:flutter/material.dart';
import '../../../core/app_bus.dart';
import '../../../core/jalali_utils.dart';
import '../../../core/palette.dart';
import '../../../core/theme.dart';
import '../../../data/curriculum.dart';
import '../../../data/database.dart';
import '../../../data/profile_repo.dart';
import '../../widgets/haptic.dart';
import '../../widgets/lux_button.dart';
import '../../widgets/lux_kit.dart';

String _norm(String s) => enDigits(s)
    .replaceAll('ي', 'ی')
    .replaceAll('ك', 'ک')
    .replaceAll('\u200c', '')
    .replaceAll(' ', '')
    .trim();

/// فهرستِ آماده‌ی دروسِ پایه و رشته‌ی کاربر را نشان می‌دهد و می‌پرسد:
/// «از روی فهرست اضافه کنم یا خودت اضافه می‌کنی؟»
/// تعدادِ درس‌های اضافه‌شده را برمی‌گرداند (۰ یعنی کاربر خودش اضافه می‌کند).
/// این برگه همیشه از صفحه‌ی «درس‌ها» و «پروفایل» در دسترس است.
Future<int> showCurriculumSheet(BuildContext context) async {
  final pr = await ProfileRepo.get();
  if (!context.mounted) return 0;
  if (pr == null || !Curriculum.has(pr.track, pr.grade)) {
    await luxNotice(
      context,
      'برای این پایه و رشته هنوز فهرستِ آماده نداریم (فهرست‌ها برای رشته‌های تجربی، ریاضی و انسانیِ پایه‌های دهم تا دوازدهم است). درس‌ها را خودت اضافه کن.',
    );
    return 0;
  }

  final list = Curriculum.coursesFor(pr.track, pr.grade);
  var loaded = false;
  var existing = <String>{};
  final picked = <int>{};

  Future<void> loadExisting(void Function() refresh) async {
    final rows = await LuxDb.instance.query('courses');
    existing = {for (final r in rows) _norm((r['name'] ?? '').toString())};
    picked
      ..clear()
      ..addAll([
        for (var i = 0; i < list.length; i++)
          if (!existing.contains(_norm(list[i].name))) i,
      ]);
    refresh();
  }

  final added = await showLuxSheet<int>(
    context,
    (ctx) => StatefulBuilder(builder: (ctx, setS) {
      if (!loaded) {
        loaded = true;
        loadExisting(() {
          if (ctx.mounted) setS(() {});
        });
      }
      final selectable = [
        for (var i = 0; i < list.length; i++)
          if (!existing.contains(_norm(list[i].name))) i,
      ];
      final allOn = selectable.isNotEmpty && picked.length == selectable.length;

      Widget row(int i) {
        final c = list[i];
        final have = existing.contains(_norm(c.name));
        final on = picked.contains(i);
        final tag = have
            ? 'اضافه شده'
            : (c.coef != null ? 'ضریب ${fmtNum(c.coef!, dec: 2)}' : 'بدون ضریب');
        return GestureDetector(
          behavior: HitTestBehavior.opaque,
          onTap: have
              ? null
              : () {
                  Haptic.tap();
                  setS(() => on ? picked.remove(i) : picked.add(i));
                },
          child: Padding(
            padding: const EdgeInsets.symmetric(vertical: 10),
            child: Row(
              children: [
                Icon(
                  have
                      ? Icons.check_circle_outline_rounded
                      : (on ? Icons.check_circle_rounded : Icons.radio_button_unchecked_rounded),
                  color: have ? LuxColors.textDim : (on ? LuxColors.accent : LuxColors.silverDim),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Text(c.name, style: LuxText.body.copyWith(color: have ? LuxColors.textDim : LuxColors.text)),
                ),
                const SizedBox(width: 8),
                Text(
                  tag,
                  style: LuxText.caption.copyWith(
                    color: (!have && c.coef != null) ? LuxColors.accent : LuxColors.textDim,
                  ),
                ),
              ],
            ),
          ),
        );
      }

      return Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Text('درس‌های ${pr.gradeLabel} ${Curriculum.trackTitle(pr.track)}', style: LuxText.title),
          const SizedBox(height: 8),
          Text(
            'می‌خواهی درس‌ها را از روی فهرستِ آماده اضافه کنم یا خودت اضافه می‌کنی؟ '
            'ضریب‌ها همان «ضریب سوابق تحصیلی کنکور» هستند؛ درس‌هایی که در جدول ضریب ندارند با ضریب '
            '${fmtNum(Curriculum.defaultCoef)} اضافه می‌شوند و بعداً قابل ویرایش‌اند.',
            style: LuxText.body,
          ),
          const SizedBox(height: 12),
          if (selectable.isNotEmpty)
            Align(
              alignment: AlignmentDirectional.centerStart,
              child: TextButton(
                onPressed: () => setS(() {
                  if (allOn) {
                    picked.clear();
                  } else {
                    picked
                      ..clear()
                      ..addAll(selectable);
                  }
                }),
                child: Text(allOn ? 'برداشتنِ همه' : 'انتخاب همه', style: LuxText.label.copyWith(color: LuxColors.accent)),
              ),
            ),
          for (var i = 0; i < list.length; i++) row(i),
          const SizedBox(height: 14),
          LuxButton(
            label: picked.isEmpty ? 'افزودن' : 'افزودن ${faDigits(picked.length)} درس',
            icon: Icons.playlist_add_rounded,
            onPressed: picked.isEmpty
                ? null
                : () async {
                    final db = LuxDb.instance;
                    final base = await db.count('courses');
                    final order = picked.toList()..sort();
                    var k = 0;
                    for (final i in order) {
                      final c = list[i];
                      await db.insert('courses', <String, Object?>{
                        'name': c.name,
                        'coef': c.coef ?? Curriculum.defaultCoef,
                        'difficulty': 3,
                        'max_score': 20.0,
                        'pass_score': 10.0,
                        'color': (base + k) % LuxColors.series.length,
                        'notes': '',
                        'created_at': DateTime.now().millisecondsSinceEpoch,
                      });
                      k++;
                    }
                    AppBus.bump();
                    if (ctx.mounted) Navigator.of(ctx).pop(order.length);
                  },
          ),
          const SizedBox(height: 10),
          LuxButton(label: 'خودم اضافه می‌کنم', filled: false, onPressed: () => Navigator.of(ctx).pop(0)),
        ],
      );
    }),
  );
  return added ?? 0;
}

/// یک‌بار برای هر ترکیبِ «رشته + پایه» می‌پرسد؛ بعد از آن فقط از طریق دکمه‌ها در دسترس است.
Future<void> offerCurriculumOnce(BuildContext context, {bool force = false}) async {
  final pr = await ProfileRepo.get();
  if (pr == null || !Curriculum.has(pr.track, pr.grade)) return;
  final key = '${pr.track}|${pr.grade}';
  if (!force && await LuxDb.instance.kvGet('curriculum_asked') == key) return;
  // پیش از نمایش ثبت می‌شود تا با بستنِ برگه دوباره مزاحم نشویم.
  await LuxDb.instance.kvSet('curriculum_asked', key);
  if (!context.mounted) return;
  final n = await showCurriculumSheet(context);
  if (n > 0 && context.mounted) luxToast(context, '${faDigits(n)} درس اضافه شد.');
}
