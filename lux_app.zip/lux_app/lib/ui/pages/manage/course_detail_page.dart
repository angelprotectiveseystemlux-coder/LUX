import 'package:flutter/material.dart';
import '../../../core/app_bus.dart';
import '../../../core/jalali_utils.dart';
import '../../../core/palette.dart';
import '../../../core/theme.dart';
import '../../../core/util.dart';
import '../../../data/database.dart';
import '../../../engine/grades.dart';
import '../../widgets/lux_card.dart';
import '../../widgets/lux_chip.dart';
import '../../widgets/lux_kit.dart';
import '../../widgets/lux_section.dart';
import 'editors.dart';

class CourseDetailPage extends StatefulWidget {
  final int courseId;
  const CourseDetailPage({super.key, required this.courseId});

  @override
  State<CourseDetailPage> createState() => _CourseDetailPageState();
}

class _CourseDetailPageState extends State<CourseDetailPage> {
  Map<String, Object?>? _course;
  String _teacher = '';
  List<Map<String, Object?>> _slots = <Map<String, Object?>>[];
  List<Map<String, Object?>> _grades = <Map<String, Object?>>[];
  int _target = 18;
  bool _gone = false;

  @override
  void initState() {
    super.initState();
    _load();
    AppBus.data.addListener(_load);
  }

  @override
  void dispose() {
    AppBus.data.removeListener(_load);
    super.dispose();
  }

  Future<void> _load() async {
    final db = LuxDb.instance;
    final rows = await db.query('courses', where: 'id = ?', args: [widget.courseId], limit: 1);
    if (rows.isEmpty) {
      if (mounted) setState(() => _gone = true);
      return;
    }
    final c = rows.first;
    final tn = await teacherName(c['teacher_id'] == null ? null : asInt(c['teacher_id']));
    final slots = await db.query('class_slots', where: 'course_id = ?', args: [widget.courseId], orderBy: 'weekday, start_min');
    final grades = await db.query('grades', where: 'course_id = ?', args: [widget.courseId], orderBy: 'at_ts DESC');
    if (!mounted) return;
    setState(() {
      _course = c;
      _teacher = tn;
      _slots = slots;
      _grades = grades;
    });
  }

  List<WeightedScore> get _items => [
        for (final g in _grades)
          WeightedScore(asDouble(g['score']), asDouble(g['max_score'], 20), asDouble(g['weight'], 1)),
      ];

  Future<void> _deleteCourse() async {
    final ok = await luxConfirm(
      context,
      'حذف این درس؟',
      body: 'نمره‌ها، امتحان‌ها و ساعت‌های کلاسِ این درس هم پاک می‌شوند. این کار برگشت ندارد.',
    );
    if (!ok) return;
    await LuxDb.instance.delete('courses', where: 'id = ?', args: [widget.courseId]);
    AppBus.bump();
    if (mounted) Navigator.of(context).pop();
  }

  Widget _targetCard() {
    final items = _items;
    final c = _course!;
    final scale = asDouble(c['max_score'], 20);
    final avg = GradeMath.weightedAverage(items, scale: scale);
    final req = avg == null
        ? null
        : GradeMath.requiredScore(
            sumWeighted: GradeMath.sumWeightedOf(items, scale: scale),
            sumWeights: GradeMath.sumWeightsOf(items),
            nextWeight: 1,
            target: _target.toDouble() * scale / 20,
            scale: scale,
          );
    String text;
    Color color = LuxColors.textDim;
    if (req == null) {
      text = 'بعد از ثبتِ اولین نمره، نمره‌ی لازم برای رسیدن به هدف اینجا حساب می‌شود.';
    } else if (req.alreadySafe) {
      text = 'هدفِ ${faDigits(_target)} با همین وضع تضمین است.';
      color = LuxColors.ok;
    } else if (!req.possible) {
      text = 'با یک ارزیابیِ دیگر (وزن ۱) به ${faDigits(_target)} نمی‌رسی؛ ارزیابی‌های بیشتری لازم است.';
      color = LuxColors.warn;
    } else {
      text = 'برای رسیدن به معدلِ ${faDigits(_target)}، در ارزیابیِ بعدی (وزن ۱) حداقل ${fmtNum(req.neededOnScale, dec: 2)} بگیر.';
      color = LuxColors.accent;
    }
    return LuxCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('هدف معدل این درس', style: LuxText.heading),
          const SizedBox(height: 12),
          Wrap(spacing: 8, runSpacing: 8, children: [
            for (final t in const [15, 16, 17, 18, 19, 20])
              LuxChip(label: faDigits(t), selected: _target == t, onTap: () => setState(() => _target = t)),
          ]),
          const SizedBox(height: 12),
          Text(text, style: LuxText.body.copyWith(color: color)),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final c = _course;
    if (_gone) {
      return const LuxSubPage(title: 'درس', children: [LuxEmpty(icon: Icons.menu_book_rounded, title: 'این درس دیگر وجود ندارد')]);
    }
    if (c == null) {
      return const LuxSubPage(title: 'درس', children: [Center(child: CircularProgressIndicator(color: LuxColors.accent))]);
    }
    final scale = asDouble(c['max_score'], 20);
    final avg = GradeMath.weightedAverage(_items, scale: scale);
    final pass = asDouble(c['pass_score'], 10);
    final diff = asInt(c['difficulty'], 3).clamp(1, 5);

    return LuxSubPage(
      title: asStr(c['name']),
      subtitle: _teacher.isEmpty ? 'بدون معلم' : 'معلم: $_teacher',
      action: LuxAddButton(icon: Icons.edit_rounded, onTap: () => showCourseEditor(context, course: c)),
      children: [
        LuxCard(
          radius: 28,
          child: Row(
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('میانگین', style: LuxText.caption),
                    const SizedBox(height: 6),
                    Text(
                      avg == null ? '—' : latinNum(avg, dec: 2),
                      style: LuxText.dot(40, color: avg == null || avg >= pass ? LuxColors.accent : LuxColors.danger),
                    ),
                  ],
                ),
              ),
              Column(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Text('ضریب ${fmtNum(asDouble(c['coef'], 1))}', style: LuxText.body),
                  Text('سختی: ${kDifficulty[diff - 1]}', style: LuxText.caption),
                  Text('نمره‌ی ${fmtNum(scale)} · قبولی ${fmtNum(pass)}', style: LuxText.caption),
                ],
              ),
            ],
          ),
        ),
        const SizedBox(height: 16),
        _targetCard(),
        const SizedBox(height: 22),
        LuxSection(title: 'نمره‌ها', children: [
          if (_grades.isEmpty)
            const LuxEmpty(icon: Icons.grade_rounded, title: 'نمره‌ای ثبت نشده', hint: 'با دکمه‌ی پایین اولین نمره را اضافه کن.')
          else
            for (final g in _grades)
              LuxRow(
                title: asStr(g['name']).isEmpty ? 'نمره' : asStr(g['name']),
                subtitle: '${jalaliLabel(fromTs(g['at_ts']))} · وزن ${fmtNum(asDouble(g['weight'], 1))}',
                trailing: Text(
                  '${fmtNum(asDouble(g['score']), dec: 2)} / ${fmtNum(asDouble(g['max_score'], 20))}',
                  style: LuxText.heading.copyWith(color: LuxColors.accent),
                ),
                onTap: () => showGradeEditor(context, courseId: widget.courseId, grade: g),
              ),
          LuxRow(
            leading: const Icon(Icons.add_circle_outline_rounded, color: LuxColors.accent),
            title: 'افزودن نمره',
            onTap: () => showGradeEditor(context, courseId: widget.courseId),
          ),
        ]),
        LuxSection(title: 'ساعت‌های کلاس', children: [
          if (_slots.isEmpty)
            const LuxEmpty(icon: Icons.schedule_rounded, title: 'ساعتی ثبت نشده'),
          for (final s in _slots)
            LuxRow(
              title: weekdayName(asInt(s['weekday'])),
              subtitle: asStr(s['room']).isEmpty ? null : 'کلاس ${asStr(s['room'])}',
              trailing: Text(
                '${minutesLabel(asInt(s['start_min']))} – ${minutesLabel(asInt(s['end_min']))}',
                style: LuxText.body,
              ),
              onTap: () => showSlotEditor(context, courseId: widget.courseId, slot: s),
            ),
          LuxRow(
            leading: const Icon(Icons.add_circle_outline_rounded, color: LuxColors.accent),
            title: 'افزودن ساعت کلاس',
            onTap: () => showSlotEditor(context, courseId: widget.courseId),
          ),
        ]),
        if (asStr(c['notes']).isNotEmpty)
          LuxSection(title: 'یادداشت', children: [
            Padding(padding: const EdgeInsets.all(18), child: Text(asStr(c['notes']), style: LuxText.body)),
          ]),
        const SizedBox(height: 4),
        GestureDetector(
          onTap: _deleteCourse,
          child: Padding(
            padding: const EdgeInsets.all(14),
            child: Text('حذف این درس', textAlign: TextAlign.center, style: LuxText.label.copyWith(color: LuxColors.danger)),
          ),
        ),
      ],
    );
  }
}
