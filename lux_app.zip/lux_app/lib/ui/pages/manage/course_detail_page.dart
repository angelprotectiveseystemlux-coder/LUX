import 'package:flutter/material.dart';
import '../../../core/app_bus.dart';
import '../../../core/jalali_utils.dart';
import '../../../core/palette.dart';
import '../../../core/theme.dart';
import '../../../core/util.dart';
import '../../../data/database.dart';
import '../../../data/smart_repo.dart';
import '../../../data/study_repo.dart';
import '../../../engine/grades.dart';
import '../../widgets/lux_card.dart';
import '../../widgets/lux_chip.dart';
import '../../widgets/lux_kit.dart';
import '../../widgets/lux_section.dart';
import '../../widgets/lux_button.dart';
import 'book_pages.dart';
import 'editors.dart';
import 'exam_pages.dart';
import 'record_pages.dart';
import 'task_pages.dart';

class CourseDetailPage extends StatefulWidget {
  final int courseId;
  const CourseDetailPage({super.key, required this.courseId});

  @override
  State<CourseDetailPage> createState() => _CourseDetailPageState();
}

class _CourseDetailPageState extends State<CourseDetailPage> {
  Map<String, Object?>? _course;
  String _teacher = '';
  List<Map<String, Object?>> _slots = <Map<String, Object?>>[];
  List<Map<String, Object?>> _grades = <Map<String, Object?>>[];
  List<Map<String, Object?>> _books = <Map<String, Object?>>[];
  TermScore? _term;
  List<int> _beh = <int>[0, 0]; // [مثبت، منفی]
  int _target = 18;
  bool _gone = false;

  @override
  void initState() {
    super.initState();
    _load();
    AppBus.data.addListener(_load);
  }

  @override
  void dispose() {
    AppBus.data.removeListener(_load);
    super.dispose();
  }

  Future<void> _load() async {
    final db = LuxDb.instance;
    final rows = await db.query('courses', where: 'id = ?', args: [widget.courseId], limit: 1);
    if (rows.isEmpty) {
      if (mounted) setState(() => _gone = true);
      return;
    }
    final c = rows.first;
    final tn = await teacherName(c['teacher_id'] == null ? null : asInt(c['teacher_id']));
    final slots = await db.query('class_slots', where: 'course_id = ?', args: [widget.courseId], orderBy: 'weekday, start_min');
    final grades = await StudyRepo.gradesOfCourse(widget.courseId);
    final term = await StudyRepo.termScoreOf(widget.courseId);
    _override = await SmartRepo.contOverride(widget.courseId);
    final beh = (await StudyRepo.behaviorCounts())[widget.courseId] ?? <int>[0, 0];
    final books = await db.rawQuery(
      'SELECT b.*, '
      '(SELECT COUNT(*) FROM chapters h WHERE h.book_id = b.id) AS ch_total, '
      '(SELECT COUNT(*) FROM chapters h WHERE h.book_id = b.id AND h.done = 1) AS ch_done '
      'FROM books b WHERE b.course_id = ? ORDER BY b.id',
      [widget.courseId],
    );
    if (!mounted) return;
    setState(() {
      _course = c;
      _teacher = tn;
      _slots = slots;
      _grades = grades;
      _term = term;
      _beh = beh;
      _books = books;
    });
  }

  Future<void> _deleteCourse() async {
    final ok = await luxConfirm(
      context,
      'حذف این درس؟',
      body: 'نمره‌ها، امتحان‌ها و ساعت‌های کلاسِ این درس هم پاک می‌شوند. این کار برگشت ندارد.',
    );
    if (!ok) return;
    await LuxDb.instance.delete('courses', where: 'id = ?', args: [widget.courseId]);
    AppBus.bump();
    if (mounted) Navigator.of(context).pop();
  }

  Widget _heading(String t) => Padding(
        padding: const EdgeInsetsDirectional.only(start: 6, bottom: 10),
        child: Text(t, style: LuxText.label),
      );

  Widget _targetCard() {
    final t = _term;
    final c = _course!;
    final scale = asDouble(c['max_score'], 20);
    final target = _target.toDouble() * scale / 20;
    String text;
    Color color = LuxColors.textDim;
    if (t == null || t.total == null) {
      text = 'بعد از ثبتِ اولین نمره، نمره‌ی لازم برای رسیدن به هدف اینجا حساب می‌شود.';
    } else if (t.finalScore != null) {
      final total = t.total!;
      if (total >= target) {
        text = 'نمره‌ی کلِ فعلی ${fmtNum(total, dec: 2)} است؛ به هدفِ ${faDigits(_target)} رسیده‌ای.';
        color = LuxColors.ok;
      } else {
        text = 'نمره‌ی کلِ فعلی ${fmtNum(total, dec: 2)} است؛ ${fmtNum(target - total, dec: 2)} تا هدفِ ${faDigits(_target)} فاصله داری.';
        color = LuxColors.warn;
      }
    } else {
      final madj = t.continuousAdj!;
      final need = TermMath.neededFinal(continuousAdj: madj, target: target, finalShare: t.finalShare);
      if (need == null) {
        text = 'سهمِ نمره‌ی نهایی صفر است؛ نمره‌ی کل همان مستمر است (${fmtNum(madj, dec: 2)}).';
      } else if (need <= 0) {
        text = 'با مستمرِ فعلی (${fmtNum(madj, dec: 2)}) هدفِ ${faDigits(_target)} حتی با نمره‌ی صفر در نهایی هم تضمین است.';
        color = LuxColors.ok;
      } else if (need > scale) {
        text = 'با مستمرِ فعلی (${fmtNum(madj, dec: 2)}) حتی نمره‌ی کاملِ نهایی هم تو را به ${faDigits(_target)} نمی‌رساند.';
        color = LuxColors.warn;
      } else {
        text = 'برای رسیدن به معدلِ ${faDigits(_target)}، در نمره‌ی نهایی حداقل ${fmtNum(need, dec: 2)} (از ${fmtNum(scale)}) بگیر.';
        color = LuxColors.accent;
      }
    }
    return LuxCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('هدف معدل این درس', style: LuxText.heading),
          const SizedBox(height: 12),
          Wrap(spacing: 8, runSpacing: 8, children: [
            for (final t in const [15, 16, 17, 18, 19, 20])
              LuxChip(label: faDigits(t), selected: _target == t, onTap: () => setState(() => _target = t)),
          ]),
          const SizedBox(height: 12),
          Text(text, style: LuxText.body.copyWith(color: color)),
        ],
      ),
    );
  }

  Widget _stat(String label, String value, {Color? color}) => Expanded(
        child: Column(
          children: [
            Text(value, style: LuxText.heading.copyWith(color: color ?? LuxColors.text)),
            const SizedBox(height: 2),
            Text(label, style: LuxText.caption, textAlign: TextAlign.center),
          ],
        ),
      );

  double? _override;

  Future<void> _editOverride() async {
    final c = TextEditingController(text: _override == null ? '' : latinNum(_override!, dec: 2));
    await showLuxSheet<void>(
      context,
      (ctx) => Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Text('مستمرِ اعلام‌شده از معلم', style: LuxText.title),
          const SizedBox(height: 6),
          Text('اگر معلم نمره‌ی مستمرِ کلِ ترم را اعلام کرد (مثلاً ۲۰)، همین‌جا بنویس. این عدد جای همه‌ی نمره‌های مستمرِ دیگر می‌نشیند و در معدل و پیش‌بینی می‌آید.', style: LuxText.caption),
          const SizedBox(height: 14),
          LuxField(label: 'نمره‌ی مستمر (از ۲۰)', controller: c, keyboard: TextInputType.number, hint: 'مثلاً ۲۰'),
          LuxButton(
            label: 'ثبت',
            onPressed: () async {
              final v = parseNum(c.text);
              if (v == null || v < 0 || v > 20) {
                luxNotice(ctx, 'عددی بین ۰ تا ۲۰ بنویس.');
                return;
              }
              await SmartRepo.setContOverride(widget.courseId, v);
              AppBus.bump();
              if (ctx.mounted) Navigator.of(ctx).pop();
            },
          ),
          if (_override != null) ...[
            const SizedBox(height: 8),
            LuxButton(
              label: 'برداشتنِ این مقدار',
              filled: false,
              onPressed: () async {
                await SmartRepo.setContOverride(widget.courseId, null);
                AppBus.bump();
                if (ctx.mounted) Navigator.of(ctx).pop();
              },
            ),
          ],
        ],
      ),
    );
    c.dispose();
  }

  String _signed(double v) => '${v < 0 ? '−' : '+'}${fmtNum(v.abs(), dec: 2)}';

  /// تفکیکِ مستمر و نهایی + اثرِ مثبت/منفی
  Widget _termCard() {
    final t = _term;
    if (t == null) return const SizedBox.shrink();
    final share = (t.finalShare * 100).round();
    final b = t.behavior;
    return LuxCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('مستمر و نهایی', style: LuxText.heading),
          const SizedBox(height: 4),
          Text(
            'نمره‌ی کل = مستمر × ${faDigits(100 - share)}٪ + نهایی × ${faDigits(share)}٪',
            style: LuxText.caption,
          ),
          const SizedBox(height: 14),
          Row(
            children: [
              _stat('مستمر', t.continuousAdj == null ? '—' : fmtNum(t.continuousAdj!, dec: 2)),
              _stat('نهایی', t.finalScore == null ? '—' : fmtNum(t.finalScore!, dec: 2)),
              _stat(
                'مثبت و منفی',
                b == 0 ? '۰' : _signed(b),
                color: b < 0 ? LuxColors.danger : (b > 0 ? LuxColors.accent : null),
              ),
            ],
          ),
          const SizedBox(height: 12),
          GestureDetector(
            behavior: HitTestBehavior.opaque,
            onTap: _editOverride,
            child: Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(color: LuxColors.cardHi, borderRadius: BorderRadius.circular(LuxColors.r(16))),
              child: Row(
                children: [
                  Icon(Icons.verified_rounded, color: _override == null ? LuxColors.silverDim : LuxColors.accent, size: 20),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Text(
                      _override == null ? 'مستمرِ اعلام‌شده از معلم را ثبت کن' : 'مستمرِ اعلام‌شده: ${fmtNum(_override!, dec: 2)} از ۲۰ (نمره‌های مستمرِ دیگر نادیده‌اند)',
                      style: LuxText.caption.copyWith(color: LuxColors.text),
                    ),
                  ),
                  Icon(Icons.edit_rounded, size: 16, color: LuxColors.silverDim),
                ],
              ),
            ),
          ),
          if (t.continuous == null && (_beh[0] > 0 || _beh[1] > 0)) ...[
            const SizedBox(height: 10),
            Text('اثرِ مثبت و منفی از وقتی اعمال می‌شود که حداقل یک نمره‌ی مستمر ثبت شده باشد.', style: LuxText.caption),
          ],
        ],
      ),
    );
  }

  Widget _gradeRow(Map<String, Object?> g) => LuxRow(
        title: asStr(g['name']).isEmpty ? 'نمره' : asStr(g['name']),
        subtitle: '${jalaliLabel(fromTs(g['at_ts']))} · وزن ${fmtNum(asDouble(g['weight'], 1))}',
        trailing: Text(
          '${fmtNum(asDouble(g['score']), dec: 2)} / ${fmtNum(asDouble(g['max_score'], 20))}',
          style: LuxText.heading.copyWith(color: LuxColors.accent),
        ),
        onTap: () => showGradeEditor(context, courseId: widget.courseId, grade: g),
      );

  @override
  Widget build(BuildContext context) {
    final c = _course;
    if (_gone) {
      return const LuxSubPage(title: 'درس', children: [LuxEmpty(icon: Icons.menu_book_rounded, title: 'این درس دیگر وجود ندارد')]);
    }
    if (c == null) {
      return LuxSubPage(title: 'درس', children: [Center(child: CircularProgressIndicator(color: LuxColors.accent))]);
    }
    final scale = asDouble(c['max_score'], 20);
    final avg = _term?.total;
    final conf = [for (final g in _grades) if (asStr(g['kind']) == 'conference' && asInt(g['is_final']) != 1) g];
    final cont = [for (final g in _grades) if (asInt(g['is_final']) != 1 && asStr(g['kind']) != 'conference') g];
    final fin = [for (final g in _grades) if (asInt(g['is_final']) == 1) g];
    final pass = asDouble(c['pass_score'], 10);
    final diff = asInt(c['difficulty'], 3).clamp(1, 5);

    return LuxSubPage(
      title: asStr(c['name']),
      subtitle: _teacher.isEmpty ? 'بدون معلم' : 'معلم: $_teacher',
      action: LuxAddButton(icon: Icons.edit_rounded, onTap: () => showCourseEditor(context, course: c)),
      children: [
        LuxCard(
          radius: 28,
          child: Row(
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('نمره‌ی کل', style: LuxText.caption),
                    const SizedBox(height: 6),
                    Text(
                      avg == null ? '—' : latinNum(avg, dec: 2),
                      style: LuxText.dot(40, color: avg == null || avg >= pass ? LuxColors.accent : LuxColors.danger),
                    ),
                  ],
                ),
              ),
              Column(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Text('ضریب ${fmtNum(asDouble(c['coef'], 1))}', style: LuxText.body),
                  Text('سختی: ${kDifficulty[diff - 1]}', style: LuxText.caption),
                  Text('نمره‌ی ${fmtNum(scale)} · قبولی ${fmtNum(pass)}', style: LuxText.caption),
                ],
              ),
            ],
          ),
        ),
        const SizedBox(height: 14),
        Row(
          children: [
            Expanded(
              child: LuxButton(
                label: 'امتحان',
                icon: Icons.edit_note_rounded,
                compact: true,
                filled: false,
                onPressed: () => showExamEditor(context, courseId: widget.courseId),
              ),
            ),
            const SizedBox(width: 8),
            Expanded(
              child: LuxButton(
                label: 'تکلیف',
                icon: Icons.checklist_rounded,
                compact: true,
                filled: false,
                onPressed: () => showTaskEditor(context, courseId: widget.courseId),
              ),
            ),
            const SizedBox(width: 8),
            Expanded(
              child: LuxButton(
                label: 'نمره',
                icon: Icons.grade_rounded,
                compact: true,
                filled: false,
                onPressed: () => showGradeEditor(context, courseId: widget.courseId),
              ),
            ),
          ],
        ),
        const SizedBox(height: 16),
        _termCard(),
        const SizedBox(height: 14),
        _targetCard(),
        const SizedBox(height: 22),
        _heading('امتحان‌ها'),
        ExamsBody(courseId: widget.courseId),
        const SizedBox(height: 22),
        _heading('تکالیف'),
        TasksBody(courseId: widget.courseId),
        const SizedBox(height: 22),
        LuxSection(title: 'نمره‌های مستمر', children: [
          if (cont.isEmpty)
            const LuxEmpty(icon: Icons.grade_rounded, title: 'نمره‌ی مستمری ثبت نشده', hint: 'کوییز، میان‌ترم، شفاهی و … اینجا می‌آیند.')
          else
            for (final g in cont) _gradeRow(g),
          LuxRow(
            leading: Icon(Icons.add_circle_outline_rounded, color: LuxColors.accent),
            title: 'افزودن نمره',
            onTap: () => showGradeEditor(context, courseId: widget.courseId),
          ),
        ]),
        LuxSection(title: 'کنفرانس', children: [
          if (conf.isEmpty)
            const LuxEmpty(icon: Icons.record_voice_over_rounded, title: 'کنفرانسی ثبت نشده', hint: 'نمره‌ی کنفرانس جزو نمره‌ی مستمر حساب می‌شود.')
          else
            for (final g in conf) _gradeRow(g),
          LuxRow(
            leading: Icon(Icons.add_circle_outline_rounded, color: LuxColors.accent),
            title: 'افزودن کنفرانس',
            onTap: () => showGradeEditor(context, courseId: widget.courseId, conference: true),
          ),
        ]),
        LuxSection(title: 'نمره‌ی نهایی', children: [
          if (fin.isEmpty)
            const LuxEmpty(icon: Icons.flag_rounded, title: 'نمره‌ی نهایی ثبت نشده', hint: 'امتحانِ «پایان‌ترم» بعد از ثبتِ نمره اینجا می‌آید.')
          else
            for (final g in fin) _gradeRow(g),
        ]),
        LuxSection(title: 'مثبت و منفی سر کلاس', children: [
          LuxRow(
            leading: Icon(Icons.thumb_up_alt_rounded, color: LuxColors.silver),
            title: 'مثبت ${faDigits(_beh[0])} · منفی ${faDigits(_beh[1])}',
            subtitle: 'روی نمره‌ی مستمر اثر می‌گذارد',
            trailing: Row(mainAxisSize: MainAxisSize.min, children: [
              Text(
                (_term?.behavior ?? 0) == 0 ? '۰' : _signed(_term!.behavior),
                style: LuxText.heading.copyWith(
                  color: (_term?.behavior ?? 0) < 0 ? LuxColors.danger : LuxColors.accent,
                ),
              ),
              const SizedBox(width: 6),
              Icon(Icons.chevron_left_rounded, color: LuxColors.silverDim),
            ]),
            onTap: () => pushPage<void>(context, const PositivesPage()),
          ),
        ]),
        LuxSection(title: 'کتاب‌ها', children: [
          if (_books.isEmpty) const LuxEmpty(icon: Icons.menu_book_rounded, title: 'کتابی برای این درس ثبت نشده'),
          for (final b in _books)
            LuxRow(
              leading: Icon(Icons.menu_book_rounded, color: LuxColors.silver),
              title: asStr(b['title']),
              subtitle: [
                if (asInt(b['ch_total']) > 0) 'فصل ${faDigits(asInt(b['ch_done']))} از ${faDigits(asInt(b['ch_total']))}',
                if (b['pages'] != null) 'صفحه ${faDigits(asInt(b['last_page']))} از ${faDigits(asInt(b['pages']))}',
              ].join(' · '),
              trailing: Icon(Icons.chevron_left_rounded, color: LuxColors.silverDim),
              onTap: () => pushPage<void>(context, BookDetailPage(bookId: asInt(b['id']))),
            ),
          LuxRow(
            leading: Icon(Icons.add_circle_outline_rounded, color: LuxColors.accent),
            title: 'افزودن کتاب',
            onTap: () => showBookEditor(context, courseId: widget.courseId),
          ),
        ]),
        LuxSection(title: 'ساعت‌های کلاس', children: [
          if (_slots.isEmpty)
            const LuxEmpty(icon: Icons.schedule_rounded, title: 'ساعتی ثبت نشده'),
          for (final s in _slots)
            LuxRow(
              title: weekdayName(asInt(s['weekday'])),
              subtitle: asStr(s['room']).isEmpty ? null : 'کلاس ${asStr(s['room'])}',
              trailing: Text(
                '${minutesLabel(asInt(s['start_min']))} – ${minutesLabel(asInt(s['end_min']))}',
                style: LuxText.body,
              ),
              onTap: () => showSlotEditor(context, courseId: widget.courseId, slot: s),
            ),
          LuxRow(
            leading: Icon(Icons.add_circle_outline_rounded, color: LuxColors.accent),
            title: 'افزودن ساعت کلاس',
            onTap: () => showSlotEditor(context, courseId: widget.courseId),
          ),
        ]),
        if (asStr(c['notes']).isNotEmpty)
          LuxSection(title: 'یادداشت', children: [
            Padding(padding: const EdgeInsets.all(18), child: Text(asStr(c['notes']), style: LuxText.body)),
          ]),
        const SizedBox(height: 4),
        GestureDetector(
          onTap: _deleteCourse,
          child: Padding(
            padding: const EdgeInsets.all(14),
            child: Text('حذف این درس', textAlign: TextAlign.center, style: LuxText.label.copyWith(color: LuxColors.danger)),
          ),
        ),
      ],
    );
  }
}
