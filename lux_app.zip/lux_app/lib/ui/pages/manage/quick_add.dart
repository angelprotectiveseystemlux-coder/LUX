import 'package:flutter/material.dart';
import '../../../core/palette.dart';
import '../../../core/theme.dart';
import '../../widgets/haptic.dart';
import '../../widgets/lux_kit.dart';
import 'book_pages.dart';
import 'editors.dart';
import 'exam_pages.dart';
import 'task_pages.dart';

/// «چه چیزی اضافه کنیم؟» — همه‌ی ثبت‌ها از یک‌جا
Future<void> showQuickAdd(BuildContext context) {
  return showLuxSheet<void>(context, (ctx) {
    void run(VoidCallback go) {
      Navigator.of(ctx).pop();
      go();
    }

    Widget tile(IconData icon, String label, String sub, VoidCallback go) {
      return Expanded(
        child: GestureDetector(
          behavior: HitTestBehavior.opaque,
          onTap: () {
            Haptic.light();
            run(go);
          },
          child: Container(
            margin: const EdgeInsets.all(5),
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: LuxColors.cardHi,
              borderRadius: BorderRadius.circular(22),
              border: Border.all(color: LuxColors.stroke),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Icon(icon, color: LuxColors.accent, size: 28),
                const SizedBox(height: 12),
                Text(label, style: LuxText.heading),
                const SizedBox(height: 2),
                Text(sub, style: LuxText.caption),
              ],
            ),
          ),
        ),
      );
    }

    return Column(
      mainAxisSize: MainAxisSize.min,
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Text('چه چیزی اضافه کنیم؟', style: LuxText.title),
        const SizedBox(height: 14),
        Row(children: [
          tile(Icons.menu_book_rounded, 'درس', 'نام، معلم و ضریب', () => showCourseEditor(context)),
          tile(Icons.edit_note_rounded, 'امتحان', 'تاریخ و یادآور', () => showExamEditor(context)),
        ]),
        Row(children: [
          tile(Icons.checklist_rounded, 'تکلیف', 'کار و موعدش', () => showTaskEditor(context)),
          tile(Icons.grade_rounded, 'نمره', 'ثبتِ نمره‌ی درس', () => showGradeEditor(context)),
        ]),
        Row(children: [
          tile(Icons.person_rounded, 'معلم', 'سبک تدریس و یادداشت', () => showTeacherEditor(context)),
          tile(Icons.auto_stories_rounded, 'کتاب', 'کتابِ یک درس', () => showBookEditor(context)),
        ]),
      ],
    );
  });
}
