import 'dart:async';
import 'package:flutter/material.dart';
import '../../../core/app_bus.dart';
import '../../../core/jalali_utils.dart';
import '../../../core/palette.dart';
import '../../../core/theme.dart';
import '../../../core/util.dart';
import '../../../data/database.dart';
import '../../../data/week_plan_repo.dart';
import '../../../services/bag_reminders.dart';
import '../../widgets/lux_button.dart';
import '../../widgets/lux_card.dart';
import '../../widgets/lux_chip.dart';
import '../../widgets/lux_kit.dart';
import '../../widgets/lux_section.dart';
import '../../widgets/lux_switch.dart';
import 'editors.dart';

const List<String> _kPeriodKinds = <String>['درس', 'بیکاری', 'تک‌زنگ (متناوب)'];
const List<String> _kKindKeys = <String>['class', 'free', 'alt'];

// ───────────────────────── کارتِ «کیفِ فردا» ─────────────────────────

/// کتاب‌هایی که برای روزِ مدرسه‌ی بعد باید در کیف باشد.
/// از ساعتِ ۱۴ (قابل‌تنظیم) به بعد «فردا» را نشان می‌دهد؛ قبلش همان «امروز» را.
class TomorrowBagCard extends StatefulWidget {
  /// در خودِ صفحه‌ی برنامه‌ی هفتگی false است تا دوباره همان صفحه را باز نکند.
  final bool openPlan;
  const TomorrowBagCard({super.key, this.openPlan = true});

  @override
  State<TomorrowBagCard> createState() => _TomorrowBagCardState();
}

class _TomorrowBagCardState extends State<TomorrowBagCard> {
  DayBag? _day;
  bool _hasPlan = false;
  bool _loaded = false;
  Timer? _tick;

  @override
  void initState() {
    super.initState();
    _load();
    AppBus.data.addListener(_load);
    // عبور از ساعتِ ۱۴ بدونِ بازکردنِ دوباره‌ی برنامه هم دیده شود.
    _tick = Timer.periodic(const Duration(minutes: 1), (_) => _load());
  }

  @override
  void dispose() {
    _tick?.cancel();
    AppBus.data.removeListener(_load);
    super.dispose();
  }

  Future<void> _load() async {
    final day = await WeekPlanRepo.target();
    final any = (await LuxDb.instance.count('week_plan')) > 0;
    if (!mounted) return;
    setState(() {
      _day = day;
      _hasPlan = any;
      _loaded = true;
    });
  }

  @override
  Widget build(BuildContext context) {
    if (!_loaded) return const SizedBox.shrink();
    final day = _day;
    if (!_hasPlan || day == null) {
      return LuxCard(
        onTap: widget.openPlan ? () => pushPage<void>(context, const WeekPlanPage()) : null,
        child: Row(
          children: [
            Icon(Icons.calendar_view_week_rounded, color: LuxColors.accent),
            const SizedBox(width: 14),
            Expanded(
              child: Text(
                'برنامه‌ی هفتگی‌ات را بساز تا هر روز بدانی چه کتاب‌هایی توی کیف بگذاری.',
                style: LuxText.body.copyWith(color: LuxColors.textDim),
              ),
            ),
            Icon(Icons.chevron_left_rounded, color: LuxColors.silverDim),
          ],
        ),
      );
    }
    final onlyFree = day.bag.isEmpty;
    return LuxCard(
      radius: 28,
      onTap: widget.openPlan ? () => pushPage<void>(context, const WeekPlanPage()) : null,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(Icons.menu_book_rounded, color: LuxColors.accent),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('کیفِ ${day.label}', style: LuxText.heading),
                    Text('${day.weekdayName} · ${day.parityName}', style: LuxText.caption),
                  ],
                ),
              ),
              Icon(Icons.chevron_left_rounded, color: LuxColors.silverDim),
            ],
          ),
          const SizedBox(height: 14),
          if (onlyFree)
            Text('${day.label} کتابی لازم نیست؛ همه‌ی زنگ‌ها بیکاری است.', style: LuxText.body.copyWith(color: LuxColors.textDim))
          else ...[
            Wrap(spacing: 8, runSpacing: 8, children: [
              for (final b in day.bag) LuxChip(label: b.text, selected: false, onTap: () {}),
            ]),
            const SizedBox(height: 14),
            for (final p in day.periods)
              Padding(
                padding: const EdgeInsets.only(bottom: 6),
                child: Row(
                  children: [
                    SizedBox(width: 56, child: Text('زنگ ${faDigits(p.period)}', style: LuxText.caption)),
                    Expanded(
                      child: Text(
                        p.activeName(day.parity),
                        style: LuxText.body.copyWith(color: p.isFree ? LuxColors.textDim : LuxColors.text),
                      ),
                    ),
                    if (p.isAlt) Icon(Icons.swap_horiz_rounded, size: 18, color: LuxColors.silverDim),
                  ],
                ),
              ),
          ],
        ],
      ),
    );
  }
}

// ───────────────────────── صفحه‌ی برنامه‌ی هفتگی ─────────────────────────

class WeekPlanPage extends StatefulWidget {
  const WeekPlanPage({super.key});

  @override
  State<WeekPlanPage> createState() => _WeekPlanPageState();
}

class _WeekPlanPageState extends State<WeekPlanPage> {
  List<PlanPeriod> _plan = <PlanPeriod>[];
  WeekPlanSettings _s = const WeekPlanSettings();
  int _parity = 0;
  bool _loaded = false;

  @override
  void initState() {
    super.initState();
    _load();
    AppBus.data.addListener(_load);
  }

  @override
  void dispose() {
    AppBus.data.removeListener(_load);
    super.dispose();
  }

  Future<void> _load() async {
    final plan = await WeekPlanRepo.all();
    final s = await WeekPlanRepo.settings();
    final parity = await WeekPlanRepo.parityOf(DateTime.now());
    if (!mounted) return;
    setState(() {
      _plan = plan;
      _s = s;
      _parity = parity;
      _loaded = true;
    });
  }

  String _hhmm(int m) => minutesLabel(m);

  Widget _badge(int n) => Container(
        width: 34,
        height: 34,
        alignment: Alignment.center,
        decoration: BoxDecoration(color: LuxColors.alpha(LuxColors.accent, 0.12), shape: BoxShape.circle),
        child: Text(faDigits(n), style: LuxText.label.copyWith(color: LuxColors.accent)),
      );

  Widget _periodRow(PlanPeriod p) {
    final active = p.activeName(_parity);
    String? sub;
    if (p.isAlt) {
      sub = 'هفته‌ی بعد: ${p.otherName(_parity)}';
    } else if (p.note.isNotEmpty) {
      sub = p.note;
    }
    if (p.isAlt && p.note.isNotEmpty) sub = '$sub · ${p.note}';
    return LuxRow(
      leading: _badge(p.period),
      title: active,
      subtitle: sub,
      trailing: p.isAlt
          ? Icon(Icons.swap_horiz_rounded, color: LuxColors.silverDim)
          : (p.isFree ? Icon(Icons.free_breakfast_rounded, color: LuxColors.silverDim) : LuxDot(color: courseColor(p.color), size: 12)),
      onTap: () => showPeriodEditor(context, period: p),
    );
  }

  @override
  Widget build(BuildContext context) {
    final today = weekdayIndex(DateTime.now());
    final hasAlt = _plan.any((p) => p.isAlt);
    final sections = <Widget>[];
    final empty = <String>[];
    for (var d = 0; d < 7; d++) {
      final list = [for (final p in _plan) if (p.weekday == d) p];
      if (list.isEmpty) {
        empty.add(jalaliWeekdays[d]);
        continue;
      }
      sections.add(LuxSection(
        title: d == today ? '${jalaliWeekdays[d]} (امروز)' : jalaliWeekdays[d],
        children: [for (final p in list) _periodRow(p)],
      ));
    }
    return LuxSubPage(
      title: 'برنامه‌ی هفتگی',
      subtitle: 'زنگ‌ها، بیکاری و تک‌زنگ‌ها',
      action: LuxAddButton(onTap: () => showPeriodEditor(context)),
      children: [
        const TomorrowBagCard(openPlan: false),
        const SizedBox(height: 14),
        if (hasAlt) ...[
          LuxCard(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('این هفته کدام است؟', style: LuxText.heading),
                const SizedBox(height: 4),
                Text('تک‌زنگ‌ها یک هفته درسِ اول و هفته‌ی بعد درسِ دوم را نشان می‌دهند.', style: LuxText.caption),
                const SizedBox(height: 12),
                LuxChoice(
                  label: 'هفته‌ی جاری',
                  options: const ['هفته‌ی اول', 'هفته‌ی دوم'],
                  selected: _parity,
                  onChanged: (i) async {
                    await WeekPlanRepo.setCurrentParity(i);
                    AppBus.bump();
                  },
                ),
              ],
            ),
          ),
          const SizedBox(height: 14),
        ],
        LuxCard(
          onTap: () => showWeekPlanSettings(context),
          child: Row(
            children: [
              Icon(Icons.notifications_active_rounded, color: LuxColors.accent),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('یادآورِ کیف', style: LuxText.heading),
                    const SizedBox(height: 2),
                    Text(
                      !_s.remindOn
                          ? 'خاموش'
                          : 'ساعت ${faDigits(_hhmm(_s.remind1))}${_s.remind2On ? ' و ${faDigits(_hhmm(_s.remind2))}' : ''} · «فردا» از ${faDigits(_hhmm(_s.cutoffMin))}',
                      style: LuxText.caption,
                    ),
                  ],
                ),
              ),
              Icon(Icons.chevron_left_rounded, color: LuxColors.silverDim),
            ],
          ),
        ),
        const SizedBox(height: 22),
        if (_loaded && _plan.isEmpty)
          LuxCard(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                const LuxEmpty(
                  icon: Icons.calendar_view_week_rounded,
                  title: 'برنامه‌ای ثبت نشده',
                  hint: 'برای هر روز زنگ‌ها را اضافه کن: درس، بیکاری یا تک‌زنگ.',
                ),
                LuxButton(label: 'افزودن اولین زنگ', icon: Icons.add_rounded, onPressed: () => showPeriodEditor(context)),
              ],
            ),
          )
        else ...[
          ...sections,
          if (empty.isNotEmpty)
            Padding(
              padding: const EdgeInsetsDirectional.only(start: 6, bottom: 10),
              child: Text('بدون برنامه: ${empty.join('، ')}', style: LuxText.caption),
            ),
        ],
      ],
    );
  }
}

// ───────────────────────── ویرایش یک زنگ ─────────────────────────

Future<bool?> showPeriodEditor(BuildContext context, {PlanPeriod? period, int? weekday}) {
  final isNew = period == null;
  var wd = period?.weekday ?? weekday ?? weekdayIndex(DateTime.now());
  if (wd < 0 || wd > 6) wd = 0;
  var no = (period?.period ?? 1).clamp(1, 9);
  var kind = period == null ? 0 : _kKindKeys.indexOf(period.kind).clamp(0, 2);
  int? cid = period?.courseId;
  int? alt = period?.altCourseId;
  final note = TextEditingController(text: period?.note ?? '');
  return showLuxSheet<bool>(
    context,
    (ctx) => StatefulBuilder(builder: (ctx, setS) {
      return Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Text(isNew ? 'زنگ جدید' : 'ویرایش زنگ', style: LuxText.title),
          const SizedBox(height: 16),
          LuxChoice(label: 'روز هفته', options: jalaliWeekdays, selected: wd, onChanged: (i) => setS(() => wd = i)),
          LuxChoice(
            label: 'شماره‌ی زنگ',
            options: [for (var i = 1; i <= 9; i++) faDigits(i)],
            selected: no - 1,
            onChanged: (i) => setS(() => no = i + 1),
          ),
          LuxChoice(label: 'نوع', options: _kPeriodKinds, selected: kind, onChanged: (i) => setS(() => kind = i)),
          if (kind == 0) LuxCourseChips(selectedId: cid, onChanged: (id) => setS(() => cid = id)),
          if (kind == 2) ...[
            LuxCourseChips(label: 'درسِ هفته‌ی اول', selectedId: cid, onChanged: (id) => setS(() => cid = id)),
            LuxCourseChips(label: 'درسِ هفته‌ی دوم', selectedId: alt, onChanged: (id) => setS(() => alt = id)),
          ],
          if (kind != 1) LuxField(label: 'یادداشت (اختیاری)', controller: note, hint: 'مثلاً کتاب کار هم ببر'),
          LuxButton(
            label: 'ذخیره',
            onPressed: () async {
              if (kind == 0 && cid == null) {
                luxNotice(ctx, 'درس را انتخاب کن.');
                return;
              }
              if (kind == 2 && (cid == null || alt == null)) {
                luxNotice(ctx, 'هر دو درس را انتخاب کن.');
                return;
              }
              if (kind == 2 && cid == alt) {
                luxNotice(ctx, 'دو درسِ تک‌زنگ باید با هم فرق داشته باشند.');
                return;
              }
              final db = LuxDb.instance;
              // یک روز در هر شماره‌ی زنگ فقط یک ردیف دارد.
              final clash = await db.query(
                'week_plan',
                where: 'weekday = ? AND period = ?',
                args: [wd, no],
              );
              final selfId = period?.id;
              for (final r in clash) {
                if (selfId != null && asInt(r['id']) == selfId) continue;
                await db.delete('week_plan', where: 'id = ?', args: [asInt(r['id'])]);
              }
              final values = <String, Object?>{
                'weekday': wd,
                'period': no,
                'kind': _kKindKeys[kind],
                'course_id': kind == 1 ? null : cid,
                'alt_course_id': kind == 2 ? alt : null,
                'note': kind == 1 ? '' : note.text.trim(),
              };
              if (selfId == null) {
                await db.insert('week_plan', values);
              } else {
                await db.update('week_plan', values, where: 'id = ?', args: [selfId]);
              }
              AppBus.bump();
              if (ctx.mounted) Navigator.of(ctx).pop(true);
            },
          ),
          if (!isNew) ...[
            const SizedBox(height: 10),
            LuxButton(
              label: 'حذف این زنگ',
              filled: false,
              onPressed: () async {
                final ok = await luxConfirm(ctx, 'این زنگ حذف شود؟');
                if (!ok) return;
                await LuxDb.instance.delete('week_plan', where: 'id = ?', args: [period!.id]);
                AppBus.bump();
                if (ctx.mounted) Navigator.of(ctx).pop(true);
              },
            ),
          ],
        ],
      );
    }),
  );
}

// ───────────────────────── تنظیمات یادآور ─────────────────────────

Future<void> showWeekPlanSettings(BuildContext context) async {
  var s = await WeekPlanRepo.settings();
  if (!context.mounted) return;
  return showLuxSheet<void>(
    context,
    (ctx) => StatefulBuilder(builder: (ctx, setS) {
      Future<void> pick(int current, ValueChanged<int> set) async {
        final r = await pickTimeOfDayMinutes(ctx, current);
        if (r != null) setS(() => set(r));
      }

      return Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Text('یادآورِ کیف', style: LuxText.title),
          const SizedBox(height: 6),
          Text('اعلان می‌دهد که برای روزِ مدرسه‌ی بعد چه کتاب‌هایی توی کیف بگذاری.', style: LuxText.caption),
          const SizedBox(height: 16),
          Row(
            children: [
              Expanded(child: Text('یادآور روشن باشد', style: LuxText.heading)),
              LuxSwitch(value: s.remindOn, onChanged: (v) => setS(() => s = s.copyWith(remindOn: v))),
            ],
          ),
          const SizedBox(height: 14),
          if (s.remindOn) ...[
            LuxPickField(
              label: 'یادآور اول',
              value: minutesLabel(s.remind1),
              icon: Icons.schedule_rounded,
              onTap: () => pick(s.remind1, (m) => s = s.copyWith(remind1: m)),
            ),
            Row(
              children: [
                Expanded(child: Text('یادآور دوم', style: LuxText.heading)),
                LuxSwitch(value: s.remind2On, onChanged: (v) => setS(() => s = s.copyWith(remind2On: v))),
              ],
            ),
            const SizedBox(height: 10),
            if (s.remind2On)
              LuxPickField(
                label: 'ساعتِ یادآور دوم',
                value: minutesLabel(s.remind2),
                icon: Icons.schedule_rounded,
                onTap: () => pick(s.remind2, (m) => s = s.copyWith(remind2: m)),
              ),
          ],
          LuxPickField(
            label: 'از چه ساعتی «فردا» حساب شود؟',
            value: minutesLabel(s.cutoffMin),
            icon: Icons.home_rounded,
            onTap: () => pick(s.cutoffMin, (m) => s = s.copyWith(cutoffMin: m)),
          ),
          LuxButton(
            label: 'ذخیره',
            onPressed: () async {
              await WeekPlanRepo.saveSettings(s);
              AppBus.bump();
              BagReminders.requestReschedule();
              if (ctx.mounted) Navigator.of(ctx).pop();
            },
          ),
          const SizedBox(height: 10),
          LuxButton(
            label: 'ارسالِ نمونه‌ی اعلان',
            filled: false,
            onPressed: () async {
              try {
                await BagReminders.sendSample();
              } catch (_) {}
            },
          ),
        ],
      );
    }),
  );
}
