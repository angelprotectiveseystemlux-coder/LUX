import 'dart:async';
import 'package:flutter/material.dart';
import '../../../core/app_bus.dart';
import '../../../core/jalali_utils.dart';
import '../../../core/palette.dart';
import '../../../core/theme.dart';
import '../../../core/util.dart';
import '../../../data/database.dart';
import '../../../services/notification_service.dart';
import '../../charts/radial.dart';
import '../../widgets/haptic.dart';
import '../../widgets/lux_button.dart';
import '../../widgets/lux_card.dart';
import '../../widgets/lux_chip.dart';
import '../../widgets/lux_kit.dart';
import '../../widgets/lux_section.dart';
import 'editors.dart';
import 'exam_pages.dart';

// ───────────────────────── جدول هفتگی کلاس‌ها ─────────────────────────

class TimetablePage extends StatefulWidget {
  const TimetablePage({super.key});

  @override
  State<TimetablePage> createState() => _TimetablePageState();
}

class _TimetablePageState extends State<TimetablePage> {
  List<Map<String, Object?>> _rows = <Map<String, Object?>>[];
  bool _loaded = false;

  @override
  void initState() {
    super.initState();
    _load();
    AppBus.data.addListener(_load);
  }

  @override
  void dispose() {
    AppBus.data.removeListener(_load);
    super.dispose();
  }

  Future<void> _load() async {
    final r = await LuxDb.instance.rawQuery(
      'SELECT s.*, c.name AS course_name, c.color AS course_color FROM class_slots s '
      'JOIN courses c ON c.id = s.course_id WHERE c.archived = 0 ORDER BY s.weekday, s.start_min',
    );
    if (!mounted) return;
    setState(() {
      _rows = r;
      _loaded = true;
    });
  }

  @override
  Widget build(BuildContext context) {
    final today = weekdayIndex(DateTime.now());
    final sections = <Widget>[];
    for (var d = 0; d < 7; d++) {
      final list = _rows.where((r) => asInt(r['weekday']) == d).toList();
      if (list.isEmpty) continue;
      sections.add(LuxSection(
        title: d == today ? '${jalaliWeekdays[d]} (امروز)' : jalaliWeekdays[d],
        children: [
          for (final s in list)
            LuxRow(
              leading: LuxDot(color: courseColor(s['course_color']), size: 14),
              title: asStr(s['course_name']),
              subtitle: asStr(s['room']).isEmpty ? null : 'کلاس ${asStr(s['room'])}',
              trailing: Text('${minutesLabel(asInt(s['start_min']))} – ${minutesLabel(asInt(s['end_min']))}', style: LuxText.body),
              onTap: () => showSlotEditor(context, slot: s),
            ),
        ],
      ));
    }
    return LuxSubPage(
      title: 'جدول کلاس‌ها',
      subtitle: 'برنامه‌ی هفتگی',
      action: LuxAddButton(onTap: () => showSlotEditor(context)),
      children: [
        if (_loaded && _rows.isEmpty)
          const LuxCard(child: LuxEmpty(icon: Icons.calendar_view_week_rounded, title: 'ساعتی ثبت نشده', hint: 'با دکمه‌ی + ساعت کلاس هر درس را اضافه کن.'))
        else
          ...sections,
      ],
    );
  }
}

// ───────────────────────── تقویم (فهرست روزبه‌روز) ─────────────────────────

class AgendaPage extends StatefulWidget {
  const AgendaPage({super.key});

  @override
  State<AgendaPage> createState() => _AgendaPageState();
}

class _AgendaPageState extends State<AgendaPage> {
  final Map<int, List<Map<String, Object?>>> _byDay = <int, List<Map<String, Object?>>>{};
  bool _loaded = false;

  @override
  void initState() {
    super.initState();
    _load();
    AppBus.data.addListener(_load);
  }

  @override
  void dispose() {
    AppBus.data.removeListener(_load);
    super.dispose();
  }

  int _key(DateTime d) => dateOnly(d).millisecondsSinceEpoch;

  Future<void> _load() async {
    final now = DateTime.now();
    final from = dateOnly(now).millisecondsSinceEpoch;
    final to = dateOnly(now).add(const Duration(days: 90)).millisecondsSinceEpoch;
    final db = LuxDb.instance;
    final exams = await db.rawQuery(
      'SELECT e.*, c.name AS course_name FROM exams e JOIN courses c ON c.id = e.course_id '
      "WHERE e.status = 'planned' AND e.at_ts >= ? AND e.at_ts < ? ORDER BY e.at_ts",
      [from, to],
    );
    final tasks = await db.rawQuery(
      'SELECT t.*, c.name AS course_name FROM tasks t LEFT JOIN courses c ON c.id = t.course_id '
      "WHERE t.status = 'open' AND t.due_ts IS NOT NULL AND t.due_ts >= ? AND t.due_ts < ? ORDER BY t.due_ts",
      [from, to],
    );
    final m = <int, List<Map<String, Object?>>>{};
    for (final e in exams) {
      m.putIfAbsent(_key(fromTs(e['at_ts'])), () => <Map<String, Object?>>[]).add(<String, Object?>{...e, '_kind': 'exam'});
    }
    for (final t in tasks) {
      m.putIfAbsent(_key(fromTs(t['due_ts'])), () => <Map<String, Object?>>[]).add(<String, Object?>{...t, '_kind': 'task'});
    }
    if (!mounted) return;
    setState(() {
      _byDay
        ..clear()
        ..addAll(m);
      _loaded = true;
    });
  }

  @override
  Widget build(BuildContext context) {
    final keys = _byDay.keys.toList()..sort();
    return LuxSubPage(
      title: 'تقویم',
      subtitle: 'امتحان‌ها و تکالیفِ ۹۰ روز آینده',
      children: [
        if (_loaded && keys.isEmpty)
          const LuxCard(child: LuxEmpty(icon: Icons.event_note_rounded, title: 'چیزی در پیش نیست', hint: 'امتحان‌ها و تکالیفی که موعد دارند اینجا به‌ترتیب روز می‌آیند.'))
        else
          for (final k in keys)
            LuxSection(
              title: '${jalaliLabelWithDay(DateTime.fromMillisecondsSinceEpoch(k))} · ${relativeDay(DateTime.fromMillisecondsSinceEpoch(k))}',
              children: [
                for (final it in _byDay[k]!)
                  if (it['_kind'] == 'exam')
                    LuxRow(
                      leading: const Icon(Icons.edit_note_rounded, color: LuxColors.accent),
                      title: 'امتحان ${examTitle(it)}',
                      subtitle: 'ساعت ${clockLabel(fromTs(it['at_ts']))}${asStr(it['location']).isEmpty ? '' : ' · ${asStr(it['location'])}'}',
                    )
                  else
                    LuxRow(
                      leading: const Icon(Icons.checklist_rounded, color: LuxColors.silver),
                      title: asStr(it['title']),
                      subtitle: 'موعد ساعت ${clockLabel(fromTs(it['due_ts']))}${asStr(it['course_name']).isEmpty ? '' : ' · ${asStr(it['course_name'])}'}',
                    ),
              ],
            ),
      ],
    );
  }
}

// ───────────────────────── پومودورو ─────────────────────────

class PomodoroPage extends StatefulWidget {
  const PomodoroPage({super.key});

  @override
  State<PomodoroPage> createState() => _PomodoroPageState();
}

class _PomodoroPageState extends State<PomodoroPage> {
  static const int _notifId = 300001;
  static const List<int> _focusOptions = <int>[15, 25, 45, 60];

  int _focusMin = 25;
  int _breakMin = 5;
  bool _isBreak = false;
  bool _running = false;
  DateTime? _startedAt;
  DateTime? _endAt;
  int _remainingSec = 25 * 60; // وقتی متوقف است
  Timer? _timer;
  int? _courseId;
  String _courseName = '';
  int _todayMin = 0;
  int _todayCount = 0;

  @override
  void initState() {
    super.initState();
    _loadToday();
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  int get _totalSec => (_isBreak ? _breakMin : _focusMin) * 60;

  int get _left {
    final e = _endAt;
    if (_running && e != null) {
      final s = e.difference(DateTime.now()).inSeconds;
      return s < 0 ? 0 : s;
    }
    return _remainingSec;
  }

  Future<void> _loadToday() async {
    final start = dateOnly(DateTime.now()).millisecondsSinceEpoch;
    final r = await LuxDb.instance.rawQuery(
      'SELECT COUNT(*) AS n, COALESCE(SUM(end_ts - start_ts), 0) AS ms FROM study_sessions '
      "WHERE kind = 'pomodoro' AND completed = 1 AND start_ts >= ?",
      [start],
    );
    if (!mounted) return;
    setState(() {
      _todayCount = asInt(r.first['n']);
      _todayMin = (asInt(r.first['ms']) / 60000).round();
    });
  }

  void _start() {
    final now = DateTime.now();
    _startedAt ??= now;
    _endAt = now.add(Duration(seconds: _remainingSec));
    _running = true;
    _timer?.cancel();
    _timer = Timer.periodic(const Duration(milliseconds: 500), (_) => _tick());
    try {
      NotificationService.instance.schedule(
        id: _notifId,
        title: _isBreak ? 'استراحت تمام شد' : 'جلسه‌ی تمرکز تمام شد',
        body: _isBreak ? 'وقتِ برگشتن به درس است.' : 'آفرین! حالا کمی استراحت کن.',
        when: _endAt!,
      );
    } catch (_) {}
    Haptic.light();
    setState(() {});
  }

  void _pause() {
    _remainingSec = _left;
    _running = false;
    _timer?.cancel();
    try {
      NotificationService.instance.cancel(_notifId);
    } catch (_) {}
    Haptic.light();
    setState(() {});
  }

  void _reset() {
    _timer?.cancel();
    _running = false;
    _startedAt = null;
    _endAt = null;
    _remainingSec = _totalSec;
    try {
      NotificationService.instance.cancel(_notifId);
    } catch (_) {}
    setState(() {});
  }

  Future<void> _tick() async {
    if (!mounted) return;
    if (_left <= 0) {
      _timer?.cancel();
      _running = false;
      Haptic.alert();
      if (!_isBreak) {
        final s = _startedAt ?? DateTime.now().subtract(Duration(minutes: _focusMin));
        await LuxDb.instance.insert('study_sessions', <String, Object?>{
          'course_id': _courseId,
          'start_ts': s.millisecondsSinceEpoch,
          'end_ts': DateTime.now().millisecondsSinceEpoch,
          'kind': 'pomodoro',
          'planned_min': _focusMin,
          'completed': 1,
        });
        AppBus.bump();
        await _loadToday();
      }
      if (!mounted) return;
      setState(() {
        _isBreak = !_isBreak;
        _startedAt = null;
        _endAt = null;
        _remainingSec = _totalSec;
      });
      return;
    }
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    final left = _left;
    final total = _totalSec;
    final mm = two(left ~/ 60);
    final ss = two(left % 60);
    final progress = total == 0 ? 0.0 : 1 - left / total;
    return LuxSubPage(
      title: 'پومودورو',
      subtitle: _isBreak ? 'استراحت' : 'تمرکز',
      children: [
        LuxCard(
          radius: 32,
          padding: const EdgeInsets.symmetric(vertical: 28, horizontal: 18),
          child: Column(
            children: [
              RingProgress(
                value: progress.clamp(0.0, 1.0),
                size: 230,
                stroke: 12,
                color: _isBreak ? LuxColors.ok : LuxColors.accent,
                child: Directionality(
                  textDirection: TextDirection.ltr,
                  child: Text('$mm:$ss', style: LuxText.dot(54)),
                ),
              ),
              const SizedBox(height: 26),
              Row(
                children: [
                  Expanded(
                    child: LuxButton(
                      label: _running ? 'توقف' : (_startedAt == null ? 'شروع' : 'ادامه'),
                      icon: _running ? Icons.pause_rounded : Icons.play_arrow_rounded,
                      onPressed: _running ? _pause : _start,
                    ),
                  ),
                  const SizedBox(width: 12),
                  LuxButton(label: 'از نو', filled: false, expand: false, onPressed: _reset),
                ],
              ),
            ],
          ),
        ),
        const SizedBox(height: 18),
        LuxCard(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('مدت تمرکز (دقیقه)', style: LuxText.caption),
              const SizedBox(height: 10),
              Wrap(spacing: 8, runSpacing: 8, children: [
                for (final m in _focusOptions)
                  LuxChip(
                    label: faDigits(m),
                    selected: _focusMin == m,
                    onTap: () {
                      if (_running) return;
                      setState(() {
                        _focusMin = m;
                        _breakMin = m >= 45 ? 10 : 5;
                        if (!_isBreak) _remainingSec = m * 60;
                      });
                    },
                  ),
              ]),
              const SizedBox(height: 16),
              LuxPickField(
                label: 'درسِ در حال مطالعه',
                value: _courseName.isEmpty ? 'بدون درس' : _courseName,
                placeholder: _courseName.isEmpty,
                onTap: () async {
                  final r = await pickCourse(context, selectedId: _courseId, allowNone: true);
                  if (r == null) return;
                  final n = await courseNameOf(r);
                  setState(() {
                    _courseId = r < 0 ? null : r;
                    _courseName = n;
                  });
                },
              ),
            ],
          ),
        ),
        const SizedBox(height: 18),
        LuxSection(title: 'امروز', children: [
          LuxRow(title: 'جلسه‌های کامل', trailing: Text(faDigits(_todayCount), style: LuxText.heading.copyWith(color: LuxColors.accent))),
          LuxRow(title: 'مجموع مطالعه', trailing: Text('${faDigits(_todayMin)} دقیقه', style: LuxText.heading.copyWith(color: LuxColors.accent))),
        ]),
        Text('برنامه را باز نگه دار؛ اگر بسته شود، اعلانِ پایانِ جلسه می‌رسد ولی جلسه ثبت نمی‌شود.',
            style: LuxText.caption, textAlign: TextAlign.center),
      ],
    );
  }
}
