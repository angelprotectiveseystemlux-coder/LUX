import 'dart:async';
import 'package:flutter/material.dart';
import '../../../core/app_bus.dart';
import '../../../core/jalali_utils.dart';
import '../../../core/palette.dart';
import '../../../core/theme.dart';
import '../../../core/util.dart';
import '../../../data/database.dart';
import '../../../services/notification_service.dart';
import '../../charts/radial.dart';
import '../../widgets/haptic.dart';
import '../../widgets/lux_button.dart';
import '../../widgets/lux_card.dart';
import '../../widgets/lux_chip.dart';
import '../../widgets/lux_kit.dart';
import '../../widgets/lux_section.dart';
import 'editors.dart';
import 'exam_pages.dart';
export 'pomodoro_page.dart';

// ───────────────────────── جدول هفتگی کلاس‌ها ─────────────────────────

class TimetableBody extends StatefulWidget {
  const TimetableBody({super.key});

  @override
  State<TimetableBody> createState() => _TimetableBodyState();
}

class _TimetableBodyState extends State<TimetableBody> {
  List<Map<String, Object?>> _rows = <Map<String, Object?>>[];
  bool _loaded = false;

  @override
  void initState() {
    super.initState();
    _load();
    AppBus.data.addListener(_load);
  }

  @override
  void dispose() {
    AppBus.data.removeListener(_load);
    super.dispose();
  }

  Future<void> _load() async {
    final r = await LuxDb.instance.rawQuery(
      'SELECT s.*, c.name AS course_name, c.color AS course_color FROM class_slots s '
      'JOIN courses c ON c.id = s.course_id WHERE c.archived = 0 ORDER BY s.weekday, s.start_min',
    );
    if (!mounted) return;
    setState(() {
      _rows = r;
      _loaded = true;
    });
  }

  @override
  Widget build(BuildContext context) {
    final today = weekdayIndex(DateTime.now());
    final sections = <Widget>[];
    for (var d = 0; d < 7; d++) {
      final list = _rows.where((r) => asInt(r['weekday']) == d).toList();
      if (list.isEmpty) continue;
      sections.add(LuxSection(
        title: d == today ? '${jalaliWeekdays[d]} (امروز)' : jalaliWeekdays[d],
        children: [
          for (final s in list)
            LuxRow(
              leading: LuxDot(color: courseColor(s['course_color']), size: 14),
              title: asStr(s['course_name']),
              subtitle: asStr(s['room']).isEmpty ? null : 'کلاس ${asStr(s['room'])}',
              trailing: Text('${minutesLabel(asInt(s['start_min']))} – ${minutesLabel(asInt(s['end_min']))}', style: LuxText.body),
              onTap: () => showSlotEditor(context, slot: s),
            ),
        ],
      ));
    }
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        if (_loaded && _rows.isEmpty)
          const LuxCard(child: LuxEmpty(icon: Icons.calendar_view_week_rounded, title: 'ساعتی ثبت نشده', hint: 'با دکمه‌ی + ساعت کلاس هر درس را اضافه کن.'))
        else
          ...sections,
      ],
    );
  }
}

class TimetablePage extends StatelessWidget {
  const TimetablePage({super.key});

  @override
  Widget build(BuildContext context) {
    return LuxSubPage(
      title: 'جدول کلاس‌ها',
      subtitle: 'برنامه‌ی هفتگی',
      action: LuxAddButton(onTap: () => showSlotEditor(context)),
      children: const [TimetableBody()],
    );
  }
}

// ───────────────────────── تقویم (فهرست روزبه‌روز) ─────────────────────────

class AgendaBody extends StatefulWidget {
  const AgendaBody({super.key});

  @override
  State<AgendaBody> createState() => _AgendaBodyState();
}

class _AgendaBodyState extends State<AgendaBody> {
  final Map<int, List<Map<String, Object?>>> _byDay = <int, List<Map<String, Object?>>>{};
  bool _loaded = false;

  @override
  void initState() {
    super.initState();
    _load();
    AppBus.data.addListener(_load);
  }

  @override
  void dispose() {
    AppBus.data.removeListener(_load);
    super.dispose();
  }

  int _key(DateTime d) => dateOnly(d).millisecondsSinceEpoch;

  Future<void> _load() async {
    final now = DateTime.now();
    final from = dateOnly(now).millisecondsSinceEpoch;
    final to = dateOnly(now).add(const Duration(days: 90)).millisecondsSinceEpoch;
    final db = LuxDb.instance;
    final exams = await db.rawQuery(
      'SELECT e.*, c.name AS course_name FROM exams e JOIN courses c ON c.id = e.course_id '
      "WHERE e.status = 'planned' AND e.at_ts >= ? AND e.at_ts < ? ORDER BY e.at_ts",
      [from, to],
    );
    final tasks = await db.rawQuery(
      'SELECT t.*, c.name AS course_name FROM tasks t LEFT JOIN courses c ON c.id = t.course_id '
      "WHERE t.status = 'open' AND t.due_ts IS NOT NULL AND t.due_ts >= ? AND t.due_ts < ? ORDER BY t.due_ts",
      [from, to],
    );
    final m = <int, List<Map<String, Object?>>>{};
    for (final e in exams) {
      m.putIfAbsent(_key(fromTs(e['at_ts'])), () => <Map<String, Object?>>[]).add(<String, Object?>{...e, '_kind': 'exam'});
    }
    for (final t in tasks) {
      m.putIfAbsent(_key(fromTs(t['due_ts'])), () => <Map<String, Object?>>[]).add(<String, Object?>{...t, '_kind': 'task'});
    }
    if (!mounted) return;
    setState(() {
      _byDay
        ..clear()
        ..addAll(m);
      _loaded = true;
    });
  }

  @override
  Widget build(BuildContext context) {
    final keys = _byDay.keys.toList()..sort();
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        if (_loaded && keys.isEmpty)
          const LuxCard(child: LuxEmpty(icon: Icons.event_note_rounded, title: 'چیزی در پیش نیست', hint: 'امتحان‌ها و تکالیفی که موعد دارند اینجا به‌ترتیب روز می‌آیند.'))
        else
          for (final k in keys)
            LuxSection(
              title: '${jalaliLabelWithDay(DateTime.fromMillisecondsSinceEpoch(k))} · ${relativeDay(DateTime.fromMillisecondsSinceEpoch(k))}',
              children: [
                for (final it in _byDay[k]!)
                  if (it['_kind'] == 'exam')
                    LuxRow(
                      leading: Icon(Icons.edit_note_rounded, color: LuxColors.accent),
                      title: 'امتحان ${examTitle(it)}',
                      subtitle: 'ساعت ${clockLabel(fromTs(it['at_ts']))}${asStr(it['location']).isEmpty ? '' : ' · ${asStr(it['location'])}'}',
                    )
                  else
                    LuxRow(
                      leading: Icon(Icons.checklist_rounded, color: LuxColors.silver),
                      title: asStr(it['title']),
                      subtitle: 'موعد ساعت ${clockLabel(fromTs(it['due_ts']))}${asStr(it['course_name']).isEmpty ? '' : ' · ${asStr(it['course_name'])}'}',
                    ),
              ],
            ),
      ],
    );
  }
}

class AgendaPage extends StatelessWidget {
  const AgendaPage({super.key});

  @override
  Widget build(BuildContext context) {
    return const LuxSubPage(
      title: 'تقویم',
      subtitle: 'امتحان‌ها و تکالیفِ ۹۰ روز آینده',
      children: [AgendaBody()],
    );
  }
}
