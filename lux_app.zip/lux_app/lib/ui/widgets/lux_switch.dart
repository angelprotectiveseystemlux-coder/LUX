import 'package:flutter/material.dart';
import '../../core/palette.dart';
import '../../core/theme.dart';
import 'haptic.dart';

class LuxSwitch extends StatelessWidget {
  final bool value;
  final ValueChanged<bool> onChanged;
  const LuxSwitch({super.key, required this.value, required this.onChanged});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTap: () {
        Haptic.tap();
        onChanged(!value);
      },
      child: AnimatedContainer(
        duration: LuxMotion.medium,
        curve: LuxMotion.curve,
        width: 54,
        height: 32,
        padding: const EdgeInsets.all(4),
        decoration: BoxDecoration(
          color: value ? LuxColors.accent : LuxColors.cardHi,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: value ? LuxColors.accent : LuxColors.stroke, width: 1),
        ),
        child: AnimatedAlign(
          duration: LuxMotion.medium,
          curve: LuxMotion.curve,
          alignment: value ? AlignmentDirectional.centerEnd : AlignmentDirectional.centerStart,
          child: Container(
            width: 22,
            height: 22,
            decoration: BoxDecoration(
              color: value ? LuxColors.onAccent : LuxColors.silverDim,
              shape: BoxShape.circle,
            ),
          ),
        ),
      ),
    );
  }
}
