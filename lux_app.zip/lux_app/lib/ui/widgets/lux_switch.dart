import 'package:flutter/material.dart';
import '../../core/palette.dart';
import '../../core/theme.dart';
import 'haptic.dart';

/// کلید روشن/خاموش. مسیرِ حرکتِ دکمه‌ی گرد کاملاً قرینه است:
/// فاصله‌ی دکمه تا لبه‌های بالا، پایین، چپ و راستِ مسیر همیشه ۴ پیکسل است.
class LuxSwitch extends StatelessWidget {
  final bool value;
  final ValueChanged<bool> onChanged;
  const LuxSwitch({super.key, required this.value, required this.onChanged});

  static const double _w = 56;
  static const double _h = 32;
  static const double _knob = 24;
  static const double _gap = 4;

  @override
  Widget build(BuildContext context) {
    return Semantics(
      toggled: value,
      child: GestureDetector(
        behavior: HitTestBehavior.opaque,
        onTap: () {
          Haptic.tap();
          onChanged(!value);
        },
        child: SizedBox(
          width: _w,
          height: _h,
          child: Stack(
            children: [
              Positioned.fill(
                child: AnimatedContainer(
                  duration: LuxMotion.medium,
                  curve: LuxMotion.curve,
                  decoration: BoxDecoration(
                    color: value ? LuxColors.accent : LuxColors.cardHi,
                    borderRadius: BorderRadius.circular(_h / 2),
                  ),
                ),
              ),
              if (!value)
                Positioned.fill(
                  child: DecoratedBox(
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(_h / 2),
                      border: Border.all(color: LuxColors.stroke, width: 1),
                    ),
                  ),
                ),
              AnimatedPositionedDirectional(
                duration: LuxMotion.medium,
                curve: LuxMotion.curve,
                top: _gap,
                start: value ? _w - _gap - _knob : _gap,
                child: AnimatedContainer(
                  duration: LuxMotion.medium,
                  curve: LuxMotion.curve,
                  width: _knob,
                  height: _knob,
                  decoration: BoxDecoration(
                    color: value ? LuxColors.onAccent : LuxColors.silverDim,
                    shape: BoxShape.circle,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
