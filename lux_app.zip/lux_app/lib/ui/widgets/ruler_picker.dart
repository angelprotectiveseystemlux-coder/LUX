import 'dart:math' as math;
import 'package:flutter/material.dart';
import '../../core/jalali_utils.dart';
import '../../core/palette.dart';
import '../../core/theme.dart';
import 'haptic.dart';

/// انتخابگرِ خط‌کشی (لمسیِ افقی) با ویبره روی هر تیک.
class RulerPicker extends StatefulWidget {
  final double min;
  final double max;
  final double step;
  final double initial;
  final ValueChanged<double> onChanged;
  final String Function(double)? format;

  const RulerPicker({
    super.key,
    required this.min,
    required this.max,
    required this.step,
    required this.initial,
    required this.onChanged,
    this.format,
  });

  @override
  State<RulerPicker> createState() => _RulerPickerState();
}

class _RulerPickerState extends State<RulerPicker> {
  static const double _tickW = 14;
  late final ScrollController _ctl;
  late int _count;
  late int _idx;

  @override
  void initState() {
    super.initState();
    _count = ((widget.max - widget.min) / widget.step).round();
    _idx = ((widget.initial - widget.min) / widget.step).round().clamp(0, _count);
    _ctl = ScrollController(initialScrollOffset: _idx * _tickW);
    _ctl.addListener(_onScroll);
  }

  @override
  void dispose() {
    _ctl.dispose();
    super.dispose();
  }

  double get _value => widget.min + _idx * widget.step;

  void _onScroll() {
    final i = (_ctl.offset / _tickW).round().clamp(0, _count);
    if (i != _idx) {
      setState(() => _idx = i);
      Haptic.tap();
      widget.onChanged(_value);
    }
  }

  @override
  Widget build(BuildContext context) {
    final fmt = widget.format ?? (double v) => latinNum(v);
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Text(fmt(_value), style: LuxText.dot(54, color: LuxColors.accent)),
        const SizedBox(height: 18),
        SizedBox(
          height: 84,
          child: Directionality(
            textDirection: TextDirection.ltr,
            child: LayoutBuilder(builder: (context, cons) {
              final vw = cons.maxWidth;
              return Stack(
                alignment: Alignment.topCenter,
                children: [
                  NotificationListener<ScrollNotification>(
                    onNotification: (n) {
                      if (n is ScrollEndNotification) {
                        final target = (_ctl.offset / _tickW).round().clamp(0, _count) * _tickW;
                        if ((target - _ctl.offset).abs() > 0.5) {
                          _ctl.animateTo(target, duration: LuxMotion.medium, curve: LuxMotion.curve);
                        }
                      }
                      return false;
                    },
                    child: SingleChildScrollView(
                      controller: _ctl,
                      scrollDirection: Axis.horizontal,
                      physics: const BouncingScrollPhysics(),
                      child: RepaintBoundary(
                        child: CustomPaint(
                          size: Size(_count * _tickW + vw, 84),
                          painter: _RulerPainter(
                            count: _count,
                            tickW: _tickW,
                            pad: vw / 2,
                            min: widget.min,
                            step: widget.step,
                          ),
                        ),
                      ),
                    ),
                  ),
                  IgnorePointer(
                    child: Container(
                      width: 3,
                      height: 52,
                      decoration: BoxDecoration(color: LuxColors.accent, borderRadius: BorderRadius.circular(LuxColors.r(2))),
                    ),
                  ),
                ],
              );
            }),
          ),
        ),
      ],
    );
  }
}

class _RulerPainter extends CustomPainter {
  final int count;
  final double tickW;
  final double pad;
  final double min;
  final double step;
  _RulerPainter({required this.count, required this.tickW, required this.pad, required this.min, required this.step});

  @override
  void paint(Canvas canvas, Size size) {
    final minor = Paint()
      ..color = LuxColors.alpha(LuxColors.silverDim, 0.5)
      ..strokeWidth = 1.5
      ..strokeCap = StrokeCap.round;
    final major = Paint()
      ..color = LuxColors.silver
      ..strokeWidth = 2
      ..strokeCap = StrokeCap.round;
    final perUnit = (1 / step).round();
    for (var i = 0; i <= count; i++) {
      final x = pad + i * tickW;
      final isMajor = perUnit > 0 && i % perUnit == 0;
      final isMid = perUnit > 1 && i % math.max(1, perUnit ~/ 2) == 0;
      final h = isMajor ? 34.0 : (isMid ? 24.0 : 16.0);
      canvas.drawLine(Offset(x, 2), Offset(x, 2 + h), isMajor ? major : minor);
      if (isMajor) {
        final v = min + i * step;
        final tp = TextPainter(
          text: TextSpan(text: faDigits(v.round()), style: LuxText.caption.copyWith(color: LuxColors.textDim)),
          textDirection: TextDirection.rtl,
        )..layout();
        tp.paint(canvas, Offset(x - tp.width / 2, 44));
      }
    }
  }

  @override
  bool shouldRepaint(covariant _RulerPainter old) =>
      old.count != count || old.pad != pad || old.min != min || old.step != step;
}
