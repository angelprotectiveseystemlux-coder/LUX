import 'package:flutter/material.dart';
import '../../core/palette.dart';
import '../../core/theme.dart';

/// امضای پایین پروفایل: لوگوی پیشوا + «By Pishva System»
class PishvaCredit extends StatelessWidget {
  final String? versionLine;
  const PishvaCredit({super.key, this.versionLine});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(top: 18, bottom: 8),
      child: Column(
        children: [
          Container(
            height: 1,
            margin: const EdgeInsets.symmetric(horizontal: 48),
            decoration: BoxDecoration(
              gradient: LinearGradient(colors: [
                LuxColors.alpha(LuxColors.accent, 0.0),
                LuxColors.alpha(LuxColors.accent, 0.55),
                LuxColors.alpha(LuxColors.accent, 0.0),
              ]),
            ),
          ),
          const SizedBox(height: 26),
          Image.asset(
            'assets/logo/pishva_logo.png',
            width: 150,
            height: 150,
            cacheWidth: 450,
            filterQuality: FilterQuality.high,
          ),
          const SizedBox(height: 12),
          Directionality(
            textDirection: TextDirection.ltr,
            child: ShaderMask(
              blendMode: BlendMode.srcIn,
              shaderCallback: (r) => const LinearGradient(
                colors: [Color(0xFFFFFFFF), Color(0xFF8FD3F4), Color(0xFF19B8F0)],
              ).createShader(r),
              child: Text(
                'By Pishva System',
                textAlign: TextAlign.center,
                style: const TextStyle(
                  fontFamily: LuxText.fontCredit,
                  fontFamilyFallback: <String>['monospace'],
                  fontSize: 17,
                  letterSpacing: 3.2,
                  color: Colors.white,
                  height: 1.2,
                ),
              ),
            ),
          ),
          if (versionLine != null) ...[
            const SizedBox(height: 10),
            Text(versionLine!, style: LuxText.caption.copyWith(color: LuxColors.silverDim)),
          ],
        ],
      ),
    );
  }
}
