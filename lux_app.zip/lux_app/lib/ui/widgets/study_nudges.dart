import 'package:flutter/material.dart';

import '../../core/app_bus.dart';
import '../../core/jalali_utils.dart';
import '../../core/palette.dart';
import '../../core/theme.dart';
import '../../core/util.dart';
import '../../data/review_repo.dart';
import '../pages/manage/overdue_page.dart';
import '../pages/manage/review_pages.dart';
import 'lux_card.dart';
import 'lux_kit.dart';

/// روی صفحه‌ی «امروز»: اگر مروری موعدش رسیده یا کاری عقب افتاده، یادآوری می‌کند. وقتی چیزی نیست، چیزی نشان نمی‌دهد.
class StudyNudges extends StatefulWidget {
  const StudyNudges({super.key});

  @override
  State<StudyNudges> createState() => _StudyNudgesState();
}

class _StudyNudgesState extends State<StudyNudges> {
  int _review = 0;
  int _overdue = 0;

  @override
  void initState() {
    super.initState();
    _load();
    AppBus.data.addListener(_load);
  }

  @override
  void dispose() {
    AppBus.data.removeListener(_load);
    super.dispose();
  }

  Future<void> _load() async {
    int r = 0;
    int o = 0;
    try {
      r = await ReviewRepo.dueCount();
      o = await overdueTaskCount();
    } catch (_) {}
    if (!mounted) return;
    setState(() {
      _review = r;
      _overdue = o;
    });
  }

  Widget _card(IconData icon, Color color, String title, String sub, VoidCallback onTap) => Padding(
        padding: const EdgeInsets.only(bottom: 12),
        child: LuxCard(
          radius: 24,
          onTap: onTap,
          child: Row(
            children: [
              Container(
                width: 46,
                height: 46,
                decoration: BoxDecoration(color: LuxColors.alpha(color, 0.15), shape: BoxShape.circle),
                child: Icon(icon, color: color),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(title, style: LuxText.heading),
                    Text(sub, style: LuxText.caption),
                  ],
                ),
              ),
              Icon(Icons.chevron_left_rounded, color: LuxColors.silverDim),
            ],
          ),
        ),
      );

  @override
  Widget build(BuildContext context) {
    if (_review == 0 && _overdue == 0) return const SizedBox.shrink();
    return Column(
      children: [
        if (_overdue > 0)
          _card(Icons.update_rounded, LuxColors.danger, '${faDigits(_overdue)} کارِ عقب‌افتاده', 'بزن تا لوکس برات توی روزهای آینده پخششون کنه',
              () => pushPage<void>(context, const OverduePage())),
        if (_review > 0)
          _card(Icons.replay_circle_filled_rounded, LuxColors.accent, '${faDigits(_review)} مورد برای مرورِ امروز', 'اشتباه‌ها و فصل‌هایی که وقتِ مرورشونه',
              () => pushPage<void>(context, const ReviewPage())),
      ],
    );
  }
}
