import 'package:flutter/material.dart';
import '../../core/palette.dart';
import '../../core/theme.dart';
import 'haptic.dart';

/// کارتِ گردِ پایه با افکت فشار (بدون بلور و سایه‌ی سنگین — سبک و روان).
class LuxCard extends StatefulWidget {
  final Widget child;
  final EdgeInsetsGeometry padding;
  final VoidCallback? onTap;
  final Color? color;
  final double radius;
  final Border? border;

  const LuxCard({
    super.key,
    required this.child,
    this.padding = const EdgeInsets.all(18),
    this.onTap,
    this.color,
    this.radius = 26,
    this.border,
  });

  @override
  State<LuxCard> createState() => _LuxCardState();
}

class _LuxCardState extends State<LuxCard> {
  bool _down = false;

  @override
  Widget build(BuildContext context) {
    final box = Container(
      padding: widget.padding,
      decoration: BoxDecoration(
        color: widget.color ?? LuxColors.card,
        borderRadius: BorderRadius.circular(LuxColors.r(widget.radius)),
        border: widget.border ??
            (LuxColors.hardShadow
                ? Border.all(color: LuxColors.strokeColor, width: LuxColors.strokeW)
                : Border.all(color: LuxColors.alpha(LuxColors.stroke, LuxColors.isDark ? 0.55 : 0.5), width: 1)),
        boxShadow: LuxColors.hardShadow
            ? LuxColors.shadow()
            : (LuxColors.isDark
                ? const <BoxShadow>[]
                : const <BoxShadow>[BoxShadow(color: Color(0x0F0F1720), blurRadius: 22, offset: Offset(0, 8))]),
      ),
      child: widget.child,
    );
    if (widget.onTap == null) return box;
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTapDown: (_) => setState(() => _down = true),
      onTapCancel: () => setState(() => _down = false),
      onTapUp: (_) => setState(() => _down = false),
      onTap: () {
        Haptic.tap();
        widget.onTap!();
      },
      child: AnimatedScale(
        scale: _down ? 0.975 : 1.0,
        duration: LuxMotion.fast,
        curve: LuxMotion.curve,
        child: box,
      ),
    );
  }
}
