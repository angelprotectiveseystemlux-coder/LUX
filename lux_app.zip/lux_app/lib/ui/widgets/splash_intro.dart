import 'package:flutter/material.dart';
import '../../core/palette.dart';
import '../../core/theme.dart';

/// انیمیشن ورودِ LUX در هر بار باز شدنِ برنامه (غیر از معرفی اولیه):
/// حلقه‌هایی از نور پخش می‌شوند، لوگو از وسط با یک دایره‌ی باز‌شونده نمایان می‌شود،
/// نام برند از حالتِ باز به حالتِ جمع می‌رسد و همه محو می‌شود.
class SplashIntro extends StatefulWidget {
  final VoidCallback onDone;
  const SplashIntro({super.key, required this.onDone});

  @override
  State<SplashIntro> createState() => _SplashIntroState();
}

class _SplashIntroState extends State<SplashIntro> with SingleTickerProviderStateMixin {
  late final AnimationController _c = AnimationController(vsync: this, duration: const Duration(milliseconds: 1900));
  bool _done = false;

  @override
  void initState() {
    super.initState();
    _c.forward().whenComplete(_finish);
  }

  void _finish() {
    if (_done || !mounted) return;
    _done = true;
    widget.onDone();
  }

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  double _iv(double t, double a, double b) => ((t - a) / (b - a)).clamp(0.0, 1.0).toDouble();

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTap: _finish,
      child: AnimatedBuilder(
        animation: _c,
        builder: (context, _) {
          final t = _c.value;
          final reveal = Curves.easeOutCubic.transform(_iv(t, 0.0, 0.5));
          final text = Curves.easeOut.transform(_iv(t, 0.35, 0.75));
          final fade = 1 - Curves.easeIn.transform(_iv(t, 0.82, 1.0));
          return Opacity(
            opacity: fade,
            child: Container(
              color: LuxColors.bg,
              alignment: Alignment.center,
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  SizedBox(
                    width: 240,
                    height: 240,
                    child: Stack(
                      alignment: Alignment.center,
                      children: [
                        CustomPaint(size: const Size(240, 240), painter: _RingsPainter(t, LuxColors.accent)),
                        ClipPath(
                          clipper: _CircleReveal(reveal),
                          child: Transform.scale(
                            scale: 0.86 + 0.14 * reveal,
                            child: Image.asset('assets/logo/lux_logo.png', width: 150, height: 150, cacheWidth: 450),
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 14),
                  Opacity(
                    opacity: text,
                    child: Directionality(
                      textDirection: TextDirection.ltr,
                      child: Text(
                        'LUX',
                        style: TextStyle(
                          fontFamily: LuxText.fontCredit,
                          fontFamilyFallback: const <String>['monospace'],
                          fontSize: 30,
                          letterSpacing: 16 - 10 * text,
                          color: LuxColors.text,
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(height: 8),
                  Opacity(opacity: text, child: Text('مدیریت هوشمند تحصیل', style: LuxText.caption)),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}

class _CircleReveal extends CustomClipper<Path> {
  final double r;
  _CircleReveal(this.r);

  @override
  Path getClip(Size size) {
    return Path()..addOval(Rect.fromCircle(center: size.center(Offset.zero), radius: size.longestSide * 0.75 * r));
  }

  @override
  bool shouldReclip(covariant _CircleReveal old) => old.r != r;
}

class _RingsPainter extends CustomPainter {
  final double t;
  final Color color;
  _RingsPainter(this.t, this.color);

  @override
  void paint(Canvas canvas, Size size) {
    final c = size.center(Offset.zero);
    for (var i = 0; i < 3; i++) {
      final phase = (t * 1.25 - i * 0.16).clamp(0.0, 1.0).toDouble();
      if (phase <= 0 || phase >= 1) continue;
      final radius = 46 + phase * 74;
      final p = Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1.6
        ..color = LuxColors.alpha(color, (1 - phase) * 0.55);
      canvas.drawCircle(c, radius, p);
    }
  }

  @override
  bool shouldRepaint(covariant _RingsPainter old) => old.t != t || old.color != color;
}
