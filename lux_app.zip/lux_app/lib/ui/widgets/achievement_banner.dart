import 'dart:async';
import 'package:flutter/material.dart';
import '../../core/achievements.dart';
import '../../core/palette.dart';
import '../../core/theme.dart';
import 'haptic.dart';

/// اعلانِ بالای صفحه برای جایزه‌ی تازه. هر جایزه یک‌بار و به‌نوبت نشان داده می‌شود.
class AchievementBanner extends StatefulWidget {
  const AchievementBanner({super.key});

  @override
  State<AchievementBanner> createState() => _AchievementBannerState();
}

class _AchievementBannerState extends State<AchievementBanner> {
  AchEvent? _cur;
  bool _show = false;
  Timer? _t;

  @override
  void initState() {
    super.initState();
    Achievements.events.addListener(_pump);
    WidgetsBinding.instance.addPostFrameCallback((_) => _pump());
  }

  @override
  void dispose() {
    _t?.cancel();
    Achievements.events.removeListener(_pump);
    super.dispose();
  }

  void _pump() {
    if (_cur != null || !mounted) return;
    final l = Achievements.events.value;
    if (l.isEmpty) return;
    final e = l.first;
    Haptic.heavy();
    setState(() {
      _cur = e;
      _show = true;
    });
    _t = Timer(Duration(milliseconds: e.big ? 4800 : 3400), () {
      if (!mounted) return;
      setState(() => _show = false);
      Timer(const Duration(milliseconds: 420), () {
        if (!mounted) return;
        Achievements.dismissFirst();
        setState(() => _cur = null);
        _pump();
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    final e = _cur;
    if (e == null) return const SizedBox.shrink();
    final pad = MediaQuery.of(context).padding;
    final c = achTierColor(e.tier);
    return Positioned(
      top: pad.top + 10,
      left: 16,
      right: 16,
      child: IgnorePointer(
        child: AnimatedSlide(
          duration: const Duration(milliseconds: 420),
          curve: Curves.easeOutBack,
          offset: _show ? Offset.zero : const Offset(0, -1.6),
          child: AnimatedOpacity(
            duration: const Duration(milliseconds: 300),
            opacity: _show ? 1 : 0,
            child: Material(
              color: Colors.transparent,
              child: Container(
                padding: EdgeInsets.symmetric(horizontal: 16, vertical: e.big ? 22 : 14),
                decoration: BoxDecoration(
                  color: LuxColors.card,
                  borderRadius: BorderRadius.circular(LuxColors.r(22)),
                  border: Border.all(color: c.withOpacity(0.8), width: 1.4),
                  boxShadow: [BoxShadow(color: c.withOpacity(0.35), blurRadius: e.big ? 36 : 22, spreadRadius: e.big ? 2 : 0)],
                ),
                child: Row(
                  children: [
                    Container(
                      width: e.big ? 58 : 46,
                      height: e.big ? 58 : 46,
                      decoration: BoxDecoration(shape: BoxShape.circle, color: c.withOpacity(0.18), border: Border.all(color: c, width: 2)),
                      child: Icon(e.icon, color: c, size: e.big ? 30 : 24),
                    ),
                    const SizedBox(width: 14),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Text(e.big ? '✨ ${e.title}' : '🏅 ${e.title}', style: LuxText.title.copyWith(fontSize: e.big ? 18 : 15)),
                          const SizedBox(height: 3),
                          Text(e.sub, style: LuxText.caption),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
