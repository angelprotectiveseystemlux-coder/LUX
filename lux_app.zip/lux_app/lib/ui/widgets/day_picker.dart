import 'package:flutter/material.dart';
import 'package:shamsi_date/shamsi_date.dart';
import '../../core/jalali_utils.dart';
import '../../core/theme.dart';
import 'jalali_picker.dart';
import 'lux_button.dart';
import 'lux_kit.dart';

/// انتخابِ یک روزِ شمسی (بدون ساعت). از سال گذشته تا شش سال بعد.
Future<DateTime?> pickJalaliDay(BuildContext context, {DateTime? initial, int yearsBack = 2, int yearsAhead = 6}) async {
  var j = Jalali.fromDateTime(initial ?? DateTime.now());
  final nowY = Jalali.now().year;
  final ok = await showLuxSheet<bool>(
    context,
    (ctx) => Column(
      mainAxisSize: MainAxisSize.min,
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Text('انتخاب تاریخ', style: LuxText.title),
        const SizedBox(height: 12),
        JalaliDatePicker(minYear: nowY - yearsBack, maxYear: nowY + yearsAhead, initial: j, onChanged: (x) => j = x),
        const SizedBox(height: 16),
        LuxButton(label: 'تأیید', onPressed: () => Navigator.of(ctx).pop(true)),
      ],
    ),
  );
  if (ok != true) return null;
  return dateOnly(j.toDateTime());
}
