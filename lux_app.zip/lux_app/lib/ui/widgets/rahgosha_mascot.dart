import 'dart:math' as math;
import 'package:flutter/material.dart';
import '../../core/nav.dart';
import '../../core/palette.dart';
import '../../core/theme.dart';
import '../../services/rahgosha.dart';
import '../pages/rahgosha_page.dart';
import 'haptic.dart';

enum RgMood { idle, think, talk, happy }

/// کله‌ی رباتِ گوگولیِ رهگشا: پلک می‌زند، چشمش دنبالِ انگشت می‌چرخد و حالت دارد.
class RgMascot extends StatefulWidget {
  final double size;
  final RgMood mood;
  final Color? color;
  const RgMascot({super.key, this.size = 56, this.mood = RgMood.idle, this.color});

  @override
  State<RgMascot> createState() => _RgMascotState();
}

class _RgMascotState extends State<RgMascot> with SingleTickerProviderStateMixin {
  late final AnimationController _c = AnimationController(vsync: this, duration: const Duration(milliseconds: 6000))..repeat();
  final GlobalKey _key = GlobalKey();
  Offset _look = Offset.zero;

  @override
  void initState() {
    super.initState();
    _c.addListener(_tick);
  }

  @override
  void dispose() {
    _c.removeListener(_tick);
    _c.dispose();
    super.dispose();
  }

  void _tick() {
    Offset target = Offset.zero;
    final p = Rahgosha.pointer.value;
    final ro = _key.currentContext?.findRenderObject();
    if (p != null && ro is RenderBox && ro.attached) {
      final center = ro.localToGlobal(ro.size.center(Offset.zero));
      final d = p - center;
      final len = d.distance;
      if (len > 1) target = d / math.max(len, 120.0);
    }
    final next = Offset.lerp(_look, Offset(target.dx.clamp(-1.0, 1.0), target.dy.clamp(-1.0, 1.0)), 0.18)!;
    if (mounted) setState(() => _look = next); // هر فریم؛ پلک‌زدن و جنبشِ سر هم از همین می‌آید
  }

  @override
  Widget build(BuildContext context) {
    return RepaintBoundary(
      key: _key,
      child: SizedBox(
        width: widget.size,
        height: widget.size,
        child: CustomPaint(painter: _RgPainter(_c.value, _look, widget.mood, widget.color ?? LuxColors.accent)),
      ),
    );
  }
}

class _RgPainter extends CustomPainter {
  final double t;
  final Offset look;
  final RgMood mood;
  final Color color;
  _RgPainter(this.t, this.look, this.mood, this.color);

  @override
  void paint(Canvas canvas, Size s) {
    final w = s.width;
    final ms = t * 6000;
    final bob = math.sin(t * math.pi * 2) * w * 0.02;
    canvas.translate(0, bob);

    // آنتن
    final tipGlow = 0.55 + 0.45 * math.sin(t * math.pi * 6);
    final ap = Paint()
      ..color = color.withOpacity(0.9)
      ..strokeWidth = w * 0.04
      ..strokeCap = StrokeCap.round;
    canvas.drawLine(Offset(w * 0.5, w * 0.2), Offset(w * 0.5, w * 0.09), ap);
    canvas.drawCircle(Offset(w * 0.5, w * 0.08), w * 0.055, Paint()..color = Colors.white.withOpacity(0.9));
    canvas.drawCircle(Offset(w * 0.5, w * 0.08), w * (0.09 + 0.03 * tipGlow), Paint()..color = color.withOpacity(0.28 * tipGlow));

    // گوش‌ها
    final earP = Paint()..color = color.withOpacity(0.85);
    canvas.drawRRect(RRect.fromRectAndRadius(Rect.fromLTWH(w * 0.045, w * 0.44, w * 0.09, w * 0.2), Radius.circular(w * 0.04)), earP);
    canvas.drawRRect(RRect.fromRectAndRadius(Rect.fromLTWH(w * 0.865, w * 0.44, w * 0.09, w * 0.2), Radius.circular(w * 0.04)), earP);

    // سر
    final head = RRect.fromRectAndRadius(Rect.fromLTWH(w * 0.1, w * 0.2, w * 0.8, w * 0.68), Radius.circular(w * 0.24));
    canvas.drawRRect(
      head,
      Paint()..shader = LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: [Color.lerp(color, Colors.white, 0.35)!, color]).createShader(head.outerRect),
    );

    // صفحه‌ی صورت
    final plate = RRect.fromRectAndRadius(Rect.fromLTWH(w * 0.18, w * 0.3, w * 0.64, w * 0.46), Radius.circular(w * 0.18));
    canvas.drawRRect(plate, Paint()..color = const Color(0xFF0B1118));

    // چشم‌ها
    final eyeY = w * 0.49 + look.dy * w * 0.025;
    final dx = look.dx * w * 0.035;
    final blinkT = (ms % 4200);
    final blink = blinkT > 4000 ? 1 - ((blinkT - 4000) / 200 - 1).abs() : 0.0; // ۰..۱..۰
    final eyeColor = Color.lerp(color, Colors.white, 0.7)!;
    for (final cx in [w * 0.37, w * 0.63]) {
      final c = Offset(cx + dx, eyeY);
      if (mood == RgMood.happy) {
        final p = Path()..addArc(Rect.fromCenter(center: c.translate(0, w * 0.03), width: w * 0.12, height: w * 0.12), math.pi, math.pi);
        canvas.drawPath(p, Paint()..style = PaintingStyle.stroke..strokeWidth = w * 0.04..strokeCap = StrokeCap.round..color = eyeColor);
      } else {
        var h = w * 0.13 * (1 - 0.92 * blink);
        var wd = w * 0.095;
        if (mood == RgMood.think) {
          h *= 0.75;
          wd *= 0.9;
        }
        final rect = Rect.fromCenter(center: c, width: wd, height: math.max(h, w * 0.012));
        canvas.drawRRect(RRect.fromRectAndRadius(rect, Radius.circular(w * 0.05)), Paint()..color = eyeColor);
        canvas.drawCircle(c.translate(-wd * 0.18, -h * 0.18), w * 0.018, Paint()..color = Colors.white.withOpacity(0.85 * (1 - blink)));
      }
    }

    // لپ‌ها
    if (mood == RgMood.happy) {
      final cp = Paint()..color = const Color(0xFFFF8FB1).withOpacity(0.55);
      canvas.drawCircle(Offset(w * 0.27, w * 0.62), w * 0.04, cp);
      canvas.drawCircle(Offset(w * 0.73, w * 0.62), w * 0.04, cp);
    }

    // دهان
    final mc = Offset(w * 0.5 + dx * 0.4, w * 0.65);
    if (mood == RgMood.talk) {
      final open = 0.4 + 0.6 * (0.5 + 0.5 * math.sin(t * math.pi * 24));
      canvas.drawOval(Rect.fromCenter(center: mc, width: w * 0.1, height: w * 0.07 * open), Paint()..color = eyeColor);
    } else if (mood == RgMood.think) {
      canvas.drawLine(mc.translate(-w * 0.04, 0), mc.translate(w * 0.04, 0), Paint()..color = eyeColor..strokeWidth = w * 0.025..strokeCap = StrokeCap.round);
    } else {
      final p = Path()..addArc(Rect.fromCenter(center: mc.translate(0, -w * 0.02), width: w * 0.12, height: w * 0.09), 0.2, math.pi - 0.4);
      canvas.drawPath(p, Paint()..style = PaintingStyle.stroke..strokeWidth = w * 0.03..strokeCap = StrokeCap.round..color = eyeColor);
    }
  }

  @override
  bool shouldRepaint(covariant _RgPainter old) => true;
}

/// دکمه‌ی شناورِ رهگشا؛ روی همه‌ی صفحه‌ها دیده می‌شود، می‌شود جابه‌جایش کرد.
class RahgoshaFab extends StatefulWidget {
  const RahgoshaFab({super.key});

  @override
  State<RahgoshaFab> createState() => _RahgoshaFabState();
}

class _RahgoshaFabState extends State<RahgoshaFab> {
  Offset? _pos;
  static const double _sz = 58;

  void _open() {
    Haptic.light();
    Rahgosha.unread.value = false;
    Rahgosha.bubble.value = null;
    luxNavKey.currentState?.push(PageRouteBuilder<void>(
      transitionDuration: const Duration(milliseconds: 380),
      pageBuilder: (_, __, ___) => const RahgoshaPage(),
      transitionsBuilder: (_, a, __, child) => FadeTransition(
        opacity: a,
        child: ScaleTransition(scale: Tween<double>(begin: 0.92, end: 1).animate(CurvedAnimation(parent: a, curve: Curves.easeOutCubic)), child: child),
      ),
    ));
  }

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;
    final pad = MediaQuery.of(context).padding;
    _pos ??= Offset(size.width - _sz - 12, size.height - pad.bottom - 190);
    final pos = Offset(_pos!.dx.clamp(8.0, size.width - _sz - 8), _pos!.dy.clamp(pad.top + 8, size.height - pad.bottom - _sz - 8));
    final onRight = pos.dx > size.width / 2;
    return Positioned.fill(
      child: Material(
        type: MaterialType.transparency,
        child: Stack(
        children: [
          Positioned(
            left: pos.dx,
            top: pos.dy,
            child: ValueListenableBuilder<bool>(
              valueListenable: Rahgosha.chatOpen,
              builder: (context, open, _) {
                if (open) return const SizedBox.shrink();
                return GestureDetector(
                  onTap: _open,
                  onPanUpdate: (d) => setState(() => _pos = _pos! + d.delta),
                  onPanEnd: (_) => setState(() {
                    final x = _pos!.dx + _sz / 2 < size.width / 2 ? 10.0 : size.width - _sz - 10;
                    _pos = Offset(x, _pos!.dy);
                  }),
                  child: SizedBox(
                    width: _sz,
                    height: _sz,
                    child: Stack(
                      clipBehavior: Clip.none,
                      children: [
                        Container(
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            color: LuxColors.card,
                            border: Border.all(color: LuxColors.alpha(LuxColors.accent, 0.5), width: 1.4),
                            boxShadow: [BoxShadow(color: LuxColors.alpha(LuxColors.accent, 0.35), blurRadius: 18)],
                          ),
                          padding: const EdgeInsets.all(4),
                          child: ValueListenableBuilder<bool>(
                            valueListenable: Rahgosha.unread,
                            builder: (context, un, _) => ValueListenableBuilder<bool>(
                              valueListenable: Rahgosha.thinking,
                              builder: (context, th, _) => RgMascot(size: _sz - 8, mood: th ? RgMood.think : (un ? RgMood.happy : RgMood.idle), color: Rahgosha.color(LuxColors.accent)),
                            ),
                          ),
                        ),
                        ValueListenableBuilder<bool>(
                          valueListenable: Rahgosha.unread,
                          builder: (context, un, _) => un
                              ? Positioned(top: 0, right: 0, child: Container(width: 14, height: 14, decoration: BoxDecoration(shape: BoxShape.circle, color: LuxColors.danger, border: Border.all(color: LuxColors.card, width: 2))))
                              : const SizedBox.shrink(),
                        ),
                        Positioned(
                          top: -4,
                          left: onRight ? null : _sz + 8,
                          right: onRight ? _sz + 8 : null,
                          child: ValueListenableBuilder<String?>(
                            valueListenable: Rahgosha.bubble,
                            builder: (context, b, _) => AnimatedOpacity(
                              duration: const Duration(milliseconds: 250),
                              opacity: b == null ? 0 : 1,
                              child: b == null
                                  ? const SizedBox.shrink()
                                  : Container(
                                      constraints: const BoxConstraints(maxWidth: 210),
                                      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 9),
                                      decoration: BoxDecoration(color: LuxColors.card, borderRadius: BorderRadius.circular(LuxColors.r(16)), border: Border.all(color: LuxColors.alpha(LuxColors.accent, 0.5))),
                                      child: Text(b, style: LuxText.caption.copyWith(color: LuxColors.text, height: 1.5)),
                                    ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
          ),
        ],
      ),
      ),
    );
  }
}
