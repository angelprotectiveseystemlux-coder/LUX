import 'package:flutter/material.dart';
import 'package:shamsi_date/shamsi_date.dart';
import '../../core/jalali_utils.dart';
import '../../core/palette.dart';
import '../../core/theme.dart';
import 'haptic.dart';
import 'jalali_picker.dart';
import 'lux_button.dart';
import 'lux_chip.dart';

/// ابزارهای مشترک فرم‌ها و صفحه‌های مدیریتی (درس، معلم، امتحان، تکلیف، …).

Future<T?> showLuxSheet<T>(BuildContext context, Widget Function(BuildContext) builder) {
  return showModalBottomSheet<T>(
    context: context,
    isScrollControlled: true,
    backgroundColor: LuxColors.card,
    builder: (ctx) => SafeArea(
      top: false,
      child: Padding(
        padding: EdgeInsets.fromLTRB(22, 22, 22, 22 + MediaQuery.of(ctx).viewInsets.bottom),
        child: SingleChildScrollView(child: builder(ctx)),
      ),
    ),
  );
}

Future<bool> luxConfirm(BuildContext context, String title, {String? body, String yes = 'حذف'}) async {
  final r = await showDialog<bool>(
    context: context,
    builder: (ctx) => AlertDialog(
      backgroundColor: LuxColors.card,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
      title: Text(title, style: LuxText.title),
      content: body == null ? null : Text(body, style: LuxText.body),
      actions: [
        TextButton(onPressed: () => Navigator.of(ctx).pop(false), child: Text('انصراف', style: LuxText.label)),
        TextButton(
          onPressed: () => Navigator.of(ctx).pop(true),
          child: Text(yes, style: LuxText.label.copyWith(color: LuxColors.danger)),
        ),
      ],
    ),
  );
  return r == true;
}

void luxToast(BuildContext context, String message) {
  ScaffoldMessenger.of(context)
    ..hideCurrentSnackBar()
    ..showSnackBar(SnackBar(content: Text(message)));
}

/// پیامِ کوتاه که روی برگه‌ها (bottom sheet) هم دیده می‌شود (SnackBar زیرِ برگه پنهان می‌ماند).
Future<void> luxNotice(BuildContext context, String message) {
  return showDialog<void>(
    context: context,
    builder: (ctx) => AlertDialog(
      backgroundColor: LuxColors.card,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
      content: Text(message, style: LuxText.body),
      actions: [
        TextButton(onPressed: () => Navigator.of(ctx).pop(), child: Text('باشه', style: LuxText.label)),
      ],
    ),
  );
}

Future<T?> pushPage<T>(BuildContext context, Widget page) =>
    Navigator.of(context).push<T>(MaterialPageRoute<T>(builder: (_) => page));

/// انتخاب تاریخ شمسی (و در صورت نیاز ساعت). اگر کاربر انصراف بدهد null برمی‌گرداند.
Future<DateTime?> pickJalaliDateTime(BuildContext context, {DateTime? initial, bool withTime = true}) async {
  final init = initial ?? DateTime.now();
  var j = Jalali.fromDateTime(init);
  final nowY = Jalali.now().year;
  final ok = await showLuxSheet<bool>(
    context,
    (ctx) => Column(
      mainAxisSize: MainAxisSize.min,
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Text('انتخاب تاریخ', style: LuxText.title),
        const SizedBox(height: 12),
        JalaliDatePicker(minYear: nowY - 3, maxYear: nowY + 3, initial: j, onChanged: (x) => j = x),
        const SizedBox(height: 16),
        LuxButton(label: 'تأیید', onPressed: () => Navigator.of(ctx).pop(true)),
      ],
    ),
  );
  if (ok != true) return null;
  var h = init.hour;
  var m = init.minute;
  if (withTime) {
    if (!context.mounted) return null;
    final t = await showTimePicker(context: context, initialTime: TimeOfDay(hour: h, minute: m));
    if (t == null) return null;
    h = t.hour;
    m = t.minute;
  }
  final g = j.toDateTime();
  return DateTime(g.year, g.month, g.day, h, m);
}

Future<int?> pickTimeOfDayMinutes(BuildContext context, int initialMinutes) async {
  final t = await showTimePicker(
    context: context,
    initialTime: TimeOfDay(hour: initialMinutes ~/ 60, minute: initialMinutes % 60),
  );
  if (t == null) return null;
  return t.hour * 60 + t.minute;
}

/// فیلد متنیِ استاندارد با برچسب بالا
class LuxField extends StatelessWidget {
  final String label;
  final TextEditingController controller;
  final String? hint;
  final TextInputType? keyboard;
  final int maxLines;

  const LuxField({
    super.key,
    required this.label,
    required this.controller,
    this.hint,
    this.keyboard,
    this.maxLines = 1,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 14),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsetsDirectional.only(start: 4, bottom: 6),
            child: Text(label, style: LuxText.caption),
          ),
          TextField(
            controller: controller,
            keyboardType: keyboard,
            maxLines: maxLines,
            style: LuxText.body,
            decoration: LuxInput.decoration(hint ?? ''),
          ),
        ],
      ),
    );
  }
}

/// فیلدِ قابل‌لمس (برای تاریخ، ساعت، انتخاب درس و …)
class LuxPickField extends StatelessWidget {
  final String label;
  final String value;
  final VoidCallback onTap;
  final IconData icon;
  final bool placeholder;

  const LuxPickField({
    super.key,
    required this.label,
    required this.value,
    required this.onTap,
    this.icon = Icons.expand_more_rounded,
    this.placeholder = false,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 14),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsetsDirectional.only(start: 4, bottom: 6),
            child: Text(label, style: LuxText.caption),
          ),
          GestureDetector(
            behavior: HitTestBehavior.opaque,
            onTap: () {
              Haptic.tap();
              onTap();
            },
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 16),
              decoration: BoxDecoration(color: LuxColors.cardHi, borderRadius: BorderRadius.circular(18)),
              child: Row(
                children: [
                  Expanded(
                    child: Text(
                      value,
                      style: LuxText.body.copyWith(color: placeholder ? LuxColors.textDim : LuxColors.text),
                    ),
                  ),
                  Icon(icon, color: LuxColors.silverDim, size: 22),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

/// برچسب + ردیفِ چیپ‌ها
class LuxChoice extends StatelessWidget {
  final String label;
  final List<String> options;
  final int selected; // -1 یعنی هیچ‌کدام
  final ValueChanged<int> onChanged;

  const LuxChoice({
    super.key,
    required this.label,
    required this.options,
    required this.selected,
    required this.onChanged,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 14),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsetsDirectional.only(start: 4, bottom: 8),
            child: Text(label, style: LuxText.caption),
          ),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: [
              for (var i = 0; i < options.length; i++)
                LuxChip(label: options[i], selected: i == selected, onTap: () => onChanged(i)),
            ],
          ),
        ],
      ),
    );
  }
}

/// دکمه‌ی گردِ «افزودن» برای سرِ صفحه‌ها
class LuxAddButton extends StatelessWidget {
  final VoidCallback onTap;
  final IconData icon;
  const LuxAddButton({super.key, required this.onTap, this.icon = Icons.add_rounded});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTap: () {
        Haptic.light();
        onTap();
      },
      child: Container(
        width: 46,
        height: 46,
        decoration: BoxDecoration(color: LuxColors.accent, shape: BoxShape.circle),
        child: Icon(icon, color: LuxColors.onAccent, size: 26),
      ),
    );
  }
}

/// حالتِ خالی با راهنما
class LuxEmpty extends StatelessWidget {
  final IconData icon;
  final String title;
  final String? hint;
  const LuxEmpty({super.key, required this.icon, required this.title, this.hint});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 36, horizontal: 24),
      child: Column(
        children: [
          Icon(icon, size: 44, color: LuxColors.silverDim),
          const SizedBox(height: 14),
          Text(title, style: LuxText.heading, textAlign: TextAlign.center),
          if (hint != null) ...[
            const SizedBox(height: 6),
            Text(hint!, style: LuxText.caption, textAlign: TextAlign.center),
          ],
        ],
      ),
    );
  }
}

/// نقطه‌ی رنگیِ درس
class LuxDot extends StatelessWidget {
  final Color color;
  final double size;
  const LuxDot({super.key, required this.color, this.size = 14});

  @override
  Widget build(BuildContext context) =>
      Container(width: size, height: size, decoration: BoxDecoration(color: color, shape: BoxShape.circle));
}

/// قابِ صفحه‌های داخلی (با دکمه‌ی برگشت)
class LuxSubPage extends StatelessWidget {
  final String title;
  final String? subtitle;
  final Widget? action;
  final List<Widget> children;

  const LuxSubPage({super.key, required this.title, this.subtitle, this.action, required this.children});

  @override
  Widget build(BuildContext context) {
    final pad = MediaQuery.of(context).padding;
    return Scaffold(
      backgroundColor: LuxColors.bg,
      body: ListView(
        physics: const BouncingScrollPhysics(),
        padding: EdgeInsets.fromLTRB(20, pad.top + 14, 20, 40 + pad.bottom),
        children: [
          Row(
            children: [
              GestureDetector(
                behavior: HitTestBehavior.opaque,
                onTap: () {
                  Haptic.tap();
                  Navigator.of(context).maybePop();
                },
                child: Container(
                  width: 46,
                  height: 46,
                  decoration: BoxDecoration(
                    color: LuxColors.cardHi,
                    shape: BoxShape.circle,
                    border: Border.all(color: LuxColors.stroke),
                  ),
                  child: Icon(Icons.arrow_back_rounded, color: LuxColors.silver, size: 22),
                ),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(title, style: LuxText.display.copyWith(fontSize: 26), maxLines: 1, overflow: TextOverflow.ellipsis),
                    if (subtitle != null) Text(subtitle!, style: LuxText.caption),
                  ],
                ),
              ),
              if (action != null) action!,
            ],
          ),
          const SizedBox(height: 22),
          ...children,
        ],
      ),
    );
  }
}

/// ردیف انتخابِ رنگ
class LuxColorPicker extends StatelessWidget {
  final int selected;
  final ValueChanged<int> onChanged;
  const LuxColorPicker({super.key, required this.selected, required this.onChanged});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 14),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsetsDirectional.only(start: 4, bottom: 8),
            child: Text('رنگ', style: LuxText.caption),
          ),
          Wrap(
            spacing: 12,
            runSpacing: 12,
            children: [
              for (var i = 0; i < LuxColors.series.length; i++)
                GestureDetector(
                  onTap: () {
                    Haptic.tap();
                    onChanged(i);
                  },
                  child: Container(
                    width: 36,
                    height: 36,
                    decoration: BoxDecoration(
                      color: LuxColors.series[i],
                      shape: BoxShape.circle,
                      border: Border.all(color: i == selected ? LuxColors.text : Colors.transparent, width: 2.5),
                    ),
                  ),
                ),
            ],
          ),
        ],
      ),
    );
  }
}

/// رنگِ ذخیره‌شده‌ی درس (اندیس در پالت) → Color
Color courseColor(Object? stored) {
  final i = stored is int ? stored : 0;
  return LuxColors.seriesAt(i < 0 ? 0 : i);
}

String weekdayName(int i) => jalaliWeekdays[i.clamp(0, 6)];
