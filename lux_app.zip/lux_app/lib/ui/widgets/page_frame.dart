import 'package:flutter/material.dart';
import '../../core/theme.dart';

/// قابِ استانداردِ هر تب: عنوان بزرگ + لیستِ روان با فاصله‌ی ثابت.
class PageFrame extends StatelessWidget {
  final String title;
  final String? subtitle;
  final Widget? trailing;
  final List<Widget> children;

  const PageFrame({super.key, required this.title, this.subtitle, this.trailing, required this.children});

  @override
  Widget build(BuildContext context) {
    final pad = MediaQuery.of(context).padding;
    return ListView.builder(
      physics: const BouncingScrollPhysics(),
      padding: EdgeInsets.fromLTRB(20, pad.top + 16, 20, 132 + pad.bottom),
      itemCount: children.length + 1,
      itemBuilder: (context, i) {
        if (i == 0) {
          return Padding(
            padding: const EdgeInsets.only(bottom: 22),
            child: Row(
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(title, style: LuxText.title.copyWith(fontSize: 26)),
                      if (subtitle != null) ...[
                        const SizedBox(height: 4),
                        Text(subtitle!, style: LuxText.caption),
                      ],
                    ],
                  ),
                ),
                if (trailing != null) trailing!,
              ],
            ),
          );
        }
        return children[i - 1];
      },
    );
  }
}
