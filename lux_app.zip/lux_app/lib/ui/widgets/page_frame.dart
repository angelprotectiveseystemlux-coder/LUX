import 'package:flutter/material.dart';
import '../../core/layout.dart';
import '../../core/theme.dart';

/// قابِ استانداردِ هر تب: عنوان بزرگ + لیستِ روان با فاصله‌ی ثابت.
/// در حالت افقی/عریض محتوا دو ستونه می‌شود و نوار پایینی جایی نمی‌گیرد.
class PageFrame extends StatelessWidget {
  final String title;
  final String? subtitle;
  final Widget? trailing;
  final List<Widget> children;

  const PageFrame({super.key, required this.title, this.subtitle, this.trailing, required this.children});

  Widget _header() {
    return Padding(
      padding: const EdgeInsets.only(bottom: 22),
      child: Row(
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title, style: LuxText.display),
                if (subtitle != null) ...[
                  const SizedBox(height: 4),
                  Text(subtitle!, style: LuxText.caption),
                ],
              ],
            ),
          ),
          if (trailing != null) trailing!,
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final pad = MediaQuery.of(context).padding;
    final wide = LuxLayout.isWide(context);
    final bottom = (wide ? 32.0 : 132.0) + pad.bottom;
    final left = 20.0 + pad.left;
    final right = 20.0 + (wide ? 0.0 : pad.right);
    return LayoutBuilder(builder: (context, cons) {
      final two = cons.maxWidth >= 760 && children.length > 1;
      if (!two) {
        return ListView.builder(
          physics: const BouncingScrollPhysics(),
          padding: EdgeInsets.fromLTRB(left, pad.top + 16, right, bottom),
          itemCount: children.length + 1,
          itemBuilder: (context, i) => i == 0 ? _header() : children[i - 1],
        );
      }
      final half = (children.length + 1) ~/ 2;
      return ListView(
        physics: const BouncingScrollPhysics(),
        padding: EdgeInsets.fromLTRB(left, pad.top + 16, right, bottom),
        children: [
          _header(),
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: children.sublist(0, half))),
              const SizedBox(width: 16),
              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: children.sublist(half))),
            ],
          ),
        ],
      );
    });
  }
}
