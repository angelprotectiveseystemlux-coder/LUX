import 'package:flutter/material.dart';
import '../../core/palette.dart';
import '../../core/theme.dart';
import 'haptic.dart';

class LuxButton extends StatefulWidget {
  final String label;
  final VoidCallback? onPressed;
  final bool filled;
  final IconData? icon;
  final bool expand;
  final bool compact;

  const LuxButton({
    super.key,
    required this.label,
    this.onPressed,
    this.filled = true,
    this.icon,
    this.expand = true,
    this.compact = false,
  });

  @override
  State<LuxButton> createState() => _LuxButtonState();
}

class _LuxButtonState extends State<LuxButton> {
  bool _down = false;

  @override
  Widget build(BuildContext context) {
    final enabled = widget.onPressed != null;
    final bg = !enabled
        ? LuxColors.cardHi
        : (widget.filled ? LuxColors.accent : LuxColors.alpha(LuxColors.accent, 0.12));
    final fg = !enabled
        ? LuxColors.textDim
        : (widget.filled ? LuxColors.onAccent : LuxColors.accent);
    final labelStyle = widget.compact
        ? LuxText.label.copyWith(color: fg, fontWeight: FontWeight.w700)
        : LuxText.heading.copyWith(color: fg);
    final child = FittedBox(
      fit: BoxFit.scaleDown,
      child: Row(
        mainAxisSize: MainAxisSize.min,
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          if (widget.icon != null) ...[Icon(widget.icon, size: 20, color: fg), const SizedBox(width: 8)],
          Text(widget.label, style: labelStyle, textAlign: TextAlign.center),
        ],
      ),
    );
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTapDown: enabled ? (_) => setState(() => _down = true) : null,
      onTapCancel: enabled ? () => setState(() => _down = false) : null,
      onTapUp: enabled ? (_) => setState(() => _down = false) : null,
      onTap: enabled
          ? () {
              Haptic.light();
              widget.onPressed!();
            }
          : null,
      child: AnimatedScale(
        scale: _down ? 0.97 : 1,
        duration: LuxMotion.fast,
        curve: LuxMotion.curve,
        child: Container(
          height: widget.compact ? 44 : 54,
          padding: EdgeInsets.symmetric(horizontal: widget.compact ? 8 : 26),
          decoration: BoxDecoration(
            color: bg,
            borderRadius: BorderRadius.circular(LuxColors.r(28)),
            border: LuxColors.hardShadow ? Border.all(color: LuxColors.stroke, width: LuxColors.strokeW) : null,
            boxShadow: enabled ? LuxColors.shadow(d: 2.5) : const <BoxShadow>[],
          ),
          alignment: Alignment.center,
          child: child,
        ),
      ),
    );
  }
}
