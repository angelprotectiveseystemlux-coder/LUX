import 'package:flutter/material.dart';
import '../../core/palette.dart';
import '../../core/theme.dart';
import 'haptic.dart';

class LuxButton extends StatefulWidget {
  final String label;
  final VoidCallback? onPressed;
  final bool filled;
  final IconData? icon;
  final bool expand;

  const LuxButton({
    super.key,
    required this.label,
    this.onPressed,
    this.filled = true,
    this.icon,
    this.expand = true,
  });

  @override
  State<LuxButton> createState() => _LuxButtonState();
}

class _LuxButtonState extends State<LuxButton> {
  bool _down = false;

  @override
  Widget build(BuildContext context) {
    final enabled = widget.onPressed != null;
    final bg = !enabled
        ? LuxColors.cardHi
        : (widget.filled ? LuxColors.accent : LuxColors.alpha(LuxColors.accent, 0.12));
    final fg = !enabled
        ? LuxColors.textDim
        : (widget.filled ? LuxColors.onAccent : LuxColors.accent);
    final child = Row(
      mainAxisSize: widget.expand ? MainAxisSize.max : MainAxisSize.min,
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        if (widget.icon != null) ...[Icon(widget.icon, size: 20, color: fg), const SizedBox(width: 8)],
        Text(widget.label, style: LuxText.heading.copyWith(color: fg)),
      ],
    );
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTapDown: enabled ? (_) => setState(() => _down = true) : null,
      onTapCancel: enabled ? () => setState(() => _down = false) : null,
      onTapUp: enabled ? (_) => setState(() => _down = false) : null,
      onTap: enabled
          ? () {
              Haptic.light();
              widget.onPressed!();
            }
          : null,
      child: AnimatedScale(
        scale: _down ? 0.97 : 1,
        duration: LuxMotion.fast,
        curve: LuxMotion.curve,
        child: Container(
          height: 54,
          padding: const EdgeInsets.symmetric(horizontal: 26),
          decoration: BoxDecoration(color: bg, borderRadius: BorderRadius.circular(28)),
          alignment: Alignment.center,
          child: child,
        ),
      ),
    );
  }
}
