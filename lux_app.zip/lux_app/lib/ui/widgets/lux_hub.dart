import 'dart:math' as math;
import 'package:flutter/material.dart';
import '../../core/palette.dart';
import '../../core/theme.dart';
import 'haptic.dart';
import 'lux_card.dart';

/// دکمه‌ی آیکونیِ گردگوشه برای سربرگ‌ها (تقویم، پروفایل، جست‌وجو، …)
class LuxIconBtn extends StatelessWidget {
  final IconData icon;
  final VoidCallback onTap;
  final bool accent;
  final double size;
  final String? badge;

  const LuxIconBtn({
    super.key,
    required this.icon,
    required this.onTap,
    this.accent = false,
    this.size = 44,
    this.badge,
  });

  @override
  Widget build(BuildContext context) {
    final bg = accent ? LuxColors.accent : LuxColors.card;
    final fg = accent ? LuxColors.onAccent : LuxColors.silver;
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTap: () {
        Haptic.tap();
        onTap();
      },
      child: Stack(
        clipBehavior: Clip.none,
        children: [
          Container(
            width: size,
            height: size,
            decoration: BoxDecoration(
              color: bg,
              borderRadius: BorderRadius.circular(LuxColors.r(size * 0.36)),
              border: accent ? null : Border.all(color: LuxColors.strokeColor, width: LuxColors.strokeW),
              boxShadow: LuxColors.shadow(d: 2),
            ),
            child: Icon(icon, color: fg, size: size * 0.5),
          ),
          if (badge != null)
            PositionedDirectional(
              top: -4,
              end: -4,
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                decoration: BoxDecoration(color: LuxColors.danger, borderRadius: BorderRadius.circular(10)),
                child: Text(badge!, style: LuxText.caption.copyWith(color: Colors.white, fontSize: 10.5, height: 1.2)),
              ),
            ),
        ],
      ),
    );
  }
}

/// کلیدِ چندبخشی (سگمنت) برای جابه‌جایی بین بخش‌های یک تب
class LuxSegmented extends StatelessWidget {
  final List<String> names;
  final int index;
  final ValueChanged<int> onChanged;

  const LuxSegmented({super.key, required this.names, required this.index, required this.onChanged});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(4),
      decoration: BoxDecoration(
        color: LuxColors.cardHi,
        borderRadius: BorderRadius.circular(LuxColors.r(20)),
      ),
      child: Row(
        children: [
          for (var i = 0; i < names.length; i++)
            Expanded(
              child: GestureDetector(
                behavior: HitTestBehavior.opaque,
                onTap: () {
                  if (i == index) return;
                  Haptic.tap();
                  onChanged(i);
                },
                child: AnimatedContainer(
                  duration: LuxMotion.fast,
                  curve: LuxMotion.curve,
                  padding: const EdgeInsets.symmetric(vertical: 11),
                  decoration: BoxDecoration(
                    color: i == index ? LuxColors.accent : Colors.transparent,
                    borderRadius: BorderRadius.circular(LuxColors.r(16)),
                  ),
                  child: Text(
                    names[i],
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    textAlign: TextAlign.center,
                    style: LuxText.label.copyWith(
                      color: i == index ? LuxColors.onAccent : LuxColors.textDim,
                      fontWeight: i == index ? FontWeight.w700 : FontWeight.w600,
                    ),
                  ),
                ),
              ),
            ),
        ],
      ),
    );
  }
}

/// عنوانِ یک گروه (کوچک و کم‌رنگ، بالای شبکه‌ی کاشی‌ها)
class LuxGroupTitle extends StatelessWidget {
  final String text;
  final Widget? trailing;
  const LuxGroupTitle(this.text, {super.key, this.trailing});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsetsDirectional.only(start: 4, end: 4, bottom: 10, top: 4),
      child: Row(
        children: [
          Expanded(child: Text(text, style: LuxText.label.copyWith(color: LuxColors.textDim, letterSpacing: 0.2))),
          if (trailing != null) trailing!,
        ],
      ),
    );
  }
}

/// کاشیِ میان‌بر: آیکون در قابِ رنگی + عنوان + توضیحِ کوتاه + نشان (عدد/وضعیت)
class LuxTile extends StatelessWidget {
  final IconData icon;
  final String title;
  final String? sub;
  final String? badge;
  final Color? tint;
  final VoidCallback onTap;

  const LuxTile({
    super.key,
    required this.icon,
    required this.title,
    required this.onTap,
    this.sub,
    this.badge,
    this.tint,
  });

  @override
  Widget build(BuildContext context) {
    final c = tint ?? LuxColors.accent;
    return LuxCard(
      padding: const EdgeInsets.all(14),
      radius: 22,
      onTap: onTap,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Row(
            children: [
              Container(
                width: 40,
                height: 40,
                decoration: BoxDecoration(
                  color: LuxColors.alpha(c, 0.14),
                  borderRadius: BorderRadius.circular(LuxColors.r(14)),
                ),
                child: Icon(icon, color: c, size: 22),
              ),
              const Spacer(),
              if (badge != null)
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 3),
                  decoration: BoxDecoration(
                    color: LuxColors.alpha(c, 0.14),
                    borderRadius: BorderRadius.circular(LuxColors.r(10)),
                  ),
                  child: Text(badge!, style: LuxText.caption.copyWith(color: c, fontWeight: FontWeight.w700)),
                ),
            ],
          ),
          const SizedBox(height: 12),
          Text(title, style: LuxText.heading.copyWith(fontSize: 15), maxLines: 1, overflow: TextOverflow.ellipsis),
          if (sub != null) ...[
            const SizedBox(height: 2),
            Text(sub!, style: LuxText.caption, maxLines: 2, overflow: TextOverflow.ellipsis),
          ],
        ],
      ),
    );
  }
}

/// شبکه‌ی دوستونه از کاشی‌ها (ارتفاعِ هر ردیف برابر)
class LuxTileGrid extends StatelessWidget {
  final List<Widget> tiles;
  const LuxTileGrid({super.key, required this.tiles});

  @override
  Widget build(BuildContext context) {
    final rows = <Widget>[];
    for (var i = 0; i < tiles.length; i += 2) {
      rows.add(Padding(
        padding: const EdgeInsets.only(bottom: 10),
        child: IntrinsicHeight(
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Expanded(child: tiles[i]),
              const SizedBox(width: 10),
              Expanded(child: i + 1 < tiles.length ? tiles[i + 1] : const SizedBox.shrink()),
            ],
          ),
        ),
      ));
    }
    return Column(children: rows);
  }
}

/// کارتِ بزرگِ «اقدام اصلی» با رنگِ تأکید (مثلاً شروع تمرکز)
class LuxHeroAction extends StatelessWidget {
  final IconData icon;
  final String title;
  final String sub;
  final String cta;
  final VoidCallback onTap;

  const LuxHeroAction({
    super.key,
    required this.icon,
    required this.title,
    required this.sub,
    required this.cta,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final fg = LuxColors.onAccent;
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTap: () {
        Haptic.light();
        onTap();
      },
      child: Container(
        padding: const EdgeInsets.all(18),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: AlignmentDirectional.topStart,
            end: AlignmentDirectional.bottomEnd,
            colors: [LuxColors.accent, LuxColors.accentDim],
          ),
          borderRadius: BorderRadius.circular(LuxColors.r(28)),
          border: LuxColors.hardShadow ? Border.all(color: LuxColors.stroke, width: LuxColors.strokeW) : null,
          boxShadow: LuxColors.hardShadow
              ? LuxColors.shadow()
              : [BoxShadow(color: LuxColors.alpha(LuxColors.accent, 0.28), blurRadius: 22, offset: const Offset(0, 8))],
        ),
        child: Row(
          children: [
            Container(
              width: 54,
              height: 54,
              decoration: BoxDecoration(
                color: LuxColors.alpha(fg, 0.16),
                borderRadius: BorderRadius.circular(LuxColors.r(18)),
              ),
              child: Icon(icon, color: fg, size: 28),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(title, style: LuxText.title.copyWith(color: fg)),
                  const SizedBox(height: 2),
                  Text(sub, style: LuxText.caption.copyWith(color: LuxColors.alpha(fg, 0.8))),
                ],
              ),
            ),
            const SizedBox(width: 10),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 9),
              decoration: BoxDecoration(color: fg, borderRadius: BorderRadius.circular(LuxColors.r(16))),
              child: Text(cta, style: LuxText.label.copyWith(color: LuxColors.accent, fontWeight: FontWeight.w700)),
            ),
          ],
        ),
      ),
    );
  }
}

/// حاشیه‌ی نورانیِ چرخان به رنگِ تأکیدِ پروفایل (دور آواتار، کارتِ تنظیمات و …)
class LuxGlowBorder extends StatefulWidget {
  final Widget child;
  final double radius;
  final double width;
  final bool circle;
  const LuxGlowBorder({super.key, required this.child, this.radius = 26, this.width = 2, this.circle = false});

  @override
  State<LuxGlowBorder> createState() => _LuxGlowBorderState();
}

class _LuxGlowBorderState extends State<LuxGlowBorder> with SingleTickerProviderStateMixin {
  late final AnimationController _c = AnimationController(vsync: this, duration: const Duration(seconds: 4))..repeat();

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final a = LuxColors.accent;
    final inner = widget.radius - widget.width;
    return RepaintBoundary(
      child: AnimatedBuilder(
        animation: _c,
        builder: (context, child) {
          return Container(
            padding: EdgeInsets.all(widget.width),
            decoration: BoxDecoration(
              shape: widget.circle ? BoxShape.circle : BoxShape.rectangle,
              borderRadius: widget.circle ? null : BorderRadius.circular(widget.radius),
              gradient: SweepGradient(
                transform: GradientRotation(_c.value * 2 * math.pi),
                colors: [a, LuxColors.alpha(a, 0.08), LuxColors.accentDim, LuxColors.alpha(a, 0.08), a],
              ),
              boxShadow: [BoxShadow(color: LuxColors.alpha(a, 0.22), blurRadius: 14)],
            ),
            child: widget.circle
                ? ClipOval(child: child)
                : ClipRRect(borderRadius: BorderRadius.circular(inner < 0 ? 0 : inner), child: child),
          );
        },
        child: widget.child,
      ),
    );
  }
}
