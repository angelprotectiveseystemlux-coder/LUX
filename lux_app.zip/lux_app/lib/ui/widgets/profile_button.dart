import 'dart:io';
import 'package:flutter/material.dart';
import '../../core/app_bus.dart';
import '../../core/palette.dart';
import '../../data/profile_repo.dart';
import '../pages/profile_page.dart';
import 'haptic.dart';
import 'lux_kit.dart';

/// آواتارِ گوشه‌ی سربرگ همه‌ی تب‌ها؛ با لمس، پروفایل و تنظیمات باز می‌شود.
/// اگر عکسی نباشد، لوگوی LUX نشان داده می‌شود.
class ProfileButton extends StatefulWidget {
  final double size;
  const ProfileButton({super.key, this.size = 44});

  @override
  State<ProfileButton> createState() => _ProfileButtonState();
}

class _ProfileButtonState extends State<ProfileButton> {
  String? _photo;

  @override
  void initState() {
    super.initState();
    _load();
    AppBus.data.addListener(_load);
  }

  @override
  void dispose() {
    AppBus.data.removeListener(_load);
    super.dispose();
  }

  Future<void> _load() async {
    final p = await ProfileRepo.get();
    if (!mounted) return;
    setState(() => _photo = p?.photoPath);
  }

  Future<void> _open() async {
    Haptic.tap();
    await pushPage<void>(context, const Scaffold(body: ProfilePage()));
    if (mounted) _load();
  }

  @override
  Widget build(BuildContext context) {
    final photo = _photo;
    final has = photo != null && File(photo).existsSync();
    final s = widget.size;
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTap: _open,
      child: Container(
        width: s,
        height: s,
        decoration: BoxDecoration(
          color: LuxColors.card,
          borderRadius: BorderRadius.circular(LuxColors.r(s * 0.36)),
          border: Border.all(color: LuxColors.alpha(LuxColors.accent, 0.7), width: 1.6),
          image: has ? DecorationImage(image: FileImage(File(photo)), fit: BoxFit.cover) : null,
        ),
        padding: EdgeInsets.all(has ? 0 : s * 0.14),
        child: has ? null : Image.asset('assets/logo/lux_logo.png', cacheWidth: 120, filterQuality: FilterQuality.medium),
      ),
    );
  }
}
