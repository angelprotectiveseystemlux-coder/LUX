import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:shamsi_date/shamsi_date.dart';
import '../../core/jalali_utils.dart';
import '../../core/palette.dart';
import '../../core/theme.dart';
import 'haptic.dart';

/// چرخِ انتخابِ تاریخ شمسی (روز | ماه | سال)
class JalaliDatePicker extends StatefulWidget {
  final int minYear;
  final int maxYear;
  final Jalali initial;
  final ValueChanged<Jalali> onChanged;

  const JalaliDatePicker({
    super.key,
    required this.minYear,
    required this.maxYear,
    required this.initial,
    required this.onChanged,
  });

  @override
  State<JalaliDatePicker> createState() => _JalaliDatePickerState();
}

class _JalaliDatePickerState extends State<JalaliDatePicker> {
  late int _y;
  late int _m;
  late int _d;
  late FixedExtentScrollController _yc;
  late FixedExtentScrollController _mc;
  late FixedExtentScrollController _dc;

  @override
  void initState() {
    super.initState();
    _y = widget.initial.year.clamp(widget.minYear, widget.maxYear);
    _m = widget.initial.month;
    _d = widget.initial.day;
    _clampDay();
    _yc = FixedExtentScrollController(initialItem: _y - widget.minYear);
    _mc = FixedExtentScrollController(initialItem: _m - 1);
    _dc = FixedExtentScrollController(initialItem: _d - 1);
  }

  @override
  void dispose() {
    _yc.dispose();
    _mc.dispose();
    _dc.dispose();
    super.dispose();
  }

  int get _len => jalaliMonthLength(_y, _m);

  void _clampDay() {
    if (_d > _len) _d = _len;
  }

  /// با تغییر ماه/سال، تعداد روزها عوض می‌شود؛ چرخِ روز با کنترلرِ تازه ساخته می‌شود.
  void _resetDayController() {
    final old = _dc;
    _dc = FixedExtentScrollController(initialItem: _d - 1);
    WidgetsBinding.instance.addPostFrameCallback((_) => old.dispose());
  }

  void _emit() {
    widget.onChanged(Jalali(_y, _m, _d));
  }

  Widget _wheel({
    required FixedExtentScrollController controller,
    required int count,
    required String Function(int) label,
    required ValueChanged<int> onSelected,
    required double flex,
    Key? key,
  }) {
    return Expanded(
      flex: (flex * 10).round(),
      child: CupertinoPicker.builder(
        key: key,
        scrollController: controller,
        itemExtent: 46,
        useMagnifier: false,
        diameterRatio: 1.5,
        squeeze: 1.0,
        selectionOverlay: Container(
          decoration: BoxDecoration(
            border: Border.symmetric(
              horizontal: BorderSide(color: LuxColors.alpha(LuxColors.accent, 0.55), width: 1),
            ),
          ),
        ),
        onSelectedItemChanged: (i) {
          Haptic.tap();
          onSelected(i);
        },
        childCount: count,
        itemBuilder: (context, i) => Center(
          child: Text(label(i), style: LuxText.heading.copyWith(fontSize: 20)),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final yearCount = widget.maxYear - widget.minYear + 1;
    final wd = jalaliWeekdays[weekdayIndex(Jalali(_y, _m, _d).toDateTime())];
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 8),
          decoration: BoxDecoration(
            color: LuxColors.alpha(LuxColors.accent, 0.12),
            borderRadius: BorderRadius.circular(LuxColors.r(16)),
          ),
          child: Text(
            '$wd، ${faDigits(_d)} ${jalaliMonths[_m - 1]} ${faDigits(_y)}',
            style: LuxText.heading.copyWith(color: LuxColors.accent),
          ),
        ),
        const SizedBox(height: 6),
        SizedBox(
          height: 220,
          child: _wheels(yearCount),
        ),
      ],
    );
  }

  Widget _wheels(int yearCount) {
    return Row(
        children: [
          // در حالت RTL اولین فرزند سمت راست است: روز | ماه | سال
          _wheel(
            key: ValueKey('day-$_y-$_m'),
            controller: _dc,
            count: _len,
            label: (i) => faDigits(i + 1),
            flex: 0.8,
            onSelected: (i) {
              setState(() => _d = i + 1);
              _emit();
            },
          ),
          _wheel(
            controller: _mc,
            count: 12,
            label: (i) => jalaliMonths[i],
            flex: 1.4,
            onSelected: (i) {
              setState(() {
                _m = i + 1;
                _clampDay();
                _resetDayController();
              });
              _emit();
            },
          ),
          _wheel(
            controller: _yc,
            count: yearCount,
            label: (i) => faDigits(widget.minYear + i),
            flex: 1.0,
            onSelected: (i) {
              setState(() {
                _y = widget.minYear + i;
                _clampDay();
                _resetDayController();
              });
              _emit();
            },
          ),
        ],
    );
  }
}
