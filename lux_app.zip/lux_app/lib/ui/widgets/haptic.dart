import 'package:flutter/services.dart';

class Haptic {
  Haptic._();
  static bool enabled = true;

  static void tap() {
    if (enabled) HapticFeedback.selectionClick();
  }

  static void light() {
    if (enabled) HapticFeedback.lightImpact();
  }

  static void heavy() {
    if (enabled) HapticFeedback.mediumImpact();
  }
}
