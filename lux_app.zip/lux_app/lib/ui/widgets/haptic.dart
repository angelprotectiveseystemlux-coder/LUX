import 'package:flutter/services.dart';

/// ویبره‌ی لمسی.
/// اول از موتور لرزشِ خودِ گوشی (کانال native) استفاده می‌کند؛ چون `HapticFeedback`
/// روی خیلی از گوشی‌ها (شیائومی، سامسونگ، ...) اگر «بازخورد لمسی» سیستم خاموش باشد کار نمی‌کند.
/// اگر native جواب نداد، به HapticFeedback برمی‌گردد.
class Haptic {
  Haptic._();
  static bool enabled = true;
  static const MethodChannel _ch = MethodChannel('lux/haptic');
  static bool _nativeOk = true;

  static Future<void> _fire(String kind, void Function() fallback) async {
    if (!enabled) return;
    if (_nativeOk) {
      try {
        final ok = await _ch.invokeMethod<bool>('vibrate', <String, Object>{'kind': kind});
        if (ok == true) return;
        _nativeOk = false;
      } catch (_) {
        _nativeOk = false;
      }
    }
    fallback();
  }

  /// لمسِ خیلی ملایم (انتخاب، سوییچ، چیپ)
  static void tap() => _fire('tick', HapticFeedback.selectionClick);

  /// کلیک سبک (دکمه‌ها)
  static void light() => _fire('click', HapticFeedback.lightImpact);

  /// ضربه‌ی محکم‌تر (تأیید نهایی)
  static void heavy() => _fire('heavy', HapticFeedback.mediumImpact);

  /// برای دکمه‌ی تست در پروفایل: همیشه جواب بدهد و نتیجه را برگرداند.
  static Future<bool> test() async {
    try {
      final ok = await _ch.invokeMethod<bool>('vibrate', <String, Object>{'kind': 'heavy'});
      if (ok == true) return true;
    } catch (_) {}
    HapticFeedback.heavyImpact();
    return false;
  }
}
