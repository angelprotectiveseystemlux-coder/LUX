import 'package:flutter/services.dart';

/// ویبره‌ی لمسی.
/// اول از موتور لرزشِ خودِ گوشی (کانال native، با کاربردِ «آلارم») استفاده می‌کند تا حتی
/// روی حالت بی‌صدا یا وقتی «بازخورد لمسی» سیستم خاموش است کار کند.
/// اگر native جواب نداد، به HapticFeedback برمی‌گردد.
class Haptic {
  Haptic._();
  static bool enabled = true;
  static const MethodChannel _ch = MethodChannel('lux/haptic');

  static Future<bool> _native(String kind) async {
    try {
      return (await _ch.invokeMethod<bool>('vibrate', <String, Object>{'kind': kind})) == true;
    } catch (_) {
      return false;
    }
  }

  static Future<void> _fire(String kind, Future<void> Function() fallback) async {
    if (!enabled) return;
    if (await _native(kind)) return;
    try {
      await fallback();
    } catch (_) {}
  }

  /// لمسِ خیلی ملایم (انتخاب، سوییچ، چیپ)
  static void tap() => _fire('tick', HapticFeedback.selectionClick);

  /// کلیک سبک (دکمه‌ها)
  static void light() => _fire('click', HapticFeedback.lightImpact);

  /// ضربه‌ی محکم‌تر (تأیید نهایی)
  static void heavy() => _fire('heavy', HapticFeedback.mediumImpact);

  /// لرزشِ بلند (پایان تایمر، هشدار)
  static void alert() => _fire('long', HapticFeedback.heavyImpact);

  /// برای دکمه‌ی آزمایش در پروفایل: همیشه (حتی اگر ویبره خاموش باشد) جواب می‌دهد و نتیجه را برمی‌گرداند.
  static Future<bool> test() async {
    if (await _native('long')) return true;
    try {
      await HapticFeedback.heavyImpact();
    } catch (_) {}
    return false;
  }
}
