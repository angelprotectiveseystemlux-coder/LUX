import 'package:flutter/material.dart';
import '../../core/palette.dart';
import '../../core/theme.dart';
import 'haptic.dart';

class LuxChip extends StatelessWidget {
  final String label;
  final bool selected;
  final VoidCallback onTap;
  const LuxChip({super.key, required this.label, required this.selected, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTap: () {
        Haptic.tap();
        onTap();
      },
      child: AnimatedContainer(
        duration: LuxMotion.fast,
        curve: LuxMotion.curve,
        padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 12),
        decoration: BoxDecoration(
          color: selected ? LuxColors.accent : LuxColors.cardHi,
          borderRadius: BorderRadius.circular(22),
          border: Border.all(color: selected ? LuxColors.accent : LuxColors.stroke),
        ),
        child: Text(
          label,
          style: LuxText.body.copyWith(
            color: selected ? LuxColors.onAccent : LuxColors.text,
            fontWeight: FontWeight.w600,
          ),
        ),
      ),
    );
  }
}
