import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../../core/jalali_utils.dart';
import '../../core/palette.dart';
import '../../core/theme.dart';
import '../charts/radial.dart';

const List<String> kClockNames = <String>['حلقه‌ای', 'آنالوگ کلاسیک', 'تایم‌تایمر', 'مینیمال', 'دیجیتال'];

/// ساعتِ تایمرِ تمرکز؛ پنج سبک: حلقه‌ای، آنالوگِ کلاسیک، «تایم‌تایمر»، مینیمالِ براون‌گونه، دیجیتال.
class FocusClock extends StatelessWidget {
  final int style;
  final int leftMs;
  final int totalMs;
  final bool isBreak;
  final double size;

  const FocusClock({
    super.key,
    required this.style,
    required this.leftMs,
    required this.totalMs,
    required this.isBreak,
    required this.size,
  });

  String get _mmss {
    final t = (leftMs.clamp(0, 1 << 40) + 999) ~/ 1000;
    return '${(t ~/ 60).toString().padLeft(2, '0')}:${(t % 60).toString().padLeft(2, '0')}';
  }

  @override
  Widget build(BuildContext context) {
    final progress = totalMs <= 0 ? 0.0 : (1 - leftMs / totalMs).clamp(0.0, 1.0).toDouble();
    final color = isBreak ? LuxColors.ok : LuxColors.accent;
    switch (style) {
      case 1:
        return RepaintBoundary(
          child: CustomPaint(size: Size(size, size), painter: _ClassicPainter(leftMs, totalMs, color, isBreak)),
        );
      case 2:
        return RepaintBoundary(
          child: CustomPaint(size: Size(size, size), painter: _TimeTimerPainter(leftMs, totalMs, color)),
        );
      case 3:
        return RepaintBoundary(
          child: CustomPaint(size: Size(size, size), painter: _MinimalPainter(leftMs, totalMs, color)),
        );
      case 4:
        return SizedBox(
          width: size,
          height: size * 0.62,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Directionality(
                textDirection: TextDirection.ltr,
                child: Text(_mmss, style: LuxText.dot(size * 0.30, color: color)),
              ),
              const SizedBox(height: 14),
              ClipRRect(
                borderRadius: BorderRadius.circular(LuxColors.r(8)),
                child: SizedBox(
                  width: size * 0.8,
                  height: 8,
                  child: LinearProgressIndicator(value: 1 - progress, minHeight: 8, color: color, backgroundColor: LuxColors.cardHi),
                ),
              ),
            ],
          ),
        );
      default:
        return RingProgress(
          value: progress,
          size: size,
          stroke: 12,
          color: color,
          child: Directionality(
            textDirection: TextDirection.ltr,
            child: Text(_mmss, style: LuxText.dot(size * 0.235)),
          ),
        );
    }
  }
}

Offset _pt(Offset c, double r, double a) => Offset(c.dx + r * math.sin(a), c.dy - r * math.cos(a));

void _text(Canvas canvas, String s, Offset center, double fs, Color col, {FontWeight w = FontWeight.w600}) {
  final tp = TextPainter(
    text: TextSpan(text: s, style: TextStyle(color: col, fontSize: fs, fontWeight: w, height: 1.0)),
    textDirection: TextDirection.ltr,
  )..layout();
  tp.paint(canvas, center - Offset(tp.width / 2, tp.height / 2));
}

/// آنالوگِ کلاسیک: صفحه‌ی ساعت با عددها، عقربه‌ی ساعت‌شمار/دقیقه‌شمار/ثانیه‌شمار که «زمانِ باقی‌مانده» را نشان می‌دهند.
class _ClassicPainter extends CustomPainter {
  final int leftMs;
  final int totalMs;
  final Color color;
  final bool isBreak;
  _ClassicPainter(this.leftMs, this.totalMs, this.color, this.isBreak);

  @override
  void paint(Canvas canvas, Size size) {
    final c = Offset(size.width / 2, size.height / 2);
    final r = size.width / 2;
    canvas.drawCircle(c, r, Paint()..color = LuxColors.card);
    canvas.drawCircle(
      c,
      r - 1,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 2
        ..color = LuxColors.alpha(LuxColors.stroke, 0.8),
    );
    // کمانِ پیشرفت روی لبه
    final frac = totalMs <= 0 ? 0.0 : (leftMs / totalMs).clamp(0.0, 1.0).toDouble();
    canvas.drawArc(
      Rect.fromCircle(center: c, radius: r - 8),
      -math.pi / 2,
      2 * math.pi * frac,
      false,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeCap = StrokeCap.round
        ..strokeWidth = 5
        ..color = color,
    );
    // خط‌های دقیقه
    for (var i = 0; i < 60; i++) {
      final a = i * math.pi / 30;
      final big = i % 5 == 0;
      canvas.drawLine(
        _pt(c, r * (big ? 0.80 : 0.85), a),
        _pt(c, r * 0.89, a),
        Paint()
          ..strokeWidth = big ? 2.2 : 1.0
          ..color = LuxColors.alpha(LuxColors.text, big ? 0.9 : 0.4),
      );
    }
    // عددها
    for (var h = 1; h <= 12; h++) {
      _text(canvas, faDigits(h), _pt(c, r * 0.67, h * math.pi / 6), r * 0.15, LuxColors.text);
    }
    final s = leftMs / 1000.0;
    // ساعت‌شمار، دقیقه‌شمار
    _hand(canvas, c, (s / 3600 % 12) * math.pi / 6, r * 0.42, 5.0, LuxColors.text);
    _hand(canvas, c, (s / 60 % 60) * math.pi / 30, r * 0.62, 3.4, LuxColors.text);
    // ثانیه‌شمار (با دُم)
    final sa = (s % 60) * math.pi / 30;
    final sp = Paint()
      ..strokeWidth = 1.8
      ..strokeCap = StrokeCap.round
      ..color = color;
    canvas.drawLine(_pt(c, -r * 0.14, sa), _pt(c, r * 0.76, sa), sp);
    canvas.drawCircle(c, 6, Paint()..color = color);
    canvas.drawCircle(c, 2.4, Paint()..color = LuxColors.card);
  }

  void _hand(Canvas canvas, Offset c, double a, double len, double w, Color col) {
    canvas.drawLine(
      c,
      _pt(c, len, a),
      Paint()
        ..strokeWidth = w
        ..strokeCap = StrokeCap.round
        ..color = col,
    );
  }

  @override
  bool shouldRepaint(covariant _ClassicPainter old) => true;
}

/// «تایم‌تایمر»: قرصِ رنگی که با گذشتنِ زمان کم می‌شود (مقیاس ۶۰ دقیقه).
class _TimeTimerPainter extends CustomPainter {
  final int leftMs;
  final int totalMs;
  final Color color;
  _TimeTimerPainter(this.leftMs, this.totalMs, this.color);

  @override
  void paint(Canvas canvas, Size size) {
    final c = Offset(size.width / 2, size.height / 2);
    final r = size.width / 2;
    canvas.drawCircle(c, r, Paint()..color = LuxColors.card);
    canvas.drawCircle(
      c,
      r - 1,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 2
        ..color = LuxColors.alpha(LuxColors.stroke, 0.8),
    );
    final dial = r * 0.70;
    final minutes = (leftMs / 60000.0).clamp(0.0, 60.0).toDouble();
    final sweep = minutes / 60.0 * 2 * math.pi;
    if (sweep > 0.001) {
      canvas.drawArc(
        Rect.fromCircle(center: c, radius: dial),
        -math.pi / 2,
        sweep,
        true,
        Paint()..color = color,
      );
    }
    canvas.drawCircle(
      c,
      dial,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1.5
        ..color = LuxColors.alpha(LuxColors.text, 0.35),
    );
    for (var i = 0; i < 60; i++) {
      final a = i * math.pi / 30;
      final big = i % 5 == 0;
      canvas.drawLine(
        _pt(c, r * (big ? 0.76 : 0.80), a),
        _pt(c, r * 0.84, a),
        Paint()
          ..strokeWidth = big ? 2.0 : 1.0
          ..color = LuxColors.alpha(LuxColors.text, big ? 0.9 : 0.4),
      );
    }
    for (var i = 0; i < 12; i++) {
      final m = i * 5;
      _text(canvas, faDigits(m), _pt(c, r * 0.92, i * math.pi / 6), r * 0.11, LuxColors.alpha(LuxColors.text, 0.85), w: FontWeight.w500);
    }
    canvas.drawCircle(c, r * 0.07, Paint()..color = LuxColors.card);
    canvas.drawCircle(
      c,
      r * 0.07,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 2
        ..color = LuxColors.alpha(LuxColors.text, 0.6),
    );
  }

  @override
  bool shouldRepaint(covariant _TimeTimerPainter old) => true;
}

/// مینیمال به سبکِ ساعت‌های براون: نقطه‌های ساعت، دو عقربه‌ی نازک، ثانیه‌شمارِ رنگی.
class _MinimalPainter extends CustomPainter {
  final int leftMs;
  final int totalMs;
  final Color color;
  _MinimalPainter(this.leftMs, this.totalMs, this.color);

  @override
  void paint(Canvas canvas, Size size) {
    final c = Offset(size.width / 2, size.height / 2);
    final r = size.width / 2;
    canvas.drawCircle(c, r, Paint()..color = LuxColors.cardHi);
    for (var i = 0; i < 12; i++) {
      final a = i * math.pi / 6;
      canvas.drawCircle(_pt(c, r * 0.86, a), i % 3 == 0 ? r * 0.035 : r * 0.02, Paint()..color = LuxColors.alpha(LuxColors.text, i % 3 == 0 ? 0.95 : 0.5));
    }
    final s = leftMs / 1000.0;
    final ma = (s / 60 % 60) * math.pi / 30;
    final ha = (s / 3600 % 12) * math.pi / 6;
    canvas.drawLine(
      c,
      _pt(c, r * 0.50, ha),
      Paint()
        ..strokeWidth = 4.5
        ..strokeCap = StrokeCap.round
        ..color = LuxColors.text,
    );
    canvas.drawLine(
      c,
      _pt(c, r * 0.74, ma),
      Paint()
        ..strokeWidth = 3
        ..strokeCap = StrokeCap.round
        ..color = LuxColors.text,
    );
    final sa = (s % 60) * math.pi / 30;
    canvas.drawLine(
      _pt(c, -r * 0.16, sa),
      _pt(c, r * 0.80, sa),
      Paint()
        ..strokeWidth = 1.6
        ..strokeCap = StrokeCap.round
        ..color = color,
    );
    canvas.drawCircle(c, r * 0.05, Paint()..color = color);
    canvas.drawCircle(c, r * 0.02, Paint()..color = LuxColors.cardHi);
  }

  @override
  bool shouldRepaint(covariant _MinimalPainter old) => true;
}
