import 'package:flutter/services.dart';
import '../core/jalali_utils.dart';
import '../core/util.dart';
import '../data/database.dart';

/// جزیره‌ی زنده (شیائومی) برای چیزهای دیگرِ LUX: کلاسِ بعدی، امتحانِ نزدیک، تکلیفِ نزدیک.
/// نزدیک‌ترین مورد در یک اعلانِ زنده با شمارشِ معکوس نشان داده می‌شود. تایمرِ تمرکز جدا و مستقل است.
class IslandLive {
  IslandLive._();

  static const MethodChannel _ch = MethodChannel('lux/island');
  static const String _key = 'island_live';

  static Future<bool> enabled() async => (await LuxDb.instance.kvGet(_key) ?? '1') != '0';

  static Future<void> setEnabled(bool v) async {
    await LuxDb.instance.kvSet(_key, v ? '1' : '0');
    await refresh();
  }

  static Future<void> hide() async {
    try {
      await _ch.invokeMethod<bool>('hide');
    } catch (_) {}
  }

  /// نزدیک‌ترین رویدادِ پیش‌رو را پیدا می‌کند و نشان می‌دهد؛ اگر چیزی نزدیک نبود، اعلان را برمی‌دارد.
  static Future<void> refresh() async {
    try {
      if (!await enabled()) {
        await hide();
        return;
      }
      final db = LuxDb.instance;
      final now = DateTime.now();
      final nowMs = now.millisecondsSinceEpoch;

      String? kind, title, sub, clock;
      var at = 0;
      var start = 0;
      void pick(String k, String t, String s, DateTime when, Duration lead) {
        final ms = when.millisecondsSinceEpoch;
        if (ms <= nowMs) return;
        if (at != 0 && ms >= at) return;
        kind = k;
        title = t;
        sub = s;
        clock = clockLabel(when);
        at = ms;
        start = when.subtract(lead).millisecondsSinceEpoch;
      }

      // کلاس‌های امروز که تا یک ساعت دیگر شروع می‌شوند
      final slots = await db.rawQuery(
        'SELECT s.start_min, s.room, c.name AS course FROM class_slots s '
        'JOIN courses c ON c.id = s.course_id WHERE s.weekday = ? AND c.archived = 0 ORDER BY s.start_min',
        [weekdayIndex(now)],
      );
      final day = dateOnly(now);
      for (final s in slots) {
        final when = day.add(Duration(minutes: asInt(s['start_min'])));
        final left = when.difference(now);
        if (left.inMinutes > 60) continue;
        final room = asStr(s['room']);
        pick('class', asStr(s['course']), room.isEmpty ? 'شروع ${clockLabel(when)}' : 'کلاس $room · شروع ${clockLabel(when)}', when, const Duration(hours: 1));
      }

      // امتحان‌هایی که تا ۲۴ ساعت دیگر شروع می‌شوند
      final exams = await db.rawQuery(
        'SELECT e.at_ts, e.title, e.type_name, c.name AS course FROM exams e JOIN courses c ON c.id = e.course_id '
        "WHERE e.status = 'planned' AND e.at_ts > ? AND e.at_ts < ? ORDER BY e.at_ts LIMIT 3",
        [nowMs, nowMs + const Duration(hours: 24).inMilliseconds],
      );
      for (final e in exams) {
        final t = asStr(e['title']).isNotEmpty ? asStr(e['title']) : asStr(e['type_name']);
        pick('exam', asStr(e['course']), t.isEmpty ? 'ساعت ${clockLabel(fromTs(e['at_ts']))}' : '$t · ${clockLabel(fromTs(e['at_ts']))}', fromTs(e['at_ts']), const Duration(hours: 24));
      }

      // تکلیف‌هایی که تا ۶ ساعت دیگر موعد دارند
      final tasks = await db.rawQuery(
        "SELECT t.title, t.due_ts FROM tasks t WHERE t.status = 'open' AND t.due_ts IS NOT NULL AND t.due_ts > ? AND t.due_ts < ? ORDER BY t.due_ts LIMIT 3",
        [nowMs, nowMs + const Duration(hours: 6).inMilliseconds],
      );
      for (final t in tasks) {
        pick('task', asStr(t['title']), 'موعد ${clockLabel(fromTs(t['due_ts']))}', fromTs(t['due_ts']), const Duration(hours: 6));
      }

      if (kind == null) {
        await hide();
        return;
      }
      await _ch.invokeMethod<bool>('show', <String, Object?>{
        'kind': kind,
        'title': title ?? '',
        'sub': sub ?? '',
        'clock': clock ?? '',
        'at': at,
        'start': start,
      });
    } catch (_) {}
  }
}
