import 'package:flutter/services.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:timezone/data/latest.dart' as tzdata;
import 'package:timezone/timezone.dart' as tz;

/// نتیجه‌ی آزمایش یادآور؛ برای اینکه به کاربر دقیق بگوییم چه چیزی کم است.
class ReminderCheck {
  final bool notificationsAllowed;
  final bool exactAlarmAllowed;
  final bool shownNow;
  final String? error;
  const ReminderCheck({
    required this.notificationsAllowed,
    required this.exactAlarmAllowed,
    required this.shownNow,
    this.error,
  });
}

/// سرویس یادآور/نوتیف محلی (بدون سرور). زمان‌بندی دقیق با آلارم اندروید.
class NotificationService {
  NotificationService._();
  static final NotificationService instance = NotificationService._();

  static const String channelId = 'lux_reminders_v2';
  static const String channelName = 'یادآورها';
  static const String _icon = 'ic_stat_lux';

  final FlutterLocalNotificationsPlugin _plugin = FlutterLocalNotificationsPlugin();
  bool _ready = false;

  AndroidFlutterLocalNotificationsPlugin? get _android =>
      _plugin.resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>();

  Future<void> init() async {
    if (_ready) return;
    tzdata.initializeTimeZones();
    tz.setLocalLocation(tz.getLocation('Asia/Tehran'));

    await _plugin.initialize(const InitializationSettings(android: AndroidInitializationSettings(_icon)));

    await _android?.createNotificationChannel(const AndroidNotificationChannel(
      channelId,
      channelName,
      description: 'یادآور امتحان‌ها، تکالیف و بریف',
      importance: Importance.max,
      playSound: true,
      enableVibration: true,
      showBadge: true,
    ));
    _ready = true;
  }

  /// مجوز اعلان (اندروید ۱۳+) و آلارم دقیق (اندروید ۱۲+) را مستقیم از خودِ پلاگین می‌خواهد.
  /// برگشتی: (اعلان مجاز؟، آلارم دقیق مجاز؟)
  Future<(bool, bool)> ensurePermissions() async {
    await init();
    bool notif = true;
    bool exact = true;
    try {
      notif = (await _android?.areNotificationsEnabled()) ?? true;
      if (!notif) notif = (await _android?.requestNotificationsPermission()) ?? false;
    } catch (_) {}
    try {
      exact = (await _android?.canScheduleExactNotifications()) ?? true;
      if (!exact) exact = (await _android?.requestExactAlarmsPermission()) ?? false;
    } catch (_) {}
    return (notif, exact);
  }

  NotificationDetails _details({bool fullScreen = false, String? bigText}) => NotificationDetails(
        android: AndroidNotificationDetails(
          channelId,
          channelName,
          channelDescription: 'یادآور امتحان‌ها، تکالیف و بریف',
          icon: _icon,
          importance: Importance.max,
          priority: Priority.high,
          playSound: true,
          enableVibration: true,
          fullScreenIntent: fullScreen,
          category: AndroidNotificationCategory.reminder,
          visibility: NotificationVisibility.public,
          styleInformation: bigText == null ? null : BigTextStyleInformation(bigText),
        ),
      );

  /// اعلان فوری.
  Future<void> showNow({required int id, required String title, required String body, String? payload, String? bigText}) async {
    await init();
    await _plugin.show(id, title, body, _details(bigText: bigText), payload: payload);
  }

  /// زمان‌بندی دقیق؛ اگر مجوز «آلارم دقیق» نبود، به حالت تقریبی برمی‌گردد.
  /// مقدار برگشتی: true یعنی دقیق زمان‌بندی شد.
  Future<bool> schedule({
    required int id,
    required String title,
    required String body,
    required DateTime when,
    String? payload,
    bool fullScreen = false,
    String? bigText,
  }) async {
    await init();
    final at = tz.TZDateTime.from(when, tz.local);
    try {
      await _plugin.zonedSchedule(
        id,
        title,
        body,
        at,
        _details(fullScreen: fullScreen, bigText: bigText),
        androidScheduleMode: AndroidScheduleMode.exactAllowWhileIdle,
        uiLocalNotificationDateInterpretation: UILocalNotificationDateInterpretation.absoluteTime,
        payload: payload,
      );
      return true;
    } on PlatformException {
      await _plugin.zonedSchedule(
        id,
        title,
        body,
        at,
        _details(fullScreen: fullScreen, bigText: bigText),
        androidScheduleMode: AndroidScheduleMode.inexactAllowWhileIdle,
        uiLocalNotificationDateInterpretation: UILocalNotificationDateInterpretation.absoluteTime,
        payload: payload,
      );
      return false;
    }
  }

  Future<void> cancel(int id) async {
    await init();
    await _plugin.cancel(id);
  }

  Future<void> cancelAll() async {
    await init();
    await _plugin.cancelAll();
  }

  /// آزمایش کامل: مجوزها را می‌خواهد، یک اعلان فوری نشان می‌دهد و یکی هم برای چند ثانیه‌ی بعد می‌گذارد.
  Future<ReminderCheck> runCheck({int seconds = 10}) async {
    try {
      final (notif, exact) = await ensurePermissions();
      if (!notif) {
        return ReminderCheck(notificationsAllowed: false, exactAlarmAllowed: exact, shownNow: false);
      }
      await showNow(
        id: 999001,
        title: 'LUX — اعلان کار می‌کند',
        body: 'این اعلان فوری بود. یادآور زمان‌دار هم ${seconds.toString()} ثانیه‌ی دیگر می‌رسد.',
      );
      await schedule(
        id: 999000,
        title: 'LUX — یادآور زمان‌دار',
        body: 'اگر این پیام را سرِ وقت می‌بینی، یادآورها درست کار می‌کنند.',
        when: DateTime.now().add(Duration(seconds: seconds)),
      );
      return ReminderCheck(notificationsAllowed: true, exactAlarmAllowed: exact, shownNow: true);
    } catch (e) {
      return ReminderCheck(notificationsAllowed: false, exactAlarmAllowed: false, shownNow: false, error: '$e');
    }
  }
}
