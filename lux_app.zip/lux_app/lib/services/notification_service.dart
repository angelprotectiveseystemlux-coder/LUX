import 'package:flutter/services.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:timezone/data/latest.dart' as tzdata;
import 'package:timezone/timezone.dart' as tz;

/// سرویس یادآور/نوتیف محلی (بدون سرور). زمان‌بندی دقیق با آلارم اندروید.
class NotificationService {
  NotificationService._();
  static final NotificationService instance = NotificationService._();

  static const String channelId = 'lux_reminders';
  static const String channelName = 'یادآورها';

  final FlutterLocalNotificationsPlugin _plugin = FlutterLocalNotificationsPlugin();
  bool _ready = false;

  Future<void> init() async {
    if (_ready) return;
    tzdata.initializeTimeZones();
    tz.setLocalLocation(tz.getLocation('Asia/Tehran'));

    const android = AndroidInitializationSettings('@mipmap/ic_launcher');
    await _plugin.initialize(const InitializationSettings(android: android));

    final impl = _plugin.resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>();
    await impl?.createNotificationChannel(const AndroidNotificationChannel(
      channelId,
      channelName,
      description: 'یادآور امتحان‌ها، تکالیف و بریف',
      importance: Importance.max,
    ));
    _ready = true;
  }

  NotificationDetails _details({bool fullScreen = true}) => NotificationDetails(
        android: AndroidNotificationDetails(
          channelId,
          channelName,
          channelDescription: 'یادآور امتحان‌ها، تکالیف و بریف',
          importance: Importance.max,
          priority: Priority.high,
          fullScreenIntent: fullScreen,
          category: AndroidNotificationCategory.reminder,
          visibility: NotificationVisibility.public,
        ),
      );

  /// زمان‌بندی دقیق؛ اگر مجوز «آلارم دقیق» نبود، به حالت تقریبی برمی‌گردد.
  /// مقدار برگشتی: true یعنی دقیق زمان‌بندی شد.
  Future<bool> schedule({
    required int id,
    required String title,
    required String body,
    required DateTime when,
    String? payload,
    bool fullScreen = true,
  }) async {
    await init();
    final at = tz.TZDateTime.from(when, tz.local);
    try {
      await _plugin.zonedSchedule(
        id,
        title,
        body,
        at,
        _details(fullScreen: fullScreen),
        androidScheduleMode: AndroidScheduleMode.exactAllowWhileIdle,
        uiLocalNotificationDateInterpretation: UILocalNotificationDateInterpretation.absoluteTime,
        payload: payload,
      );
      return true;
    } on PlatformException {
      await _plugin.zonedSchedule(
        id,
        title,
        body,
        at,
        _details(fullScreen: fullScreen),
        androidScheduleMode: AndroidScheduleMode.inexactAllowWhileIdle,
        uiLocalNotificationDateInterpretation: UILocalNotificationDateInterpretation.absoluteTime,
        payload: payload,
      );
      return false;
    }
  }

  Future<void> cancel(int id) async {
    await init();
    await _plugin.cancel(id);
  }

  Future<void> cancelAll() async {
    await init();
    await _plugin.cancelAll();
  }

  /// یادآور آزمایشی برای سنجش اعلان و آلارم دقیق روی گوشی.
  Future<bool> scheduleTest({int seconds = 10}) {
    return schedule(
      id: 999000,
      title: 'LUX — آزمایش یادآور',
      body: 'اگر این پیام را سر وقت می‌بینی، یادآورها درست کار می‌کنند.',
      when: DateTime.now().add(Duration(seconds: seconds)),
    );
  }
}
