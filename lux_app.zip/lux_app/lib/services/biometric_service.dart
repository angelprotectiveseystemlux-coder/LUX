import 'package:local_auth/local_auth.dart';
import '../data/database.dart';

/// ورود با اثر انگشت / چهره (اگر گوشی پشتیبانی کند و ثبت شده باشد)
class BiometricService {
  BiometricService._();

  static final LocalAuthentication _auth = LocalAuthentication();
  static const String _kOn = 'bio_on';

  /// آیا گوشی حسگر دارد و حداقل یک اثر انگشت/چهره ثبت شده؟
  static Future<bool> available() async {
    try {
      if (!await _auth.isDeviceSupported()) return false;
      final types = await _auth.getAvailableBiometrics();
      return types.isNotEmpty;
    } catch (_) {
      return false;
    }
  }

  static Future<bool> isEnabled() async => (await LuxDb.instance.kvGet(_kOn)) == '1';

  static Future<void> setEnabled(bool v) async {
    if (v) {
      await LuxDb.instance.kvSet(_kOn, '1');
    } else {
      await LuxDb.instance.kvDelete(_kOn);
    }
  }

  static Future<bool> authenticate(String reason) async {
    try {
      return await _auth.authenticate(
        localizedReason: reason,
        options: const AuthenticationOptions(biometricOnly: true, stickyAuth: true),
      );
    } catch (_) {
      return false;
    }
  }
}
