import 'package:flutter/services.dart' show PlatformException;
import 'package:local_auth/local_auth.dart';
import '../data/database.dart';

/// ورود با اثر انگشت / چهره (اگر گوشی پشتیبانی کند و ثبت شده باشد)
class BiometricService {
  BiometricService._();

  static final LocalAuthentication _auth = LocalAuthentication();
  static const String _kOn = 'bio_on';

  /// آیا گوشی حسگر دارد و حداقل یک اثر انگشت/چهره ثبت شده؟
  static Future<bool> available() async {
    try {
      if (!await _auth.isDeviceSupported()) return false;
      final types = await _auth.getAvailableBiometrics();
      return types.isNotEmpty;
    } catch (_) {
      return false;
    }
  }

  static Future<bool> isEnabled() async => (await LuxDb.instance.kvGet(_kOn)) == '1';

  static Future<void> setEnabled(bool v) async {
    if (v) {
      await LuxDb.instance.kvSet(_kOn, '1');
    } else {
      await LuxDb.instance.kvDelete(_kOn);
    }
  }

  /// (موفق؟، کدِ خطا). کدِ خطا برای توضیح دادن به کاربر است.
  static Future<(bool, String?)> authenticate(String reason) async {
    try {
      final ok = await _auth.authenticate(
        localizedReason: reason,
        options: const AuthenticationOptions(biometricOnly: true, stickyAuth: true),
      );
      return (ok, null);
    } on PlatformException catch (e) {
      return (false, e.code);
    } catch (e) {
      return (false, e.toString());
    }
  }

  static String explain(String? code) {
    switch (code) {
      case null:
        return 'تأیید انجام نشد.';
      case 'NotAvailable':
      case 'NotEnrolled':
      case 'passcodeNotSet':
        return 'روی این گوشی اثر انگشت یا قفل زیستی ثبت نشده. از تنظیمات گوشی یک اثر انگشت اضافه کن و دوباره امتحان کن.';
      case 'LockedOut':
      case 'PermanentlyLockedOut':
        return 'به‌خاطر چند بار اشتباه، اثر انگشت موقتاً قفل شده. کمی بعد دوباره امتحان کن.';
      default:
        return 'تأیید انجام نشد ($code).';
    }
  }
}
