import 'dart:async';

import 'package:shamsi_date/shamsi_date.dart';

import '../core/app_bus.dart';
import '../core/jalali_utils.dart';
import '../core/util.dart';
import '../data/database.dart';
import '../data/profile_repo.dart';
import 'notification_service.dart';

/// تنظیمات خلاصه‌ی روزانه
class BriefSettings {
  final bool on;
  final int hour;
  final int minute;
  final bool classes;
  final bool exams;
  final bool tasks;
  final bool birthday;
  final bool tip;

  const BriefSettings({
    this.on = true,
    this.hour = 7,
    this.minute = 0,
    this.classes = true,
    this.exams = true,
    this.tasks = true,
    this.birthday = true,
    this.tip = true,
  });

  BriefSettings copyWith({bool? on, int? hour, int? minute, bool? classes, bool? exams, bool? tasks, bool? birthday, bool? tip}) =>
      BriefSettings(
        on: on ?? this.on,
        hour: hour ?? this.hour,
        minute: minute ?? this.minute,
        classes: classes ?? this.classes,
        exams: exams ?? this.exams,
        tasks: tasks ?? this.tasks,
        birthday: birthday ?? this.birthday,
        tip: tip ?? this.tip,
      );
}

class BriefSection {
  final String title;
  final List<String> lines;
  const BriefSection(this.title, this.lines);
}

class BriefData {
  final String title; // «صبح بخیر علی»
  final String dateLine;
  final String summary; // «۲ کلاس · ۱ امتحان · ۳ تکلیف»
  final List<BriefSection> sections;
  const BriefData({required this.title, required this.dateLine, required this.summary, required this.sections});

  String get bodyText {
    final b = StringBuffer(dateLine);
    for (final s in sections) {
      b.write('\n\n${s.title}');
      for (final l in s.lines) {
        b.write('\n• $l');
      }
    }
    return b.toString();
  }

  String get shortBody => summary.isEmpty ? dateLine : '$dateLine — $summary';
}

/// ساخت و زمان‌بندیِ خلاصه‌ی روزانه
class DailyBrief {
  DailyBrief._();

  static const int _baseId = 400000;
  static const int _days = 14;
  static Timer? _debounce;
  static bool _started = false;

  static Future<BriefSettings> load() async {
    final db = LuxDb.instance;
    Future<bool> flag(String k) async => (await db.kvGet(k) ?? '1') == '1';
    final time = (await db.kvGet('brief_time') ?? '07:00').split(':');
    final h = int.tryParse(time.isNotEmpty ? time[0] : '') ?? 7;
    final m = int.tryParse(time.length > 1 ? time[1] : '') ?? 0;
    return BriefSettings(
      on: await flag('brief_on'),
      hour: h.clamp(0, 23),
      minute: m.clamp(0, 59),
      classes: await flag('brief_classes'),
      exams: await flag('brief_exams'),
      tasks: await flag('brief_tasks'),
      birthday: await flag('brief_birthday'),
      tip: await flag('brief_tip'),
    );
  }

  static Future<void> save(BriefSettings s) async {
    final db = LuxDb.instance;
    String b(bool v) => v ? '1' : '0';
    await db.kvSet('brief_on', b(s.on));
    await db.kvSet('brief_time', '${two(s.hour)}:${two(s.minute)}');
    await db.kvSet('brief_classes', b(s.classes));
    await db.kvSet('brief_exams', b(s.exams));
    await db.kvSet('brief_tasks', b(s.tasks));
    await db.kvSet('brief_birthday', b(s.birthday));
    await db.kvSet('brief_tip', b(s.tip));
  }

  /// خلاصه‌ی روزِ [day] را از روی داده‌های فعلی می‌سازد.
  static Future<BriefData> compose(DateTime day, BriefSettings s, {DateTime? at}) async {
    final db = LuxDb.instance;
    final dayStart = dateOnly(day);
    final startMs = dayStart.millisecondsSinceEpoch;
    final profile = await ProfileRepo.get();
    final hour = (at ?? DateTime.now()).hour;
    final greet = hour < 11 ? 'صبح بخیر' : (hour < 15 ? 'ظهر بخیر' : (hour < 19 ? 'عصر بخیر' : 'شب بخیر'));
    final name = (profile?.name ?? '').trim();

    final sections = <BriefSection>[];
    var nClasses = 0;
    var nExams = 0;
    var nTasks = 0;

    // کلاس‌ها
    if (s.classes) {
      final rows = await db.rawQuery(
        'SELECT s.start_min, s.end_min, s.room, c.name AS course FROM class_slots s '
        'JOIN courses c ON c.id = s.course_id WHERE s.weekday = ? AND c.archived = 0 ORDER BY s.start_min',
        [weekdayIndex(day)],
      );
      if (rows.isNotEmpty) {
        nClasses = rows.length;
        sections.add(BriefSection('کلاس‌ها', [
          for (final r in rows)
            '${minutesLabel(asInt(r['start_min']))} تا ${minutesLabel(asInt(r['end_min']))} — ${asStr(r['course'])}'
                '${asStr(r['room']).isEmpty ? '' : ' (کلاس ${asStr(r['room'])})'}',
        ]));
      }
    }

    // امتحان‌های نزدیک (۸ روز آینده) — برای پیشنهاد هم لازم است
    final exams = await db.rawQuery(
      'SELECT e.*, c.name AS course FROM exams e JOIN courses c ON c.id = e.course_id '
      "WHERE e.status = 'planned' AND e.at_ts >= ? AND e.at_ts < ? ORDER BY e.at_ts",
      [startMs, dayStart.add(const Duration(days: 8)).millisecondsSinceEpoch],
    );
    if (s.exams && exams.isNotEmpty) {
      final lines = <String>[];
      for (final e in exams.take(5)) {
        final at = fromTs(e['at_ts']);
        final d = daysBetween(dayStart, at);
        final label = d <= 0 ? 'امروز' : (d == 1 ? 'فردا' : '${faDigits(d)} روز دیگر');
        final what = asStr(e['title']).isNotEmpty ? asStr(e['title']) : asStr(e['type_name'], 'امتحان');
        lines.add('$label: ${asStr(e['course'])} — $what، ساعت ${clockLabel(at)}'
            '${asStr(e['location']).isEmpty ? '' : ' (${asStr(e['location'])})'}');
        if (d <= 0 && asStr(e['scope_note']).isNotEmpty) lines.add('محدوده: ${asStr(e['scope_note'])}');
      }
      nExams = exams.length;
      sections.add(BriefSection('امتحان‌ها', lines));
    }

    // تکالیف: عقب‌افتاده، امروز و فردا
    List<Map<String, Object?>> tasks = <Map<String, Object?>>[];
    if (s.tasks || s.tip) {
      tasks = await db.rawQuery(
        'SELECT t.*, c.name AS course FROM tasks t LEFT JOIN courses c ON c.id = t.course_id '
        "WHERE t.status = 'open' AND t.due_ts IS NOT NULL AND t.due_ts < ? ORDER BY t.due_ts, t.priority DESC",
        [dayStart.add(const Duration(days: 2)).millisecondsSinceEpoch],
      );
    }
    if (s.tasks && tasks.isNotEmpty) {
      final lines = <String>[];
      for (final t in tasks.take(6)) {
        final due = fromTs(t['due_ts']);
        final course = asStr(t['course']).isEmpty ? '' : ' (${asStr(t['course'])})';
        final title = asStr(t['title']);
        if (asInt(t['due_ts']) < startMs) {
          lines.add('عقب‌افتاده: $title$course');
        } else if (daysBetween(dayStart, due) == 0) {
          lines.add('امروز تا ${clockLabel(due)}: $title$course');
        } else {
          lines.add('فردا: $title$course');
        }
      }
      nTasks = tasks.length;
      sections.add(BriefSection('تکالیف', lines));
    }

    // تولد
    if (s.birthday && profile != null) {
      final jy = Jalali.fromDateTime(dayStart).year;
      DateTime bd(int y) {
        final len = jalaliMonthLength(y, profile.birthM);
        return Jalali(y, profile.birthM, profile.birthD > len ? len : profile.birthD).toDateTime();
      }

      var next = dateOnly(bd(jy));
      if (next.isBefore(dayStart)) next = dateOnly(bd(jy + 1));
      final d = daysBetween(dayStart, next);
      if (d == 0) {
        sections.add(const BriefSection('مناسبت‌ها', ['امروز تولدته؛ تولدت مبارک!']));
      } else if (d <= 7) {
        sections.add(BriefSection('مناسبت‌ها', ['${faDigits(d)} روز تا تولدت مانده.']));
      }
    }

    // پیشنهاد
    if (s.tip) {
      String tip;
      if (exams.isNotEmpty) {
        final e = exams.first;
        final d = daysBetween(dayStart, fromTs(e['at_ts']));
        final minutes = 30 + 15 * asInt(e['difficulty'], 3).clamp(1, 5);
        if (d <= 0) {
          tip = 'امروز امتحان ${asStr(e['course'])} داری؛ فقط یک مرورِ سبک کن و آرامش‌ات را حفظ کن.';
        } else if (d == 1) {
          tip = 'فردا امتحان ${asStr(e['course'])} است؛ امروز یک مرورِ کامل بکن و شب زود بخواب.';
        } else {
          tip = 'تا امتحان ${asStr(e['course'])} ${faDigits(d)} روز مانده؛ امروز ${faDigits(minutes)} دقیقه رویش وقت بگذار.';
        }
      } else if (tasks.isNotEmpty) {
        tip = 'اول تکلیفِ «${asStr(tasks.first['title'])}» را تمام کن.';
      } else if (nClasses > 0) {
        tip = 'قبل از کلاس‌ها ده دقیقه درس‌های امروز را مرور کن.';
      } else {
        tip = 'روز آرامی است؛ یک جلسه‌ی پومودورو برای مرورِ درس‌ها بگذار.';
      }
      sections.add(BriefSection('پیشنهاد', [tip]));
    }

    if (sections.isEmpty) {
      sections.add(const BriefSection('امروز', ['برنامه‌ی خاصی ثبت نشده؛ روز خوبی داشته باش.']));
    }

    final parts = <String>[
      if (nClasses > 0) '${faDigits(nClasses)} کلاس',
      if (nExams > 0) '${faDigits(nExams)} امتحان',
      if (nTasks > 0) '${faDigits(nTasks)} تکلیف',
    ];
    return BriefData(
      title: name.isEmpty ? greet : '$greet $name',
      dateLine: jalaliLabelWithDay(dayStart),
      summary: parts.join(' · '),
      sections: sections,
    );
  }

  /// اعلان‌های ۱۴ روزِ آینده را از نو می‌سازد (متن هر روز از روی داده‌های امروز ساخته می‌شود).
  static Future<void> reschedule() async {
    final ns = NotificationService.instance;
    for (var i = 0; i < _days; i++) {
      try {
        await ns.cancel(_baseId + i);
      } catch (_) {}
    }
    final s = await load();
    if (!s.on) return;
    final now = DateTime.now();
    var made = 0;
    for (var i = 0; i <= _days && made < _days; i++) {
      final d = DateTime(now.year, now.month, now.day).add(Duration(days: i));
      final when = DateTime(d.year, d.month, d.day, s.hour, s.minute);
      if (!when.isAfter(now)) continue;
      try {
        final data = await compose(d, s, at: when);
        await ns.schedule(
          id: _baseId + made,
          title: data.title,
          body: data.shortBody,
          bigText: data.bodyText,
          when: when,
        );
        made++;
      } catch (_) {}
    }
  }

  /// نمونه‌ی فوری از اعلان
  static Future<void> sendSample() async {
    final s = await load();
    final data = await compose(DateTime.now(), s);
    await NotificationService.instance.showNow(
      id: _baseId + 99,
      title: data.title,
      body: data.shortBody,
      bigText: data.bodyText,
    );
  }

  /// با هر تغییرِ داده‌ها (و با شروع برنامه) اعلان‌ها دوباره ساخته می‌شوند.
  static void start() {
    if (_started) return;
    _started = true;
    AppBus.data.addListener(requestReschedule);
    requestReschedule();
  }

  static void requestReschedule() {
    _debounce?.cancel();
    _debounce = Timer(const Duration(seconds: 3), () {
      reschedule();
    });
  }
}
