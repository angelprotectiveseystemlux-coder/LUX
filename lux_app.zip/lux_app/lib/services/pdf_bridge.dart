import 'dart:typed_data';
import 'package:flutter/services.dart';

class PdfInfo {
  final int count;
  final List<double> ratios; // ارتفاع ÷ عرضِ هر صفحه
  const PdfInfo(this.count, this.ratios);
}

/// رندرِ PDF با PdfRendererِ خودِ اندروید (بدون پکیجِ خارجی).
class PdfBridge {
  PdfBridge._();
  static const MethodChannel _ch = MethodChannel('lux/pdf');

  static Future<PdfInfo?> open(String path) async {
    try {
      final r = await _ch.invokeMethod<Map<Object?, Object?>>('open', <String, Object>{'path': path});
      if (r == null) return null;
      final count = (r['count'] as num?)?.toInt() ?? 0;
      final raw = r['ratios'];
      final ratios = <double>[];
      if (raw is List) {
        for (final e in raw) {
          ratios.add((e as num).toDouble());
        }
      }
      if (count <= 0) return null;
      while (ratios.length < count) {
        ratios.add(1.41);
      }
      return PdfInfo(count, ratios);
    } catch (_) {
      return null;
    }
  }

  /// صفحه‌ی [page] (از صفر) را با عرضِ [width] پیکسل رندر می‌کند و JPEG برمی‌گرداند.
  static Future<Uint8List?> render(String path, int page, int width) async {
    try {
      final r = await _ch.invokeMethod<Uint8List>('render', <String, Object>{'path': path, 'page': page, 'width': width});
      return r;
    } catch (_) {
      return null;
    }
  }

  static Future<void> close() async {
    try {
      await _ch.invokeMethod<bool>('close');
    } catch (_) {}
  }

  static Future<void> keepAwake(bool on) async {
    try {
      await _ch.invokeMethod<bool>('keepAwake', <String, Object>{'on': on});
    } catch (_) {}
  }
}
