import 'dart:async';
import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';

import '../core/app_bus.dart';
import '../data/database.dart';

/// تنظیماتِ کاربرِ پومودورو (در پایگاه‌داده نگه داشته می‌شود).
class FocusSettings {
  int focusMin = 25;
  int shortMin = 5;
  int longMin = 15;
  int longEvery = 4;
  bool autoNext = false;
  bool vibrate = true;
  bool keepAwake = true;
  String endSound = 'bell';
  String ambient = '';
  double ambVol = 0.6;
  int island = 1; // ۰ خاموش، ۱ روشن
  int clock = 0; // سبکِ ساعت

  static const List<String> endSounds = <String>['bell', 'chime', 'beep', 'gong', 'soft', 'wood'];
  static const List<String> endSoundNames = <String>['زنگ', 'چایم', 'بوق', 'گونگ', 'نرم', 'چوبی'];
  static const List<String> ambients = <String>['', 'rain', 'waves', 'fire', 'brown', 'pink', 'white'];
  static const List<String> ambientNames = <String>['بدون صدا', 'باران', 'موج', 'آتش', 'نویز قهوه‌ای', 'نویز صورتی', 'نویز سفید'];

  Map<String, Object?> toCfg() => <String, Object?>{
        'focusMin': focusMin,
        'shortMin': shortMin,
        'longMin': longMin,
        'longEvery': longEvery,
        'autoNext': autoNext,
        'vibrate': vibrate,
        'endSound': endSound,
        'ambient': ambient,
        'ambVol': ambVol,
        'island': island,
      };

  static Future<FocusSettings> load() async {
    final db = LuxDb.instance;
    int i(String v, int d) => int.tryParse(v) ?? d;
    final s = FocusSettings();
    s.focusMin = i(await db.kvGet('pomo_focus') ?? '', 25).clamp(1, 240).toInt();
    s.shortMin = i(await db.kvGet('pomo_short') ?? '', 5).clamp(1, 60).toInt();
    s.longMin = i(await db.kvGet('pomo_long') ?? '', 15).clamp(1, 90).toInt();
    s.longEvery = i(await db.kvGet('pomo_every') ?? '', 4).clamp(0, 12).toInt();
    s.autoNext = (await db.kvGet('pomo_auto') ?? '0') == '1';
    s.vibrate = (await db.kvGet('pomo_vib') ?? '1') == '1';
    s.keepAwake = (await db.kvGet('pomo_awake') ?? '1') == '1';
    final es = await db.kvGet('pomo_end') ?? 'bell';
    s.endSound = endSounds.contains(es) ? es : 'bell';
    final am = await db.kvGet('pomo_amb') ?? '';
    s.ambient = ambients.contains(am) ? am : '';
    s.ambVol = (double.tryParse(await db.kvGet('pomo_vol') ?? '') ?? 0.6).clamp(0.1, 1.0).toDouble();
    s.island = i(await db.kvGet('pomo_island') ?? '', 1) == 0 ? 0 : 1;
    s.clock = i(await db.kvGet('pomo_clock') ?? '', 0).clamp(0, 4).toInt();
    return s;
  }

  Future<void> save() async {
    final db = LuxDb.instance;
    await db.kvSet('pomo_focus', '$focusMin');
    await db.kvSet('pomo_short', '$shortMin');
    await db.kvSet('pomo_long', '$longMin');
    await db.kvSet('pomo_every', '$longEvery');
    await db.kvSet('pomo_auto', autoNext ? '1' : '0');
    await db.kvSet('pomo_vib', vibrate ? '1' : '0');
    await db.kvSet('pomo_awake', keepAwake ? '1' : '0');
    await db.kvSet('pomo_end', endSound);
    await db.kvSet('pomo_amb', ambient);
    await db.kvSet('pomo_vol', '$ambVol');
    await db.kvSet('pomo_island', '$island');
    await db.kvSet('pomo_clock', '$clock');
  }
}

/// وضعیتِ فعلیِ تایمر (از سرویسِ اندروید).
class FocusState {
  final bool active;
  final bool running;
  final String phase; // focus | short | long
  final int endAt;
  final int leftMs;
  final int totalMs;
  final String label;
  final int courseId;
  final int cycle;

  const FocusState({
    this.active = false,
    this.running = false,
    this.phase = 'focus',
    this.endAt = 0,
    this.leftMs = 0,
    this.totalMs = 0,
    this.label = '',
    this.courseId = -1,
    this.cycle = 0,
  });

  bool get isBreak => phase != 'focus';

  /// میلی‌ثانیه‌ی باقی‌مانده در لحظه‌ی [nowMs].
  int leftAt(int nowMs) {
    if (!active) return 0;
    if (running) {
      final l = endAt - nowMs;
      return l < 0 ? 0 : l;
    }
    return leftMs;
  }

  static FocusState fromMap(Map<Object?, Object?> m) {
    int n(Object? v) => v is num ? v.toInt() : 0;
    return FocusState(
      active: m['active'] == true,
      running: m['running'] == true,
      phase: (m['phase'] as String?) ?? 'focus',
      endAt: n(m['endAt']),
      leftMs: n(m['leftMs']),
      totalMs: n(m['totalMs']),
      label: (m['label'] as String?) ?? '',
      courseId: m['courseId'] is num ? n(m['courseId']) : -1,
      cycle: n(m['cycle']),
    );
  }
}

/// اطلاعاتِ پشتیبانیِ دستگاه (برای جزیره‌ی شیائومی).
class FocusInfo {
  final bool xiaomi;
  final int protocol;
  final bool focusPerm;
  final bool island;
  const FocusInfo({this.xiaomi = false, this.protocol = 0, this.focusPerm = false, this.island = false});
}

/// پلِ Flutter به سرویسِ پیش‌زمینه‌ی تایمر. جلسه با بسته‌شدنِ برنامه ادامه می‌یابد.
class FocusTimer extends ChangeNotifier {
  FocusTimer._();
  static final FocusTimer instance = FocusTimer._();
  static const MethodChannel _ch = MethodChannel('lux/focus');

  FocusState state = const FocusState();
  FocusSettings settings = FocusSettings();
  FocusInfo info = const FocusInfo();

  /// شناسه‌ی جلسه‌های ثبت‌شده که هنوز «کیفیتِ تمرکز» نگرفته‌اند.
  final List<int> pendingQuality = <int>[];
  bool _inited = false;

  Future<void> init() async {
    if (_inited) return;
    _inited = true;
    _ch.setMethodCallHandler((call) async {
      if (call.method == 'changed') {
        await refresh();
        await drain();
      }
      return null;
    });
    settings = await FocusSettings.load();
    await refresh();
    await drain();
    await loadInfo();
  }

  Future<void> loadInfo() async {
    try {
      final m = await _ch.invokeMethod<Map<Object?, Object?>>('info');
      if (m != null) {
        info = FocusInfo(
          xiaomi: m['xiaomi'] == true,
          protocol: m['protocol'] is num ? (m['protocol'] as num).toInt() : 0,
          focusPerm: m['focusPerm'] == true,
          island: m['island'] == true,
        );
        notifyListeners();
      }
    } catch (_) {}
  }

  Future<void> refresh() async {
    try {
      final m = await _ch.invokeMethod<Map<Object?, Object?>>('state');
      if (m != null) {
        state = FocusState.fromMap(m);
        notifyListeners();
      }
    } catch (_) {}
  }

  /// جلسه‌های تمام‌شده (حتی وقتی برنامه بسته بود) را در پایگاه‌داده ثبت می‌کند.
  Future<void> drain() async {
    try {
      final s = await _ch.invokeMethod<String>('drain');
      if (s == null || s.isEmpty || s == '[]') return;
      final list = jsonDecode(s) as List<dynamic>;
      var any = false;
      for (final e in list) {
        final m = e as Map<String, dynamic>;
        final c = (m['c'] as num?)?.toInt() ?? -1;
        final id = await LuxDb.instance.insert('study_sessions', <String, Object?>{
          'course_id': c < 0 ? null : c,
          'start_ts': (m['s'] as num).toInt(),
          'end_ts': (m['e'] as num).toInt(),
          'kind': 'pomodoro',
          'planned_min': (m['p'] as num?)?.toInt(),
          'completed': 1,
        });
        pendingQuality.add(id);
        any = true;
      }
      if (any) {
        AppBus.bump();
        notifyListeners();
      }
    } catch (_) {}
  }

  Future<void> _call(String m, [Map<String, Object?>? args]) async {
    try {
      await _ch.invokeMethod<Object?>(m, args);
    } catch (_) {}
    await refresh();
  }

  Future<void> start({required String phase, required String label, required int courseId, int? cycle, int? minutes}) async {
    final cfg = <String, Object?>{
      ...settings.toCfg(),
      'phase': phase,
      'label': label,
      'courseId': courseId,
      if (cycle != null) 'cycle': cycle,
      if (minutes != null) 'minutes': minutes,
    };
    await _call('start', <String, Object?>{'cfg': jsonEncode(cfg)});
  }

  Future<void> pause() => _call('pause');
  Future<void> resume() => _call('resume');
  Future<void> stop() => _call('stop');
  Future<void> skip() => _call('skip');
  Future<void> addFive() => _call('add');

  /// تنظیمات را ذخیره می‌کند و (اگر جلسه‌ای در جریان است) فوراً به سرویس می‌رساند.
  Future<void> pushSettings() async {
    await settings.save();
    await _call('configure', <String, Object?>{
      'cfg': jsonEncode(<String, Object?>{...settings.toCfg()}),
    });
  }

  Future<void> preview(String key, {bool ambient = false}) async {
    try {
      await _ch.invokeMethod<Object?>('preview', <String, Object?>{'key': key, 'vol': settings.ambVol, 'ambient': ambient});
    } catch (_) {}
  }

  Future<void> stopPreview() async {
    try {
      await _ch.invokeMethod<Object?>('stopPreview');
    } catch (_) {}
  }

  Future<void> openNotifSettings() async {
    try {
      await _ch.invokeMethod<Object?>('openNotifSettings');
    } catch (_) {}
  }

  Future<void> openAppSettings() async {
    try {
      await _ch.invokeMethod<Object?>('openAppSettings');
    } catch (_) {}
  }
}
