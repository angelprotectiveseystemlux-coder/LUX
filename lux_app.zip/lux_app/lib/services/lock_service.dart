import 'dart:convert';
import 'dart:math';

import 'package:crypto/crypto.dart';

import '../data/database.dart';

/// رمز ورودِ برنامه. فقط هشِ نمک‌دار ذخیره می‌شود، نه خودِ رمز.
class LockService {
  LockService._();

  static const String _kHash = 'pin_hash';
  static const String _kSalt = 'pin_salt';
  static const String _kLen = 'pin_len';

  static int _fails = 0;
  static DateTime? _blockedUntil;

  static String _hash(String pin, String salt) =>
      sha256.convert(utf8.encode('$salt|$pin|LUX')).toString();

  static Future<bool> hasPin() async => (await LuxDb.instance.kvGet(_kHash)) != null;

  static Future<int> pinLength() async => int.tryParse(await LuxDb.instance.kvGet(_kLen) ?? '') ?? 4;

  static Future<void> setPin(String pin) async {
    final r = Random.secure();
    final salt = List<int>.generate(16, (_) => r.nextInt(256)).map((b) => b.toRadixString(16).padLeft(2, '0')).join();
    await LuxDb.instance.kvSet(_kSalt, salt);
    await LuxDb.instance.kvSet(_kLen, pin.length.toString());
    await LuxDb.instance.kvSet(_kHash, _hash(pin, salt));
    _fails = 0;
    _blockedUntil = null;
  }

  static Future<void> clear() async {
    await LuxDb.instance.kvDelete(_kHash);
    await LuxDb.instance.kvDelete(_kSalt);
    await LuxDb.instance.kvDelete(_kLen);
    await LuxDb.instance.kvDelete('bio_on');
    _fails = 0;
    _blockedUntil = null;
  }

  /// ثانیه‌های باقی‌مانده از قفلِ موقت بعد از چند بار اشتباه
  static int blockedSeconds() {
    final b = _blockedUntil;
    if (b == null) return 0;
    final s = b.difference(DateTime.now()).inSeconds;
    return s > 0 ? s : 0;
  }

  static Future<bool> verify(String pin) async {
    if (blockedSeconds() > 0) return false;
    final salt = await LuxDb.instance.kvGet(_kSalt) ?? '';
    final h = await LuxDb.instance.kvGet(_kHash) ?? '';
    final ok = h.isNotEmpty && _hash(pin, salt) == h;
    if (ok) {
      _fails = 0;
      _blockedUntil = null;
    } else {
      _fails++;
      if (_fails >= 5) {
        _blockedUntil = DateTime.now().add(Duration(seconds: 30 * (_fails - 4)));
      }
    }
    return ok;
  }
}
