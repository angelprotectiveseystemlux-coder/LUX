import '../engine/smart/estimators.dart';
import '../engine/smart/models.dart';
import 'notification_service.dart';

/// اعلانِ شروعِ بلوک‌های برنامه‌ی هوشمند؛ کم‌مزاحم: حداکثر ۳ اعلان در روز و فقط در ساعت‌هایی که معمولاً جواب می‌دهی.
class SmartNotifs {
  SmartNotifs._();

  static const int _base = 700000;
  static const int _slots = 60;

  static Future<void> sync(List<SBlock> blocks, ExecStats exec, DateTime now) async {
    final n = NotificationService.instance;
    for (var i = 0; i < _slots; i++) {
      try {
        await n.cancel(_base + i);
      } catch (_) {}
    }
    var idx = 0;
    final perDay = <int, int>{};
    for (final b in blocks) {
      if (b.status != 'planned' || b.kind == 'micro' || b.kind == 'light') continue;
      final d = dayFromKey(b.day);
      final at = DateTime(d.year, d.month, d.day, 0, b.startMin);
      if (!at.isAfter(now.add(const Duration(minutes: 3)))) continue;
      final count = perDay[b.day] ?? 0;
      if (count >= 3) continue;
      final hr = (b.startMin ~/ 60).clamp(0, 23).toInt();
      final ignored = exec.samples >= 8 && exec.byHour[hr] < 0.35;
      final must = b.kind == 'mock' || count == 0;
      if (ignored && !must) continue;
      try {
        await n.schedule(
          id: _base + idx,
          title: b.title,
          body: 'وقتِ شروع است (${b.durMin} دقیقه). اگر سخت است، فقط ۵ دقیقه شروع کن.',
          when: at.subtract(const Duration(minutes: 1)),
        );
      } catch (_) {}
      perDay[b.day] = count + 1;
      idx++;
      if (idx >= _slots) break;
    }
  }
}
