import 'dart:async';

import '../core/app_bus.dart';
import '../core/jalali_utils.dart';
import '../data/week_plan_repo.dart';
import 'notification_service.dart';

/// یادآورِ کیف: در دو ساعتی که کاربر تعیین کرده، اعلان می‌دهد که برای روزِ مدرسه‌ی بعد کدام کتاب‌ها را بگذارد.
/// «روزِ بعد» از ساعتِ تعیین‌شده (پیش‌فرض ۱۴) به بعد حساب می‌شود و روزهای بدونِ زنگ رد می‌شوند.
class BagReminders {
  BagReminders._();

  static const int _baseId = 500000;
  static const int _days = 14;
  static Timer? _debounce;
  static bool _started = false;

  /// اعلان‌های ۱۴ روزِ آینده را از نو می‌سازد.
  static Future<void> reschedule() async {
    final ns = NotificationService.instance;
    for (var i = 0; i < _days * 2; i++) {
      try {
        await ns.cancel(_baseId + i);
      } catch (_) {}
    }
    final s = await WeekPlanRepo.settings();
    if (!s.remindOn) return;
    final plan = await WeekPlanRepo.all();
    if (plan.isEmpty) return;
    final times = <int>[s.remind1, if (s.remind2On) s.remind2];
    final now = DateTime.now();
    for (var i = 0; i < _days; i++) {
      final d = DateTime(now.year, now.month, now.day + i);
      for (var k = 0; k < times.length; k++) {
        final when = DateTime(d.year, d.month, d.day, times[k] ~/ 60, times[k] % 60);
        if (!when.isAfter(now)) continue;
        try {
          final day = await WeekPlanRepo.targetFor(when, settings: s, plan: plan);
          if (day == null || day.bag.isEmpty) continue;
          final lines = <String>[
            for (final p in day.periods)
              if (!p.isFree) 'زنگ ${faDigits(p.period)}: ${p.activeName(day.parity)}',
          ];
          await ns.schedule(
            id: _baseId + i * 2 + k,
            title: 'کیفِ ${day.label} (${day.weekdayName})',
            body: day.bagText,
            bigText: '${day.bagText}\n\n${lines.join('\n')}',
            when: when,
          );
        } catch (_) {}
      }
    }
  }

  /// نمونه‌ی فوری
  static Future<void> sendSample() async {
    final day = await WeekPlanRepo.target();
    if (day == null || day.bag.isEmpty) return;
    await NotificationService.instance.showNow(
      id: _baseId + _days * 2 + 1,
      title: 'کیفِ ${day.label} (${day.weekdayName})',
      body: day.bagText,
    );
  }

  /// با هر تغییرِ داده‌ها (و با شروعِ برنامه) اعلان‌ها دوباره ساخته می‌شوند.
  static void start() {
    if (_started) return;
    _started = true;
    AppBus.data.addListener(requestReschedule);
    requestReschedule();
  }

  static void requestReschedule() {
    _debounce?.cancel();
    _debounce = Timer(const Duration(seconds: 4), () {
      reschedule();
    });
  }
}
