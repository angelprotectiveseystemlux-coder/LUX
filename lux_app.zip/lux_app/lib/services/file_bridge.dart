import 'package:flutter/services.dart';

/// پل به انتخابگر فایلِ خودِ اندروید (ذخیره در… / انتخاب فایل).
class FileBridge {
  FileBridge._();
  static const MethodChannel _ch = MethodChannel('lux/files');

  /// فایلِ [srcPath] را با پنجره‌ی «ذخیره»ی اندروید در جایی که کاربر می‌خواهد می‌نویسد.
  static Future<bool> saveAs(String srcPath, String name) async {
    try {
      return (await _ch.invokeMethod<bool>('saveAs', <String, Object>{'path': srcPath, 'name': name})) ?? false;
    } catch (_) {
      return false;
    }
  }

  /// فایل را با انتخابگرِ اندروید می‌گیرد و مسیرِ نسخه‌ی موقتش را برمی‌گرداند.
  static Future<String?> pick() async {
    try {
      return await _ch.invokeMethod<String>('pick');
    } catch (_) {
      return null;
    }
  }
}
