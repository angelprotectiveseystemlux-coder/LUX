/// معادلات نمره و معدل — خالص، آفلاین و قابل‌توضیح.
class WeightedScore {
  final double value; // نمره‌ی کسب‌شده
  final double max; // حداکثر آن ارزیابی
  final double weight; // ضریب/وزن
  const WeightedScore(this.value, this.max, this.weight);

  /// نمره روی مقیاس مشترک [scale]
  double normalized(double scale) => max <= 0 ? 0 : value / max * scale;
}

class Requirement {
  /// نمره‌ی لازم روی مقیاس مشترک (ممکن است منفی یا بزرگ‌تر از مقیاس باشد)
  final double neededOnScale;

  /// نمره‌ی لازم روی حداکثرِ همان امتحان
  final double neededOnExam;

  /// اگر لازم باشد از حداکثر بیشتر بگیری، ممکن نیست.
  final bool possible;

  /// اگر نمره‌ی لازم صفر یا کمتر باشد، هدف همین حالا هم تضمین است.
  final bool alreadySafe;

  const Requirement(this.neededOnScale, this.neededOnExam, this.possible, this.alreadySafe);
}

class CourseResult {
  final double average; // میانگین وزنیِ درس روی مقیاس
  final double coef; // ضریب (واحد) درس
  const CourseResult(this.average, this.coef);
}

class GradeMath {
  GradeMath._();

  /// معدل وزنی: Σ(نمره×وزن) / Σوزن  روی مقیاس مشترک
  static double? weightedAverage(List<WeightedScore> items, {double scale = 20}) {
    var s = 0.0, w = 0.0;
    for (final it in items) {
      if (it.weight <= 0) continue;
      s += it.normalized(scale) * it.weight;
      w += it.weight;
    }
    if (w == 0) return null;
    return s / w;
  }

  /// معدل کل: Σ(میانگین درس × ضریب درس) / Σضریب
  static double? gpa(List<CourseResult> courses) {
    var s = 0.0, w = 0.0;
    for (final c in courses) {
      if (c.coef <= 0) continue;
      s += c.average * c.coef;
      w += c.coef;
    }
    if (w == 0) return null;
    return s / w;
  }

  /// نمره‌ی لازم برای رسیدن به معدل هدف [target] با یک ارزیابیِ بعدی.
  /// S = Σ(نمره×وزن)، W = Σوزن‌های فعلی، w = وزن ارزیابی بعدی:
  ///   x = (G·(W+w) − S) / w
  static Requirement? requiredScore({
    required double sumWeighted,
    required double sumWeights,
    required double nextWeight,
    required double target,
    double scale = 20,
    double? nextMax,
  }) {
    if (nextWeight <= 0) return null;
    final x = (target * (sumWeights + nextWeight) - sumWeighted) / nextWeight;
    final onExam = (nextMax ?? scale) / scale * x;
    return Requirement(x, onExam, x <= scale + 1e-9, x <= 0);
  }

  /// حساسیت: اگر نمره‌ی این درس یک واحد عوض شود معدل چقدر عوض می‌شود.
  static double sensitivity(double coef, double sumCoefs) => sumCoefs <= 0 ? 0 : coef / sumCoefs;

  /// جمع نمره×وزن روی مقیاس مشترک (ورودیِ requiredScore)
  static double sumWeightedOf(List<WeightedScore> items, {double scale = 20}) {
    var s = 0.0;
    for (final it in items) {
      if (it.weight > 0) s += it.normalized(scale) * it.weight;
    }
    return s;
  }

  static double sumWeightsOf(List<WeightedScore> items) {
    var w = 0.0;
    for (final it in items) {
      if (it.weight > 0) w += it.weight;
    }
    return w;
  }

  /// شبیه‌ساز «اگر…»: معدل کل اگر نمره‌ی فرضیِ [hypothetical] به درس‌ها اضافه شود.
  /// کلید: اندیس درس، مقدار: میانگین فرضیِ جدید آن درس.
  static double? whatIfGpa(List<CourseResult> courses, Map<int, double> hypothetical) {
    final list = <CourseResult>[];
    for (var i = 0; i < courses.length; i++) {
      list.add(CourseResult(hypothetical[i] ?? courses[i].average, courses[i].coef));
    }
    return gpa(list);
  }
}

// ───────────────────────── مستمر / نهایی + مثبت و منفی ─────────────────────────

/// نوعِ امتحانی که «نهایی» حساب می‌شود (بقیه‌ی امتحان‌ها مستمرند).
const String kFinalExamType = '\u067E\u0627\u06CC\u0627\u0646\u200C\u062A\u0631\u0645'; // پایان‌ترم

/// اثرِ مثبت و منفیِ سر کلاس روی نمره‌ی مستمر (همه روی مقیاس ۲۰ تعریف می‌شوند).
class BehaviorRule {
  final double positiveValue; // هر مثبت چند نمره اضافه کند
  final double negativeValue; // هر منفی چند نمره کم کند
  final double cap; // سقفِ کل اثر (هم مثبت هم منفی)
  const BehaviorRule({this.positiveValue = 0.25, this.negativeValue = 0.25, this.cap = 2});

  /// اثرِ خالص روی مستمر برای [positives] مثبت و [negatives] منفی، روی مقیاسِ [scale].
  double delta(int positives, int negatives, {double scale = 20}) {
    final raw = positives * positiveValue - negatives * negativeValue;
    final c = cap.abs();
    final capped = raw > c ? c : (raw < -c ? -c : raw);
    return capped * scale / 20;
  }
}

/// نتیجه‌ی یک درس: مستمر + نهایی → نمره‌ی کل.
class TermScore {
  final double? continuous; // میانگین مستمر، بدون اثرِ مثبت/منفی
  final double behavior; // اثرِ مثبت/منفی
  final double? continuousAdj; // مستمر بعد از اثرِ مثبت/منفی
  final double? finalScore; // میانگین نهایی
  final double finalShare; // سهم نهایی (۰ تا ۱)
  final double? total; // نمره‌ی کل درس
  const TermScore({
    required this.continuous,
    required this.behavior,
    required this.continuousAdj,
    required this.finalScore,
    required this.finalShare,
    required this.total,
  });
}

class TermMath {
  TermMath._();

  /// معادله: کل = مستمرِ اصلاح‌شده × (۱ − سهم) + نهایی × سهم
  /// اگر فقط یکی از دو بخش نمره دارد، همان بخش نمره‌ی درس است.
  /// مثبت/منفی فقط به مستمر اضافه یا از آن کم می‌شود (و در بازه‌ی ۰ تا [scale] می‌ماند).
  static TermScore compute({
    required List<WeightedScore> continuous,
    required List<WeightedScore> finals,
    double behavior = 0,
    double finalShare = 0.5,
    double scale = 20,
  }) {
    final share = finalShare < 0 ? 0.0 : (finalShare > 1 ? 1.0 : finalShare);
    final m = GradeMath.weightedAverage(continuous, scale: scale);
    final f = GradeMath.weightedAverage(finals, scale: scale);
    double? madj;
    if (m != null) {
      final v = m + behavior;
      madj = v < 0 ? 0.0 : (v > scale ? scale : v);
    }
    double? total;
    if (madj != null && f != null) {
      total = madj * (1 - share) + f * share;
    } else {
      total = madj ?? f;
    }
    return TermScore(
      continuous: m,
      behavior: behavior,
      continuousAdj: madj,
      finalScore: f,
      finalShare: share,
      total: total,
    );
  }

  /// نمره‌ای که در نهایی لازم است تا کلِ درس به [target] برسد (ممکن است بیشتر از [scale] شود = دست‌نیافتنی).
  static double? neededFinal({required double continuousAdj, required double target, required double finalShare}) {
    if (finalShare <= 0) return null;
    return (target - (1 - finalShare) * continuousAdj) / finalShare;
  }
}
