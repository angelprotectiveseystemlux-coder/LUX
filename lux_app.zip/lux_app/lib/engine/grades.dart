/// معادلات نمره و معدل — خالص، آفلاین و قابل‌توضیح.
class WeightedScore {
  final double value; // نمره‌ی کسب‌شده
  final double max; // حداکثر آن ارزیابی
  final double weight; // ضریب/وزن
  const WeightedScore(this.value, this.max, this.weight);

  /// نمره روی مقیاس مشترک [scale]
  double normalized(double scale) => max <= 0 ? 0 : value / max * scale;
}

class Requirement {
  /// نمره‌ی لازم روی مقیاس مشترک (ممکن است منفی یا بزرگ‌تر از مقیاس باشد)
  final double neededOnScale;

  /// نمره‌ی لازم روی حداکثرِ همان امتحان
  final double neededOnExam;

  /// اگر لازم باشد از حداکثر بیشتر بگیری، ممکن نیست.
  final bool possible;

  /// اگر نمره‌ی لازم صفر یا کمتر باشد، هدف همین حالا هم تضمین است.
  final bool alreadySafe;

  const Requirement(this.neededOnScale, this.neededOnExam, this.possible, this.alreadySafe);
}

class CourseResult {
  final double average; // میانگین وزنیِ درس روی مقیاس
  final double coef; // ضریب (واحد) درس
  const CourseResult(this.average, this.coef);
}

class GradeMath {
  GradeMath._();

  /// معدل وزنی: Σ(نمره×وزن) / Σوزن  روی مقیاس مشترک
  static double? weightedAverage(List<WeightedScore> items, {double scale = 20}) {
    var s = 0.0, w = 0.0;
    for (final it in items) {
      if (it.weight <= 0) continue;
      s += it.normalized(scale) * it.weight;
      w += it.weight;
    }
    if (w == 0) return null;
    return s / w;
  }

  /// معدل کل: Σ(میانگین درس × ضریب درس) / Σضریب
  static double? gpa(List<CourseResult> courses) {
    var s = 0.0, w = 0.0;
    for (final c in courses) {
      if (c.coef <= 0) continue;
      s += c.average * c.coef;
      w += c.coef;
    }
    if (w == 0) return null;
    return s / w;
  }

  /// نمره‌ی لازم برای رسیدن به معدل هدف [target] با یک ارزیابیِ بعدی.
  /// S = Σ(نمره×وزن)، W = Σوزن‌های فعلی، w = وزن ارزیابی بعدی:
  ///   x = (G·(W+w) − S) / w
  static Requirement? requiredScore({
    required double sumWeighted,
    required double sumWeights,
    required double nextWeight,
    required double target,
    double scale = 20,
    double? nextMax,
  }) {
    if (nextWeight <= 0) return null;
    final x = (target * (sumWeights + nextWeight) - sumWeighted) / nextWeight;
    final onExam = (nextMax ?? scale) / scale * x;
    return Requirement(x, onExam, x <= scale + 1e-9, x <= 0);
  }

  /// حساسیت: اگر نمره‌ی این درس یک واحد عوض شود معدل چقدر عوض می‌شود.
  static double sensitivity(double coef, double sumCoefs) => sumCoefs <= 0 ? 0 : coef / sumCoefs;

  /// جمع نمره×وزن روی مقیاس مشترک (ورودیِ requiredScore)
  static double sumWeightedOf(List<WeightedScore> items, {double scale = 20}) {
    var s = 0.0;
    for (final it in items) {
      if (it.weight > 0) s += it.normalized(scale) * it.weight;
    }
    return s;
  }

  static double sumWeightsOf(List<WeightedScore> items) {
    var w = 0.0;
    for (final it in items) {
      if (it.weight > 0) w += it.weight;
    }
    return w;
  }

  /// شبیه‌ساز «اگر…»: معدل کل اگر نمره‌ی فرضیِ [hypothetical] به درس‌ها اضافه شود.
  /// کلید: اندیس درس، مقدار: میانگین فرضیِ جدید آن درس.
  static double? whatIfGpa(List<CourseResult> courses, Map<int, double> hypothetical) {
    final list = <CourseResult>[];
    for (var i = 0; i < courses.length; i++) {
      list.add(CourseResult(hypothetical[i] ?? courses[i].average, courses[i].coef));
    }
    return gpa(list);
  }
}
