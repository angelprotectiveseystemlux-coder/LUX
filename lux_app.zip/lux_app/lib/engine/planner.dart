import 'dart:math' as math;

class PressureInput {
  final double coef; // ضریب امتحان/درس
  final double difficulty; // ۱..۵ (یا هر مقیاس ثابت)
  final double readiness; // ۰..۱
  final int daysLeft; // روزهای مانده
  const PressureInput(this.coef, this.difficulty, this.readiness, this.daysLeft);
}

class StudyItem {
  final String id;
  final double coef;
  final double difficulty; // ۱..۵
  final double gap; // شکاف تا هدف (۰..۱)، مثلاً (هدف − پیش‌بینی)/مقیاس
  final int daysLeft;
  const StudyItem({
    required this.id,
    required this.coef,
    required this.difficulty,
    required this.gap,
    required this.daysLeft,
  });

  /// وزنِ اولویت = ضریب × سختی × شکاف × نزدیکی
  /// نزدیکی = 1/√max(1, روزهای مانده)  (هرچه امتحان نزدیک‌تر، اولویت بیشتر)
  double get priority {
    final proximity = 1.0 / math.sqrt(math.max(1, daysLeft).toDouble());
    return coef * difficulty * math.max(0.05, gap) * proximity;
  }
}

class Allocation {
  final String id;
  final double hours;
  const Allocation(this.id, this.hours);
}

class Planner {
  Planner._();

  /// شاخص فشار یک امتحان: ضریب × سختی × (۱ − آمادگی) / روزهای مانده
  static double examPressure(PressureInput i) {
    final days = math.max(1, i.daysLeft).toDouble();
    return i.coef * i.difficulty * (1 - i.readiness.clamp(0.0, 1.0)) / days;
  }

  /// مجموع فشارِ چند امتحان (برای نقشه‌ی گرمایی فشار هفته)
  static double totalPressure(List<PressureInput> xs) {
    var s = 0.0;
    for (final x in xs) {
      s += examPressure(x);
    }
    return s;
  }

  /// پخشِ ساعت مطالعه‌ی روزانه بین درس‌ها بر اساس وزن اولویت.
  /// - هر سهم کوچک‌تر از [minBlock] حذف و باقی دوباره نرمال می‌شود.
  /// - هیچ درسی بیشتر از [maxPerItem] نمی‌گیرد.
  /// - خروجی به مضرب [step] گرد می‌شود و مجموعش دقیقاً به [dailyHours] می‌رسد
  ///   (در حدی که سقف‌ها اجازه بدهند).
  static List<Allocation> allocate(
    List<StudyItem> items,
    double dailyHours, {
    double minBlock = 0.5,
    double maxPerItem = 3.0,
    double step = 0.25,
  }) {
    if (items.isEmpty || dailyHours <= 0) return const [];
    var active = List<StudyItem>.from(items);
    final hours = <String, double>{};

    for (var round = 0; round < 12; round++) {
      final total = active.fold<double>(0, (a, b) => a + b.priority);
      if (total <= 0) break;
      hours.clear();
      for (final it in active) {
        hours[it.id] = dailyHours * it.priority / total;
      }
      // سقف: مازاد را بین بقیه پخش کن
      var excess = 0.0;
      final capped = <String>{};
      for (final it in active) {
        final h = hours[it.id]!;
        if (h > maxPerItem) {
          excess += h - maxPerItem;
          hours[it.id] = maxPerItem;
          capped.add(it.id);
        }
      }
      if (excess > 0) {
        final free = active.where((e) => !capped.contains(e.id)).toList();
        final freeTotal = free.fold<double>(0, (a, b) => a + b.priority);
        if (freeTotal > 0) {
          for (final it in free) {
            hours[it.id] = hours[it.id]! + excess * it.priority / freeTotal;
          }
        }
      }
      // حذف سهم‌های کوچک
      final small = active.where((e) => hours[e.id]! < minBlock).toList();
      if (small.isEmpty || small.length == active.length) break;
      // کوچک‌ترین را حذف کن و دوباره حساب کن
      small.sort((a, b) => hours[a.id]!.compareTo(hours[b.id]!));
      active.removeWhere((e) => e.id == small.first.id);
    }

    // گرد کردن به مضرب step با روش بیشترین باقیمانده
    final ids = hours.keys.toList();
    final units = <String, int>{};
    final rema = <String, double>{};
    var used = 0;
    for (final id in ids) {
      final raw = hours[id]! / step;
      final fl = raw.floor();
      units[id] = fl;
      rema[id] = raw - fl;
      used += fl;
    }
    final target = (dailyHours / step).round();
    var left = target - used;
    final order = List<String>.from(ids)..sort((a, b) => rema[b]!.compareTo(rema[a]!));
    var guard = 0;
    while (left > 0 && order.isNotEmpty && guard < 1000) {
      final id = order[guard % order.length];
      if (units[id]! * step + step <= maxPerItem + 1e-9) {
        units[id] = units[id]! + 1;
        left--;
      }
      guard++;
      if (guard > order.length * 4) break;
    }
    final out = <Allocation>[];
    for (final id in ids) {
      final h = units[id]! * step;
      if (h > 0) out.add(Allocation(id, h));
    }
    out.sort((a, b) => b.hours.compareTo(a.hours));
    return out;
  }

  /// سرعت خواندن: صفحه در ساعت
  static double? pagesPerHour(int pages, double hours) => hours <= 0 ? null : pages / hours;

  /// تعداد روزِ لازم برای اتمام: صفحه‌های باقی‌مانده ÷ (سرعت × ساعت روزانه)
  static double? daysToFinish({required int remainingPages, required double pagesPerHour, required double hoursPerDay}) {
    final perDay = pagesPerHour * hoursPerDay;
    if (perDay <= 0) return null;
    return remainingPages / perDay;
  }

  /// انحراف از برنامه: (واقعی − برنامه) / برنامه
  static double? deviation(double actual, double planned) => planned <= 0 ? null : (actual - planned) / planned;
}
