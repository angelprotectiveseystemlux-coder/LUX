/// مرور فاصله‌دار — الگوریتم SM-2
class SrsCard {
  final double ef; // ضریب سهولت (حداقل ۱٫۳)
  final int reps; // تعداد مرورهای موفق پیاپی
  final int intervalDays;
  final DateTime due;
  const SrsCard({required this.ef, required this.reps, required this.intervalDays, required this.due});

  factory SrsCard.fresh(DateTime now) => SrsCard(ef: 2.5, reps: 0, intervalDays: 0, due: now);
}

class Srs {
  Srs._();

  /// [q] کیفیتِ یادآوری از ۰ تا ۵ (۵ = کاملاً آسان). q < 3 یعنی شکست.
  /// - شکست: تکرارها از نو، فاصله ۱ روز، ضریب سهولت بدون تغییر.
  /// - موفق: فاصله‌ها ۱، ۶، سپس فاصله‌ی قبلی × EF؛ و
  ///   EF' = EF + (0.1 − (5−q)·(0.08 + (5−q)·0.02))  با کفِ ۱٫۳
  static SrsCard review(SrsCard c, int q, DateTime now) {
    final quality = q.clamp(0, 5);
    var ef = c.ef;
    var reps = c.reps;
    var interval = c.intervalDays;

    if (quality < 3) {
      reps = 0;
      interval = 1;
    } else {
      reps += 1;
      if (reps == 1) {
        interval = 1;
      } else if (reps == 2) {
        interval = 6;
      } else {
        interval = (interval * ef).round();
      }
      ef = ef + (0.1 - (5 - quality) * (0.08 + (5 - quality) * 0.02));
      if (ef < 1.3) ef = 1.3;
    }
    return SrsCard(ef: ef, reps: reps, intervalDays: interval, due: now.add(Duration(days: interval)));
  }
}
