import 'dart:math' as math;

import 'estimators.dart';
import 'models.dart';

class _Day {
  final int index;
  final DateTime date;
  final int key;
  final bool off;
  List<List<int>> free = <List<int>>[];
  int capacity = 0;
  int busyMin = 0;
  bool examToday = false;
  bool examTomorrow = false;
  final List<SBlock> blocks = <SBlock>[];
  final Map<int, int> minutes = <int, int>{}; // درس → دقیقه‌ی مطالعه‌ی تخصیص‌یافته
  _Day(this.index, this.date, this.off) : key = dayKey(date);
}

class _Chap {
  final SChapter chapter;
  double remainingMin;
  _Chap(this.chapter, this.remainingMin);
}

/// موتورِ برنامه‌ریزِ هوشمند: ظرفیتِ واقعی، تخصیصِ ساعت‌ها بر پایه‌ی «سودِ هر ساعت»، فازِ امتحان،
/// مرورِ به‌موقع، ساعتِ اوجِ تمرکز و هشدارها.
class Scheduler {
  Scheduler._();

  static const int _unit = 15;

  static List<List<int>> _subtract(List<List<int>> free, int a, int b) {
    final out = <List<int>>[];
    for (final iv in free) {
      if (b <= iv[0] || a >= iv[1]) {
        out.add(iv);
        continue;
      }
      if (a > iv[0]) out.add(<int>[iv[0], a]);
      if (b < iv[1]) out.add(<int>[b, iv[1]]);
    }
    return out.where((e) => e[1] - e[0] >= 10).toList();
  }

  static String _f1(double v) => v.toStringAsFixed(1);

  static SPlanResult run(SSnapshot s, {List<SBlock> keep = const <SBlock>[]}) {
    final st = s.settings;
    final now = s.now;
    final today = dateOnly0(now);
    final models = Estimators.courseModels(s);
    final hourScore = Estimators.hourScores(s);
    final bestH = Estimators.bestHour(hourScore);
    final exec = Estimators.execStats(s);
    final shares = Estimators.reflectionShares(s);
    final burn = Estimators.burnout(s);
    final avgMin = Estimators.avgDailyMinutes(s);
    final alerts = <SAlert>[];

    if (s.courses.isEmpty) {
      return const SPlanResult(blocks: <SBlock>[], days: <SDayInfo>[], alerts: <SAlert>[], forecasts: <SExamForecast>[]);
    }

    final H = st.horizonDays.clamp(3, 14).toInt();
    final upcoming = [
      for (final e in s.exams)
        if (e.status == 'planned' && e.at.isAfter(now.subtract(const Duration(hours: 1)))) e,
    ]..sort((a, b) => a.at.compareTo(b.at));

    int daysUntil(DateTime a, DateTime b) => dateOnly0(b).difference(dateOnly0(a)).inDays;

    // ───────── روزها و ظرفیت ─────────
    final days = <_Day>[];
    for (var i = 0; i < H; i++) {
      final date = DateTime(today.year, today.month, today.day + i);
      days.add(_Day(i, date, s.offDays.contains(dayKey(date))));
    }
    for (final d in days) {
      for (final e in upcoming) {
        final dl = daysUntil(d.date, e.at);
        if (dl == 0) d.examToday = true;
        if (dl == 1) d.examTomorrow = true;
      }
      final wd = (d.date.weekday + 1) % 7;
      final daySlots = [for (final x in s.slots) if (x.weekday == wd) x]..sort((a, b) => a.startMin.compareTo(b.startMin));
      var start = d.off ? st.offStartMin : st.schoolEndMin + st.restAfterSchoolMin;
      if (!d.off && daySlots.isNotEmpty) {
        final lastEnd = daySlots.map((e) => e.endMin).reduce(math.max);
        start = math.max(start, lastEnd + 45);
      }
      var end = st.bedMin;
      if (d.examTomorrow) end = math.min(end, 21 * 60 + 30);
      if (d.index == 0) {
        final nowMin = now.hour * 60 + now.minute;
        start = math.max(start, ((nowMin + 10) / 5).ceil() * 5);
      }
      if (d.examToday) {
        var examEnd = start;
        for (final e in upcoming) {
          if (daysUntil(d.date, e.at) == 0) examEnd = math.max(examEnd, e.at.hour * 60 + e.at.minute + 90);
        }
        start = math.max(start, examEnd);
      }
      var free = <List<int>>[];
      if (end - start >= 20) free.add(<int>[start, end]);
      if (d.off) free = _subtract(free, 13 * 60, 14 * 60);
      for (final iv in s.events[d.key] ?? const <List<int>>[]) {
        free = _subtract(free, iv[0] - 10, iv[1] + 10);
      }
      var usedByKeep = 0;
      for (final b in keep) {
        if (b.day != d.key || b.status == 'rejected' || b.status == 'skipped') continue;
        if (b.status == 'planned' && !b.locked) continue;
        free = _subtract(free, b.startMin - 5, b.endMin + 5);
        if (b.kind != 'micro') usedByKeep += b.durMin;
      }
      d.free = free;
      var raw = 0;
      for (final iv in free) {
        raw += iv[1] - iv[0];
      }
      final factor = exec.samples >= 6 ? exec.overall.clamp(0.6, 1.0).toDouble() : 0.85;
      var cap = (raw * factor).floor();
      var maxDaily = st.maxDailyMin ?? (d.off ? 360 : 270);
      if (st.maxDailyMin == null && avgMin > 20) maxDaily = math.min(maxDaily, math.max(90, (avgMin * 1.5 + 30).round()));
      if (burn.active) maxDaily = (maxDaily * 0.7).round();
      cap = math.min(cap, maxDaily - usedByKeep);
      if (d.examToday) cap = math.min(cap, 45);
      if (d.examTomorrow) cap = math.min(cap, 120);
      d.capacity = math.max(0, (cap ~/ 5) * 5);
      d.busyMin = usedByKeep;
    }

    // ───────── مرور به‌موقع (اشتباه‌ها و فصل‌ها) + تکلیف‌ها ─────────
    final reviewMin = List<int>.filled(H, 0);
    final reviewReason = List<String>.filled(H, '');
    final reviewCourse = List<int?>.filled(H, null);
    var backlog = 0;
    final backlogByCourse = <int, int>{};
    for (var i = 0; i < H; i++) {
      final dayEnd = DateTime(days[i].date.year, days[i].date.month, days[i].date.day + 1);
      final dayStart = i == 0 ? DateTime(2000) : days[i].date;
      var chaptersDue = 0;
      for (final m in s.mistakes) {
        if (!m.open) continue;
        final due = m.due ?? now;
        if (due.isBefore(dayEnd) && due.isAfter(dayStart.subtract(const Duration(milliseconds: 1)))) {
          backlog++;
          if (m.courseId != null) backlogByCourse[m.courseId!] = (backlogByCourse[m.courseId!] ?? 0) + 1;
        }
      }
      for (final c in s.chapters) {
        if (!c.done || c.due == null) continue;
        if (c.due!.isBefore(dayEnd) && c.due!.isAfter(dayStart.subtract(const Duration(milliseconds: 1)))) chaptersDue++;
      }
      final cap = days[i].capacity;
      var minutes = (backlog * 1.5 + chaptersDue * 8).round();
      minutes = math.min(minutes, math.min(40, (cap * 0.4).floor()));
      if (days[i].examToday) minutes = 0;
      if (minutes >= 10) {
        final used = (minutes / 1.5).floor();
        reviewMin[i] = (minutes ~/ 5) * 5;
        int? top;
        var tv = 0;
        backlogByCourse.forEach((k, v) {
          if (v > tv) {
            tv = v;
            top = k;
          }
        });
        reviewCourse[i] = backlogByCourse.length == 1 ? top : null;
        reviewReason[i] = 'اشتباه‌های موعدرسیده: ${math.min(used, backlog)} مورد${chaptersDue > 0 ? ' و $chaptersDue فصل برای مرور' : ''}. مرورِ به‌موقع جلوی فراموشی را می‌گیرد (سیستم SM-2).';
        backlog = math.max(0, backlog - used);
        if (backlog == 0) backlogByCourse.clear();
        days[i].capacity = math.max(0, days[i].capacity - reviewMin[i]);
      }
    }

    final taskBlocks = <int, List<SBlock>>{};
    for (final t in s.tasks) {
      if (t.due == null) continue;
      final dl = daysUntil(today, t.due!);
      if (dl > 3 || dl < -7) continue;
      final idx = (dl - 1).clamp(0, H - 1).toInt();
      final dur = t.priority >= 3 ? 35 : 25;
      (taskBlocks[idx] ??= <SBlock>[]).add(SBlock(
        day: days[idx].key,
        startMin: 0,
        durMin: dur,
        kind: 'task',
        courseId: t.courseId,
        refId: t.id,
        title: 'تکلیف: ${t.title}',
        reason: dl <= 0 ? 'مهلتش رسیده یا گذشته؛ زودتر تمامش کن.' : 'تکلیف ${dl == 1 ? 'فردا' : 'تا $dl روز دیگر'} موعد دارد؛ یک روز زودتر بگذار تا شب‌امتحانی نشود.',
      ));
      days[idx].capacity = math.max(0, days[idx].capacity - dur);
    }

    // ───────── تخصیصِ ساعت‌ها بر پایه‌ی سودِ نهایی ─────────
    final courseHasExam = <int>{for (final e in upcoming) if (daysUntil(today, e.at) <= 30) e.courseId};
    double coefMean = 0;
    for (final c in s.courses) {
      coefMean += c.coef;
    }
    coefMean = coefMean / s.courses.length;
    final h = <int, double>{};
    for (final c in s.courses) {
      h[c.id] = Estimators.hoursBefore(s, c.id, now);
    }
    final rejectsByCourse = <int, int>{};
    exec.rejects.forEach((k, v) {
      final cid = int.tryParse(k.split(':').first) ?? 0;
      rejectsByCourse[cid] = (rejectsByCourse[cid] ?? 0) + v;
    });

    double riv(int cid) {
      final g = s.rivalGap[cid];
      if (g == null) return 1.0;
      if (g > 0) return 1 + math.min(0.35, g / 6);
      return 1 - math.min(0.1, -g / 10);
    }

    double refl(int cid) => 1 + 0.4 * (shares[cid]?['dontknow'] ?? 0);

    for (final d in days) {
      var units = d.capacity ~/ _unit;
      if (d.examToday) units = math.min(units, 3);
      while (units > 0) {
        var bestV = 0.0;
        int? bestCourse;
        for (final e in upcoming) {
          final dl = daysUntil(d.date, e.at);
          if (dl < 1 || dl > 30) continue;
          final c = s.course(e.courseId);
          final m = models[e.courseId];
          if (c == null || m == null) continue;
          final w = (c.coef / math.max(0.1, coefMean)) * math.sqrt(math.max(0.5, e.weight));
          var urg = 1 / math.sqrt(dl);
          if (dl <= 3) urg *= 1.5;
          if (dl > 14) urg *= 0.5;
          final ready = e.readiness == null ? 1.0 : (1.15 - (e.readiness!.clamp(0, 5) / 5.0) * 0.5);
          final done = d.minutes[c.id] ?? 0;
          final fat = done >= 120 ? 0.3 : (done >= 90 ? 0.6 : 1.0);
          var v = w * m.marginal(h[c.id] ?? 0) * urg * ready * riv(c.id) * math.pow(0.97, rejectsByCourse[c.id] ?? 0) * fat * refl(c.id);
          if (m.ability >= st.target + 1) v *= 0.6;
          if (v > bestV) {
            bestV = v;
            bestCourse = c.id;
          }
        }
        for (final c in s.courses) {
          if (courseHasExam.contains(c.id)) continue;
          final m = models[c.id];
          if (m == null) continue;
          final gapF = ((st.target - m.ability) / 4).clamp(0.2, 1.2).toDouble();
          final done = d.minutes[c.id] ?? 0;
          final fat = done >= 90 ? 0.4 : 1.0;
          final v = (c.coef / math.max(0.1, coefMean)) * m.marginal(h[c.id] ?? 0) * 0.22 * gapF * riv(c.id) * fat;
          if (v > bestV) {
            bestV = v;
            bestCourse = c.id;
          }
        }
        if (bestCourse == null) break;
        d.minutes[bestCourse] = (d.minutes[bestCourse] ?? 0) + _unit;
        h[bestCourse] = (h[bestCourse] ?? 0) + _unit / 60.0;
        units--;
      }
      // تکه‌های خیلی کوچک را به بزرگ‌ترین درسِ همان روز ببر.
      if (d.minutes.length > 1) {
        int? big;
        var bv = 0;
        d.minutes.forEach((k, v) {
          if (v > bv) {
            bv = v;
            big = k;
          }
        });
        final small = [for (final e in d.minutes.entries) if (e.value < 20 && e.key != big) e.key];
        for (final k in small) {
          d.minutes[big!] = (d.minutes[big!] ?? 0) + (d.minutes[k] ?? 0);
          d.minutes.remove(k);
        }
      }
    }

    // ───────── صفِ فصل‌ها ─────────
    final speedByBook = {for (final b in s.books) b.id: b.pagesPerHour};
    final chapQueue = <int, List<_Chap>>{};
    final chaps = [for (final c in s.chapters) if (!c.done && c.courseId != null) c]..sort((a, b) {
        final k = a.bookId.compareTo(b.bookId);
        if (k != 0) return k;
        return (a.startPage ?? 0).compareTo(b.startPage ?? 0);
      });
    for (final c in chaps) {
      final sp = math.max(6.0, speedByBook[c.bookId] ?? 18.0);
      final mins = math.max(25.0, c.pages / sp * 60.0);
      (chapQueue[c.courseId!] ??= <_Chap>[]).add(_Chap(c, mins));
    }

    // ───────── ساختنِ بلوک‌ها ─────────
    final mockPlaced = <int>{};
    SExam? nearest(int cid, _Day d) {
      SExam? best;
      for (final e in upcoming) {
        if (e.courseId != cid) continue;
        if (daysUntil(d.date, e.at) < 1) continue;
        if (best == null || e.at.isBefore(best.at)) best = e;
      }
      return best;
    }

    String reasonFor(SCourse c, SExam? e, int dl, CourseModel m, double hrs, String phase, String? chap) {
      final parts = <String>[];
      if (e != null) {
        parts.add('$dl روز تا ${e.title.isEmpty ? 'امتحان' : e.title}');
        final pred = m.predict(hrs);
        if (pred < st.target - 0.3) {
          parts.add('با این روند نمره‌ی پیش‌بینی‌شده ${_f1(pred)} است و هدفت ${_f1(st.target)}');
        } else {
          parts.add('پیش‌بینی ${_f1(pred)} است؛ حفظِ این سطح مهم است');
        }
        if (e.scope.trim().isNotEmpty) parts.add('محدوده: ${e.scope.trim()}');
      } else {
        parts.add('درسی که امتحانِ نزدیک ندارد؛ پیشرفتِ پایدارِ آن مهم است');
      }
      final mg = m.marginal(hrs);
      if (mg > 0.05) parts.add('هر ساعتِ دیگر حدود +${_f1(mg)} نمره می‌ارزد');
      final g = s.rivalGap[c.id];
      if (g != null && g > 1) parts.add('رقیبِ برتر در این درس ${_f1(g)} نمره جلوتر است');
      final sh = shares[c.id];
      if (sh != null) {
        String? top;
        var tv = 0.0;
        sh.forEach((k, v) {
          if (v > tv) {
            tv = v;
            top = k;
          }
        });
        const names = {'dontknow': 'ندانستنِ مبحث', 'time': 'کمبودِ وقت', 'careless': 'بی‌دقتی', 'stress': 'استرس', 'scope': 'سؤالِ خارج از محدوده'};
        if (top != null && top != 'good' && tv >= 0.4 && names.containsKey(top)) parts.add('بارِ قبل بیشتر به‌خاطرِ ${names[top]} نمره از دست دادی');
      }
      if (chap != null) parts.add(chap);
      if (phase == 'light') parts.add('شبِ امتحان: فقط مرورِ سبک و خوابِ کافی');
      return '${parts.join('. ')}.';
    }

    final studyBlocks = <int, List<SBlock>>{};
    for (final d in days) {
      final list = <SBlock>[];
      d.minutes.forEach((cid, minutes) {
        final c = s.course(cid);
        final m = models[cid];
        if (c == null || m == null) return;
        final e = nearest(cid, d);
        final dl = e == null ? 99 : daysUntil(d.date, e.at);
        var phase = 'learn';
        if (e != null) {
          if (dl >= 11) {
            phase = 'learn';
          } else if (dl >= 5) {
            phase = 'practice';
          } else if (dl >= 2) {
            phase = 'practice';
          } else {
            phase = 'light';
          }
        }
        var total = minutes;
        if (phase == 'light') total = math.min(total, 30);
        // امتحانِ آزمایشی: یک‌بار در ۲ تا ۴ روزِ مانده
        if (e != null && dl >= 2 && dl <= 4 && !mockPlaced.contains(e.id) && total >= 45) {
          final dur = math.min(60, total);
          mockPlaced.add(e.id);
          list.add(SBlock(
            day: d.key,
            startMin: 0,
            durMin: (dur ~/ 5) * 5,
            kind: 'mock',
            courseId: cid,
            refId: e.id,
            title: 'امتحان آزمایشیِ ${c.name}',
            reason: reasonFor(c, e, dl, m, h[cid] ?? 0, 'mock', 'تمرینِ شرایطِ واقعیِ امتحان با تایمر؛ نمره‌اش وارد پیش‌بینی می‌شود'),
          ));
          total -= dur;
        }
        if (total < 20) return;
        final maxLen = c.difficulty >= 4 ? math.min(st.blockMin, 40) : st.blockMin;
        final n = (total / maxLen).ceil();
        var left = total;
        for (var k = 0; k < n; k++) {
          var dur = (left / (n - k) / 5).round() * 5;
          dur = dur.clamp(20, maxLen).toInt();
          dur = math.min(dur, left);
          if (dur < 15) break;
          left -= dur;
          String? chapNote;
          String title;
          int? ref;
          var kind = phase;
          final sh = shares[cid];
          if (phase == 'practice') {
            final timed = (sh?['time'] ?? 0) >= 0.3;
            final careless = (sh?['careless'] ?? 0) >= 0.3;
            title = timed ? 'تمرینِ زمان‌دارِ ${c.name}' : (careless ? 'تمرین و بازبینیِ ${c.name}' : 'تمرین و حل مسئله‌ی ${c.name}');
          } else if (phase == 'light') {
            title = 'مرورِ سبکِ ${c.name}';
          } else {
            title = 'مطالعه‌ی ${c.name}';
            final q = chapQueue[cid];
            if (q != null && q.isNotEmpty) {
              final cq = q.first;
              title = '${c.name} · ${cq.chapter.title}';
              ref = cq.chapter.id;
              kind = 'learn';
              chapNote = '${cq.chapter.pages} صفحه؛ حدود ${(cq.remainingMin / 60).toStringAsFixed(1)} ساعت مانده تا تمام شود';
              cq.remainingMin -= dur;
              if (cq.remainingMin <= 5) q.removeAt(0);
            }
          }
          list.add(SBlock(
            day: d.key,
            startMin: 0,
            durMin: dur,
            kind: kind,
            courseId: cid,
            refId: ref,
            title: title,
            reason: reasonFor(c, e, dl, m, h[cid] ?? 0, phase, chapNote),
          ));
        }
      });
      studyBlocks[d.index] = list;
    }

    // ───────── جانمایی در ساعت‌های اوج ─────────
    int weight(SBlock b) {
      switch (b.kind) {
        case 'mock':
          return 6;
        case 'learn':
        case 'practice':
          final c = s.course(b.courseId);
          return (c != null && c.difficulty >= 4) ? 5 : 4;
        case 'task':
          return 3;
        case 'review':
          return 2;
        default:
          return 1;
      }
    }

    double scoreAt(int start, int dur) {
      var sum = 0.0, n = 0;
      for (var t = start; t < start + dur; t += 15) {
        sum += hourScore[(t ~/ 60).clamp(0, 23).toInt()];
        n++;
      }
      return n == 0 ? 0 : sum / n;
    }

    final placed = <SBlock>[];
    var overflowMin = <int, int>{};
    for (final d in days) {
      final pending = <SBlock>[
        if (reviewMin[d.index] >= 10)
          SBlock(
            day: d.key,
            startMin: 0,
            durMin: reviewMin[d.index],
            kind: 'review',
            courseId: reviewCourse[d.index],
            title: 'مرورِ اشتباه‌ها و فصل‌ها',
            reason: reviewReason[d.index],
          ),
        ...?taskBlocks[d.index],
        ...?studyBlocks[d.index],
      ]..sort((a, b) => weight(b).compareTo(weight(a)));
      final placedToday = <SBlock>[];
      for (final b in pending) {
        var bestStart = -1;
        var bestScore = -9.0;
        for (final iv in d.free) {
          for (var t = iv[0]; t + b.durMin <= iv[1]; t += 5) {
            var sc = scoreAt(t, b.durMin);
            for (final p in placedToday) {
              if (p.courseId != null && p.courseId == b.courseId && (t - p.endMin).abs() <= 15) sc -= 0.15;
              if ((t + b.durMin - p.startMin).abs() <= 15 && p.courseId == b.courseId && b.courseId != null) sc -= 0.15;
            }
            final rj = exec.rejects['${b.courseId ?? 0}:${t ~/ 60}'] ?? 0;
            sc -= math.min(0.3, rj * 0.1);
            if (sc > bestScore + 0.0001) {
              bestScore = sc;
              bestStart = t;
            }
          }
        }
        if (bestStart < 0) {
          if (b.courseId != null) overflowMin[b.courseId!] = (overflowMin[b.courseId!] ?? 0) + b.durMin;
          continue;
        }
        final gap = b.durMin >= 40 ? 10 : 5;
        d.free = _subtract(d.free, bestStart - gap, bestStart + b.durMin + gap);
        var reason = b.reason;
        if (bestScore >= 0.62 && weight(b) >= 4) {
          final hh = bestStart ~/ 60;
          reason = '$reason این ساعت (حدود $hh) از ساعت‌های اوجِ تمرکزت است.';
        }
        final nb = SBlock(
          day: b.day,
          startMin: bestStart,
          durMin: b.durMin,
          kind: b.kind,
          courseId: b.courseId,
          refId: b.refId,
          title: b.title,
          reason: reason,
        );
        placedToday.add(nb);
        placed.add(nb);
        d.blocks.add(nb);
      }
    }

    // ───────── خرده‌جلسه‌ها (فاصله‌ی بین زنگ‌ها) ─────────
    final dueMist = s.mistakes.where((m) => m.open && (m.due == null || m.due!.isBefore(now.add(const Duration(days: 1))))).length;
    if (s.cardsDue > 0 || dueMist > 0) {
      for (final d in days) {
        if (d.off) continue;
        final wd = (d.date.weekday + 1) % 7;
        final ds = [for (final x in s.slots) if (x.weekday == wd) x]..sort((a, b) => a.startMin.compareTo(b.startMin));
        var count = 0;
        for (var i = 0; i + 1 < ds.length && count < 2; i++) {
          final gap = ds[i + 1].startMin - ds[i].endMin;
          if (gap < 10 || gap > 25) continue;
          final start = ds[i].endMin + 2;
          if (d.index == 0 && start < now.hour * 60 + now.minute) continue;
          placed.add(SBlock(
            day: d.key,
            startMin: start,
            durMin: math.min(15, gap - 4),
            kind: 'micro',
            title: 'مرورِ فوری (فلش‌کارت و اشتباه‌ها)',
            reason: 'فاصله‌ی کوتاهِ بینِ دو زنگ؛ مناسبِ مرورِ سبک است. ${s.cardsDue} فلش‌کارت و $dueMist اشتباه در صف است.',
          ));
          count++;
        }
      }
    }

    // ───────── پیش‌بینی هر امتحان ─────────
    final forecasts = <SExamForecast>[];
    for (final e in upcoming) {
      final dl = daysUntil(today, e.at);
      if (dl > 45) continue;
      final m = models[e.courseId];
      if (m == null) continue;
      var planned = 0.0;
      for (final b in placed) {
        if (b.courseId != e.courseId || b.kind == 'micro' || b.kind == 'review' || b.kind == 'task') continue;
        final bd = dayFromKey(b.day);
        if (bd.isBefore(dateOnly0(e.at))) planned += b.durMin / 60.0;
      }
      for (final b in keep) {
        if (b.courseId != e.courseId || b.status == 'rejected' || b.status == 'skipped') continue;
        if (b.status == 'planned' && !b.locked) continue;
        if (!dayFromKey(b.day).isBefore(dateOnly0(e.at))) continue;
        planned += b.durMin / 60.0;
      }
      final past = Estimators.hoursBefore(s, e.courseId, now);
      final tot = past + planned;
      forecasts.add(SExamForecast(
        examId: e.id,
        courseId: e.courseId,
        mean: m.predict(tot),
        sd: m.sd,
        hoursPlanned: planned,
        hoursTotal: tot,
        hoursNeeded: math.max(0.0, m.hoursFor(st.target) - past),
      ));
    }

    // ───────── هشدارها ─────────
    final byDay = <int, List<SExam>>{};
    for (final e in upcoming) {
      (byDay[dayKey(e.at)] ??= <SExam>[]).add(e);
    }
    byDay.forEach((k, list) {
      if (list.length >= 2 && daysUntil(today, dayFromKey(k)) <= 21) {
        alerts.add(SAlert(
          kind: 'collision',
          title: 'دو امتحان در یک روز',
          body: '${list.map((e) => s.course(e.courseId)?.name ?? '').where((e) => e.isNotEmpty).join(' و ')} در یک روز است؛ فشار را از چند روز قبل پخش کردم و شبِ قبلش را سبک گذاشتم.',
          severity: 3,
        ));
      }
    });
    final sortedE = [for (final e in upcoming) if (daysUntil(today, e.at) <= 21) e];
    for (var i = 0; i + 2 < sortedE.length; i++) {
      if (daysUntil(sortedE[i].at, sortedE[i + 2].at) <= 2 && byDay[dayKey(sortedE[i].at)]!.length == 1) {
        alerts.add(const SAlert(kind: 'collision', title: 'سه امتحان پشت سرِ هم', body: 'در سه روز سه امتحان داری. خوابِ کافی را قربانی نکن؛ برنامه را سبک‌تر و حساب‌شده چیدم.', severity: 2));
        break;
      }
    }
    for (final f in forecasts) {
      final c = s.course(f.courseId);
      if (c == null) continue;
      if (f.mean < st.target - 0.5 && f.hoursNeeded > f.hoursPlanned * 1.15 + 0.5 && f.hoursNeeded < 40) {
        alerts.add(SAlert(
          kind: 'capacity',
          title: 'ظرفیتِ ${c.name} کم است',
          body: 'برای رسیدن به ${_f1(st.target)} در ${c.name} حدود ${f.hoursNeeded.toStringAsFixed(0)} ساعتِ دیگر لازم است ولی در برنامه ${f.hoursPlanned.toStringAsFixed(0)} ساعت جا شد. اولویت‌ها را بازبینی کن.',
          severity: 2,
          courseId: c.id,
        ));
      }
    }
    overflowMin.forEach((cid, m) {
      final c = s.course(cid);
      if (c != null && m >= 30) {
        alerts.add(SAlert(kind: 'capacity', title: 'جا نشد', body: 'حدود $m دقیقه از ${c.name} در این هفته جا نشد.', severity: 1, courseId: cid));
      }
    });
    if (burn.active) alerts.add(SAlert(kind: 'burnout', title: 'نشانه‌ی خستگی', body: burn.message, severity: 2));
    if (exec.lateRate >= 0.4) {
      alerts.add(const SAlert(kind: 'late', title: 'شروع‌کردن سخت است؟', body: 'چند بار بلوکی را دیر شروع کردی یا رد شد. برای هر بلوک دکمه‌ی «فقط ۵ دقیقه» هست؛ شروعِ کوتاه معمولاً کافی است.', severity: 1));
    }
    if (exec.samples >= 6 && exec.overall < 0.6) {
      alerts.add(SAlert(kind: 'realism', title: 'برنامه را واقع‌بینانه‌تر کردم', body: 'حدود ${(exec.overall * 100).round()}٪ از برنامه‌هایت انجام می‌شود؛ ظرفیتِ روزانه را همان‌قدر گرفتم تا خودت را عقب‌افتاده حس نکنی.', severity: 1));
    }
    s.rivalGap.forEach((cid, gap) {
      final m = models[cid];
      final c = s.course(cid);
      if (m == null || c == null || gap <= 1) return;
      final need = m.hoursFor(m.ability + gap) - (h[cid] ?? 0);
      if (need > 0 && need <= 8) {
        alerts.add(SAlert(
          kind: 'rival',
          title: 'فرصتِ رقابتی در ${c.name}',
          body: 'رقیبِ برتر ${_f1(gap)} نمره جلوتر است؛ با حدود ${need.toStringAsFixed(0)} ساعتِ تمرکز می‌توانی فاصله را ببندی. این از بیشتر درس‌ها ارزان‌تر است.',
          severity: 1,
          courseId: cid,
        ));
      }
    });
    shares.forEach((cid, sh) {
      final c = s.course(cid);
      if (c == null) return;
      if ((sh['careless'] ?? 0) >= 0.4) {
        alerts.add(SAlert(kind: 'weak', title: 'بی‌دقتی در ${c.name}', body: 'در تحلیلِ امتحان‌های اخیر بی‌دقتی دلیلِ اصلی بود؛ تمرینِ زمان‌دار و مرورِ اشتباه‌ها را بیشتر کردم.', severity: 1, courseId: cid));
      }
    });
    for (final d in days) {
      if (d.examTomorrow && d.index <= 2) {
        alerts.add(SAlert(kind: 'sleep', title: 'فردا امتحان داری', body: 'برنامه‌ی امشب را تا ۲۱:۳۰ بستم. بدونِ مطلبِ تازه؛ زود بخواب.', severity: 1));
        break;
      }
    }

    // ───────── فشارِ روزها ─────────
    final infos = <SDayInfo>[];
    var meanCoef = coefMean;
    for (final d in days) {
      var p = 0.0;
      for (final e in upcoming) {
        final dl = daysUntil(d.date, e.at);
        if (dl < 0 || dl > 10) continue;
        final c = s.course(e.courseId);
        p += ((c?.coef ?? 1) / math.max(0.1, meanCoef)) * e.weight / (1.0 + dl);
      }
      var planned = 0;
      for (final b in d.blocks) {
        if (b.kind != 'micro') planned += b.durMin;
      }
      p = (p / 3.0 + (d.capacity <= 0 ? 0 : planned / math.max(60, d.capacity + planned)) * 0.3).clamp(0.0, 1.0).toDouble();
      infos.add(SDayInfo(day: d.key, capacityMin: d.capacity + planned, plannedMin: planned, pressure: p, off: d.off));
    }

    placed.sort((a, b) {
      final k = a.day.compareTo(b.day);
      return k != 0 ? k : a.startMin.compareTo(b.startMin);
    });
    // اطلاعِ «بهترین ساعت» برای صفحه‌ی برنامه
    if (bestH >= 6) {
      alerts.add(SAlert(kind: 'golden', title: 'ساعتِ اوجِ تو', body: 'حدودِ ساعتِ $bestH بهترین تمرکزت را داری؛ درس‌های سخت را آنجا گذاشتم.', severity: 0));
    }
    return SPlanResult(blocks: placed, days: infos, alerts: alerts, forecasts: forecasts);
  }
}
