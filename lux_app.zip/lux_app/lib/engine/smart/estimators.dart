import 'dart:math' as math;

import 'models.dart';

/// مدلِ یادگیریِ هر درس: توانِ فعلی، میزانِ پاسخ‌گویی به مطالعه، و بازه‌ی نمره.
class CourseModel {
  final int courseId;
  final double ability; // نمره‌ی توانایی روی ۲۰
  final double responsiveness; // ۱ = معمولی؛ بالاتر یعنی هر ساعت بیشتر می‌ارزد
  final double potential; // بیشینه‌ی بهبودِ شدنی (نمره)
  final double tau; // مقیاسِ ساعت (بازده‌ی نزولی)
  final double sd;
  final int samples; // تعداد نقطه‌های یادگیریِ پاسخ‌گویی
  const CourseModel({
    required this.courseId,
    required this.ability,
    required this.responsiveness,
    required this.potential,
    required this.tau,
    required this.sd,
    required this.samples,
  });

  /// بهبودِ مورد انتظار با h ساعت مطالعه.
  double gain(double h) => potential * responsiveness * (1 - math.exp(-math.max(0, h) / tau));

  /// نمره‌ی پیش‌بینی‌شده با h ساعت.
  double predict(double h) => math.min(20.0, ability + gain(h));

  /// سودِ ساعتِ بعدی وقتی تا حالا h ساعت خوانده‌ای (نمره بر ساعت).
  double marginal(double h) => potential * responsiveness / tau * math.exp(-math.max(0, h) / tau);

  /// چند ساعت (در کل) لازم است تا به نمره‌ی [target] برسی؛ ۴۰ یعنی با این روند شدنی نیست.
  double hoursFor(double target) {
    final need = target - ability;
    if (need <= 0) return 0;
    final cap = potential * responsiveness;
    if (cap <= 0.05 || need >= cap * 0.96) return 40;
    return math.min(40.0, -tau * math.log(1 - need / cap));
  }
}

class ExecStats {
  final double overall;
  final Map<int, double> byCourse;
  final List<double> byHour;
  final Map<String, int> rejects; // "course:hour" → تعداد
  final double lateRate;
  final int samples;
  const ExecStats({required this.overall, required this.byCourse, required this.byHour, required this.rejects, required this.lateRate, required this.samples});
}

class Burnout {
  final bool active;
  final String message;
  const Burnout(this.active, this.message);
}

class Estimators {
  Estimators._();

  static double _decay(DateTime at, DateTime now, double halfLifeDays) {
    final d = now.difference(at).inHours / 24.0;
    return math.pow(0.5, d / halfLifeDays).toDouble();
  }

  static double _mean(List<double> xs) => xs.isEmpty ? double.nan : xs.reduce((a, b) => a + b) / xs.length;

  static double _std(List<double> xs) {
    if (xs.length < 2) return double.nan;
    final m = _mean(xs);
    var s = 0.0;
    for (final x in xs) {
      s += (x - m) * (x - m);
    }
    return math.sqrt(s / xs.length);
  }

  /// ساعتِ مطالعه‌ی یک درس در [days] روزِ پیش از [at].
  static double hoursBefore(SSnapshot s, int courseId, DateTime at, {int days = 14}) {
    final from = at.subtract(Duration(days: days));
    var m = 0.0;
    for (final x in s.sessions) {
      if (x.courseId != courseId) continue;
      if (!x.end.isAfter(from) || x.start.isAfter(at)) continue;
      m += x.minutes;
    }
    return m / 60.0;
  }

  static double overallMean(SSnapshot s) {
    final xs = <double>[];
    final ws = <double>[];
    for (final g in s.grades) {
      xs.add(g.score20);
      ws.add(_decay(g.at, s.now, 90));
    }
    if (xs.isEmpty) return 14.0;
    var a = 0.0, b = 0.0;
    for (var i = 0; i < xs.length; i++) {
      a += xs[i] * ws[i];
      b += ws[i];
    }
    return b <= 0 ? 14.0 : a / b;
  }

  static double _abilityBefore(SSnapshot s, SCourse c, DateTime before, {bool excludeFuture = true}) {
    var a = 0.0, b = 0.0;
    for (final g in s.grades) {
      if (g.courseId != c.id) continue;
      if (excludeFuture && !g.at.isBefore(before)) continue;
      final w = _decay(g.at, before, 60) * (g.isConference ? 0.6 : 1.0);
      a += g.score20 * w;
      b += w;
    }
    for (final m in s.mocks) {
      if (m.courseId != c.id) continue;
      if (excludeFuture && !m.at.isBefore(before)) continue;
      final w = _decay(m.at, before, 45) * 0.5;
      a += m.score20 * w;
      b += w;
    }
    if (b <= 0.0001) return double.nan;
    return a / b;
  }

  static double abilityOf(SSnapshot s, SCourse c) {
    final v = _abilityBefore(s, c, s.now.add(const Duration(days: 1)), excludeFuture: false);
    if (!v.isNaN) return v.clamp(4.0, 20.0).toDouble();
    return (overallMean(s) - (c.difficulty - 3) * 0.6).clamp(8.0, 19.0).toDouble();
  }

  /// مدلِ هر درس را از تاریخچه‌ی نمره و ساعتِ مطالعه می‌سازد.
  static Map<int, CourseModel> courseModels(SSnapshot s) {
    final pairs = <int, List<List<double>>>{}; // courseId → [[h, Δ]]
    final residuals = <int, List<double>>{};
    final all = <List<double>>[];
    for (final e in s.exams) {
      final sc = e.score20;
      if (e.status != 'done' || sc == null) continue;
      final c = s.course(e.courseId);
      if (c == null) continue;
      final prior = _abilityBefore(s, c, e.at);
      if (prior.isNaN) continue;
      final delta = sc - prior;
      (residuals[c.id] ??= <double>[]).add(delta);
      final h = hoursBefore(s, c.id, e.at);
      if (h >= 0.5) {
        (pairs[c.id] ??= <List<double>>[]).add(<double>[h, delta]);
        all.add(<double>[h, delta]);
      }
    }
    double slope(List<List<double>> ps) {
      var a = 0.0, b = 0.0;
      for (final p in ps) {
        a += p[0] * p[1];
        b += p[0] * p[0];
      }
      return b <= 0 ? 0.35 : a / b;
    }

    const prior = 0.35; // نمره بر ساعتِ آغازین
    final globalResp = all.length >= 3 ? (slope(all) / prior).clamp(0.5, 1.8).toDouble() : 1.0;
    final out = <int, CourseModel>{};
    for (final c in s.courses) {
      final ps = pairs[c.id] ?? const <List<double>>[];
      final n = ps.length;
      var resp = globalResp;
      if (n >= 1) {
        final own = (slope(ps) / prior).clamp(0.4, 2.0).toDouble();
        resp = (own * n + globalResp * 3) / (n + 3);
      }
      final ability = abilityOf(s, c);
      final rs = residuals[c.id] ?? const <double>[];
      var sd = 1.8;
      if (rs.length >= 3) {
        final v = _std(rs);
        if (!v.isNaN) sd = v.clamp(1.0, 3.5).toDouble();
      }
      out[c.id] = CourseModel(
        courseId: c.id,
        ability: ability,
        responsiveness: resp,
        potential: math.max(0.6, (20 - ability) * 0.55),
        tau: 5.0 + 1.5 * c.difficulty,
        sd: sd,
        samples: n,
      );
    }
    return out;
  }

  /// امتیازِ هر ساعتِ شبانه‌روز (۰ تا ۱) برای کارهای سنگین؛ از تمرکزِ واقعی‌ات یاد می‌گیرد.
  static List<double> hourScores(SSnapshot s) {
    final prior = List<double>.generate(24, (h) {
      if (h < 7) return 0.15;
      if (h < 10) return 0.55;
      if (h < 14) return 0.5;
      if (h < 16) return 0.55;
      if (h < 19) return 0.7;
      if (h < 21) return 0.62;
      if (h < 22) return 0.45;
      return 0.3;
    });
    final sum = List<double>.filled(24, 0);
    final wsum = List<double>.filled(24, 0);
    for (final x in s.sessions) {
      if (x.minutes < 8) continue;
      final q = ((x.quality ?? 3) / 5.0) * (x.completed ? 1.0 : 0.7);
      var t = x.start;
      while (t.isBefore(x.end)) {
        final nextHour = DateTime(t.year, t.month, t.day, t.hour + 1);
        final segEnd = nextHour.isBefore(x.end) ? nextHour : x.end;
        final m = segEnd.difference(t).inSeconds / 60.0;
        sum[t.hour] += q * m;
        wsum[t.hour] += m;
        t = segEnd;
      }
    }
    const k = 180.0; // ثباتِ پیش‌فرض
    return List<double>.generate(24, (h) {
      final data = wsum[h] > 0 ? sum[h] / wsum[h] : prior[h];
      return ((prior[h] * k + data * wsum[h]) / (k + wsum[h])).clamp(0.0, 1.0).toDouble();
    });
  }

  /// بهترین ساعتِ شروع (اوج تمرکز) را برای نمایش برمی‌گرداند.
  static int bestHour(List<double> scores) {
    var best = 16;
    var bv = -1.0;
    for (var h = 6; h <= 22; h++) {
      final v = (scores[h] + (h + 1 <= 23 ? scores[h + 1] : scores[h])) / 2;
      if (v > bv) {
        bv = v;
        best = h;
      }
    }
    return best;
  }

  static ExecStats execStats(SSnapshot s) {
    final from = s.now.subtract(const Duration(days: 30));
    var done = 0, skipped = 0;
    final cd = <int, List<int>>{}; // [done, skipped]
    final hd = List<List<int>>.generate(24, (_) => <int>[0, 0]);
    final rejects = <String, int>{};
    var lateCount = 0, lateN = 0;
    for (final b in s.history) {
      final day = dayFromKey(b.day);
      if (day.isBefore(from)) continue;
      final hr = (b.startMin ~/ 60).clamp(0, 23).toInt();
      if (b.status == 'done') {
        done++;
        if (b.courseId != null) (cd[b.courseId!] ??= <int>[0, 0])[0]++;
        hd[hr][0]++;
        lateN++;
        if (b.startedAt != null) {
          final planned = DateTime(day.year, day.month, day.day, 0, b.startMin);
          if (b.startedAt!.difference(planned).inMinutes > 20) lateCount++;
        }
      } else if (b.status == 'skipped') {
        skipped++;
        if (b.courseId != null) (cd[b.courseId!] ??= <int>[0, 0])[1]++;
        hd[hr][1]++;
        lateN++;
        lateCount++;
      } else if (b.status == 'rejected') {
        final key = '${b.courseId ?? 0}:$hr';
        rejects[key] = (rejects[key] ?? 0) + 1;
      }
    }
    double rate(int d, int k) => (d + 2.0) / (d + k + 3.0);
    return ExecStats(
      overall: rate(done, skipped),
      byCourse: {for (final e in cd.entries) e.key: rate(e.value[0], e.value[1])},
      byHour: List<double>.generate(24, (h) => rate(hd[h][0], hd[h][1])),
      rejects: rejects,
      lateRate: lateN >= 6 ? lateCount / lateN : 0.0,
      samples: done + skipped,
    );
  }

  static double minutesBetween(SSnapshot s, DateTime a, DateTime b) {
    var m = 0.0;
    for (final x in s.sessions) {
      if (!x.end.isAfter(a) || !x.start.isBefore(b)) continue;
      final st = x.start.isBefore(a) ? a : x.start;
      final en = x.end.isAfter(b) ? b : x.end;
      m += en.difference(st).inSeconds / 60.0;
    }
    return m;
  }

  static double avgQuality(SSnapshot s, DateTime a, DateTime b) {
    var q = 0.0, w = 0.0;
    for (final x in s.sessions) {
      if (x.quality == null || !x.end.isAfter(a) || !x.start.isBefore(b)) continue;
      q += x.quality! * x.minutes;
      w += x.minutes;
    }
    return w <= 0 ? double.nan : q / w;
  }

  /// میانگینِ مطالعه‌ی روزانه (دقیقه) در [days] روزِ گذشته.
  static double avgDailyMinutes(SSnapshot s, {int days = 21}) {
    final end = dateOnly0(s.now);
    final start = end.subtract(Duration(days: days));
    return minutesBetween(s, start, end) / days;
  }

  static Burnout burnout(SSnapshot s) {
    final end = s.now;
    final w1 = end.subtract(const Duration(days: 7));
    final w0 = end.subtract(const Duration(days: 14));
    final m1 = minutesBetween(s, w1, end);
    final m0 = minutesBetween(s, w0, w1);
    final q1 = avgQuality(s, w1, end);
    final q0 = avgQuality(s, w0, w1);
    if (m0 > 120 && m1 > m0 * 1.3 && !q1.isNaN && !q0.isNaN && q1 < q0 - 0.4) {
      return const Burnout(true, 'ساعتِ مطالعه‌ات بالا رفته ولی کیفیتِ تمرکزت پایین آمده؛ نشانه‌ی خستگی است. امروز یک بلوکِ سبک‌تر و یک استراحتِ واقعی بگذار.');
    }
    var lowEnergy = 0;
    for (final j in s.journal) {
      if (j.day.isAfter(end.subtract(const Duration(days: 4))) && j.energy != null && j.energy! <= 2) lowEnergy++;
    }
    if (lowEnergy >= 3) {
      return const Burnout(true, 'چند روزِ پیاپی انرژی‌ات پایین بوده؛ برنامه را سبک‌تر چیدم. خواب و استراحت هم بخشی از آماده‌شدن است.');
    }
    var heavyDays = 0;
    for (var i = 1; i <= 5; i++) {
      final d = dateOnly0(end).subtract(Duration(days: i));
      final m = minutesBetween(s, d, d.add(const Duration(days: 1)));
      final q = avgQuality(s, d, d.add(const Duration(days: 1)));
      if (m > 240 && !q.isNaN && q < 3) heavyDays++;
    }
    if (heavyDays >= 3) {
      return const Burnout(true, 'چند روز بیش از ۴ ساعت خواندی ولی تمرکزت کم بود. کم‌تر و باکیفیت‌تر بخوان.');
    }
    return const Burnout(false, '');
  }

  /// سهمِ هر دلیلِ ازدست‌رفتنِ نمره برای هر درس (از آخرین ۴ تحلیل).
  static Map<int, Map<String, double>> reflectionShares(SSnapshot s) {
    final byCourse = <int, List<SReflection>>{};
    for (final r in s.reflections) {
      if (r.courseId == null) continue;
      (byCourse[r.courseId!] ??= <SReflection>[]).add(r);
    }
    final out = <int, Map<String, double>>{};
    byCourse.forEach((cid, list) {
      list.sort((a, b) => b.at.compareTo(a.at));
      final take = list.take(4);
      final counts = <String, double>{};
      var total = 0.0;
      for (final r in take) {
        for (final x in r.reasons) {
          counts[x] = (counts[x] ?? 0) + 1;
          total += 1;
        }
      }
      if (total > 0) out[cid] = {for (final e in counts.entries) e.key: e.value / total};
    });
    return out;
  }
}
