/// مدل‌های خالصِ «برنامه‌ی هوشمند» (بدون وابستگی به Flutter و پایگاه‌داده).

int dayKey(DateTime d) => d.year * 10000 + d.month * 100 + d.day;

DateTime dayFromKey(int k) => DateTime(k ~/ 10000, (k ~/ 100) % 100, k % 100);

DateTime dateOnly0(DateTime d) => DateTime(d.year, d.month, d.day);

class SCourse {
  final int id;
  final String name;
  final double coef;
  final int difficulty;
  final double maxScore;
  final double finalShare;
  final int? colorValue;
  const SCourse({
    required this.id,
    required this.name,
    required this.coef,
    required this.difficulty,
    required this.maxScore,
    required this.finalShare,
    this.colorValue,
  });
}

class SExam {
  final int id;
  final int courseId;
  final DateTime at;
  final double weight;
  final double maxScore;
  final int difficulty;
  final int? readiness;
  final String title;
  final String scope;
  final String status; // planned | done | canceled
  final double? score;
  final bool isFinal;
  const SExam({
    required this.id,
    required this.courseId,
    required this.at,
    required this.weight,
    required this.maxScore,
    required this.difficulty,
    required this.title,
    required this.scope,
    required this.status,
    this.readiness,
    this.score,
    this.isFinal = false,
  });

  double? get score20 => score == null || maxScore <= 0 ? null : score! / maxScore * 20;
}

class SGrade {
  final int courseId;
  final int? examId;
  final double score20;
  final double weight;
  final DateTime at;
  final bool isFinal;
  final bool isConference;
  const SGrade({
    required this.courseId,
    required this.score20,
    required this.weight,
    required this.at,
    required this.isFinal,
    required this.isConference,
    this.examId,
  });
}

/// یک بازه‌ی مطالعه‌ی واقعی (پومودورو، آزاد، یا خواندنِ کتاب).
class SSession {
  final int? courseId;
  final DateTime start;
  final DateTime end;
  final int? quality; // ۱ تا ۵
  final bool completed;
  const SSession({this.courseId, required this.start, required this.end, this.quality, this.completed = true});

  double get minutes => end.difference(start).inSeconds / 60.0;
}

class SBook {
  final int id;
  final int? courseId;
  final String title;
  final int pages;
  final int lastPage;
  final double pagesPerHour; // سرعتِ خواندنِ تو در این کتاب
  const SBook({
    required this.id,
    required this.courseId,
    required this.title,
    required this.pages,
    required this.lastPage,
    required this.pagesPerHour,
  });
}

class SChapter {
  final int id;
  final int bookId;
  final int? courseId;
  final String title;
  final int? startPage;
  final int? endPage;
  final bool done;
  final DateTime? due;
  final double ef;
  final int reps;
  const SChapter({
    required this.id,
    required this.bookId,
    required this.courseId,
    required this.title,
    required this.done,
    required this.ef,
    required this.reps,
    this.startPage,
    this.endPage,
    this.due,
  });

  int get pages => (startPage != null && endPage != null && endPage! >= startPage!) ? endPage! - startPage! + 1 : 12;
}

class SMistake {
  final int id;
  final int? courseId;
  final int? bookId;
  final int? page;
  final String cause;
  final bool open;
  final DateTime? due;
  const SMistake({required this.id, this.courseId, this.bookId, this.page, required this.cause, required this.open, this.due});
}

class SSlot {
  final int weekday; // شنبه = ۰
  final int startMin;
  final int endMin;
  final int? courseId;
  const SSlot({required this.weekday, required this.startMin, required this.endMin, this.courseId});
}

class STask {
  final int id;
  final int? courseId;
  final String title;
  final DateTime? due;
  final int priority;
  const STask({required this.id, this.courseId, required this.title, this.due, required this.priority});
}

class SJournal {
  final DateTime day;
  final int? mood;
  final int? energy;
  final double? sleepH;
  const SJournal({required this.day, this.mood, this.energy, this.sleepH});
}

/// دلیل‌های ازدست‌رفتنِ نمره پس از هر امتحان.
class SReflection {
  final int? examId;
  final int? courseId;
  final Set<String> reasons;
  final DateTime at;
  const SReflection({this.examId, this.courseId, required this.reasons, required this.at});
}

class SMock {
  final int? courseId;
  final DateTime at;
  final double score20;
  const SMock({this.courseId, required this.at, required this.score20});
}

class SBlock {
  final int id; // ۰ = هنوز ذخیره نشده
  final int day; // yyyymmdd
  final int startMin;
  final int durMin;
  final String kind; // learn | practice | mock | light | review | task | micro | cards | chapter
  final int? courseId;
  final int? refId;
  final String title;
  final String reason;
  final String status; // planned | done | skipped | rejected
  final bool locked;
  final DateTime? startedAt;
  final DateTime? doneAt;
  const SBlock({
    this.id = 0,
    required this.day,
    required this.startMin,
    required this.durMin,
    required this.kind,
    this.courseId,
    this.refId,
    required this.title,
    this.reason = '',
    this.status = 'planned',
    this.locked = false,
    this.startedAt,
    this.doneAt,
  });

  int get endMin => startMin + durMin;

  SBlock copyWith({int? id, int? startMin, int? durMin, String? status, bool? locked, String? reason, String? title}) => SBlock(
        id: id ?? this.id,
        day: day,
        startMin: startMin ?? this.startMin,
        durMin: durMin ?? this.durMin,
        kind: kind,
        courseId: courseId,
        refId: refId,
        title: title ?? this.title,
        reason: reason ?? this.reason,
        status: status ?? this.status,
        locked: locked ?? this.locked,
        startedAt: startedAt,
        doneAt: doneAt,
      );
}

class SSettings {
  double target; // معدلِ هدف
  int schoolEndMin; // پایانِ مدرسه (روزهای عادی)
  int restAfterSchoolMin;
  int bedMin; // پایانِ پنجره‌ی مطالعه
  int offStartMin; // شروعِ پنجره‌ی روزهای تعطیل
  int? maxDailyMin; // اگر کاربر تعیین کرده
  int blockMin; // طولِ دلخواهِ هر بلوک
  int horizonDays;
  SSettings({
    this.target = 18,
    this.schoolEndMin = 14 * 60,
    this.restAfterSchoolMin = 60,
    this.bedMin = 22 * 60 + 30,
    this.offStartMin = 9 * 60,
    this.maxDailyMin,
    this.blockMin = 45,
    this.horizonDays = 7,
  });
}

/// همه‌ی داده‌هایی که موتور لازم دارد.
class SSnapshot {
  final DateTime now;
  final SSettings settings;
  final List<SCourse> courses;
  final List<SExam> exams;
  final List<SGrade> grades;
  final List<SSession> sessions;
  final List<SBook> books;
  final List<SChapter> chapters;
  final List<SMistake> mistakes;
  final List<SSlot> slots;
  final List<STask> tasks;
  final List<SJournal> journal;
  final List<SReflection> reflections;
  final List<SMock> mocks;
  final List<SBlock> history; // بلوک‌های ۶۰ روزِ اخیر (انجام/ردشده/لغو)
  final Set<int> offDays; // dayKey روزهای تعطیل (جمعه و تعطیلات رسمی)
  final Map<int, List<List<int>>> events; // dayKey → [[startMin,endMin]]
  final Map<int, double> rivalGap; // courseId → (بهترین رقیب − من) روی ۲۰
  final int cardsDue;
  final Map<int, double> behavior; // اثرِ مثبت/منفی هر درس (روی ۲۰)
  final Map<int, double> contOverride; // مستمرِ اعلام‌شده از معلم (روی ۲۰)
  const SSnapshot({
    required this.now,
    required this.settings,
    required this.courses,
    required this.exams,
    required this.grades,
    required this.sessions,
    required this.books,
    required this.chapters,
    required this.mistakes,
    required this.slots,
    required this.tasks,
    required this.journal,
    required this.reflections,
    required this.mocks,
    required this.history,
    required this.offDays,
    required this.events,
    required this.rivalGap,
    required this.cardsDue,
    this.behavior = const <int, double>{},
    this.contOverride = const <int, double>{},
  });

  SCourse? course(int? id) {
    for (final c in courses) {
      if (c.id == id) return c;
    }
    return null;
  }
}

// ───────── خروجی‌ها ─────────

class SAlert {
  final String kind; // collision | capacity | burnout | late | rival | realism | weak | sleep
  final String title;
  final String body;
  final int severity; // ۱ اطلاع، ۲ هشدار، ۳ جدی
  final int? courseId;
  const SAlert({required this.kind, required this.title, required this.body, this.severity = 1, this.courseId});
}

class SDayInfo {
  final int day;
  final int capacityMin;
  final int plannedMin;
  final double pressure; // ۰ تا ۱
  final bool off;
  const SDayInfo({required this.day, required this.capacityMin, required this.plannedMin, required this.pressure, required this.off});
}

class SExamForecast {
  final int examId;
  final int courseId;
  final double mean; // روی ۲۰
  final double sd;
  final double hoursPlanned;
  final double hoursTotal; // ساعتِ خوانده‌شده + برنامه‌ریزی‌شده
  final double hoursNeeded; // برای رسیدن به هدف
  const SExamForecast({
    required this.examId,
    required this.courseId,
    required this.mean,
    required this.sd,
    required this.hoursPlanned,
    required this.hoursTotal,
    required this.hoursNeeded,
  });
}

class SPlanResult {
  final List<SBlock> blocks;
  final List<SDayInfo> days;
  final List<SAlert> alerts;
  final List<SExamForecast> forecasts;
  const SPlanResult({required this.blocks, required this.days, required this.alerts, required this.forecasts});
}
