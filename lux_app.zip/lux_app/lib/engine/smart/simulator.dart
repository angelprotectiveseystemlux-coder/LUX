import 'dart:math' as math;

import '../grades.dart';
import 'estimators.dart';
import 'models.dart';

class SimResult {
  final double mean;
  final double p10;
  final double p50;
  final double p90;
  final double pTarget; // احتمالِ رسیدنِ معدل به هدف
  final Map<int, double> courseMean; // میانگینِ نمره‌ی کلِ هر درس
  final Map<int, double> courseP; // احتمالِ رسیدنِ هر درس به هدف
  final int runs;
  const SimResult({
    required this.mean,
    required this.p10,
    required this.p50,
    required this.p90,
    required this.pTarget,
    required this.courseMean,
    required this.courseP,
    required this.runs,
  });
}

/// شبیه‌سازیِ مونت‌کارلو: نمره‌ی هر امتحانِ پیش‌رو را تصادفی نمونه می‌گیرد و معدلِ نهایی را حساب می‌کند.
class Simulator {
  Simulator._();

  static double _normal(math.Random r) {
    final u1 = math.max(1e-9, r.nextDouble());
    final u2 = r.nextDouble();
    return math.sqrt(-2 * math.log(u1)) * math.cos(2 * math.pi * u2);
  }

  /// [extraHours] ساعتِ اضافه برای هر درس پیش از نزدیک‌ترین امتحانش.
  static SimResult run(
    SSnapshot s,
    List<SExamForecast> forecasts, {
    int runs = 1200,
    int seed = 7,
    Map<int, double> extraHours = const <int, double>{},
  }) {
    final models = Estimators.courseModels(s);
    final rnd = math.Random(seed);
    final target = s.settings.target;
    final examById = {for (final e in s.exams) e.id: e};

    // نزدیک‌ترین امتحانِ هر درس برای اعمالِ ساعتِ اضافه
    final nearest = <int, int>{};
    final byTime = [...forecasts]..sort((a, b) {
        final ea = examById[a.examId]?.at ?? DateTime(2100);
        final eb = examById[b.examId]?.at ?? DateTime(2100);
        return ea.compareTo(eb);
      });
    for (final f in byTime) {
      nearest.putIfAbsent(f.courseId, () => f.examId);
    }

    final means = <int, double>{};
    for (final f in forecasts) {
      final m = models[f.courseId];
      if (m == null) continue;
      final extra = nearest[f.courseId] == f.examId ? (extraHours[f.courseId] ?? 0.0) : 0.0;
      means[f.examId] = m.predict(f.hoursTotal + extra);
    }

    final gpas = <double>[];
    final courseSums = <int, double>{};
    final courseHits = <int, int>{};
    final courseN = <int, int>{};
    var hits = 0;

    for (var r = 0; r < runs; r++) {
      var numer = 0.0, den = 0.0;
      for (final c in s.courses) {
        final cont = <WeightedScore>[];
        final fin = <WeightedScore>[];
        for (final g in s.grades) {
          if (g.courseId != c.id) continue;
          (g.isFinal ? fin : cont).add(WeightedScore(g.score20, 20, g.weight));
        }
        if (s.contOverride.containsKey(c.id)) {
          cont
            ..clear()
            ..add(WeightedScore(s.contOverride[c.id]!, 20, 1));
        }
        for (final f in forecasts) {
          if (f.courseId != c.id) continue;
          final e = examById[f.examId];
          final mu = means[f.examId];
          if (e == null || mu == null) continue;
          final v = (mu + _normal(rnd) * f.sd).clamp(0.0, 20.0).toDouble();
          (e.isFinal ? fin : cont).add(WeightedScore(v, 20, e.weight));
        }
        final t = TermMath.compute(
          continuous: cont,
          finals: fin,
          behavior: s.behavior[c.id] ?? 0,
          finalShare: c.finalShare / 100,
          scale: 20,
        ).total;
        if (t == null) continue;
        numer += t * c.coef;
        den += c.coef;
        courseSums[c.id] = (courseSums[c.id] ?? 0) + t;
        courseN[c.id] = (courseN[c.id] ?? 0) + 1;
        if (t >= target) courseHits[c.id] = (courseHits[c.id] ?? 0) + 1;
      }
      if (den > 0) {
        final g = numer / den;
        gpas.add(g);
        if (g >= target) hits++;
      }
    }
    if (gpas.isEmpty) {
      return const SimResult(mean: 0, p10: 0, p50: 0, p90: 0, pTarget: 0, courseMean: <int, double>{}, courseP: <int, double>{}, runs: 0);
    }
    gpas.sort();
    double q(double p) => gpas[((gpas.length - 1) * p).round().clamp(0, gpas.length - 1).toInt()];
    var sum = 0.0;
    for (final g in gpas) {
      sum += g;
    }
    return SimResult(
      mean: sum / gpas.length,
      p10: q(0.10),
      p50: q(0.50),
      p90: q(0.90),
      pTarget: hits / gpas.length,
      courseMean: {for (final e in courseSums.entries) e.key: e.value / (courseN[e.key] ?? 1)},
      courseP: {for (final e in courseN.entries) e.key: (courseHits[e.key] ?? 0) / e.value},
      runs: gpas.length,
    );
  }
}
