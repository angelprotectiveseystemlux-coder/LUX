import 'dart:math' as math;

/// ابزارهای آماری خالص (بدون وابستگی به Flutter) — قابل آزمون.
class Stats {
  Stats._();

  static double mean(List<double> xs) {
    if (xs.isEmpty) return double.nan;
    var s = 0.0;
    for (final x in xs) {
      s += x;
    }
    return s / xs.length;
  }

  /// انحراف معیار جامعه (population)
  static double stdDev(List<double> xs) {
    if (xs.isEmpty) return double.nan;
    final m = mean(xs);
    var s = 0.0;
    for (final x in xs) {
      s += (x - m) * (x - m);
    }
    return math.sqrt(s / xs.length);
  }

  /// z-score؛ اگر انحراف صفر باشد صفر برمی‌گردد.
  static double zScore(double x, List<double> xs) {
    final sd = stdDev(xs);
    if (sd.isNaN || sd == 0) return 0;
    return (x - mean(xs)) / sd;
  }

  /// میانگین متحرک ساده با پنجره‌ی [window]
  static List<double> movingAverage(List<double> xs, int window) {
    if (window < 1) window = 1;
    final out = <double>[];
    for (var i = 0; i < xs.length; i++) {
      final from = math.max(0, i - window + 1);
      var s = 0.0;
      for (var j = from; j <= i; j++) {
        s += xs[j];
      }
      out.add(s / (i - from + 1));
    }
    return out;
  }

  /// رگرسیون خطی کمترین مربعات روی (x, y)
  static LinearFit? linearFit(List<double> xs, List<double> ys) {
    final n = math.min(xs.length, ys.length);
    if (n < 2) return null;
    final mx = mean(xs.sublist(0, n));
    final my = mean(ys.sublist(0, n));
    var sxx = 0.0, sxy = 0.0, syy = 0.0;
    for (var i = 0; i < n; i++) {
      final dx = xs[i] - mx;
      final dy = ys[i] - my;
      sxx += dx * dx;
      sxy += dx * dy;
      syy += dy * dy;
    }
    if (sxx == 0) return null;
    final slope = sxy / sxx;
    final intercept = my - slope * mx;
    final r2 = syy == 0 ? 1.0 : (sxy * sxy) / (sxx * syy);
    return LinearFit(slope, intercept, r2);
  }

  /// ضریب همبستگی پیرسون؛ اگر داده کم یا واریانس صفر باشد null.
  static double? pearson(List<double> xs, List<double> ys) {
    final n = math.min(xs.length, ys.length);
    if (n < 3) return null;
    final mx = mean(xs.sublist(0, n));
    final my = mean(ys.sublist(0, n));
    var sxx = 0.0, syy = 0.0, sxy = 0.0;
    for (var i = 0; i < n; i++) {
      final dx = xs[i] - mx;
      final dy = ys[i] - my;
      sxx += dx * dx;
      syy += dy * dy;
      sxy += dx * dy;
    }
    if (sxx == 0 || syy == 0) return null;
    return sxy / math.sqrt(sxx * syy);
  }

  /// میانگین خطای مطلق بین آمادگیِ اعلام‌شده (۱ تا ۱۰) و نتیجه‌ی واقعی (نسبتِ نمره به حداکثر).
  /// هر دو به بازه‌ی ۰ تا ۱ نرمال می‌شوند. مقدار کمتر = پیش‌بینیِ دقیق‌تر.
  static double? calibrationError(List<CalibrationPair> pairs) {
    if (pairs.isEmpty) return null;
    var s = 0.0;
    for (final p in pairs) {
      final pred = (p.readiness / 10.0).clamp(0.0, 1.0);
      final real = p.max <= 0 ? 0.0 : (p.score / p.max).clamp(0.0, 1.0);
      s += (pred - real).abs();
    }
    return s / pairs.length;
  }
}

class LinearFit {
  final double slope;
  final double intercept;
  final double r2;
  const LinearFit(this.slope, this.intercept, this.r2);
  double predict(double x) => slope * x + intercept;
}

class CalibrationPair {
  final double readiness; // ۱..۱۰
  final double score;
  final double max;
  const CalibrationPair(this.readiness, this.score, this.max);
}
