/// محاسبات رقابت — خالص و بدون وابستگی به UI.
///
/// همه‌ی نمره‌ها روی مقیاس ۲۰ برده می‌شوند تا امتحان‌هایی با بیشینه‌ی متفاوت قابل مقایسه باشند.
/// «من» با شناسه‌ی [RivalryCalc.me] (صفر) مشخص می‌شود؛ رقبا شناسه‌ی مثبتِ پایگاه‌داده را دارند.
class RivalExam {
  final int id;
  final int courseId;
  final String courseName;
  final String title;
  final DateTime at;
  final double max;
  final double weight;

  /// نمره‌ی خودِ کاربر (خام)؛ null اگر ثبت نشده
  final double? mine;

  /// رقیب → نمره‌ی خام (فقط رقبایی که نمره‌شان ثبت شده)
  final Map<int, double> rivals;

  /// آیتمِ «کنفرانس» (نه امتحان)
  final bool isConference;

  const RivalExam({
    required this.id,
    required this.courseId,
    required this.courseName,
    required this.title,
    required this.at,
    required this.max,
    required this.weight,
    required this.mine,
    required this.rivals,
    this.isConference = false,
  });

  double? raw(int person) => person == RivalryCalc.me ? mine : rivals[person];

  /// نمره روی مقیاس ۲۰ یا null
  double? norm(int person) {
    final r = raw(person);
    if (r == null || max <= 0) return null;
    return r / max * 20;
  }
}

class RivalryCalc {
  RivalryCalc._();

  static const int me = 0;

  /// فقط امتحان‌هایی که همه‌ی [persons] در آن نمره دارند.
  static List<RivalExam> common(List<RivalExam> exams, Iterable<int> persons) {
    final ps = persons.toList();
    return <RivalExam>[
      for (final e in exams)
        if (ps.every((p) => e.norm(p) != null)) e,
    ];
  }

  static double _w(double w) => w <= 0 ? 1.0 : w;

  static double? _weighted(Iterable<RivalExam> exams, int person) {
    var s = 0.0, w = 0.0;
    for (final e in exams) {
      final v = e.norm(person);
      if (v == null) continue;
      final wt = _w(e.weight);
      s += v * wt;
      w += wt;
    }
    return w == 0 ? null : s / w;
  }

  /// اثرِ مثبت و منفی: {شخص: {درس: اثر روی مقیاس ۲۰}}. فقط وقتی اعمال می‌شود که آن نفر در آن درس نمره دارد.
  static double? _courseAvg(Iterable<RivalExam> list, int courseId, int person, Map<int, Map<int, double>>? behavior) {
    final a = _weighted(list, person);
    if (a == null) return null;
    final v = a + (behavior?[person]?[courseId] ?? 0);
    return v < 0 ? 0.0 : (v > 20 ? 20.0 : v);
  }

  /// میانگینِ وزنی (وزنِ امتحان) یک نفر در یک درس (با اثرِ مثبت و منفی)
  static double? courseAverage(List<RivalExam> exams, int courseId, int person, {Map<int, Map<int, double>>? behavior}) =>
      _courseAvg(exams.where((e) => e.courseId == courseId), courseId, person, behavior);

  /// نمره‌ی هر امتحانِ یک درس برای یک نفر (null = ثبت نشده)
  static List<double?> courseSeries(List<RivalExam> examsOfCourse, int person) =>
      <double?>[for (final e in examsOfCourse) e.norm(person)];

  /// «سطح کلی» با اولین [count] امتحان: میانگینِ هر درس، سپس میانگینِ ضریب‌دارِ درس‌ها
  /// (همان منطقِ معدلِ برنامه). [coef] ضریب هر درس است؛ اگر نبود ۱.
  static double? overallUpTo(
    List<RivalExam> exams,
    int count,
    int person,
    Map<int, double> coef, {
    Map<int, Map<int, double>>? behavior,
  }) {
    final by = <int, List<RivalExam>>{};
    for (var i = 0; i < count && i < exams.length; i++) {
      by.putIfAbsent(exams[i].courseId, () => <RivalExam>[]).add(exams[i]);
    }
    var s = 0.0, w = 0.0;
    by.forEach((cid, list) {
      final a = _courseAvg(list, cid, person, behavior);
      if (a == null) return;
      final c = _w(coef[cid] ?? 1);
      s += a * c;
      w += c;
    });
    return w == 0 ? null : s / w;
  }

  static double? overall(List<RivalExam> exams, int person, Map<int, double> coef, {Map<int, Map<int, double>>? behavior}) =>
      overallUpTo(exams, exams.length, person, coef, behavior: behavior);

  /// سطح کلی پس از هر امتحان (قبل از اولین نمره‌ی آن نفر null است).
  static List<double?> overallSeries(List<RivalExam> exams, int person, Map<int, double> coef, {Map<int, Map<int, double>>? behavior}) =>
      <double?>[
        // کنفرانس امتحان نیست؛ در میانگین می‌آید ولی برای خودش «گام» نمی‌سازد.
        for (var i = 1; i <= exams.length; i++)
          if (!exams[i - 1].isConference) overallUpTo(exams, i, person, coef, behavior: behavior),
      ];

  /// چند امتحان برای این نفر نمره دارد
  static int count(List<RivalExam> exams, int person) => exams.where((e) => !e.isConference && e.norm(person) != null).length;
}
