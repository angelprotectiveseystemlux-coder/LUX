/// وقتی انیمیشن ورود یا صفحه‌ی قفل روی برنامه است، پیام‌های خودکار (مثل پرسشِ غیبت) باید صبر کنند.
class AppGate {
  AppGate._();
  static bool blocked = true;
}
