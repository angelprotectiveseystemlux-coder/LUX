import 'package:flutter/widgets.dart';

/// قواعدِ سادهٔ چیدمانِ واکنش‌گرا (چرخش صفحه و صفحه‌های بزرگ).
class LuxLayout {
  /// گوشی در حالت افقی یا صفحه‌ی عریض (تبلت): نوار ناوبری می‌رود کنارِ صفحه.
  static bool isWide(BuildContext context) {
    final s = MediaQuery.sizeOf(context);
    return (s.width > s.height && s.width >= 520) || s.width >= 700;
  }

  /// بیشینه‌ی عرضِ محتوا تا خطوط متن بیش‌ازحد کشیده نشوند.
  static const double maxContentWidth = 1100;
  static const double maxFormWidth = 720;
  static const double railWidth = 92;
}
