import 'jalali_utils.dart';

int asInt(Object? v, [int fallback = 0]) {
  if (v is int) return v;
  if (v is num) return v.toInt();
  if (v is String) return int.tryParse(v) ?? fallback;
  return fallback;
}

double asDouble(Object? v, [double fallback = 0]) {
  if (v is num) return v.toDouble();
  if (v is String) return double.tryParse(v) ?? fallback;
  return fallback;
}

String asStr(Object? v, [String fallback = '']) => v == null ? fallback : v.toString();

/// عددِ تایپ‌شده (با ارقام فارسی یا لاتین، «٫» یا «.») را به double تبدیل می‌کند.
double? parseNum(String s) {
  final t = enDigits(s.trim()).replaceAll('٫', '.').replaceAll(',', '.').replaceAll('،', '.');
  if (t.isEmpty) return null;
  return double.tryParse(t);
}

DateTime fromTs(Object? ts) => DateTime.fromMillisecondsSinceEpoch(asInt(ts));

int toTs(DateTime d) => d.millisecondsSinceEpoch;

String clockLabel(DateTime d) => '${faDigits(two(d.hour))}:${faDigits(two(d.minute))}';

String minutesLabel(int minutesOfDay) =>
    '${faDigits(two(minutesOfDay ~/ 60))}:${faDigits(two(minutesOfDay % 60))}';

/// «۳ روز دیگر» / «امروز» / «دیروز» / «۲ روز پیش»
String relativeDay(DateTime d) {
  final n = daysBetween(DateTime.now(), d);
  if (n == 0) return 'امروز';
  if (n == 1) return 'فردا';
  if (n == -1) return 'دیروز';
  if (n > 0) return '${faDigits(n)} روز دیگر';
  return '${faDigits(-n)} روز پیش';
}
