import 'dart:ui' show PlatformDispatcher;
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import '../data/database.dart';
import 'palette.dart';

/// تنظیمات ظاهری برنامه: تم، حالت روشن/تیره، اندازه‌ی متن و انیمیشن ورود.
class AppTheme extends ChangeNotifier {
  AppTheme._();
  static final AppTheme instance = AppTheme._();

  static const List<double> textScales = <double>[0.9, 1.0, 1.12];
  static const List<String> textScaleNames = <String>['کوچک', 'متوسط', 'بزرگ'];

  int themeIndex = 0;
  int mode = 2; // 0 روشن، 1 خودکار (مثل سیستم)، 2 تیره
  int textScaleIndex = 1;
  bool splash = true;
  Brightness _system = Brightness.dark;

  double get textScale => textScales[textScaleIndex.clamp(0, textScales.length - 1)];

  Brightness get brightness => mode == 0 ? Brightness.light : (mode == 2 ? Brightness.dark : _system);

  /// با عوض‌شدنِ این کلید، کلِ برنامه با رنگ‌های تازه ساخته می‌شود.
  String get key => '$themeIndex-${brightness == Brightness.dark ? 'd' : 'l'}-$textScaleIndex';

  LuxThemeDef get theme => LuxThemes.all[themeIndex.clamp(0, LuxThemes.all.length - 1)];

  Future<void> load() async {
    final db = LuxDb.instance;
    themeIndex = (int.tryParse(await db.kvGet('ui_theme') ?? '') ?? 0).clamp(0, LuxThemes.all.length - 1);
    mode = (int.tryParse(await db.kvGet('ui_mode') ?? '') ?? 2).clamp(0, 2);
    textScaleIndex = (int.tryParse(await db.kvGet('ui_text') ?? '') ?? 1).clamp(0, textScales.length - 1);
    splash = (await db.kvGet('ui_splash') ?? '1') == '1';
    _system = PlatformDispatcher.instance.platformBrightness;
    _apply();
  }

  void _apply() {
    LuxColors.current = theme.of(brightness);
  }

  Future<void> setTheme(int i) async {
    themeIndex = i.clamp(0, LuxThemes.all.length - 1);
    await LuxDb.instance.kvSet('ui_theme', themeIndex.toString());
    _apply();
    notifyListeners();
  }

  Future<void> setMode(int m) async {
    mode = m.clamp(0, 2);
    await LuxDb.instance.kvSet('ui_mode', mode.toString());
    _apply();
    notifyListeners();
  }

  Future<void> setTextScale(int i) async {
    textScaleIndex = i.clamp(0, textScales.length - 1);
    await LuxDb.instance.kvSet('ui_text', textScaleIndex.toString());
    notifyListeners();
  }

  Future<void> setSplash(bool v) async {
    splash = v;
    await LuxDb.instance.kvSet('ui_splash', v ? '1' : '0');
    notifyListeners();
  }

  /// وقتی سیستم بین روشن و تیره عوض شد (فقط در حالت «خودکار» اثر دارد)
  void systemChanged(Brightness b) {
    if (_system == b) return;
    _system = b;
    if (mode == 1) {
      _apply();
      notifyListeners();
    }
  }
}
