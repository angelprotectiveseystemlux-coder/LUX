import 'dart:convert';
import 'dart:io';

import 'package:path_provider/path_provider.dart';

import '../data/backup.dart';
import 'server.dart';

/// حسابِ آنلاینِ کاربر: نشست، شناسه، کلید پیوند با JSON، و رویدادهای استفاده.
class Account {
  Account._();

  static bool get enforced => ServerApi.configured;

  static String? token;
  static int? uid;
  static String? id;
  static String? link;
  static bool consent = false;
  static int lastPush = 0;
  static bool _loaded = false;
  static final List<Map<String, Object>> _queue = <Map<String, Object>>[];

  static Future<File> _file() async {
    final d = await getApplicationSupportDirectory();
    return File('${d.path}/lux_account.json');
  }

  static Future<void> _load() async {
    if (_loaded) return;
    _loaded = true;
    try {
      final f = await _file();
      if (await f.exists()) {
        final m = jsonDecode(await f.readAsString()) as Map<String, dynamic>;
        token = m['token'] as String?;
        uid = m['uid'] as int?;
        id = m['id'] as String?;
        link = m['link'] as String?;
        consent = m['consent'] == true;
        lastPush = (m['lastPush'] as int?) ?? 0;
      }
    } catch (_) {}
  }

  static Future<void> _save() async {
    try {
      final f = await _file();
      await f.writeAsString(jsonEncode({'token': token, 'uid': uid, 'id': id, 'link': link, 'consent': consent, 'lastPush': lastPush}));
    } catch (_) {}
  }

  static Future<void> logout() async {
    await _load();
    token = null;
    uid = null;
    id = null;
    link = null;
    consent = false;
    lastPush = 0;
    await _save();
  }

  static Future<bool> hasSession() async {
    await _load();
    return token != null;
  }

  static Future<bool> needsConsent() async {
    await _load();
    return token != null && !consent;
  }

  static Future<void> _adopt(Map<String, dynamic> m) async {
    token = m['token'] as String?;
    uid = m['uid'] as int?;
    id = m['id'] as String?;
    link = m['link'] as String?;
    consent = m['consent'] == true;
    await _save();
  }

  static Future<bool> idAvailable(String i) async {
    final r = await ServerApi.post('/auth/check', {'id': i});
    return r['available'] == true;
  }

  static Future<void> register(String i, String pw) async => _adopt(await ServerApi.post('/auth/register', {'id': i, 'password': pw}));

  static Future<void> login(String i, String pw) async => _adopt(await ServerApi.post('/auth/login', {'id': i, 'password': pw}));

  /// true = این فایل مالِ یک حسابِ آنلاین بود و وارد شد.
  static Future<bool> jsonLogin(String linkKey) async {
    final r = await ServerApi.post('/auth/json-login', {'link': linkKey});
    if (r['found'] == true) {
      await _adopt(r);
      return true;
    }
    return false;
  }

  static Future<Map<String, dynamic>> forgot(String i, String contact) => ServerApi.post('/auth/forgot', {'id': i, 'contact': contact});

  static Future<String> forgotStatus(int rid, String poll) async {
    final r = await ServerApi.post('/auth/forgot/status', {'request_id': rid, 'poll_key': poll});
    return (r['status'] ?? 'pending').toString();
  }

  static Future<void> reset(int rid, String poll, String pw) async => _adopt(await ServerApi.post('/auth/reset', {'request_id': rid, 'poll_key': poll, 'password': pw}));

  /// پذیرفتنِ متنِ حریم خصوصی؛ فقط یک‌بار.
  static Future<void> acceptConsent() async {
    await _load();
    consent = true;
    await _save();
    try {
      await ServerApi.post('/me/consent', <String, Object>{}, token: token);
    } catch (_) {
      // بعداً دوباره تلاش می‌شود؛ محلی ثبت شده و متن دوباره نمایش داده نمی‌شود
    }
  }

  // ───── پشتیبانِ آنلاین ─────

  static Future<void> pushSnapshot() async {
    await _load();
    if (token == null) return;
    try {
      final text = await Backup.exportJson();
      await ServerApi.request('POST', '/sync/snapshot', rawBody: text, token: token);
      lastPush = DateTime.now().millisecondsSinceEpoch ~/ 1000;
      await _save();
    } catch (_) {}
  }

  static Future<void> maybePush() async {
    await _load();
    if (token == null) return;
    final now = DateTime.now().millisecondsSinceEpoch ~/ 1000;
    if (now - lastPush > 6 * 3600) await pushSnapshot();
  }

  /// آخرین پشتیبانِ سرور؛ null اگر نبود.
  static Future<String?> pullSnapshot() async {
    await _load();
    if (token == null) return null;
    try {
      final r = await ServerApi.get('/sync/snapshot', token: token);
      if (r['found'] == true) return r['data'] as String?;
    } catch (_) {}
    return null;
  }

  // ───── رویدادهای استفاده ─────

  static void track(String kind, [String detail = '']) {
    _queue.add(<String, Object>{'kind': kind, 'detail': detail, 'at': DateTime.now().millisecondsSinceEpoch ~/ 1000});
    if (_queue.length >= 30) flush();
  }

  static Future<void> flush() async {
    await _load();
    if (token == null || _queue.isEmpty) return;
    final items = List<Map<String, Object>>.from(_queue);
    _queue.clear();
    try {
      await ServerApi.post('/events', {'items': items}, token: token);
    } catch (_) {
      _queue.insertAll(0, items.take(200));
    }
  }
}
