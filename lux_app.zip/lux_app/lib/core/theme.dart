import 'package:flutter/material.dart';
import 'palette.dart';

class LuxMotion {
  LuxMotion._();
  static const Duration fast = Duration(milliseconds: 160);
  static const Duration medium = Duration(milliseconds: 280);
  static const Duration slow = Duration(milliseconds: 520);
  static const Curve curve = Curves.easeOutCubic;
}

class LuxText {
  LuxText._();

  /// فونت اصلی: Estedad (در صورت نبودن، Vazirmatn، بعد فونت سیستم)
  static const String fontText = 'Estedad';
  static const List<String> fontFallback = <String>['Vazirmatn'];

  /// عنوان‌های بزرگِ صفحه‌ها
  static const String fontDisplay = 'Lalezar';

  /// امضای لاتین (By Pishva System)
  static const String fontCredit = 'Michroma';
  static const String fontDot = 'LuxDot';

  static const TextStyle title = TextStyle(
      fontFamily: fontText, fontFamilyFallback: fontFallback, fontSize: 20, fontWeight: FontWeight.w700, color: LuxColors.text, height: 1.4);
  /// عنوان بزرگ هر صفحه
  static const TextStyle display = TextStyle(
      fontFamily: fontDisplay, fontFamilyFallback: fontFallback, fontSize: 30, fontWeight: FontWeight.w400, color: LuxColors.text, height: 1.3);
  static const TextStyle heading = TextStyle(
      fontFamily: fontText, fontFamilyFallback: fontFallback, fontSize: 16, fontWeight: FontWeight.w600, color: LuxColors.text, height: 1.4);
  static const TextStyle body = TextStyle(
      fontFamily: fontText, fontFamilyFallback: fontFallback, fontSize: 14, fontWeight: FontWeight.w400, color: LuxColors.text, height: 1.6);
  static const TextStyle caption = TextStyle(
      fontFamily: fontText, fontFamilyFallback: fontFallback, fontSize: 12, fontWeight: FontWeight.w400, color: LuxColors.textDim, height: 1.5);
  static const TextStyle label = TextStyle(
      fontFamily: fontText, fontFamilyFallback: fontFallback, fontSize: 13, fontWeight: FontWeight.w600, color: LuxColors.silver, height: 1.4);

  /// عدد بزرگ نقطه‌ای (لاتین). اگر فونت نقطه‌ای در دسترس نبود، به مونواسپیس برمی‌گردد.
  static TextStyle dot(double size, {Color color = LuxColors.text}) => TextStyle(
        fontFamily: fontDot,
        fontFamilyFallback: const <String>['monospace'],
        fontSize: size,
        color: color,
        height: 1.0,
        letterSpacing: 2,
        fontWeight: FontWeight.w400,
      );
}

class LuxTheme {
  LuxTheme._();

  static ThemeData dark() {
    const scheme = ColorScheme.dark(
      primary: LuxColors.accent,
      onPrimary: LuxColors.onAccent,
      secondary: LuxColors.silver,
      surface: LuxColors.card,
      onSurface: LuxColors.text,
      error: LuxColors.danger,
    );
    final base = ThemeData(brightness: Brightness.dark, useMaterial3: true);
    return base.copyWith(
      colorScheme: scheme,
      scaffoldBackgroundColor: LuxColors.bg,
      splashFactory: NoSplash.splashFactory,
      highlightColor: Colors.transparent,
      dividerColor: LuxColors.stroke,
      textTheme: base.textTheme.apply(
        fontFamily: LuxText.fontText,
        fontFamilyFallback: LuxText.fontFallback,
        bodyColor: LuxColors.text,
        displayColor: LuxColors.text,
      ),
      pageTransitionsTheme: const PageTransitionsTheme(builders: {
        TargetPlatform.android: FadeUpwardsPageTransitionsBuilder(),
        TargetPlatform.iOS: FadeUpwardsPageTransitionsBuilder(),
      }),
      snackBarTheme: SnackBarThemeData(
        backgroundColor: LuxColors.cardHi,
        contentTextStyle: LuxText.body,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      ),
      bottomSheetTheme: const BottomSheetThemeData(
        backgroundColor: LuxColors.card,
        modalBackgroundColor: LuxColors.card,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(28))),
      ),
    );
  }
}

/// ظاهر فیلدهای ورودی (به‌جای InputDecorationTheme که بین نسخه‌های Flutter تغییر کرده)
class LuxInput {
  LuxInput._();

  static InputDecoration decoration(String hint) {
    OutlineInputBorder border(Color c, double w) => OutlineInputBorder(
          borderRadius: BorderRadius.circular(18),
          borderSide: w == 0 ? BorderSide.none : BorderSide(color: c, width: w),
        );
    return InputDecoration(
      hintText: hint,
      filled: true,
      fillColor: LuxColors.cardHi,
      contentPadding: const EdgeInsets.symmetric(horizontal: 18, vertical: 16),
      hintStyle: LuxText.body.copyWith(color: LuxColors.textDim),
      border: border(LuxColors.stroke, 0),
      enabledBorder: border(LuxColors.stroke, 0),
      focusedBorder: border(LuxColors.accent, 1.4),
    );
  }
}
