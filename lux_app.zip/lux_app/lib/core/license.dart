import 'dart:convert';
import 'dart:io';
import 'dart:math';
import 'dart:typed_data';

import 'package:ed25519_edwards/ed25519_edwards.dart' as ed;
import 'package:path_provider/path_provider.dart';

/// کلید عمومیِ فعال‌سازی (Base64). از ابزار ساخت کد بردار و اینجا بگذار.
/// تا وقتی این مقدار عوض نشده، قفلِ فعال‌سازی خاموش است (برای تست).
const String kLicensePublicKey = 'NFQjqNCa5jsRC0OAh4aXoUwkKeEEnJs3UKofYC4frkw=';

class License {
  License._();

  static const _alphabet = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  static String? _id;
  static String? _code;
  static bool _loaded = false;

  static bool get enforced => kLicensePublicKey != 'PASTE_PUBLIC_KEY_HERE';

  static Future<File> _file() async {
    final d = await getApplicationSupportDirectory();
    return File('${d.path}/lux_lic.json');
  }

  static Future<void> _load() async {
    if (_loaded) return;
    _loaded = true;
    try {
      final f = await _file();
      if (await f.exists()) {
        final m = jsonDecode(await f.readAsString()) as Map<String, dynamic>;
        _id = m['id'] as String?;
        _code = m['code'] as String?;
      }
    } catch (_) {}
    if (_id == null || _id!.length != 12) {
      final r = Random.secure();
      _id = List.generate(12, (_) => _alphabet[r.nextInt(_alphabet.length)]).join();
      await _save();
    }
  }

  static Future<void> _save() async {
    try {
      final f = await _file();
      await f.writeAsString(jsonEncode({'id': _id, 'code': _code}));
    } catch (_) {}
  }

  /// کدِ دستگاه، مثل K7F2-9QXA-M3LP
  static Future<String> deviceCode() async {
    await _load();
    final s = _id!;
    return '${s.substring(0, 4)}-${s.substring(4, 8)}-${s.substring(8, 12)}';
  }

  static int _today() => DateTime.now().toUtc().millisecondsSinceEpoch ~/ 86400000;

  /// null = معتبر؛ در غیر این صورت پیامِ خطا (فارسی).
  static String? _check(String id, String code) {
    try {
      final clean = code.replaceAll(RegExp(r'\s'), '');
      var b = clean.replaceAll('-', '+').replaceAll('_', '/');
      while (b.length % 4 != 0) {
        b += '=';
      }
      final raw = base64Decode(b);
      if (raw.length != 68) return 'کد کامل نیست؛ دوباره کپی کن.';
      final exp = ByteData.sublistView(Uint8List.fromList(raw.sublist(0, 4))).getUint32(0, Endian.big);
      final sig = Uint8List.fromList(raw.sublist(4));
      final pk = ed.PublicKey(base64Decode(kLicensePublicKey));
      final msg = Uint8List.fromList(utf8.encode('LUX1|$id|$exp'));
      if (!ed.verify(pk, msg, sig)) return 'این کد برای این گوشی نیست.';
      if (exp != 0 && _today() > exp) return 'مدتِ این کد تمام شده.';
      return null;
    } catch (_) {
      return 'کد درست نیست.';
    }
  }

  static Future<bool> isValid() async {
    if (!enforced) return true;
    await _load();
    if (_code == null) return false;
    return _check(_id!, _code!) == null;
  }

  /// null = موفق؛ وگرنه پیامِ خطا.
  static Future<String?> activate(String code) async {
    await _load();
    if (!enforced) return null;
    final err = _check(_id!, code);
    if (err != null) return err;
    _code = code.replaceAll(RegExp(r'\s'), '');
    await _save();
    return null;
  }
}
