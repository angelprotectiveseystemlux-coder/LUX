import 'package:shamsi_date/shamsi_date.dart';

const List<String> jalaliMonths = <String>[
  'فروردین', 'اردیبهشت', 'خرداد', 'تیر', 'مرداد', 'شهریور',
  'مهر', 'آبان', 'آذر', 'دی', 'بهمن', 'اسفند',
];

/// شنبه = ۰ ... جمعه = ۶
const List<String> jalaliWeekdays = <String>[
  'شنبه', 'یکشنبه', 'دوشنبه', 'سه‌شنبه', 'چهارشنبه', 'پنجشنبه', 'جمعه',
];

const List<String> _faDigits = <String>['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];

/// هر عددِ لاتین داخل متن را به رقم فارسی تبدیل می‌کند.
String faDigits(Object? v) {
  final s = (v ?? '').toString();
  final b = StringBuffer();
  for (final r in s.runes) {
    final c = String.fromCharCode(r);
    final d = int.tryParse(c);
    b.write(d != null ? _faDigits[d] : c);
  }
  return b.toString();
}

/// رقم فارسی/عربی را به لاتین برمی‌گرداند (برای parse).
String enDigits(String s) {
  final b = StringBuffer();
  for (final r in s.runes) {
    if (r >= 0x06F0 && r <= 0x06F9) {
      b.write(r - 0x06F0);
    } else if (r >= 0x0660 && r <= 0x0669) {
      b.write(r - 0x0660);
    } else {
      b.writeCharCode(r);
    }
  }
  return b.toString();
}

/// عدد با حداکثر [dec] رقم اعشار؛ بدون صفرهای زائد؛ ارقام فارسی و جداکننده‌ی «٫».
String fmtNum(double v, {int dec = 1}) {
  if (v.isNaN || v.isInfinite) return '—';
  var s = v.toStringAsFixed(dec);
  if (s.contains('.')) {
    s = s.replaceFirst(RegExp(r'0+$'), '');
    s = s.replaceFirst(RegExp(r'\.$'), '');
  }
  return faDigits(s.replaceAll('.', '٫'));
}

Jalali toJalali(DateTime d) => Jalali.fromDateTime(d);

/// «۱۸ مهر ۱۴۰۵»
String jalaliLabel(DateTime d) {
  final j = toJalali(d);
  return '${faDigits(j.day)} ${jalaliMonths[j.month - 1]} ${faDigits(j.year)}';
}

/// «شنبه ۱۸ مهر»
String jalaliLabelWithDay(DateTime d) {
  final j = toJalali(d);
  return '${weekdayIndex(d) >= 0 ? jalaliWeekdays[weekdayIndex(d)] : ''} ${faDigits(j.day)} ${jalaliMonths[j.month - 1]}';
}

/// شنبه = ۰ ... جمعه = ۶  (DateTime.weekday: دوشنبه=۱ ... یکشنبه=۷)
int weekdayIndex(DateTime d) => (d.weekday + 1) % 7;

DateTime dateOnly(DateTime d) => DateTime(d.year, d.month, d.day);

/// تعداد روزِ ماهِ شمسی
int jalaliMonthLength(int year, int month) => Jalali(year, month, 1).monthLength;

/// فاصله‌ی تقویمی (روز) از [from] تا [to]
int daysBetween(DateTime from, DateTime to) =>
    dateOnly(to).difference(dateOnly(from)).inDays;

String two(int n) => n.toString().padLeft(2, '0');

/// عدد لاتینِ کوتاه‌شده (برای فونت نقطه‌ای که ارقام فارسی ندارد)
String latinNum(double v, {int dec = 2}) {
  var s = v.toStringAsFixed(dec);
  if (s.contains('.')) {
    s = s.replaceFirst(RegExp(r'0+$'), '');
    s = s.replaceFirst(RegExp(r'\.$'), '');
  }
  return s;
}
