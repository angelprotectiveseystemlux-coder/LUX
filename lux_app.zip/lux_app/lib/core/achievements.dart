import 'dart:async';
import 'dart:convert';

import 'package:flutter/material.dart';

import '../data/calendar_repo.dart';
import '../data/database.dart';
import 'app_bus.dart';

enum AchTier { none, bronze, silver, gold }

class AchDef {
  final String key;
  final String title;
  final String unit;
  final IconData icon;
  final List<int> targets; // برنزی، نقره‌ای، طلایی
  const AchDef(this.key, this.title, this.unit, this.icon, this.targets);
}

const List<AchDef> kAchDefs = <AchDef>[
  AchDef('visit_streak', 'هر روز سر می‌زنم', 'روز پشت‌سرهم', Icons.local_fire_department_rounded, [3, 7, 30]),
  AchDef('journal_streak', 'گزارشِ هر روز', 'روزِ گزارش پشت‌سرهم', Icons.edit_note_rounded, [3, 7, 30]),
  AchDef('attend_streak', 'حضورِ به‌موقع', 'حضورِ پشت‌سرهم', Icons.alarm_on_rounded, [5, 15, 40]),
  AchDef('perfect20', 'بیستی‌ها', 'نمره‌ی کامل', Icons.workspace_premium_rounded, [1, 5, 15]),
  AchDef('consec20', 'بیستِ پشت‌سرهم', 'بیستِ پشت‌سرهم', Icons.bolt_rounded, [2, 3, 5]),
  AchDef('high_scores', 'نمره‌ی بالا', 'نمره‌ی ۱۷ به بالا', Icons.trending_up_rounded, [1, 10, 30]),
  AchDef('good_streak', 'بدونِ افت', 'نمره‌ی خوبِ پشت‌سرهم', Icons.shield_rounded, [3, 5, 10]),
  AchDef('class_top', 'اولِ کلاس', 'آزمون با بالاترین نمره', Icons.emoji_events_rounded, [1, 5, 15]),
  AchDef('beat_main', 'شکستِ رقیبِ اصلی', 'برد از رقیبِ اصلی', Icons.sports_martial_arts_rounded, [1, 5, 15]),
  AchDef('progress', 'پیشرفت', 'بازه‌ی پیشرفت (۳ روز، هفته، ماه)', Icons.show_chart_rounded, [1, 2, 3]),
];

const List<int> kTierPoints = <int>[0, 10, 25, 60];
const List<String> kTierNames = <String>['قفل', 'برنزی', 'نقره‌ای', 'طلایی'];
const List<int> kRankXp = <int>[0, 20, 50, 100, 180, 300, 480, 720];
const List<String> kRankNames = <String>['تازه‌وارد', 'کوشا', 'پیگیر', 'درخشان', 'ستاره', 'استاد', 'افسانه', 'لوکس'];

Color achTierColor(int tier) {
  switch (tier) {
    case 1:
      return const Color(0xFFCD7F32);
    case 2:
      return const Color(0xFFC0C8D4);
    case 3:
      return const Color(0xFFFFC53D);
    default:
      return const Color(0xFF6B7380);
  }
}

class AchState {
  final AchDef def;
  final int value;
  final int tier; // ۰ تا ۳
  const AchState(this.def, this.value, this.tier);
  int? get nextTarget => tier >= 3 ? null : def.targets[tier];
}

class AchSummary {
  final List<AchState> items;
  final int xp;
  final int rank; // ایندکسِ رتبه
  final int visitStreakNow;
  const AchSummary(this.items, this.xp, this.rank, this.visitStreakNow);

  int get rankStart => kRankXp[rank];
  int? get rankEnd => rank + 1 < kRankXp.length ? kRankXp[rank + 1] : null;
  double get rankProgress {
    final e = rankEnd;
    if (e == null) return 1;
    return ((xp - rankStart) / (e - rankStart)).clamp(0.0, 1.0).toDouble();
  }
}

class AchEvent {
  final String title;
  final String sub;
  final IconData icon;
  final int tier;
  final bool big;
  const AchEvent(this.title, this.sub, this.icon, this.tier, {this.big = false});
}

class Achievements {
  Achievements._();

  static final ValueNotifier<AchSummary?> summary = ValueNotifier<AchSummary?>(null);
  static final ValueNotifier<List<AchEvent>> events = ValueNotifier<List<AchEvent>>(<AchEvent>[]);
  static Timer? _debounce;
  static bool _busy = false;

  static bool _inited = false;

  static void init() {
    if (_inited) {
      unawaited(recordVisit().then((_) => evaluate()));
      return;
    }
    _inited = true;
    AppBus.data.addListener(() {
      _debounce?.cancel();
      _debounce = Timer(const Duration(milliseconds: 1500), () => evaluate());
    });
    unawaited(recordVisit().then((_) => evaluate()));
  }

  static void dismissFirst() {
    final l = List<AchEvent>.from(events.value);
    if (l.isNotEmpty) l.removeAt(0);
    events.value = l;
  }

  static double _d(Object? v) => v is num ? v.toDouble() : 0.0;

  static DateTime _day(String s) {
    final d = CalendarRepo.parseKey(s);
    return DateTime.utc(d.year, d.month, d.day);
  }

  static Future<void> recordVisit() async {
    final db = LuxDb.instance;
    List<String> days = <String>[];
    try {
      days = (jsonDecode(await db.kvGet('visit_days') ?? '[]') as List).cast<String>();
    } catch (_) {}
    final today = CalendarRepo.key(DateTime.now());
    if (!days.contains(today)) {
      days.add(today);
      days.sort();
      if (days.length > 500) days = days.sublist(days.length - 500);
      await db.kvSet('visit_days', jsonEncode(days));
    }
  }

  /// طولانی‌ترین رشته‌ی روزهای متوالی، و رشته‌ی جاری (تا امروز یا دیروز).
  static (int best, int current) _dayStreaks(List<String> keys) {
    final ds = keys.map(_day).toSet().toList()..sort();
    var best = 0, run = 0;
    DateTime? prev;
    for (final d in ds) {
      run = (prev != null && d.difference(prev).inDays == 1) ? run + 1 : 1;
      if (run > best) best = run;
      prev = d;
    }
    var cur = 0;
    if (ds.isNotEmpty) {
      final t = DateTime.now();
      final today = DateTime.utc(t.year, t.month, t.day);
      final gap = today.difference(ds.last).inDays;
      if (gap <= 1) cur = run;
    }
    return (best, cur);
  }

  static int _bestRun(List<bool> flags) {
    var best = 0, run = 0;
    for (final f in flags) {
      run = f ? run + 1 : 0;
      if (run > best) best = run;
    }
    return best;
  }

  static Future<AchSummary> evaluate() async {
    final db = LuxDb.instance;
    final m = <String, int>{};

    // نمره‌ها
    final gRows = await db.rawQuery('SELECT score, max_score, at_ts FROM grades ORDER BY at_ts ASC');
    final fr = <double>[];
    final ts = <int>[];
    for (final r in gRows) {
      final mx = _d(r['max_score']);
      if (mx <= 0) continue;
      fr.add(_d(r['score']) / mx);
      ts.add((r['at_ts'] as num?)?.toInt() ?? 0);
    }
    m['perfect20'] = fr.where((f) => f >= 0.9999).length;
    m['consec20'] = _bestRun(fr.map((f) => f >= 0.9999).toList());
    m['high_scores'] = fr.where((f) => f >= 0.85).length;
    m['good_streak'] = _bestRun(fr.map((f) => f >= 0.85).toList());

    // پیشرفت در بازه‌های ۳ روز، هفته و ماه
    var windows = 0;
    for (final n in const [3, 7, 30]) {
      final span = n * 86400000;
      var ok = false;
      for (var i = 0; i < ts.length && !ok; i++) {
        final t = ts[i];
        final cur = <double>[], prev = <double>[];
        for (var j = 0; j < ts.length; j++) {
          if (ts[j] > t - span && ts[j] <= t) {
            cur.add(fr[j]);
          } else if (ts[j] > t - 2 * span && ts[j] <= t - span) {
            prev.add(fr[j]);
          }
        }
        if (cur.isNotEmpty && prev.isNotEmpty) {
          final a = cur.reduce((x, y) => x + y) / cur.length;
          final b = prev.reduce((x, y) => x + y) / prev.length;
          if (a > b) ok = true;
        }
      }
      if (ok) windows++;
    }
    m['progress'] = windows;

    // رقبا
    final uRows = await db.rawQuery(
        'SELECT g.exam_id AS eid, g.score AS s, g.max_score AS mx FROM grades g WHERE g.exam_id IS NOT NULL AND g.max_score > 0');
    final user = <int, double>{};
    for (final r in uRows) {
      final id = (r['eid'] as num).toInt();
      final f = _d(r['s']) / _d(r['mx']);
      if (!user.containsKey(id) || f > user[id]!) user[id] = f;
    }
    final rRows = await db.rawQuery(
        'SELECT rs.rival_id AS rid, rs.exam_id AS eid, rs.score AS s, e.max_score AS em FROM rival_scores rs JOIN exams e ON e.id = rs.exam_id WHERE e.max_score > 0');
    final byExam = <int, Map<int, double>>{};
    final sums = <int, double>{};
    final cnts = <int, int>{};
    for (final r in rRows) {
      final rid = (r['rid'] as num).toInt();
      final eid = (r['eid'] as num).toInt();
      final f = _d(r['s']) / _d(r['em']);
      (byExam[eid] ??= <int, double>{})[rid] = f;
      sums[rid] = (sums[rid] ?? 0) + f;
      cnts[rid] = (cnts[rid] ?? 0) + 1;
    }
    var top = 0;
    user.forEach((eid, f) {
      final rv = byExam[eid];
      if (rv != null && rv.isNotEmpty && f > rv.values.reduce((a, b) => a > b ? a : b)) top++;
    });
    m['class_top'] = top;
    int? mainRival;
    var bestAvg = -1.0;
    sums.forEach((rid, s) {
      final avg = s / cnts[rid]!;
      if (avg > bestAvg || (avg == bestAvg && (mainRival == null || rid < mainRival!))) {
        bestAvg = avg;
        mainRival = rid;
      }
    });
    var beat = 0;
    if (mainRival != null) {
      user.forEach((eid, f) {
        final rf = byExam[eid]?[mainRival!];
        if (rf != null && f > rf) beat++;
      });
    }
    m['beat_main'] = beat;

    // حضور
    final aRows = await db.rawQuery("SELECT kind FROM attendance ORDER BY day ASC");
    final flags = <bool>[];
    for (final r in aRows) {
      final k = (r['kind'] ?? '').toString();
      if (k == 'holiday') continue;
      flags.add(k == 'present');
    }
    m['attend_streak'] = _bestRun(flags);

    // گزارش روزانه (دفترچه)
    final jRows = await db.rawQuery("SELECT day FROM journal WHERE text IS NOT NULL AND TRIM(text) != ''");
    m['journal_streak'] = _dayStreaks(jRows.map((r) => (r['day'] ?? '').toString()).toList()).$1;

    // سرزدن
    List<String> visits = <String>[];
    try {
      visits = (jsonDecode(await db.kvGet('visit_days') ?? '[]') as List).cast<String>();
    } catch (_) {}
    final vs = _dayStreaks(visits);
    m['visit_streak'] = vs.$1;

    // ساختنِ وضعیت
    final items = <AchState>[];
    var xp = visits.length * 2;
    for (final d in kAchDefs) {
      final v = m[d.key] ?? 0;
      var tier = 0;
      for (final t in d.targets) {
        if (v >= t) tier++;
      }
      xp += kTierPoints[tier] + (tier >= 2 ? kTierPoints[tier - 1] : 0) + (tier >= 3 ? kTierPoints[1] : 0);
      items.add(AchState(d, v, tier));
    }
    var rank = 0;
    for (var i = 0; i < kRankXp.length; i++) {
      if (xp >= kRankXp[i]) rank = i;
    }
    final sum = AchSummary(items, xp, rank, vs.$2);
    summary.value = sum;

    // جایزه‌های تازه
    if (_busy) return sum;
    _busy = true;
    try {
      final have = (await db.rawQuery('SELECT key FROM achievements')).map((r) => r['key'].toString()).toSet();
      final firstRun = (await db.kvGet('ach_init')) == null;
      final fresh = <AchEvent>[];
      var count = 0;
      for (final s in items) {
        for (var t = 1; t <= s.tier; t++) {
          final k = '${s.def.key}:$t';
          if (have.contains(k)) continue;
          count++;
          await db.insert('achievements', <String, Object?>{'key': k, 'unlocked_at': DateTime.now().millisecondsSinceEpoch});
          fresh.add(AchEvent('${s.def.title} · ${kTierNames[t]}', '${s.def.targets[t - 1]} ${s.def.unit}', s.def.icon, t));
        }
      }
      final oldRank = int.tryParse(await db.kvGet('ach_rank') ?? '') ?? -1;
      await db.kvSet('ach_rank', '$rank');
      final out = <AchEvent>[];
      if (firstRun) {
        await db.kvSet('ach_init', '1');
        if (count > 0) {
          out.add(AchEvent('تاریخچه‌ی افتخاراتت', '$count نشان از قبل داشتی. رتبه‌ات: ${kRankNames[rank]}', Icons.auto_awesome_rounded, 3, big: true));
        }
      } else {
        if (oldRank >= 0 && rank > oldRank) {
          out.add(AchEvent('ارتقا به «${kRankNames[rank]}»', 'امتیاز: $xp', Icons.military_tech_rounded, 3, big: true));
        }
        out.addAll(fresh);
      }
      if (out.isNotEmpty) events.value = <AchEvent>[...events.value, ...out];
    } finally {
      _busy = false;
    }
    return sum;
  }
}
