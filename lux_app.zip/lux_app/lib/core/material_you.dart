import 'package:flutter/material.dart';
import 'palette.dart';

/// تمِ «متریال» به سبک گوگل (Material You): پالت از یک رنگِ پایه ساخته می‌شود.
/// رنگِ پایه می‌تواند از والپیپرِ گوشی بیاید یا دلخواه باشد.
class MaterialYou {
  MaterialYou._();

  static const String id = 'material';
  static const Color googleBlue = Color(0xFF0B57D0);

  static const List<String> variantNames = <String>['متعادل', 'پرجنب‌وجوش', 'بیانگر', 'خنثی', 'تک‌رنگ'];
  static const List<DynamicSchemeVariant> variants = <DynamicSchemeVariant>[
    DynamicSchemeVariant.tonalSpot,
    DynamicSchemeVariant.vibrant,
    DynamicSchemeVariant.expressive,
    DynamicSchemeVariant.neutral,
    DynamicSchemeVariant.monochrome,
  ];

  static const List<String> contrastNames = <String>['عادی', 'متوسط', 'زیاد'];
  static const List<double> contrasts = <double>[0.0, 0.5, 1.0];

  static const List<String> roundNames = <String>['کم', 'ملایم', 'استاندارد', 'گرد', 'خیلی گرد'];
  static const List<double> rounds = <double>[0.45, 0.75, 1.0, 1.2, 1.4];

  static const List<String> cardNames = <String>['نرم', 'نازک', 'خط‌دار'];

  static const List<Color> swatches = <Color>[
    Color(0xFF0B57D0),
    Color(0xFF006A6A),
    Color(0xFF146C2E),
    Color(0xFF5B6300),
    Color(0xFF8D5000),
    Color(0xFFB3261E),
    Color(0xFF984061),
    Color(0xFF6750A4),
    Color(0xFF4355B9),
    Color(0xFF00677F),
    Color(0xFF7D5260),
    Color(0xFF6D5E0F),
    Color(0xFF3F6837),
    Color(0xFFA1402D),
    Color(0xFF5C5F72),
    Color(0xFF8A4FFF),
  ];

  static LuxPalette build({
    required Color seed,
    required Brightness brightness,
    int variant = 0,
    int contrast = 0,
    int round = 2,
    int card = 0,
    bool amoled = false,
  }) {
    final s = ColorScheme.fromSeed(
      seedColor: seed,
      brightness: brightness,
      dynamicSchemeVariant: variants[variant.clamp(0, variants.length - 1)],
      contrastLevel: contrasts[contrast.clamp(0, contrasts.length - 1)],
    );
    final dark = brightness == Brightness.dark;
    final black = dark && amoled;
    final c = card.clamp(0, 2);
    return LuxPalette(
      brightness: brightness,
      bg: black ? const Color(0xFF000000) : s.surface,
      bgSoft: black ? const Color(0xFF090909) : s.surfaceContainerLow,
      card: black ? const Color(0xFF121212) : s.surfaceContainer,
      cardHi: black ? const Color(0xFF1D1D1D) : s.surfaceContainerHigh,
      stroke: c == 2 ? s.outline : s.outlineVariant,
      accent: s.primary,
      accentDim: s.primaryContainer,
      onAccent: s.onPrimary,
      silver: s.onSurfaceVariant,
      silverDim: s.outline,
      text: s.onSurface,
      textDim: s.onSurfaceVariant,
      warn: dark ? const Color(0xFFFFC857) : const Color(0xFF8A5A00),
      danger: s.error,
      ok: dark ? const Color(0xFF7ADB9A) : const Color(0xFF1B7A3E),
      radiusScale: rounds[round.clamp(0, rounds.length - 1)],
      strokeWidth: c == 2 ? 1.4 : 1.0,
      strokeAlpha: c == 0 ? 0.0 : (c == 1 ? 0.45 : 1.0),
      hardShadow: false,
    );
  }
}
