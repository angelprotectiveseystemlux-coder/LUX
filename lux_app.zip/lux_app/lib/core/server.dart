import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:path_provider/path_provider.dart';

class ApiError implements Exception {
  final String code;
  final String message;
  ApiError(this.code, this.message);
  @override
  String toString() => message;
}

/// ارتباط با سرور Railway. آدرس سرور از یک فایل ثابتِ گیت‌هاب خوانده می‌شود
/// تا با عوض شدنِ حساب Railway فقط همان فایل عوض شود.
class ServerApi {
  ServerApi._();

  /// لینکِ خامِ فایل server_address.json در مخزن، مثلاً:
  /// https://raw.githubusercontent.com/USER/REPO/main/server_address.json
  static const String kServerListUrl = 'PASTE_RAW_GITHUB_URL_OF_server_address.json';

  /// آدرس اولیه‌ی سرور (اختیاری؛ اگر فایل بالا کار نکرد).
  static const String kDefaultServer = 'PASTE_SERVER_URL';

  static bool get configured => !kServerListUrl.startsWith('PASTE_') || !kDefaultServer.startsWith('PASTE_');

  static String? _base;
  static bool _loaded = false;

  static Future<File> _cacheFile() async {
    final d = await getApplicationSupportDirectory();
    return File('${d.path}/lux_server.json');
  }

  static Future<void> _loadCache() async {
    if (_loaded) return;
    _loaded = true;
    try {
      final f = await _cacheFile();
      if (await f.exists()) {
        _base = (jsonDecode(await f.readAsString()) as Map)['server'] as String?;
      }
    } catch (_) {}
    if (_base == null && !kDefaultServer.startsWith('PASTE_')) _base = _clean(kDefaultServer);
  }

  static String _clean(String s) {
    var t = s.trim();
    while (t.endsWith('/')) {
      t = t.substring(0, t.length - 1);
    }
    return t;
  }

  static Future<void> _saveCache(String url) async {
    _base = url;
    try {
      final f = await _cacheFile();
      await f.writeAsString(jsonEncode({'server': url}));
    } catch (_) {}
  }

  static bool _serverDown(HttpClientResponse r) =>
      r.statusCode >= 502 || r.headers.value('x-railway-fallback') == 'true';

  /// آدرس تازه را از فایل گیت‌هاب می‌خواند و اگر سالم بود ذخیره می‌کند.
  static Future<bool> _refresh() async {
    if (kServerListUrl.startsWith('PASTE_')) return false;
    final c = HttpClient()..connectionTimeout = const Duration(seconds: 8);
    try {
      final req = await c.getUrl(Uri.parse(kServerListUrl)).timeout(const Duration(seconds: 8));
      final res = await req.close().timeout(const Duration(seconds: 8));
      if (res.statusCode != 200) return false;
      final text = await res.transform(utf8.decoder).join();
      final url = _clean((jsonDecode(text) as Map)['server'] as String? ?? '');
      if (url.isEmpty) return false;
      final h = await c.getUrl(Uri.parse('$url/health')).timeout(const Duration(seconds: 8));
      final hr = await h.close().timeout(const Duration(seconds: 8));
      await hr.drain<void>();
      if (hr.statusCode == 200 && !_serverDown(hr)) {
        await _saveCache(url);
        return true;
      }
    } catch (_) {
    } finally {
      c.close(force: true);
    }
    return false;
  }

  static Future<Map<String, dynamic>?> _once(String base, String method, String path, {Object? body, String? token, String? rawBody}) async {
    final c = HttpClient()..connectionTimeout = const Duration(seconds: 12);
    try {
      final req = await c.openUrl(method, Uri.parse(base + path)).timeout(const Duration(seconds: 12));
      req.headers.set('content-type', 'application/json; charset=utf-8');
      if (token != null) req.headers.set('authorization', 'Bearer $token');
      final payload = rawBody ?? (body == null ? null : jsonEncode(body));
      if (payload != null) req.add(utf8.encode(payload));
      final res = await req.close().timeout(const Duration(seconds: 40));
      if (_serverDown(res)) {
        await res.drain<void>();
        return null; // سرور خاموش است
      }
      final text = await res.transform(utf8.decoder).join();
      Map<String, dynamic> m;
      try {
        final d = jsonDecode(text);
        m = d is Map<String, dynamic> ? d : <String, dynamic>{'ok': false};
      } catch (_) {
        m = <String, dynamic>{'ok': false, 'message': 'پاسخ نامعتبر از سرور'};
      }
      if (res.statusCode >= 400 || m['ok'] == false) {
        throw ApiError((m['code'] ?? 'http_${res.statusCode}').toString(), (m['message'] ?? m['detail'] ?? 'خطا در سرور').toString());
      }
      return m;
    } on ApiError {
      rethrow;
    } on SocketException {
      return null;
    } on TimeoutException {
      return null;
    } on HandshakeException {
      return null;
    } on HttpException {
      return null;
    } finally {
      c.close(force: true);
    }
  }

  static Future<Map<String, dynamic>> request(String method, String path, {Object? body, String? token, String? rawBody}) async {
    await _loadCache();
    if (_base != null) {
      final r = await _once(_base!, method, path, body: body, token: token, rawBody: rawBody);
      if (r != null) return r;
    }
    if (await _refresh() && _base != null) {
      final r = await _once(_base!, method, path, body: body, token: token, rawBody: rawBody);
      if (r != null) return r;
    }
    throw ApiError('offline', 'به سرور وصل نشد. مطمئن شو اینترنت روشنه و چند لحظه بعد دوباره امتحان کن.');
  }

  static Future<Map<String, dynamic>> post(String path, Object body, {String? token}) => request('POST', path, body: body, token: token);
  static Future<Map<String, dynamic>> get(String path, {String? token}) => request('GET', path, token: token);
}
