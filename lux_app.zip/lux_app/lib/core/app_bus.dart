import 'package:flutter/foundation.dart';

/// وقتی داده‌ای تغییر کرد، صفحه‌ها با شنیدنِ این اعلان دوباره بارگذاری می‌کنند.
class AppBus {
  AppBus._();
  static final ValueNotifier<int> data = ValueNotifier<int>(0);
  static void bump() => data.value++;
}
