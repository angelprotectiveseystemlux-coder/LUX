import 'package:flutter/material.dart';

/// پالت LUX — برگرفته از لوگو: نقره‌ای فلزی + آبی فیروزه‌ای روی گرافیتِ تیره‌ی سرد.
class LuxColors {
  LuxColors._();

  static const Color bg = Color(0xFF0C1117);
  static const Color bgSoft = Color(0xFF10161E);
  static const Color card = Color(0xFF151C25);
  static const Color cardHi = Color(0xFF1B2430);
  static const Color stroke = Color(0xFF263241);

  static const Color accent = Color(0xFF19B8F0);
  static const Color accentDim = Color(0xFF0E7FA6);
  static const Color onAccent = Color(0xFF04202B);

  static const Color silver = Color(0xFFD7DEE6);
  static const Color silverDim = Color(0xFF8E9AA8);

  static const Color text = Color(0xFFE9EEF4);
  static const Color textDim = Color(0xFF9AA6B4);

  // هشدار/خطا/موفق: کم‌مصرف و بدون نارنجی
  static const Color warn = Color(0xFFE3C98F);
  static const Color danger = Color(0xFFE0736E);
  static const Color ok = Color(0xFF5ED6A6);

  /// رنگ سری‌ها در نمودارها (خانواده‌ی آبی/فیروزه‌ای/نقره‌ای)
  static const List<Color> series = <Color>[
    Color(0xFF19B8F0),
    Color(0xFF4F8BFF),
    Color(0xFF7A8CFF),
    Color(0xFF2DD4BF),
    Color(0xFFA8B5C4),
    Color(0xFF8FD3F4),
    Color(0xFF3B6EA8),
    Color(0xFFC9D6E3),
  ];

  static Color seriesAt(int i) => series[i % series.length];

  /// withOpacity منسوخ شده؛ این نسخه روی همه‌ی نسخه‌های Flutter کار می‌کند.
  static Color alpha(Color c, double opacity) =>
      c.withAlpha((opacity.clamp(0.0, 1.0) * 255).round());
}
