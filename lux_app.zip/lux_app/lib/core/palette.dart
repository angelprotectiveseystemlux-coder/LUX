import 'package:flutter/material.dart';

/// یک پالت کامل (رنگ‌های یک تم در یک حالتِ روشن یا تیره).
class LuxPalette {
  final Brightness brightness;
  final Color bg;
  final Color bgSoft;
  final Color card;
  final Color cardHi;
  final Color stroke;
  final Color accent;
  final Color accentDim;
  final Color onAccent;
  final Color silver;
  final Color silverDim;
  final Color text;
  final Color textDim;
  final Color warn;
  final Color danger;
  final Color ok;

  /// ضریب گردی گوشه‌ها (۱ = پیش‌فرض، کمتر = تیزتر)
  final double radiusScale;

  /// ضخامت حاشیه‌ی کارت‌ها و دکمه‌ها
  final double strokeWidth;

  /// شفافیت رنگ حاشیه (۱ = کاملاً پررنگ)
  final double strokeAlpha;

  /// سایه‌ی سخت و بدون بلور زیر کارت‌ها (سبک کاغذی)
  final bool hardShadow;

  const LuxPalette({
    required this.brightness,
    required this.bg,
    required this.bgSoft,
    required this.card,
    required this.cardHi,
    required this.stroke,
    required this.accent,
    required this.accentDim,
    required this.onAccent,
    required this.silver,
    required this.silverDim,
    required this.text,
    required this.textDim,
    required this.warn,
    required this.danger,
    required this.ok,
    this.radiusScale = 1.0,
    this.strokeWidth = 1.0,
    this.strokeAlpha = 0.7,
    this.hardShadow = false,
  });
}

/// یک تم: نام + نسخه‌ی تیره + نسخه‌ی روشن
class LuxThemeDef {
  final String id;
  final String name;
  final LuxPalette dark;
  final LuxPalette light;
  const LuxThemeDef({required this.id, required this.name, required this.dark, required this.light});

  LuxPalette of(Brightness b) => b == Brightness.dark ? dark : light;
}

/// تم‌های آماده
class LuxThemes {
  LuxThemes._();

  static const Color _dSilver = Color(0xFFD7DEE6);
  static const Color _dSilverDim = Color(0xFF8E9AA8);
  static const Color _dText = Color(0xFFE9EEF4);
  static const Color _dTextDim = Color(0xFF9AA6B4);
  static const Color _dWarn = Color(0xFFE3C98F);
  static const Color _dDanger = Color(0xFFE0736E);
  static const Color _dOk = Color(0xFF5ED6A6);

  static const Color _lWarn = Color(0xFFA87A12);
  static const Color _lDanger = Color(0xFFC0453F);
  static const Color _lOk = Color(0xFF148F68);

  static const LuxPalette _lightBase = LuxPalette(
    brightness: Brightness.light,
    bg: Color(0xFFF3F7FA),
    bgSoft: Color(0xFFEAF0F5),
    card: Color(0xFFFFFFFF),
    cardHi: Color(0xFFEDF2F7),
    stroke: Color(0xFFD3DCE6),
    accent: Color(0xFF0A8FC4),
    accentDim: Color(0xFF0A6F99),
    onAccent: Color(0xFFFFFFFF),
    silver: Color(0xFF3A4756),
    silverDim: Color(0xFF7C8896),
    text: Color(0xFF0F1720),
    textDim: Color(0xFF586575),
    warn: _lWarn,
    danger: _lDanger,
    ok: _lOk,
  );

  static const List<LuxThemeDef> all = <LuxThemeDef>[
    // ۱) فیروزه‌ای (پیش‌فرض LUX)
    LuxThemeDef(
      id: 'lux',
      name: 'فیروزه‌ای',
      dark: LuxPalette(
        brightness: Brightness.dark,
        bg: Color(0xFF0C1117),
        bgSoft: Color(0xFF10161E),
        card: Color(0xFF151C25),
        cardHi: Color(0xFF1B2430),
        stroke: Color(0xFF263241),
        accent: Color(0xFF19B8F0),
        accentDim: Color(0xFF0E7FA6),
        onAccent: Color(0xFF04202B),
        silver: _dSilver,
        silverDim: _dSilverDim,
        text: _dText,
        textDim: _dTextDim,
        warn: _dWarn,
        danger: _dDanger,
        ok: _dOk,
      ),
      light: _lightBase,
    ),
    // ۲) بنفش
    LuxThemeDef(
      id: 'violet',
      name: 'بنفش',
      dark: LuxPalette(
        brightness: Brightness.dark,
        bg: Color(0xFF0E0C16),
        bgSoft: Color(0xFF131020),
        card: Color(0xFF191525),
        cardHi: Color(0xFF221C33),
        stroke: Color(0xFF2F2845),
        accent: Color(0xFFA68BFF),
        accentDim: Color(0xFF6F55D6),
        onAccent: Color(0xFF130A2E),
        silver: _dSilver,
        silverDim: _dSilverDim,
        text: _dText,
        textDim: _dTextDim,
        warn: _dWarn,
        danger: _dDanger,
        ok: _dOk,
      ),
      light: LuxPalette(
        brightness: Brightness.light,
        bg: Color(0xFFF6F4FB),
        bgSoft: Color(0xFFEEEAF7),
        card: Color(0xFFFFFFFF),
        cardHi: Color(0xFFF1EEF9),
        stroke: Color(0xFFDAD3EC),
        accent: Color(0xFF6E4FE0),
        accentDim: Color(0xFF5238B8),
        onAccent: Color(0xFFFFFFFF),
        silver: Color(0xFF3A4756),
        silverDim: Color(0xFF7C8896),
        text: Color(0xFF0F1720),
        textDim: Color(0xFF586575),
        warn: _lWarn,
        danger: _lDanger,
        ok: _lOk,
      ),
    ),
    // ۳) زمردی
    LuxThemeDef(
      id: 'emerald',
      name: 'زمردی',
      dark: LuxPalette(
        brightness: Brightness.dark,
        bg: Color(0xFF09120F),
        bgSoft: Color(0xFF0E1915),
        card: Color(0xFF13211C),
        cardHi: Color(0xFF1A2C25),
        stroke: Color(0xFF25403A),
        accent: Color(0xFF2EE6A6),
        accentDim: Color(0xFF14A377),
        onAccent: Color(0xFF03231A),
        silver: _dSilver,
        silverDim: _dSilverDim,
        text: _dText,
        textDim: _dTextDim,
        warn: _dWarn,
        danger: _dDanger,
        ok: Color(0xFF8EE08A),
      ),
      light: LuxPalette(
        brightness: Brightness.light,
        bg: Color(0xFFF2F8F5),
        bgSoft: Color(0xFFE7F1EC),
        card: Color(0xFFFFFFFF),
        cardHi: Color(0xFFECF4F0),
        stroke: Color(0xFFCFE0D8),
        accent: Color(0xFF0E9F6E),
        accentDim: Color(0xFF0A7A54),
        onAccent: Color(0xFFFFFFFF),
        silver: Color(0xFF3A4756),
        silverDim: Color(0xFF7C8896),
        text: Color(0xFF0F1720),
        textDim: Color(0xFF586575),
        warn: _lWarn,
        danger: _lDanger,
        ok: Color(0xFF3D8A2E),
      ),
    ),
    // ۴) کهربایی
    LuxThemeDef(
      id: 'amber',
      name: 'کهربایی',
      dark: LuxPalette(
        brightness: Brightness.dark,
        bg: Color(0xFF120F09),
        bgSoft: Color(0xFF18140C),
        card: Color(0xFF1F1A10),
        cardHi: Color(0xFF2A2314),
        stroke: Color(0xFF3B3220),
        accent: Color(0xFFF5B942),
        accentDim: Color(0xFFB8841D),
        onAccent: Color(0xFF2B1B00),
        silver: _dSilver,
        silverDim: _dSilverDim,
        text: _dText,
        textDim: _dTextDim,
        warn: Color(0xFFFFD98A),
        danger: _dDanger,
        ok: _dOk,
      ),
      light: LuxPalette(
        brightness: Brightness.light,
        bg: Color(0xFFFAF7F0),
        bgSoft: Color(0xFFF2EDE0),
        card: Color(0xFFFFFFFF),
        cardHi: Color(0xFFF6F1E4),
        stroke: Color(0xFFE3D9BF),
        accent: Color(0xFFC98A0B),
        accentDim: Color(0xFF9A6806),
        onAccent: Color(0xFFFFFFFF),
        silver: Color(0xFF3A4756),
        silverDim: Color(0xFF7C8896),
        text: Color(0xFF0F1720),
        textDim: Color(0xFF586575),
        warn: Color(0xFF8A6A10),
        danger: _lDanger,
        ok: _lOk,
      ),
    ),
    // ۵) سرخابی
    LuxThemeDef(
      id: 'rose',
      name: 'سرخابی',
      dark: LuxPalette(
        brightness: Brightness.dark,
        bg: Color(0xFF140C10),
        bgSoft: Color(0xFF1A1016),
        card: Color(0xFF22151C),
        cardHi: Color(0xFF2E1C26),
        stroke: Color(0xFF43283A),
        accent: Color(0xFFFF6B94),
        accentDim: Color(0xFFC93F69),
        onAccent: Color(0xFF33000F),
        silver: _dSilver,
        silverDim: _dSilverDim,
        text: _dText,
        textDim: _dTextDim,
        warn: _dWarn,
        danger: Color(0xFFFF9A8A),
        ok: _dOk,
      ),
      light: LuxPalette(
        brightness: Brightness.light,
        bg: Color(0xFFFBF5F7),
        bgSoft: Color(0xFFF5E9EE),
        card: Color(0xFFFFFFFF),
        cardHi: Color(0xFFF8EEF2),
        stroke: Color(0xFFE8D3DC),
        accent: Color(0xFFD63B6B),
        accentDim: Color(0xFFA82B52),
        onAccent: Color(0xFFFFFFFF),
        silver: Color(0xFF3A4756),
        silverDim: Color(0xFF7C8896),
        text: Color(0xFF0F1720),
        textDim: Color(0xFF586575),
        warn: _lWarn,
        danger: Color(0xFFB5352F),
        ok: _lOk,
      ),
    ),
    // ۶) کاغذ و جوهر — سبک متفاوت: گوشه‌های تیز، حاشیه‌ی ضخیم، سایه‌ی سخت
    LuxThemeDef(
      id: 'paper',
      name: 'کاغذ و جوهر',
      dark: LuxPalette(
        brightness: Brightness.dark,
        bg: Color(0xFF1B1915),
        bgSoft: Color(0xFF22201B),
        card: Color(0xFF2A2721),
        cardHi: Color(0xFF353128),
        stroke: Color(0xFFEDE4D0),
        accent: Color(0xFFFF6A3D),
        accentDim: Color(0xFFD9481F),
        onAccent: Color(0xFF1B1915),
        silver: Color(0xFFEDE4D0),
        silverDim: Color(0xFFA89F8C),
        text: Color(0xFFF4EDE0),
        textDim: Color(0xFFA89F8C),
        warn: Color(0xFFE8B84A),
        danger: Color(0xFFFF7A66),
        ok: Color(0xFF8CCB7E),
        radiusScale: 0.25,
        strokeWidth: 1.6,
        strokeAlpha: 1.0,
        hardShadow: true,
      ),
      light: LuxPalette(
        brightness: Brightness.light,
        bg: Color(0xFFF4EDE0),
        bgSoft: Color(0xFFEBE2D0),
        card: Color(0xFFFBF7EE),
        cardHi: Color(0xFFEFE6D3),
        stroke: Color(0xFF1B1A17),
        accent: Color(0xFFD9411E),
        accentDim: Color(0xFFA83015),
        onAccent: Color(0xFFFBF7EE),
        silver: Color(0xFF1B1A17),
        silverDim: Color(0xFF6E675A),
        text: Color(0xFF1B1A17),
        textDim: Color(0xFF6E675A),
        warn: Color(0xFFA87A12),
        danger: Color(0xFFB5352F),
        ok: Color(0xFF2F7D4F),
        radiusScale: 0.25,
        strokeWidth: 1.6,
        strokeAlpha: 1.0,
        hardShadow: true,
      ),
    ),
  ];
}

/// رنگ‌های جاریِ برنامه. مقدارها از پالتِ انتخاب‌شده می‌آیند و با عوض‌شدن تم تازه می‌شوند.
class LuxColors {
  LuxColors._();

  /// پالتِ فعال (توسط AppTheme عوض می‌شود)
  static LuxPalette current = LuxThemes.all[0].dark;

  static Color get bg => current.bg;
  static Color get bgSoft => current.bgSoft;
  static Color get card => current.card;
  static Color get cardHi => current.cardHi;
  static Color get stroke => current.stroke;

  static Color get accent => current.accent;
  static Color get accentDim => current.accentDim;
  static Color get onAccent => current.onAccent;

  static Color get silver => current.silver;
  static Color get silverDim => current.silverDim;

  static Color get text => current.text;
  static Color get textDim => current.textDim;

  static Color get warn => current.warn;
  static Color get danger => current.danger;
  static Color get ok => current.ok;

  static bool get isDark => current.brightness == Brightness.dark;

  /// گردیِ گوشه، متناسب با سبک تم
  static double r(double v) => v * current.radiusScale;

  static double get strokeW => current.strokeWidth;
  static bool get hardShadow => current.hardShadow;
  static Color get strokeColor => alpha(current.stroke, current.strokeAlpha);

  /// سایه‌ی سخت (فقط در تم‌هایی که hardShadow دارند)
  static List<BoxShadow> shadow({double d = 3}) => current.hardShadow
      ? <BoxShadow>[BoxShadow(color: current.stroke, offset: Offset(d, d), blurRadius: 0)]
      : const <BoxShadow>[];

  /// رنگ سری‌ها در نمودارها: اولی رنگِ تم، بقیه خانواده‌ی آبی/فیروزه‌ای/نقره‌ای
  static List<Color> get series => <Color>[
        accent,
        const Color(0xFF4F8BFF),
        const Color(0xFF7A8CFF),
        const Color(0xFF2DD4BF),
        const Color(0xFFA8B5C4),
        const Color(0xFF8FD3F4),
        const Color(0xFF3B6EA8),
        const Color(0xFFC9D6E3),
      ];

  static Color seriesAt(int i) {
    final s = series;
    return s[i % s.length];
  }

  /// withOpacity منسوخ شده؛ این نسخه روی همه‌ی نسخه‌های Flutter کار می‌کند.
  static Color alpha(Color c, double opacity) =>
      c.withAlpha((opacity.clamp(0.0, 1.0) * 255).round());
}
