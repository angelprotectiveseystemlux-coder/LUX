import 'dart:convert';
import 'dart:io';

import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'package:sqflite/sqflite.dart';

import 'database.dart';

/// پشتیبان‌گیری و بازیابیِ همه‌ی داده‌ها در یک فایل JSON.
class Backup {
  Backup._();

  /// ترتیب: والدها اول (برای درج). حذف به‌صورت معکوس انجام می‌شود.
  static const List<String> tables = <String>[
    'settings', 'profile', 'education_years', 'teachers', 'courses', 'class_slots',
    'assessment_types', 'exams', 'grades', 'books', 'chapters', 'reading_sessions',
    'annotations', 'study_sessions', 'tasks', 'journal', 'achievements',
    'class_positives', 'discipline_warnings', 'rivals', 'rival_scores', 'week_plan', 'rival_behavior', 'rival_conf', 'cal_items', 'attendance', 'mistakes',
  ];

  static const String fileName = 'lux_data.json';

  static Future<String> exportJson() async {
    final out = <String, Object?>{};
    for (final t in tables) {
      out[t] = await LuxDb.instance.rawQuery('SELECT * FROM $t');
    }
    return const JsonEncoder.withIndent('  ').convert(<String, Object?>{
      'app': 'LUX',
      'format': 1,
      'exported_at': DateTime.now().toIso8601String(),
      'tables': out,
    });
  }

  /// پوشه‌ی فایلِ خودکار: حافظه‌ی خارجیِ مخصوصِ برنامه (اگر نبود، پوشه‌ی اسناد برنامه).
  static Future<Directory> autoDir() async {
    Directory? d;
    try {
      d = await getExternalStorageDirectory();
    } catch (_) {}
    d ??= await getApplicationDocumentsDirectory();
    final dir = Directory(p.join(d.path, 'LUX'));
    if (!await dir.exists()) await dir.create(recursive: true);
    return dir;
  }

  /// فایلِ خودکار را به‌روز می‌کند (بی‌صدا؛ خطا را قورت می‌دهد).
  static Future<File?> autoSave() async {
    try {
      final dir = await autoDir();
      final f = File(p.join(dir.path, fileName));
      await f.writeAsString(await exportJson(), flush: true);
      await LuxDb.instance.kvSet('last_auto_backup', DateTime.now().millisecondsSinceEpoch.toString());
      return f;
    } catch (_) {
      return null;
    }
  }

  /// یک نسخه‌ی موقت برای «ذخیره در…» / اشتراک‌گذاری
  static Future<File> writeTemp() async {
    final dir = await getTemporaryDirectory();
    final stamp = DateTime.now().toIso8601String().replaceAll(':', '-').split('.').first;
    final f = File(p.join(dir.path, 'lux_backup_$stamp.json'));
    await f.writeAsString(await exportJson(), flush: true);
    return f;
  }

  /// بازیابی. در صورت نامعتبر بودنِ فایل، خطا پرتاب می‌شود و چیزی تغییر نمی‌کند.
  static Future<void> importJson(String text) async {
    final decoded = jsonDecode(text);
    if (decoded is! Map || decoded['app'] != 'LUX' || decoded['tables'] is! Map) {
      throw const FormatException('این فایل پشتیبانِ LUX نیست.');
    }
    final data = Map<String, Object?>.from(decoded['tables'] as Map);
    final db = LuxDb.instance.raw;
    await db.transaction((txn) async {
      await txn.execute('PRAGMA defer_foreign_keys = ON');
      for (final t in tables.reversed) {
        await txn.delete(t);
      }
      for (final t in tables) {
        final rows = data[t];
        if (rows is! List) continue;
        for (final r in rows) {
          if (r is! Map) continue;
          await txn.insert(t, Map<String, Object?>.from(r), conflictAlgorithm: ConflictAlgorithm.replace);
        }
      }
    });
  }
}
