import 'database.dart';

class Profile {
  final String name;
  final String titlePref; // «آقای» / «خانم» / ''
  final String level; // middle | high
  final int grade; // ۷..۹ یا ۱۰..۱۲
  final String track; // فقط دبیرستان
  final double? prevGpa;
  final int birthY, birthM, birthD;
  final String? photoPath;

  const Profile({
    required this.name,
    this.titlePref = 'آقای',
    required this.level,
    required this.grade,
    this.track = '',
    this.prevGpa,
    required this.birthY,
    required this.birthM,
    required this.birthD,
    this.photoPath,
  });

  Profile copyWith({
    String? name,
    String? titlePref,
    String? level,
    int? grade,
    String? track,
    double? prevGpa,
    bool clearGpa = false,
    int? birthY,
    int? birthM,
    int? birthD,
    String? photoPath,
  }) =>
      Profile(
        name: name ?? this.name,
        titlePref: titlePref ?? this.titlePref,
        level: level ?? this.level,
        grade: grade ?? this.grade,
        track: track ?? this.track,
        prevGpa: clearGpa ? null : (prevGpa ?? this.prevGpa),
        birthY: birthY ?? this.birthY,
        birthM: birthM ?? this.birthM,
        birthD: birthD ?? this.birthD,
        photoPath: photoPath ?? this.photoPath,
      );

  Map<String, Object?> toMap() => {
        'id': 1,
        'name': name,
        'title_pref': titlePref,
        'level': level,
        'grade': grade,
        'track': track,
        'prev_gpa': prevGpa,
        'birth_y': birthY,
        'birth_m': birthM,
        'birth_d': birthD,
        'photo_path': photoPath,
        'created_at': DateTime.now().millisecondsSinceEpoch,
      };

  static Profile fromMap(Map<String, Object?> m) => Profile(
        name: (m['name'] as String?) ?? '',
        titlePref: (m['title_pref'] as String?) ?? '',
        level: (m['level'] as String?) ?? 'high',
        grade: (m['grade'] as int?) ?? 10,
        track: (m['track'] as String?) ?? '',
        prevGpa: (m['prev_gpa'] as num?)?.toDouble(),
        birthY: (m['birth_y'] as int?) ?? 1390,
        birthM: (m['birth_m'] as int?) ?? 1,
        birthD: (m['birth_d'] as int?) ?? 1,
        photoPath: m['photo_path'] as String?,
      );

  String get greetingName => titlePref.isEmpty ? name : '$titlePref $name';

  String get levelLabel => level == 'middle' ? 'راهنمایی (متوسطه‌ی اول)' : 'دبیرستان (متوسطه‌ی دوم)';

  static const Map<int, String> gradeNames = {
    7: 'هفتم', 8: 'هشتم', 9: 'نهم', 10: 'دهم', 11: 'یازدهم', 12: 'دوازدهم',
  };

  String get gradeLabel => gradeNames[grade] ?? '$grade';
}

class ProfileRepo {
  ProfileRepo._();

  static Future<Profile?> get() async {
    final r = await LuxDb.instance.query('profile', where: 'id = 1', limit: 1);
    if (r.isEmpty) return null;
    return Profile.fromMap(r.first);
  }

  static Future<void> save(Profile p) async {
    await LuxDb.instance.insert('profile', p.toMap());
  }

  static Future<bool> isOnboarded() async {
    final v = await LuxDb.instance.kvGet('onboarded');
    return v == '1';
  }

  static Future<void> markOnboarded() => LuxDb.instance.kvSet('onboarded', '1');
}
