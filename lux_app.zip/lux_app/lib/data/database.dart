import 'dart:io';

import 'package:path/path.dart' as p;
import 'package:sqflite/sqflite.dart';

/// پایگاه‌داده‌ی SQLite محلیِ LUX.
/// طرح (schema) از همین حالا کاملِ تمام ماژول‌هاست تا بعداً مهاجرت‌های پرخطر لازم نشود.
class LuxDb {
  LuxDb._();
  static final LuxDb instance = LuxDb._();

  static const int schemaVersion = 1;

  Database? _db;
  String? _path;

  Database get raw {
    final d = _db;
    if (d == null) {
      throw StateError('LuxDb.open() صدا زده نشده است');
    }
    return d;
  }

  String get path => _path ?? '';

  Future<void> open() async {
    if (_db != null) return;
    final dir = await getDatabasesPath();
    _path = p.join(dir, 'lux.db');
    _db = await openDatabase(
      _path!,
      version: schemaVersion,
      onConfigure: (db) async {
        await db.execute('PRAGMA foreign_keys = ON');
      },
      onCreate: (db, v) async {
        final batch = db.batch();
        for (final sql in _schema) {
          batch.execute(sql);
        }
        await batch.commit(noResult: true);
      },
      onUpgrade: (db, oldV, newV) async {
        // مهاجرت‌های آینده اینجا به‌ترتیب نسخه اضافه می‌شوند.
      },
    );
  }

  Future<void> close() async {
    await _db?.close();
    _db = null;
  }

  // ───────── میانبرهای CRUD ─────────
  Future<int> insert(String table, Map<String, Object?> values) =>
      raw.insert(table, values, conflictAlgorithm: ConflictAlgorithm.replace);

  Future<int> update(String table, Map<String, Object?> values, {required String where, required List<Object?> args}) =>
      raw.update(table, values, where: where, whereArgs: args);

  Future<int> delete(String table, {required String where, required List<Object?> args}) =>
      raw.delete(table, where: where, whereArgs: args);

  Future<List<Map<String, Object?>>> query(String table,
          {String? where, List<Object?>? args, String? orderBy, int? limit}) =>
      raw.query(table, where: where, whereArgs: args, orderBy: orderBy, limit: limit);

  Future<List<Map<String, Object?>>> rawQuery(String sql, [List<Object?>? args]) => raw.rawQuery(sql, args);

  Future<int> count(String table, {String? where, List<Object?>? args}) async {
    final r = await raw.rawQuery('SELECT COUNT(*) AS c FROM $table${where == null ? '' : ' WHERE $where'}', args);
    return (r.first['c'] as int?) ?? 0;
  }

  // ───────── تنظیمات (کلید/مقدار) ─────────
  Future<String?> kvGet(String key) async {
    final r = await raw.query('settings', where: 'key = ?', whereArgs: [key], limit: 1);
    if (r.isEmpty) return null;
    return r.first['value'] as String?;
  }

  Future<void> kvSet(String key, String value) async {
    await raw.insert('settings', {'key': key, 'value': value}, conflictAlgorithm: ConflictAlgorithm.replace);
  }

  Future<void> kvDelete(String key) async {
    await raw.delete('settings', where: 'key = ?', whereArgs: [key]);
  }

  // ───────── پشتیبان ─────────
  /// نسخه‌ی پشتیبان از فایل پایگاه‌داده در [targetDir]. فایل ساخته‌شده را برمی‌گرداند.
  Future<File> backupTo(String targetDir, {String? name}) async {
    try {
      await raw.rawQuery('PRAGMA wal_checkpoint(TRUNCATE)');
    } catch (_) {}
    final dir = Directory(targetDir);
    if (!await dir.exists()) await dir.create(recursive: true);
    final stamp = DateTime.now().toIso8601String().replaceAll(':', '-').split('.').first;
    final out = File(p.join(targetDir, name ?? 'lux_$stamp.db'));
    return File(_path!).copy(out.path);
  }

  // ───────── طرح ─────────
  static const List<String> _schema = <String>[
    'CREATE TABLE settings (key TEXT PRIMARY KEY, value TEXT)',

    '''CREATE TABLE profile (
      id INTEGER PRIMARY KEY CHECK (id = 1),
      name TEXT NOT NULL,
      title_pref TEXT,
      level TEXT,
      grade INTEGER,
      track TEXT,
      prev_gpa REAL,
      birth_y INTEGER, birth_m INTEGER, birth_d INTEGER,
      photo_path TEXT,
      created_at INTEGER
    )''',

    '''CREATE TABLE education_years (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      year_label TEXT, level TEXT, grade INTEGER, track TEXT, gpa REAL, note TEXT
    )''',

    '''CREATE TABLE teachers (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL, phone TEXT, style_note TEXT, notes TEXT
    )''',

    '''CREATE TABLE courses (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      coef REAL NOT NULL DEFAULT 1,
      difficulty INTEGER NOT NULL DEFAULT 3,
      max_score REAL NOT NULL DEFAULT 20,
      pass_score REAL NOT NULL DEFAULT 10,
      teacher_id INTEGER REFERENCES teachers(id) ON DELETE SET NULL,
      color INTEGER, archived INTEGER NOT NULL DEFAULT 0,
      notes TEXT, created_at INTEGER
    )''',

    '''CREATE TABLE class_slots (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      course_id INTEGER NOT NULL REFERENCES courses(id) ON DELETE CASCADE,
      weekday INTEGER NOT NULL, start_min INTEGER NOT NULL, end_min INTEGER NOT NULL, room TEXT
    )''',

    '''CREATE TABLE assessment_types (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      course_id INTEGER NOT NULL REFERENCES courses(id) ON DELETE CASCADE,
      name TEXT NOT NULL, weight REAL NOT NULL DEFAULT 1, max_score REAL NOT NULL DEFAULT 20
    )''',

    '''CREATE TABLE exams (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      course_id INTEGER NOT NULL REFERENCES courses(id) ON DELETE CASCADE,
      type_name TEXT, title TEXT,
      at_ts INTEGER NOT NULL,
      location TEXT, scope_note TEXT,
      weight REAL NOT NULL DEFAULT 1, max_score REAL NOT NULL DEFAULT 20,
      difficulty INTEGER NOT NULL DEFAULT 3, readiness INTEGER,
      status TEXT NOT NULL DEFAULT 'planned',
      cancel_reason TEXT, new_at_ts INTEGER,
      score REAL,
      ask_offset_min INTEGER NOT NULL DEFAULT 90,
      remind_json TEXT,
      created_at INTEGER
    )''',

    '''CREATE TABLE grades (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      course_id INTEGER NOT NULL REFERENCES courses(id) ON DELETE CASCADE,
      exam_id INTEGER REFERENCES exams(id) ON DELETE SET NULL,
      name TEXT, score REAL NOT NULL, max_score REAL NOT NULL DEFAULT 20,
      weight REAL NOT NULL DEFAULT 1, at_ts INTEGER NOT NULL, kind TEXT
    )''',

    '''CREATE TABLE books (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      course_id INTEGER REFERENCES courses(id) ON DELETE SET NULL,
      title TEXT NOT NULL, pages INTEGER, file_path TEXT, cover_path TEXT,
      last_page INTEGER NOT NULL DEFAULT 0, added_at INTEGER
    )''',

    '''CREATE TABLE chapters (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      book_id INTEGER NOT NULL REFERENCES books(id) ON DELETE CASCADE,
      title TEXT NOT NULL, start_page INTEGER, end_page INTEGER,
      done INTEGER NOT NULL DEFAULT 0, review_count INTEGER NOT NULL DEFAULT 0,
      ef REAL NOT NULL DEFAULT 2.5, interval_days INTEGER NOT NULL DEFAULT 0,
      reps INTEGER NOT NULL DEFAULT 0, due_ts INTEGER
    )''',

    '''CREATE TABLE reading_sessions (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      book_id INTEGER NOT NULL REFERENCES books(id) ON DELETE CASCADE,
      start_ts INTEGER NOT NULL, end_ts INTEGER NOT NULL,
      from_page INTEGER, to_page INTEGER
    )''',

    '''CREATE TABLE annotations (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      book_id INTEGER NOT NULL REFERENCES books(id) ON DELETE CASCADE,
      page INTEGER NOT NULL, kind TEXT NOT NULL, data TEXT, note TEXT, color INTEGER, created_at INTEGER
    )''',

    '''CREATE TABLE study_sessions (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      course_id INTEGER REFERENCES courses(id) ON DELETE SET NULL,
      book_id INTEGER REFERENCES books(id) ON DELETE SET NULL,
      start_ts INTEGER NOT NULL, end_ts INTEGER,
      kind TEXT NOT NULL DEFAULT 'pomodoro',
      planned_min INTEGER, completed INTEGER NOT NULL DEFAULT 0
    )''',

    '''CREATE TABLE tasks (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      course_id INTEGER REFERENCES courses(id) ON DELETE SET NULL,
      title TEXT NOT NULL, notes TEXT,
      due_ts INTEGER, priority INTEGER NOT NULL DEFAULT 2,
      status TEXT NOT NULL DEFAULT 'open',
      remind_json TEXT, created_at INTEGER, done_at INTEGER
    )''',

    '''CREATE TABLE journal (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      day TEXT NOT NULL UNIQUE, text TEXT,
      mood INTEGER, energy INTEGER, sleep_h REAL, created_at INTEGER
    )''',

    '''CREATE TABLE achievements (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      key TEXT NOT NULL UNIQUE, unlocked_at INTEGER NOT NULL
    )''',

    '''CREATE TABLE class_positives (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      course_id INTEGER REFERENCES courses(id) ON DELETE SET NULL,
      teacher_id INTEGER REFERENCES teachers(id) ON DELETE SET NULL,
      at_ts INTEGER NOT NULL, count INTEGER NOT NULL DEFAULT 1, note TEXT
    )''',

    '''CREATE TABLE discipline_warnings (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      at_ts INTEGER NOT NULL, type TEXT, issuer TEXT, reason TEXT,
      severity INTEGER NOT NULL DEFAULT 1, points REAL,
      followup_ts INTEGER, resolved INTEGER NOT NULL DEFAULT 0, note TEXT
    )''',

    '''CREATE TABLE scheduled_notifs (
      id INTEGER PRIMARY KEY,
      kind TEXT NOT NULL, ref_id INTEGER, fire_ts INTEGER NOT NULL,
      title TEXT, body TEXT, payload TEXT
    )''',

    'CREATE INDEX idx_exams_at ON exams(at_ts)',
    'CREATE INDEX idx_exams_course ON exams(course_id)',
    'CREATE INDEX idx_grades_course ON grades(course_id, at_ts)',
    'CREATE INDEX idx_tasks_due ON tasks(due_ts)',
    'CREATE INDEX idx_reading_book ON reading_sessions(book_id, start_ts)',
    'CREATE INDEX idx_study_start ON study_sessions(start_ts)',
    'CREATE INDEX idx_positives ON class_positives(course_id, at_ts)',
    'CREATE INDEX idx_warnings ON discipline_warnings(at_ts)',
    'CREATE INDEX idx_notifs_fire ON scheduled_notifs(fire_ts)',
  ];
}
