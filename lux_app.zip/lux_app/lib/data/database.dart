import 'dart:io';

import 'package:path/path.dart' as p;
import 'package:sqflite/sqflite.dart';

/// پایگاه‌داده‌ی SQLite محلیِ LUX.
/// طرح (schema) از همین حالا کاملِ تمام ماژول‌هاست تا بعداً مهاجرت‌های پرخطر لازم نشود.
class LuxDb {
  LuxDb._();
  static final LuxDb instance = LuxDb._();

  static const int schemaVersion = 8;

  Database? _db;
  String? _path;

  Database get raw {
    final d = _db;
    if (d == null) {
      throw StateError('LuxDb.open() صدا زده نشده است');
    }
    return d;
  }

  String get path => _path ?? '';

  Future<void> open() async {
    if (_db != null) return;
    final dir = await getDatabasesPath();
    _path = p.join(dir, 'lux.db');
    _db = await openDatabase(
      _path!,
      version: schemaVersion,
      onConfigure: (db) async {
        await db.execute('PRAGMA foreign_keys = ON');
      },
      onCreate: (db, v) async {
        final batch = db.batch();
        for (final sql in _schema) {
          batch.execute(sql);
        }
        await batch.commit(noResult: true);
      },
      onUpgrade: (db, oldV, newV) async {
        // مهاجرت‌ها به‌ترتیب نسخه.
        if (oldV < 2) {
          // نسخه‌ی ۲: قابلیت رقابت (رقبا و نمره‌ی رقبا در هر امتحان)
          final batch = db.batch();
          for (final sql in _rivalrySchema) {
            batch.execute(sql);
          }
          await batch.commit(noResult: true);
        }
        if (oldV < 3) {
          // نسخه‌ی ۳: سهم نمره‌ی نهایی در هر درس، مستمر/نهایی بودنِ نمره، و مثبت/منفی بودنِ موردِ کلاسی
          for (final sql in _termUpgrade) {
            try {
              await db.execute(sql);
            } catch (_) {
              // ستون از قبل وجود دارد؛ مهم نیست.
            }
          }
        }
        if (oldV < 4) {
          // نسخه‌ی ۴: برنامه‌ی هفتگی (زنگ‌ها، بیکاری، تک‌زنگ متناوب)
          final batch = db.batch();
          for (final sql in _weekPlanSchema) {
            batch.execute(sql);
          }
          await batch.commit(noResult: true);
        }
        if (oldV < 5) {
          // نسخه‌ی ۵: مثبت و منفی و کنفرانسِ رقبا
          final batch = db.batch();
          for (final sql in _rivalExtraSchema) {
            batch.execute(sql);
          }
          await batch.commit(noResult: true);
        }
        if (oldV < 6) {
          // نسخه‌ی ۶: تقویم (یادآور، رویداد، تولد، تعطیلی) و ثبت غیبت
          final batch = db.batch();
          for (final sql in _calendarSchema) {
            batch.execute(sql);
          }
          await batch.commit(noResult: true);
        }
        if (oldV < 7) {
          // نسخه‌ی ۷: دفترچه‌ی اشتباهات + کیفیتِ تمرکزِ هر جلسه
          try {
            await db.execute('ALTER TABLE study_sessions ADD COLUMN quality INTEGER');
          } catch (_) {}
          final batch = db.batch();
          for (final sql in _reviewSchema) {
            batch.execute(sql);
          }
          await batch.commit(noResult: true);
        }
        if (oldV < 8) {
          // نسخه‌ی ۸: برنامه‌ی هوشمند، تحلیلِ بعد از امتحان، فلش‌کارت و امتحان آزمایشی
          final batch = db.batch();
          for (final sql in _smartSchema) {
            batch.execute(sql);
          }
          await batch.commit(noResult: true);
        }
      },
    );
  }

  Future<void> close() async {
    await _db?.close();
    _db = null;
  }

  // ───────── میانبرهای CRUD ─────────
  Future<int> insert(String table, Map<String, Object?> values) =>
      raw.insert(table, values, conflictAlgorithm: ConflictAlgorithm.replace);

  Future<int> update(String table, Map<String, Object?> values, {required String where, required List<Object?> args}) =>
      raw.update(table, values, where: where, whereArgs: args);

  Future<int> delete(String table, {required String where, required List<Object?> args}) =>
      raw.delete(table, where: where, whereArgs: args);

  Future<List<Map<String, Object?>>> query(String table,
          {String? where, List<Object?>? args, String? orderBy, int? limit}) =>
      raw.query(table, where: where, whereArgs: args, orderBy: orderBy, limit: limit);

  Future<List<Map<String, Object?>>> rawQuery(String sql, [List<Object?>? args]) => raw.rawQuery(sql, args);

  Future<int> count(String table, {String? where, List<Object?>? args}) async {
    final r = await raw.rawQuery('SELECT COUNT(*) AS c FROM $table${where == null ? '' : ' WHERE $where'}', args);
    return (r.first['c'] as int?) ?? 0;
  }

  // ───────── تنظیمات (کلید/مقدار) ─────────
  Future<String?> kvGet(String key) async {
    final r = await raw.query('settings', where: 'key = ?', whereArgs: [key], limit: 1);
    if (r.isEmpty) return null;
    return r.first['value'] as String?;
  }

  Future<void> kvSet(String key, String value) async {
    await raw.insert('settings', {'key': key, 'value': value}, conflictAlgorithm: ConflictAlgorithm.replace);
  }

  Future<void> kvDelete(String key) async {
    await raw.delete('settings', where: 'key = ?', whereArgs: [key]);
  }

  // ───────── پشتیبان ─────────
  /// نسخه‌ی پشتیبان از فایل پایگاه‌داده در [targetDir]. فایل ساخته‌شده را برمی‌گرداند.
  Future<File> backupTo(String targetDir, {String? name}) async {
    try {
      await raw.rawQuery('PRAGMA wal_checkpoint(TRUNCATE)');
    } catch (_) {}
    final dir = Directory(targetDir);
    if (!await dir.exists()) await dir.create(recursive: true);
    final stamp = DateTime.now().toIso8601String().replaceAll(':', '-').split('.').first;
    final out = File(p.join(targetDir, name ?? 'lux_$stamp.db'));
    return File(_path!).copy(out.path);
  }

  // ───────── طرح: رقابت (نسخه‌ی ۲) ─────────
  static const List<String> _rivalrySchema = <String>[
    '''CREATE TABLE rivals (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      color INTEGER NOT NULL DEFAULT 1,
      note TEXT,
      created_at INTEGER
    )''',
    '''CREATE TABLE rival_scores (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      rival_id INTEGER NOT NULL REFERENCES rivals(id) ON DELETE CASCADE,
      exam_id INTEGER NOT NULL REFERENCES exams(id) ON DELETE CASCADE,
      score REAL NOT NULL,
      UNIQUE (rival_id, exam_id)
    )''',
    'CREATE INDEX idx_rival_scores_exam ON rival_scores(exam_id)',
  ];

  // ───────── طرح: برنامه‌ی هوشمند (نسخه‌ی ۸) ─────────
  static const List<String> _smartSchema = <String>[
    '''CREATE TABLE IF NOT EXISTS smart_blocks (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      day INTEGER NOT NULL,
      start_min INTEGER NOT NULL,
      dur_min INTEGER NOT NULL,
      kind TEXT NOT NULL,
      course_id INTEGER REFERENCES courses(id) ON DELETE SET NULL,
      ref_id INTEGER,
      title TEXT NOT NULL,
      reason TEXT,
      status TEXT NOT NULL DEFAULT 'planned',
      locked INTEGER NOT NULL DEFAULT 0,
      started_at INTEGER,
      done_at INTEGER,
      created_at INTEGER
    )''',
    'CREATE INDEX IF NOT EXISTS idx_smart_blocks_day ON smart_blocks(day)',
    '''CREATE TABLE IF NOT EXISTS exam_reflections (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      exam_id INTEGER REFERENCES exams(id) ON DELETE CASCADE,
      course_id INTEGER REFERENCES courses(id) ON DELETE SET NULL,
      reasons TEXT,
      feel INTEGER,
      lost_note TEXT,
      created_at INTEGER
    )''',
    '''CREATE TABLE IF NOT EXISTS cards (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      course_id INTEGER REFERENCES courses(id) ON DELETE SET NULL,
      book_id INTEGER REFERENCES books(id) ON DELETE SET NULL,
      page INTEGER,
      ann_id INTEGER,
      front TEXT NOT NULL,
      back TEXT,
      ef REAL NOT NULL DEFAULT 2.5,
      interval_days INTEGER NOT NULL DEFAULT 0,
      reps INTEGER NOT NULL DEFAULT 0,
      lapses INTEGER NOT NULL DEFAULT 0,
      due_ts INTEGER,
      created_at INTEGER
    )''',
    'CREATE INDEX IF NOT EXISTS idx_cards_due ON cards(due_ts)',
    '''CREATE TABLE IF NOT EXISTS mocks (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      course_id INTEGER REFERENCES courses(id) ON DELETE SET NULL,
      exam_id INTEGER REFERENCES exams(id) ON DELETE SET NULL,
      at_ts INTEGER NOT NULL,
      dur_min INTEGER,
      score REAL,
      max_score REAL NOT NULL DEFAULT 20,
      note TEXT
    )''',
  ];

  // ───────── طرح: دفترچه‌ی اشتباهات (نسخه‌ی ۷) ─────────
  static const List<String> _reviewSchema = <String>[
    '''CREATE TABLE IF NOT EXISTS mistakes (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      course_id INTEGER REFERENCES courses(id) ON DELETE SET NULL,
      book_id INTEGER REFERENCES books(id) ON DELETE SET NULL,
      page INTEGER,
      title TEXT NOT NULL,
      answer TEXT,
      cause TEXT,
      photo_path TEXT,
      status TEXT NOT NULL DEFAULT 'open',
      ef REAL NOT NULL DEFAULT 2.5,
      interval_days INTEGER NOT NULL DEFAULT 0,
      reps INTEGER NOT NULL DEFAULT 0,
      due_ts INTEGER,
      review_count INTEGER NOT NULL DEFAULT 0,
      created_at INTEGER
    )''',
    'CREATE INDEX IF NOT EXISTS idx_mistakes_due ON mistakes(due_ts)',
  ];

  // ───────── طرح: تقویم و غیبت (نسخه‌ی ۶) ─────────
  static const List<String> _calendarSchema = <String>[
    '''CREATE TABLE IF NOT EXISTS cal_items (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      kind TEXT NOT NULL,
      title TEXT NOT NULL,
      day TEXT NOT NULL,
      time_min INTEGER,
      yearly INTEGER NOT NULL DEFAULT 0,
      remind_json TEXT,
      note TEXT,
      created_at INTEGER
    )''',
    '''CREATE TABLE IF NOT EXISTS attendance (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      day TEXT NOT NULL UNIQUE,
      kind TEXT NOT NULL,
      note TEXT,
      created_at INTEGER
    )''',
    'CREATE INDEX IF NOT EXISTS idx_cal_items_day ON cal_items(day)',
  ];

  // ───────── طرح: مثبت و منفی و کنفرانسِ رقبا (نسخه‌ی ۵) ─────────
  static const List<String> _rivalExtraSchema = <String>[
    '''CREATE TABLE IF NOT EXISTS rival_behavior (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      rival_id INTEGER NOT NULL REFERENCES rivals(id) ON DELETE CASCADE,
      course_id INTEGER NOT NULL REFERENCES courses(id) ON DELETE CASCADE,
      positives INTEGER NOT NULL DEFAULT 0,
      negatives INTEGER NOT NULL DEFAULT 0,
      UNIQUE (rival_id, course_id)
    )''',
    '''CREATE TABLE IF NOT EXISTS rival_conf (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      rival_id INTEGER NOT NULL REFERENCES rivals(id) ON DELETE CASCADE,
      course_id INTEGER NOT NULL REFERENCES courses(id) ON DELETE CASCADE,
      score REAL NOT NULL,
      at_ts INTEGER NOT NULL DEFAULT 0,
      UNIQUE (rival_id, course_id)
    )''',
  ];

  // ───────── طرح ─────────
  /// برنامه‌ی هفتگی: هر ردیف یک زنگ. kind: class (درس) | free (بیکاری) | alt (تک‌زنگ: هفته‌ی اول course_id، هفته‌ی دوم alt_course_id)
  static const List<String> _weekPlanSchema = <String>[
    '''CREATE TABLE IF NOT EXISTS week_plan (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      weekday INTEGER NOT NULL,
      period INTEGER NOT NULL,
      kind TEXT NOT NULL DEFAULT 'class',
      course_id INTEGER REFERENCES courses(id) ON DELETE SET NULL,
      alt_course_id INTEGER REFERENCES courses(id) ON DELETE SET NULL,
      note TEXT
    )''',
    'CREATE INDEX IF NOT EXISTS idx_week_plan ON week_plan(weekday, period)',
  ];

  /// مهاجرتِ نسخه‌ی ۳ (برای دیتابیس‌های قدیمی)
  static const List<String> _termUpgrade = <String>[
    'ALTER TABLE courses ADD COLUMN final_share REAL NOT NULL DEFAULT 50',
    "ALTER TABLE grades ADD COLUMN phase TEXT NOT NULL DEFAULT 'continuous'",
    'ALTER TABLE class_positives ADD COLUMN sign INTEGER NOT NULL DEFAULT 1',
  ];

  static const List<String> _schema = <String>[
    'CREATE TABLE settings (key TEXT PRIMARY KEY, value TEXT)',

    '''CREATE TABLE profile (
      id INTEGER PRIMARY KEY CHECK (id = 1),
      name TEXT NOT NULL,
      title_pref TEXT,
      level TEXT,
      grade INTEGER,
      track TEXT,
      prev_gpa REAL,
      birth_y INTEGER, birth_m INTEGER, birth_d INTEGER,
      photo_path TEXT,
      created_at INTEGER
    )''',

    '''CREATE TABLE education_years (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      year_label TEXT, level TEXT, grade INTEGER, track TEXT, gpa REAL, note TEXT
    )''',

    '''CREATE TABLE teachers (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL, phone TEXT, style_note TEXT, notes TEXT
    )''',

    '''CREATE TABLE courses (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      coef REAL NOT NULL DEFAULT 1,
      difficulty INTEGER NOT NULL DEFAULT 3,
      max_score REAL NOT NULL DEFAULT 20,
      pass_score REAL NOT NULL DEFAULT 10,
      teacher_id INTEGER REFERENCES teachers(id) ON DELETE SET NULL,
      color INTEGER, archived INTEGER NOT NULL DEFAULT 0,
      notes TEXT, created_at INTEGER,
      final_share REAL NOT NULL DEFAULT 50
    )''',

    '''CREATE TABLE class_slots (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      course_id INTEGER NOT NULL REFERENCES courses(id) ON DELETE CASCADE,
      weekday INTEGER NOT NULL, start_min INTEGER NOT NULL, end_min INTEGER NOT NULL, room TEXT
    )''',

    '''CREATE TABLE assessment_types (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      course_id INTEGER NOT NULL REFERENCES courses(id) ON DELETE CASCADE,
      name TEXT NOT NULL, weight REAL NOT NULL DEFAULT 1, max_score REAL NOT NULL DEFAULT 20
    )''',

    '''CREATE TABLE exams (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      course_id INTEGER NOT NULL REFERENCES courses(id) ON DELETE CASCADE,
      type_name TEXT, title TEXT,
      at_ts INTEGER NOT NULL,
      location TEXT, scope_note TEXT,
      weight REAL NOT NULL DEFAULT 1, max_score REAL NOT NULL DEFAULT 20,
      difficulty INTEGER NOT NULL DEFAULT 3, readiness INTEGER,
      status TEXT NOT NULL DEFAULT 'planned',
      cancel_reason TEXT, new_at_ts INTEGER,
      score REAL,
      ask_offset_min INTEGER NOT NULL DEFAULT 90,
      remind_json TEXT,
      created_at INTEGER
    )''',

    '''CREATE TABLE grades (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      course_id INTEGER NOT NULL REFERENCES courses(id) ON DELETE CASCADE,
      exam_id INTEGER REFERENCES exams(id) ON DELETE SET NULL,
      name TEXT, score REAL NOT NULL, max_score REAL NOT NULL DEFAULT 20,
      weight REAL NOT NULL DEFAULT 1, at_ts INTEGER NOT NULL, kind TEXT,
      phase TEXT NOT NULL DEFAULT 'continuous'
    )''',

    '''CREATE TABLE books (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      course_id INTEGER REFERENCES courses(id) ON DELETE SET NULL,
      title TEXT NOT NULL, pages INTEGER, file_path TEXT, cover_path TEXT,
      last_page INTEGER NOT NULL DEFAULT 0, added_at INTEGER
    )''',

    '''CREATE TABLE chapters (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      book_id INTEGER NOT NULL REFERENCES books(id) ON DELETE CASCADE,
      title TEXT NOT NULL, start_page INTEGER, end_page INTEGER,
      done INTEGER NOT NULL DEFAULT 0, review_count INTEGER NOT NULL DEFAULT 0,
      ef REAL NOT NULL DEFAULT 2.5, interval_days INTEGER NOT NULL DEFAULT 0,
      reps INTEGER NOT NULL DEFAULT 0, due_ts INTEGER
    )''',

    '''CREATE TABLE reading_sessions (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      book_id INTEGER NOT NULL REFERENCES books(id) ON DELETE CASCADE,
      start_ts INTEGER NOT NULL, end_ts INTEGER NOT NULL,
      from_page INTEGER, to_page INTEGER
    )''',

    '''CREATE TABLE annotations (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      book_id INTEGER NOT NULL REFERENCES books(id) ON DELETE CASCADE,
      page INTEGER NOT NULL, kind TEXT NOT NULL, data TEXT, note TEXT, color INTEGER, created_at INTEGER
    )''',

    '''CREATE TABLE study_sessions (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      course_id INTEGER REFERENCES courses(id) ON DELETE SET NULL,
      book_id INTEGER REFERENCES books(id) ON DELETE SET NULL,
      start_ts INTEGER NOT NULL, end_ts INTEGER,
      kind TEXT NOT NULL DEFAULT 'pomodoro',
      planned_min INTEGER, completed INTEGER NOT NULL DEFAULT 0, quality INTEGER
    )''',

    '''CREATE TABLE tasks (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      course_id INTEGER REFERENCES courses(id) ON DELETE SET NULL,
      title TEXT NOT NULL, notes TEXT,
      due_ts INTEGER, priority INTEGER NOT NULL DEFAULT 2,
      status TEXT NOT NULL DEFAULT 'open',
      remind_json TEXT, created_at INTEGER, done_at INTEGER
    )''',

    '''CREATE TABLE journal (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      day TEXT NOT NULL UNIQUE, text TEXT,
      mood INTEGER, energy INTEGER, sleep_h REAL, created_at INTEGER
    )''',

    '''CREATE TABLE achievements (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      key TEXT NOT NULL UNIQUE, unlocked_at INTEGER NOT NULL
    )''',

    '''CREATE TABLE class_positives (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      course_id INTEGER REFERENCES courses(id) ON DELETE SET NULL,
      teacher_id INTEGER REFERENCES teachers(id) ON DELETE SET NULL,
      at_ts INTEGER NOT NULL, count INTEGER NOT NULL DEFAULT 1, note TEXT,
      sign INTEGER NOT NULL DEFAULT 1
    )''',

    '''CREATE TABLE discipline_warnings (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      at_ts INTEGER NOT NULL, type TEXT, issuer TEXT, reason TEXT,
      severity INTEGER NOT NULL DEFAULT 1, points REAL,
      followup_ts INTEGER, resolved INTEGER NOT NULL DEFAULT 0, note TEXT
    )''',

    '''CREATE TABLE scheduled_notifs (
      id INTEGER PRIMARY KEY,
      kind TEXT NOT NULL, ref_id INTEGER, fire_ts INTEGER NOT NULL,
      title TEXT, body TEXT, payload TEXT
    )''',

    'CREATE INDEX idx_exams_at ON exams(at_ts)',
    'CREATE INDEX idx_exams_course ON exams(course_id)',
    'CREATE INDEX idx_grades_course ON grades(course_id, at_ts)',
    'CREATE INDEX idx_tasks_due ON tasks(due_ts)',
    'CREATE INDEX idx_reading_book ON reading_sessions(book_id, start_ts)',
    'CREATE INDEX idx_study_start ON study_sessions(start_ts)',
    'CREATE INDEX idx_positives ON class_positives(course_id, at_ts)',
    'CREATE INDEX idx_warnings ON discipline_warnings(at_ts)',
    'CREATE INDEX idx_notifs_fire ON scheduled_notifs(fire_ts)',
    ..._rivalrySchema,
    ..._weekPlanSchema,
    ..._rivalExtraSchema,
    ..._calendarSchema,
    ..._reviewSchema,
    ..._smartSchema,
  ];
}
