import '../core/util.dart';
import '../engine/grades.dart';
import 'database.dart';

/// پرس‌وجوهای مشترکِ درس‌ها، معلم‌ها و نمره‌ها.
class StudyRepo {
  StudyRepo._();

  static Future<List<Map<String, Object?>>> courses() => LuxDb.instance.rawQuery(
        'SELECT c.*, t.name AS teacher_name FROM courses c '
        'LEFT JOIN teachers t ON t.id = c.teacher_id WHERE c.archived = 0 ORDER BY c.id',
      );

  static Future<List<Map<String, Object?>>> teachers() => LuxDb.instance.query('teachers', orderBy: 'id');

  // ───────── مستمر / نهایی ─────────

  /// نمره‌ها همراه با «نهایی بودن»: نمره‌ی وابسته به امتحان از نوعِ امتحان می‌آید
  /// (پایان‌ترم = نهایی)، نمره‌ی دستی از ستونِ phase.
  static const String _gradeSelect =
      'SELECT g.*, CASE WHEN e.id IS NOT NULL THEN (CASE WHEN e.type_name = ? THEN 1 ELSE 0 END) '
      "ELSE (CASE WHEN g.phase = 'final' THEN 1 ELSE 0 END) END AS is_final "
      'FROM grades g LEFT JOIN exams e ON e.id = g.exam_id';

  /// نمره‌های یک درس (جدیدترین اول) با ستونِ is_final
  static Future<List<Map<String, Object?>>> gradesOfCourse(int courseId) =>
      LuxDb.instance.rawQuery('$_gradeSelect WHERE g.course_id = ? ORDER BY g.at_ts DESC', [kFinalExamType, courseId]);

  /// قانونِ اثرِ مثبت و منفی (تنظیم‌شده توسط کاربر)
  static Future<BehaviorRule> behaviorRule() async {
    final db = LuxDb.instance;
    double rd(String? v, double d) => (v == null ? null : double.tryParse(v)) ?? d;
    const def = BehaviorRule();
    return BehaviorRule(
      positiveValue: rd(await db.kvGet('beh_pos_value'), def.positiveValue),
      negativeValue: rd(await db.kvGet('beh_neg_value'), def.negativeValue),
      cap: rd(await db.kvGet('beh_cap'), def.cap),
    );
  }

  static Future<void> saveBehaviorRule(BehaviorRule r) async {
    final db = LuxDb.instance;
    await db.kvSet('beh_pos_value', r.positiveValue.toString());
    await db.kvSet('beh_neg_value', r.negativeValue.toString());
    await db.kvSet('beh_cap', r.cap.toString());
  }

  /// شمارِ مثبت و منفی هر درس: {شناسه‌ی درس: [مثبت، منفی]}
  static Future<Map<int, List<int>>> behaviorCounts() async {
    final rows = await LuxDb.instance.rawQuery(
      'SELECT course_id, sign, SUM(count) AS n FROM class_positives WHERE course_id IS NOT NULL GROUP BY course_id, sign',
    );
    final out = <int, List<int>>{};
    for (final r in rows) {
      final v = out.putIfAbsent(asInt(r['course_id']), () => <int>[0, 0]);
      if (asInt(r['sign'], 1) < 0) {
        v[1] += asInt(r['n']);
      } else {
        v[0] += asInt(r['n']);
      }
    }
    return out;
  }

  /// نمره‌ی کلِ یک درس با معادله‌ی مستمر/نهایی. [scale] مقیاسِ نمایش است (پیش‌فرض: بیشینه‌ی نمره‌ی خودِ درس).
  static Future<TermScore> termScoreOf(int courseId, {double? scale}) async {
    final db = LuxDb.instance;
    final c = await db.query('courses', where: 'id = ?', args: [courseId], limit: 1);
    final sc = scale ?? (c.isEmpty ? 20.0 : asDouble(c.first['max_score'], 20));
    final share = (c.isEmpty ? 50.0 : asDouble(c.first['final_share'], 50)) / 100;
    final rule = await behaviorRule();
    final counts = (await behaviorCounts())[courseId] ?? <int>[0, 0];
    final rows = await gradesOfCourse(courseId);
    return _termFrom(rows, rule.delta(counts[0], counts[1], scale: sc), share, sc);
  }

  static TermScore _termFrom(List<Map<String, Object?>> rows, double behavior, double share, double scale) {
    final cont = <WeightedScore>[];
    final fin = <WeightedScore>[];
    for (final r in rows) {
      final w = WeightedScore(asDouble(r['score']), asDouble(r['max_score'], 20), asDouble(r['weight'], 1));
      (asInt(r['is_final']) == 1 ? fin : cont).add(w);
    }
    return TermMath.compute(continuous: cont, finals: fin, behavior: behavior, finalShare: share, scale: scale);
  }

  /// نمره‌ی کلِ همه‌ی درس‌ها (روی مقیاس ۲۰) — برای معدل، تحلیل و فهرست درس‌ها.
  static Future<Map<int, TermScore>> termScores() async {
    final db = LuxDb.instance;
    final rule = await behaviorRule();
    final counts = await behaviorCounts();
    final courseRows = await db.rawQuery('SELECT id, final_share FROM courses');
    final rows = await db.rawQuery(_gradeSelect, [kFinalExamType]);
    final by = <int, List<Map<String, Object?>>>{};
    for (final r in rows) {
      by.putIfAbsent(asInt(r['course_id']), () => <Map<String, Object?>>[]).add(r);
    }
    final out = <int, TermScore>{};
    for (final c in courseRows) {
      final id = asInt(c['id']);
      final list = by[id];
      if (list == null || list.isEmpty) continue;
      final cnt = counts[id] ?? <int>[0, 0];
      out[id] = _termFrom(list, rule.delta(cnt[0], cnt[1]), asDouble(c['final_share'], 50) / 100, 20);
    }
    return out;
  }

  static Future<Map<int, double>> courseAverages() async {
    final ts = await termScores();
    final out = <int, double>{};
    ts.forEach((k, v) {
      final t = v.total;
      if (t != null) out[k] = t;
    });
    return out;
  }

  /// معدل کل (ضریب‌دار) یا null
  static Future<double?> gpa() async {
    final avgs = await courseAverages();
    final cs = await courses();
    final list = <CourseResult>[];
    for (final c in cs) {
      final a = avgs[asInt(c['id'])];
      if (a != null) list.add(CourseResult(a, asDouble(c['coef'], 1)));
    }
    return GradeMath.gpa(list);
  }
}
