import '../core/util.dart';
import '../engine/grades.dart';
import 'database.dart';

/// پرس‌وجوهای مشترکِ درس‌ها، معلم‌ها و نمره‌ها.
class StudyRepo {
  StudyRepo._();

  static Future<List<Map<String, Object?>>> courses() => LuxDb.instance.rawQuery(
        'SELECT c.*, t.name AS teacher_name FROM courses c '
        'LEFT JOIN teachers t ON t.id = c.teacher_id WHERE c.archived = 0 ORDER BY c.id',
      );

  static Future<List<Map<String, Object?>>> teachers() => LuxDb.instance.query('teachers', orderBy: 'id');

  static Future<Map<int, double>> courseAverages() async {
    final rows = await LuxDb.instance.rawQuery('SELECT course_id, score, max_score, weight FROM grades');
    final by = <int, List<WeightedScore>>{};
    for (final r in rows) {
      by.putIfAbsent(asInt(r['course_id']), () => <WeightedScore>[]).add(
            WeightedScore(asDouble(r['score']), asDouble(r['max_score'], 20), asDouble(r['weight'], 1)),
          );
    }
    final out = <int, double>{};
    by.forEach((k, v) {
      final a = GradeMath.weightedAverage(v);
      if (a != null) out[k] = a;
    });
    return out;
  }

  /// معدل کل (ضریب‌دار) یا null
  static Future<double?> gpa() async {
    final avgs = await courseAverages();
    final cs = await courses();
    final list = <CourseResult>[];
    for (final c in cs) {
      final a = avgs[asInt(c['id'])];
      if (a != null) list.add(CourseResult(a, asDouble(c['coef'], 1)));
    }
    return GradeMath.gpa(list);
  }
}
