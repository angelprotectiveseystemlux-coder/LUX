import '../core/jalali_utils.dart';
import '../core/util.dart';
import 'database.dart';

/// یک زنگ از برنامه‌ی هفتگی.
/// kind: class = درس | free = بیکاری | alt = تک‌زنگِ متناوب (هفته‌ی اول courseId، هفته‌ی دوم altCourseId)
class PlanPeriod {
  final int id;
  final int weekday; // شنبه = ۰ … جمعه = ۶
  final int period; // شماره‌ی زنگ
  final String kind;
  final int? courseId;
  final int? altCourseId;
  final String courseName;
  final String altName;
  final Object? color;
  final String note;

  const PlanPeriod({
    required this.id,
    required this.weekday,
    required this.period,
    required this.kind,
    required this.courseId,
    required this.altCourseId,
    required this.courseName,
    required this.altName,
    required this.color,
    required this.note,
  });

  bool get isFree => kind == 'free';
  bool get isAlt => kind == 'alt';

  /// درسِ فعالِ این زنگ در هفته‌ی [parity] (۰ = اول، ۱ = دوم)؛ برای بیکاری null.
  int? activeId(int parity) {
    if (isFree) return null;
    if (isAlt && parity == 1) return altCourseId;
    return courseId;
  }

  String activeName(int parity) {
    if (isFree) return 'بیکاری';
    if (isAlt && parity == 1) return altName.isEmpty ? 'بدون درس' : altName;
    return courseName.isEmpty ? 'بدون درس' : courseName;
  }

  /// در تک‌زنگ: نامِ درسِ هفته‌ی دیگر
  String otherName(int parity) {
    if (!isAlt) return '';
    final n = parity == 1 ? courseName : altName;
    return n.isEmpty ? 'بدون درس' : n;
  }
}

/// کتاب‌هایی که برای یک درس باید در کیف باشد.
class BagItem {
  final int courseId;
  final String course;
  final List<String> books;
  const BagItem(this.courseId, this.course, this.books);

  /// نمایش: اگر کتابی ثبت شده باشد نامِ کتاب‌ها، وگرنه نامِ درس
  String get text => books.isEmpty ? course : books.join('، ');
}

/// برنامه‌ی یک روزِ مشخص + کیفِ آن روز.
class DayBag {
  final DateTime date;
  final String label; // امروز | فردا | نامِ روز
  final int parity; // ۰ = هفته‌ی اول، ۱ = هفته‌ی دوم
  final List<PlanPeriod> periods;
  final List<BagItem> bag;
  const DayBag({required this.date, required this.label, required this.parity, required this.periods, required this.bag});

  String get weekdayName => jalaliWeekdays[weekdayIndex(date)];
  String get parityName => parity == 0 ? 'هفته‌ی اول' : 'هفته‌ی دوم';
  String get bagText => bag.map((b) => b.text).join('، ');
}

/// تنظیمات برنامه‌ی هفتگی و یادآورِ کیف.
class WeekPlanSettings {
  final int cutoffMin; // از این ساعت به بعد، «روزِ بعد» حساب می‌شود
  final bool remindOn;
  final int remind1; // دقیقه‌ی روز
  final bool remind2On;
  final int remind2;
  const WeekPlanSettings({
    this.cutoffMin = 14 * 60,
    this.remindOn = true,
    this.remind1 = 17 * 60,
    this.remind2On = true,
    this.remind2 = 21 * 60 + 30,
  });

  WeekPlanSettings copyWith({int? cutoffMin, bool? remindOn, int? remind1, bool? remind2On, int? remind2}) =>
      WeekPlanSettings(
        cutoffMin: cutoffMin ?? this.cutoffMin,
        remindOn: remindOn ?? this.remindOn,
        remind1: remind1 ?? this.remind1,
        remind2On: remind2On ?? this.remind2On,
        remind2: remind2 ?? this.remind2,
      );
}

class WeekPlanRepo {
  WeekPlanRepo._();

  // ───────── تنظیمات ─────────

  static Future<WeekPlanSettings> settings() async {
    final db = LuxDb.instance;
    const d = WeekPlanSettings();
    int rd(String? v, int def) => (v == null ? null : int.tryParse(v)) ?? def;
    return WeekPlanSettings(
      cutoffMin: rd(await db.kvGet('wk_cutoff'), d.cutoffMin),
      remindOn: (await db.kvGet('wk_remind_on') ?? '1') == '1',
      remind1: rd(await db.kvGet('wk_remind_1'), d.remind1),
      remind2On: (await db.kvGet('wk_remind_2_on') ?? '1') == '1',
      remind2: rd(await db.kvGet('wk_remind_2'), d.remind2),
    );
  }

  static Future<void> saveSettings(WeekPlanSettings s) async {
    final db = LuxDb.instance;
    await db.kvSet('wk_cutoff', s.cutoffMin.toString());
    await db.kvSet('wk_remind_on', s.remindOn ? '1' : '0');
    await db.kvSet('wk_remind_1', s.remind1.toString());
    await db.kvSet('wk_remind_2_on', s.remind2On ? '1' : '0');
    await db.kvSet('wk_remind_2', s.remind2.toString());
  }

  // ───────── هفته‌ی اول/دوم ─────────

  /// شنبه‌ی همان هفته (بدون ساعت)
  static DateTime weekStart(DateTime d) => DateTime(d.year, d.month, d.day - weekdayIndex(d));

  static int _weeksBetween(DateTime a, DateTime b) {
    final x = DateTime.utc(a.year, a.month, a.day);
    final y = DateTime.utc(b.year, b.month, b.day);
    return y.difference(x).inDays ~/ 7;
  }

  static Future<DateTime> _refWeek() async {
    final v = await LuxDb.instance.kvGet('wk_ref');
    final ms = v == null ? null : int.tryParse(v);
    if (ms == null) {
      final ref = weekStart(DateTime.now());
      await LuxDb.instance.kvSet('wk_ref', ref.millisecondsSinceEpoch.toString());
      return ref;
    }
    return DateTime.fromMillisecondsSinceEpoch(ms);
  }

  /// ۰ = هفته‌ی اول، ۱ = هفته‌ی دوم، برای هفته‌ای که [d] در آن است.
  static Future<int> parityOf(DateTime d) async {
    final ref = await _refWeek();
    return _weeksBetween(weekStart(ref), weekStart(d)) % 2;
  }

  /// «این هفته، هفته‌ی اول/دوم است» را تنظیم می‌کند.
  static Future<void> setCurrentParity(int parity) async {
    final base = weekStart(DateTime.now());
    final ref = parity == 0 ? base : DateTime(base.year, base.month, base.day - 7);
    await LuxDb.instance.kvSet('wk_ref', ref.millisecondsSinceEpoch.toString());
  }

  // ───────── زنگ‌ها ─────────

  static Future<List<PlanPeriod>> all() async {
    final rows = await LuxDb.instance.rawQuery(
      'SELECT w.*, c.name AS cname, c.color AS ccolor, a.name AS aname FROM week_plan w '
      'LEFT JOIN courses c ON c.id = w.course_id '
      'LEFT JOIN courses a ON a.id = w.alt_course_id '
      'ORDER BY w.weekday, w.period, w.id',
    );
    return [
      for (final r in rows)
        PlanPeriod(
          id: asInt(r['id']),
          weekday: asInt(r['weekday']),
          period: asInt(r['period'], 1),
          kind: asStr(r['kind'], 'class'),
          courseId: r['course_id'] == null ? null : asInt(r['course_id']),
          altCourseId: r['alt_course_id'] == null ? null : asInt(r['alt_course_id']),
          courseName: asStr(r['cname']),
          altName: asStr(r['aname']),
          color: r['ccolor'],
          note: asStr(r['note']),
        ),
    ];
  }

  static Future<Map<int, List<String>>> _booksByCourse() async {
    final rows = await LuxDb.instance.rawQuery(
      'SELECT course_id, title FROM books WHERE course_id IS NOT NULL ORDER BY id',
    );
    final out = <int, List<String>>{};
    for (final r in rows) {
      final t = asStr(r['title']).trim();
      if (t.isEmpty) continue;
      out.putIfAbsent(asInt(r['course_id']), () => <String>[]).add(t);
    }
    return out;
  }

  /// برنامه و کیفِ یک روزِ مشخص
  static Future<DayBag> dayBag(
    DateTime date, {
    required String label,
    List<PlanPeriod>? plan,
    Map<int, List<String>>? books,
  }) async {
    final all0 = plan ?? await WeekPlanRepo.all();
    final bk = books ?? await _booksByCourse();
    final parity = await parityOf(date);
    final wd = weekdayIndex(date);
    final periods = [for (final p in all0) if (p.weekday == wd) p];
    final seen = <int>{};
    final bag = <BagItem>[];
    for (final p in periods) {
      final id = p.activeId(parity);
      if (id == null || !seen.add(id)) continue;
      bag.add(BagItem(id, p.activeName(parity), bk[id] ?? const <String>[]));
    }
    return DayBag(date: dateOnly(date), label: label, parity: parity, periods: periods, bag: bag);
  }

  /// روزِ مدرسه‌ای که از لحظه‌ی [moment] به بعد باید برایش کیف بست:
  /// اگر [moment] در یک روزِ مدرسه و قبل از ساعتِ [WeekPlanSettings.cutoffMin] باشد، همان روز؛
  /// وگرنه نزدیک‌ترین روزِ مدرسه‌ی بعدی (روزهای بدون زنگ، مثل پنجشنبه و جمعه، رد می‌شوند).
  static Future<DayBag?> targetFor(
    DateTime moment, {
    WeekPlanSettings? settings,
    List<PlanPeriod>? plan,
    Map<int, List<String>>? books,
  }) async {
    final s = settings ?? await WeekPlanRepo.settings();
    final p = plan ?? await WeekPlanRepo.all();
    final school = {for (final x in p) x.weekday};
    if (school.isEmpty) return null;
    final today = dateOnly(moment);
    final minutes = moment.hour * 60 + moment.minute;
    int? offset;
    if (school.contains(weekdayIndex(today)) && minutes < s.cutoffMin) {
      offset = 0;
    } else {
      for (var i = 1; i <= 7; i++) {
        final d = DateTime(today.year, today.month, today.day + i);
        if (school.contains(weekdayIndex(d))) {
          offset = i;
          break;
        }
      }
    }
    if (offset == null) return null;
    final date = DateTime(today.year, today.month, today.day + offset);
    final label = offset == 0 ? 'امروز' : (offset == 1 ? 'فردا' : jalaliWeekdays[weekdayIndex(date)]);
    return dayBag(date, label: label, plan: p, books: books);
  }

  /// برای صفحه‌ها: همین لحظه
  static Future<DayBag?> target() => targetFor(DateTime.now());
}
