import 'dart:convert';

import 'package:shamsi_date/shamsi_date.dart';

import '../core/app_bus.dart';
import '../core/jalali_utils.dart';
import '../core/util.dart';
import '../services/notification_service.dart';
import 'database.dart';
import 'holidays.dart';
import 'profile_repo.dart';

/// نوعِ هر ردیف در تقویم (ترتیب = ترتیبِ نمایش در فهرستِ یک روز)
enum EntryKind { holiday, userHoliday, occasion, world, birthday, exam, task, reminder, event, attendance }

class CalEntry {
  final EntryKind kind;
  final String title;
  final String? sub;
  final int? minutes; // ساعت (دقیقه از نیمه‌شب)
  final String? table; // tasks | cal_items | attendance
  final int? id;
  final bool tentative;
  final bool done;
  final Map<String, Object?>? raw;

  const CalEntry({
    required this.kind,
    required this.title,
    this.sub,
    this.minutes,
    this.table,
    this.id,
    this.tentative = false,
    this.done = false,
    this.raw,
  });

  bool get isOfficialHoliday => kind == EntryKind.holiday;
  bool get isMine => kind.index >= EntryKind.birthday.index;
  bool get editable => table != null && raw != null;
}

class CalendarRepo {
  CalendarRepo._();

  static String key(DateTime d) => '${d.year}-${two(d.month)}-${two(d.day)}';

  static DateTime parseKey(String s) {
    final p = s.split('-');
    if (p.length != 3) return dateOnly(DateTime.now());
    return DateTime(int.tryParse(p[0]) ?? 2000, int.tryParse(p[1]) ?? 1, int.tryParse(p[2]) ?? 1);
  }

  static const Map<String, String> itemKinds = <String, String>{
    'reminder': 'یادآور',
    'event': 'رویداد',
    'birthday': 'تولد',
    'holiday': 'تعطیلی',
  };

  static const Map<String, String> attendanceKinds = <String, String>{
    'absent': 'غیبت',
    'early': 'زود رفتن',
    'holiday': 'مدرسه تعطیل بود',
    'present': 'حضور (با گوشی)',
  };

  static String clock(int minutes) => '${two(minutes ~/ 60)}:${two(minutes % 60)}';

  // ───────────────────────── خواندن ─────────────────────────

  /// همه‌ی چیزهای بازه‌ی [from, to] (شاملِ هر دو سر) به‌تفکیکِ روز؛ کلید: yyyy-mm-dd
  static Future<Map<String, List<CalEntry>>> load(DateTime from, DateTime to) async {
    final a = dateOnly(from);
    final b = dateOnly(to);
    final out = <String, List<CalEntry>>{};
    void add(DateTime d, CalEntry e) => out.putIfAbsent(key(d), () => <CalEntry>[]).add(e);

    // ۱) تعطیلات و مناسبت‌ها
    for (var d = a; !d.isAfter(b); d = DateTime(d.year, d.month, d.day + 1)) {
      for (final o in HolidayData.of(d)) {
        add(
          d,
          CalEntry(
            kind: o.type == OccasionType.holiday
                ? EntryKind.holiday
                : (o.type == OccasionType.world ? EntryKind.world : EntryKind.occasion),
            title: o.title,
            tentative: o.tentative,
          ),
        );
      }
    }

    final db = LuxDb.instance;
    final jFrom = Jalali.fromDateTime(a);
    final jTo = Jalali.fromDateTime(b);

    // تاریخ سالانه‌ی یک روزِ پایه در بازه
    List<DateTime> yearlyHits(DateTime base) {
      final jb = Jalali.fromDateTime(base);
      final hits = <DateTime>[];
      for (var y = jFrom.year; y <= jTo.year; y++) {
        final len = jalaliMonthLength(y, jb.month);
        final d = Jalali(y, jb.month, jb.day > len ? len : jb.day).toDateTime();
        final dd = dateOnly(d);
        if (!dd.isBefore(a) && !dd.isAfter(b)) hits.add(dd);
      }
      return hits;
    }

    // ۲) چیزهای خودم (یادآور، رویداد، تولد، تعطیلیِ شخصی)
    final items = await db.query('cal_items');
    for (final r in items) {
      final base = parseKey(asStr(r['day']));
      final kindStr = asStr(r['kind'], 'reminder');
      final yearly = asInt(r['yearly']) == 1;
      final hits = yearly ? yearlyHits(base) : <DateTime>[if (!base.isBefore(a) && !base.isAfter(b)) base];
      final tm = r['time_min'] == null ? null : asInt(r['time_min']);
      final note = asStr(r['note']);
      for (final d in hits) {
        final subParts = <String>[];
        if (tm != null) subParts.add(clock(tm));
        if (kindStr == 'birthday' && yearly) {
          final age = Jalali.fromDateTime(d).year - Jalali.fromDateTime(base).year;
          if (age > 0) subParts.add('${faDigits(age)} ساله می‌شود');
        }
        if (note.isNotEmpty) subParts.add(note);
        add(
          d,
          CalEntry(
            kind: kindStr == 'birthday'
                ? EntryKind.birthday
                : (kindStr == 'holiday' ? EntryKind.userHoliday : (kindStr == 'event' ? EntryKind.event : EntryKind.reminder)),
            title: kindStr == 'birthday' ? 'تولد ${asStr(r['title'])} 🎂' : asStr(r['title']),
            sub: subParts.isEmpty ? null : subParts.join(' · '),
            minutes: tm,
            table: 'cal_items',
            id: asInt(r['id']),
            raw: r,
          ),
        );
      }
    }

    // ۳) تولدِ خودِ کاربر (از پروفایل)
    try {
      final p = await ProfileRepo.get();
      if (p != null && p.birthM >= 1 && p.birthM <= 12) {
        for (var y = jFrom.year; y <= jTo.year; y++) {
          final len = jalaliMonthLength(y, p.birthM);
          final d = dateOnly(Jalali(y, p.birthM, p.birthD > len ? len : p.birthD).toDateTime());
          if (d.isBefore(a) || d.isAfter(b)) continue;
          final age = y - p.birthY;
          add(
            d,
            CalEntry(
              kind: EntryKind.birthday,
              title: 'تولد تو 🎂',
              sub: age > 0 ? '${faDigits(age)} ساله می‌شوی' : null,
            ),
          );
        }
      }
    } catch (_) {}

    final fromMs = a.millisecondsSinceEpoch;
    final toMs = DateTime(b.year, b.month, b.day + 1).millisecondsSinceEpoch;

    // ۴) تکلیف‌ها
    final tasks = await db.rawQuery(
      'SELECT t.*, c.name AS course FROM tasks t LEFT JOIN courses c ON c.id = t.course_id '
      'WHERE t.due_ts IS NOT NULL AND t.due_ts >= ? AND t.due_ts < ?',
      [fromMs, toMs],
    );
    for (final t in tasks) {
      final due = fromTs(t['due_ts']);
      final course = asStr(t['course']);
      add(
        due,
        CalEntry(
          kind: EntryKind.task,
          title: asStr(t['title']),
          sub: '${clock(due.hour * 60 + due.minute)}${course.isEmpty ? '' : ' · $course'}',
          minutes: due.hour * 60 + due.minute,
          table: 'tasks',
          id: asInt(t['id']),
          done: asStr(t['status']) == 'done',
          raw: t,
        ),
      );
    }

    // ۵) امتحان‌ها
    final exams = await db.rawQuery(
      'SELECT e.*, c.name AS course FROM exams e JOIN courses c ON c.id = e.course_id '
      'WHERE e.at_ts >= ? AND e.at_ts < ?',
      [fromMs, toMs],
    );
    for (final e in exams) {
      final at = fromTs(e['at_ts']);
      final what = asStr(e['title']).isNotEmpty ? asStr(e['title']) : asStr(e['type_name'], 'امتحان');
      add(
        at,
        CalEntry(
          kind: EntryKind.exam,
          title: 'امتحان ${asStr(e['course'])}',
          sub: '${clock(at.hour * 60 + at.minute)} · $what',
          minutes: at.hour * 60 + at.minute,
          done: asStr(e['status']) == 'done',
        ),
      );
    }

    // ۶) حضور و غیاب
    final att = await db.query('attendance', where: 'day >= ? AND day <= ?', args: [key(a), key(b)]);
    for (final r in att) {
      final d = parseKey(asStr(r['day']));
      final k = asStr(r['kind']);
      add(
        d,
        CalEntry(
          kind: EntryKind.attendance,
          title: _attendanceTitle(k),
          sub: asStr(r['note']).isEmpty ? null : asStr(r['note']),
          table: 'attendance',
          id: asInt(r['id']),
          raw: r,
        ),
      );
    }

    for (final list in out.values) {
      list.sort((x, y) {
        final c = x.kind.index.compareTo(y.kind.index);
        if (c != 0) return c;
        return (x.minutes ?? -1).compareTo(y.minutes ?? -1);
      });
    }
    return out;
  }

  static String _attendanceTitle(String k) {
    switch (k) {
      case 'absent':
        return 'غیبت از مدرسه';
      case 'early':
        return 'زودتر از مدرسه برگشتی';
      case 'holiday':
        return 'مدرسه تعطیل بود';
      default:
        return 'در مدرسه بودی';
    }
  }

  // ───────────────────────── چیزهای خودم ─────────────────────────

  static Future<int> saveItem({
    int? id,
    required String kind,
    required String title,
    required DateTime day,
    int? timeMin,
    bool yearly = false,
    List<int> remind = const <int>[],
    String note = '',
  }) async {
    final values = <String, Object?>{
      'kind': kind,
      'title': title,
      'day': key(day),
      'time_min': timeMin,
      'yearly': yearly ? 1 : 0,
      'remind_json': jsonEncode(remind),
      'note': note,
    };
    int rid;
    if (id == null) {
      values['created_at'] = DateTime.now().millisecondsSinceEpoch;
      rid = await LuxDb.instance.insert('cal_items', values);
    } else {
      await LuxDb.instance.update('cal_items', values, where: 'id = ?', args: [id]);
      rid = id;
    }
    await syncItem(rid);
    AppBus.bump();
    return rid;
  }

  static Future<void> deleteItem(int id) async {
    await _cancel(id);
    await LuxDb.instance.delete('cal_items', where: 'id = ?', args: [id]);
    AppBus.bump();
  }

  // ───────────────────────── یادآورها ─────────────────────────

  static const int _notifBase = 300000;
  static const int _slots = 4;
  static int _nid(int id, int k) => _notifBase + id * 10 + k;

  static List<int> parseOffsets(Object? json) {
    if (json == null) return <int>[];
    try {
      final v = jsonDecode(json.toString());
      if (v is List) return v.map((e) => asInt(e)).where((e) => e >= 0).toList();
    } catch (_) {}
    return <int>[];
  }

  static Future<void> _cancel(int id) async {
    for (var k = 0; k < _slots; k++) {
      try {
        await NotificationService.instance.cancel(_nid(id, k));
      } catch (_) {}
    }
  }

  /// نزدیک‌ترین زمانِ وقوعِ یک ردیف (برای سالانه‌ها: اولین سالگردِ بعدی)
  static DateTime? _nextFire(Map<String, Object?> r, DateTime now) {
    final base = parseKey(asStr(r['day']));
    final kind = asStr(r['kind']);
    final tm = r['time_min'] == null ? (kind == 'birthday' ? 9 * 60 : 8 * 60) : asInt(r['time_min']);
    DateTime at(DateTime d) => DateTime(d.year, d.month, d.day, tm ~/ 60, tm % 60);
    if (asInt(r['yearly']) != 1) return at(base);
    final jb = Jalali.fromDateTime(base);
    final jn = Jalali.fromDateTime(now);
    for (var y = jn.year; y <= jn.year + 2; y++) {
      final len = jalaliMonthLength(y, jb.month);
      final d = at(Jalali(y, jb.month, jb.day > len ? len : jb.day).toDateTime());
      if (d.isAfter(now)) return d;
    }
    return null;
  }

  static Future<void> syncItem(int id) async {
    await _cancel(id);
    final rows = await LuxDb.instance.query('cal_items', where: 'id = ?', args: [id], limit: 1);
    if (rows.isEmpty) return;
    final r = rows.first;
    final kind = asStr(r['kind']);
    if (kind == 'holiday') return;
    final offsets = parseOffsets(r['remind_json']);
    if (offsets.isEmpty) return;
    final now = DateTime.now();
    final fire = _nextFire(r, now);
    if (fire == null) return;
    final title = asStr(r['title']);
    for (var k = 0; k < offsets.length && k < _slots; k++) {
      final when = fire.subtract(Duration(minutes: offsets[k]));
      if (!when.isAfter(now)) continue;
      final header = kind == 'birthday' ? 'تولد $title 🎂' : (kind == 'event' ? 'رویداد: $title' : 'یادآور: $title');
      String body;
      if (offsets[k] == 0) {
        body = kind == 'birthday' ? 'امروز تولدشه!' : 'همین حالاست.';
      } else if (offsets[k] % 1440 == 0) {
        body = '${faDigits(offsets[k] ~/ 1440)} روز دیگر';
      } else if (offsets[k] % 60 == 0) {
        body = '${faDigits(offsets[k] ~/ 60)} ساعت دیگر';
      } else {
        body = '${faDigits(offsets[k])} دقیقه دیگر';
      }
      try {
        await NotificationService.instance.schedule(id: _nid(id, k), title: header, body: body, when: when);
      } catch (_) {}
    }
  }

  /// بعد از باز شدنِ برنامه: اعلان‌های سالانه (تولدها) را برای سالگردِ بعدی دوباره زمان‌بندی می‌کند.
  static Future<void> resyncAll() async {
    try {
      final rows = await LuxDb.instance.query('cal_items');
      for (final r in rows) {
        await syncItem(asInt(r['id']));
      }
    } catch (_) {}
  }

  // ───────────────────────── حضور و غیاب ─────────────────────────

  static Future<List<Map<String, Object?>>> attendanceAll() =>
      LuxDb.instance.query('attendance', orderBy: 'day DESC');

  static Future<Map<String, Object?>?> attendanceOn(DateTime day) async {
    final r = await LuxDb.instance.query('attendance', where: 'day = ?', args: [key(day)], limit: 1);
    return r.isEmpty ? null : r.first;
  }

  /// برای هر روز فقط یک وضعیت نگه داشته می‌شود؛ ثبتِ تازه جایگزینِ قبلی می‌شود.
  static Future<void> setAttendance(DateTime day, String kind, {String note = ''}) async {
    await LuxDb.instance.delete('attendance', where: 'day = ?', args: [key(day)]);
    await LuxDb.instance.insert('attendance', <String, Object?>{
      'day': key(day),
      'kind': kind,
      'note': note,
      'created_at': DateTime.now().millisecondsSinceEpoch,
    });
    AppBus.bump();
  }

  static Future<void> deleteAttendance(int id) async {
    await LuxDb.instance.delete('attendance', where: 'id = ?', args: [id]);
    AppBus.bump();
  }
}
