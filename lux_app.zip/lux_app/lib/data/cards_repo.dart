import '../core/util.dart';
import '../engine/srs.dart';
import 'database.dart';

/// فلش‌کارت‌ها (از هایلایت‌های کتاب یا دستی) با مرورِ فاصله‌دارِ SM-2.
class CardsRepo {
  CardsRepo._();

  static Future<int> add({required String front, String back = '', int? courseId, int? bookId, int? page, int? annId}) {
    final now = DateTime.now();
    return LuxDb.instance.insert('cards', <String, Object?>{
      'course_id': courseId,
      'book_id': bookId,
      'page': page,
      'ann_id': annId,
      'front': front,
      'back': back,
      'ef': 2.5,
      'interval_days': 0,
      'reps': 0,
      'lapses': 0,
      'due_ts': now.millisecondsSinceEpoch,
      'created_at': now.millisecondsSinceEpoch,
    });
  }

  static Future<bool> existsForAnn(int annId) async {
    final r = await LuxDb.instance.query('cards', where: 'ann_id = ?', args: [annId], limit: 1);
    return r.isNotEmpty;
  }

  static Future<List<Map<String, Object?>>> due({int limit = 50}) => LuxDb.instance.rawQuery(
        'SELECT cd.*, c.name AS course_name FROM cards cd LEFT JOIN courses c ON c.id = cd.course_id '
        'WHERE cd.due_ts IS NULL OR cd.due_ts <= ? ORDER BY cd.due_ts LIMIT ?',
        [DateTime.now().millisecondsSinceEpoch, limit],
      );

  static Future<List<Map<String, Object?>>> all() => LuxDb.instance.rawQuery(
        'SELECT cd.*, c.name AS course_name FROM cards cd LEFT JOIN courses c ON c.id = cd.course_id ORDER BY cd.id DESC',
      );

  static Future<int> dueCount() async {
    final r = await LuxDb.instance.rawQuery('SELECT COUNT(*) AS n FROM cards WHERE due_ts IS NULL OR due_ts <= ?', [DateTime.now().millisecondsSinceEpoch]);
    return asInt(r.first['n']);
  }

  /// [q] کیفیتِ یادآوری: ۰ (فراموش) تا ۵ (کامل).
  static Future<void> review(Map<String, Object?> card, int q) async {
    final now = DateTime.now();
    final cur = SrsCard(
      ef: asDouble(card['ef'], 2.5),
      reps: asInt(card['reps']),
      intervalDays: asInt(card['interval_days']),
      due: now,
    );
    final n = Srs.review(cur, q, now);
    await LuxDb.instance.update(
      'cards',
      <String, Object?>{
        'ef': n.ef,
        'interval_days': n.intervalDays,
        'reps': n.reps,
        'lapses': asInt(card['lapses']) + (q < 3 ? 1 : 0),
        'due_ts': (q < 3 ? now.add(const Duration(minutes: 10)) : n.due).millisecondsSinceEpoch,
      },
      where: 'id = ?',
      args: [asInt(card['id'])],
    );
  }

  static Future<void> update(int id, {String? front, String? back}) =>
      LuxDb.instance.update('cards', <String, Object?>{if (front != null) 'front': front, if (back != null) 'back': back}, where: 'id = ?', args: [id]).then((_) {});

  static Future<void> delete(int id) => LuxDb.instance.delete('cards', where: 'id = ?', args: [id]).then((_) {});
}
