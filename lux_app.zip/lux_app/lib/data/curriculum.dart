/// داده‌ی پیش‌فرضِ دروس دبیرستان (رشته‌های نظری) به‌همراه ضریب سوابق تحصیلی کنکور.
///
/// منبع: فهرستی که صاحب پروژه داده (سازمان سنجش / جدول ضرایب سوابق تحصیلی کنکور ۱۴۰۶).
/// `coef == null` یعنی در جدول، ضریبی برای آن درس درج نشده (نه اینکه درس ضریب ندارد).
/// فهرست پایه‌ی دهم هیچ ضریب کنکوری ندارد.
class CurriculumCourse {
  final String name;
  final double? coef;
  const CurriculumCourse(this.name, [this.coef]);
}

class Curriculum {
  Curriculum._();

  /// ضریبِ جایگزین برای درس‌هایی که در جدول ضریب ندارند.
  static const double defaultCoef = 1;

  /// نام رشته در پروفایل → عنوان کامل برای نمایش
  static const Map<String, String> trackTitles = <String, String>{
    'تجربی': 'علوم تجربی',
    'ریاضی': 'ریاضی و فیزیک',
    'انسانی': 'علوم انسانی',
  };

  static bool has(String track, int grade) => _data[track]?[grade] != null;

  static String trackTitle(String track) => trackTitles[track] ?? track;

  static List<CurriculumCourse> coursesFor(String track, int grade) =>
      _data[track]?[grade] ?? const <CurriculumCourse>[];

  // ───────── مشترکِ پایه‌ی دهم (بدون ضریب) ─────────
  static const List<CurriculumCourse> _common10 = <CurriculumCourse>[
    CurriculumCourse('فارسی ۱'),
    CurriculumCourse('نگارش ۱'),
    CurriculumCourse('دین و زندگی ۱'),
    CurriculumCourse('عربی، زبان قرآن ۱'),
    CurriculumCourse('زبان انگلیسی ۱'),
  ];
  static const List<CurriculumCourse> _tail10 = <CurriculumCourse>[
    CurriculumCourse('جغرافیای ایران'),
    CurriculumCourse('آمادگی دفاعی'),
    CurriculumCourse('تفکر و سواد رسانه‌ای'),
    CurriculumCourse('کارگاه کارآفرینی و تولید'),
    CurriculumCourse('هنر'),
  ];

  static const Map<String, Map<int, List<CurriculumCourse>>> _data = <String, Map<int, List<CurriculumCourse>>>{
    // ═════════════ علوم تجربی ═════════════
    'تجربی': <int, List<CurriculumCourse>>{
      10: <CurriculumCourse>[
        ..._common10,
        CurriculumCourse('ریاضی ۱'),
        CurriculumCourse('زیست‌شناسی ۱'),
        CurriculumCourse('فیزیک ۱'),
        CurriculumCourse('شیمی ۱'),
        CurriculumCourse('آزمایشگاه علوم تجربی ۱'),
        ..._tail10,
      ],
      11: <CurriculumCourse>[
        CurriculumCourse('فارسی ۲', 5.95),
        CurriculumCourse('نگارش ۲'),
        CurriculumCourse('تعلیمات دینی ۲', 4.78),
        CurriculumCourse('عربی، زبان قرآن ۲', 2.62),
        CurriculumCourse('زبان خارجی ۲', 3.32),
        CurriculumCourse('زیست‌شناسی ۲', 6.39),
        CurriculumCourse('شیمی ۲', 5.27),
        CurriculumCourse('فیزیک ۲'),
        CurriculumCourse('ریاضی ۲'),
        CurriculumCourse('زمین‌شناسی'),
        CurriculumCourse('انسان و محیط زیست'),
        CurriculumCourse('تاریخ معاصر ایران'),
        CurriculumCourse('آزمایشگاه علوم تجربی ۲'),
        CurriculumCourse('آمادگی دفاعی'),
      ],
      12: <CurriculumCourse>[
        CurriculumCourse('فارسی ۳', 11.90),
        CurriculumCourse('نگارش ۳'),
        CurriculumCourse('تعلیمات دینی ۳', 8.47),
        CurriculumCourse('عربی، زبان قرآن ۳', 4.64),
        CurriculumCourse('زبان خارجی ۳', 6.05),
        CurriculumCourse('سلامت و بهداشت', 1.76),
        CurriculumCourse('علوم اجتماعی', 1.31),
        CurriculumCourse('ریاضی ۳', 10.04),
        CurriculumCourse('زیست‌شناسی ۳', 10.66),
        CurriculumCourse('فیزیک ۳', 8.45),
        CurriculumCourse('شیمی ۳', 9.19),
      ],
    },

    // ═════════════ ریاضی و فیزیک ═════════════
    'ریاضی': <int, List<CurriculumCourse>>{
      10: <CurriculumCourse>[
        ..._common10,
        CurriculumCourse('ریاضی ۱'),
        CurriculumCourse('هندسه ۱'),
        CurriculumCourse('فیزیک ۱'),
        CurriculumCourse('شیمی ۱'),
        CurriculumCourse('آزمایشگاه علوم تجربی ۱'),
        ..._tail10,
      ],
      11: <CurriculumCourse>[
        CurriculumCourse('فارسی ۲', 5.95),
        CurriculumCourse('نگارش ۲'),
        CurriculumCourse('تعلیمات دینی ۲', 4.78),
        CurriculumCourse('عربی، زبان قرآن ۲', 2.62),
        CurriculumCourse('زبان خارجی ۲', 3.32),
        CurriculumCourse('هندسه ۲', 5.10),
        CurriculumCourse('فیزیک ۲', 6.57),
        CurriculumCourse('حسابان ۱'),
        CurriculumCourse('شیمی ۲'),
        CurriculumCourse('زمین‌شناسی'),
        CurriculumCourse('انسان و محیط زیست'),
        CurriculumCourse('تاریخ معاصر ایران'),
        CurriculumCourse('آمادگی دفاعی'),
      ],
      12: <CurriculumCourse>[
        CurriculumCourse('فارسی ۳', 11.09),
        CurriculumCourse('نگارش ۳'),
        CurriculumCourse('تعلیمات دینی ۳', 8.47),
        CurriculumCourse('عربی، زبان قرآن ۳', 4.64),
        CurriculumCourse('زبان خارجی ۳', 6.05),
        CurriculumCourse('سلامت و بهداشت', 1.76),
        CurriculumCourse('علوم اجتماعی', 1.31),
        CurriculumCourse('حسابان ۲', 8.17),
        CurriculumCourse('هندسه ۳', 5.49),
        CurriculumCourse('ریاضیات گسسته', 4.71),
        CurriculumCourse('فیزیک ۳', 9.26),
        CurriculumCourse('شیمی ۳', 10.70),
      ],
    },

    // ═════════════ علوم انسانی ═════════════
    'انسانی': <int, List<CurriculumCourse>>{
      10: <CurriculumCourse>[
        ..._common10,
        CurriculumCourse('ریاضی و آمار ۱'),
        CurriculumCourse('علوم و فنون ادبی ۱'),
        CurriculumCourse('اقتصاد'),
        CurriculumCourse('منطق'),
        CurriculumCourse('تاریخ ۱'),
        CurriculumCourse('جغرافیای ایران'),
        CurriculumCourse('جامعه‌شناسی ۱'),
        CurriculumCourse('آمادگی دفاعی'),
        CurriculumCourse('تفکر و سواد رسانه‌ای'),
        CurriculumCourse('کارگاه کارآفرینی و تولید'),
        CurriculumCourse('هنر'),
      ],
      11: <CurriculumCourse>[
        CurriculumCourse('فارسی ۲', 5.95),
        CurriculumCourse('نگارش ۲'),
        CurriculumCourse('تعلیمات دینی ۲', 4.78),
        CurriculumCourse('زبان خارجی ۲', 3.32),
        CurriculumCourse('عربی ۲، زبان تخصصی رشته', 4.23),
        CurriculumCourse('تاریخ ۲', 5.24),
        CurriculumCourse('جامعه‌شناسی ۲', 4.82),
        CurriculumCourse('ریاضی و آمار ۲'),
        CurriculumCourse('علوم و فنون ادبی ۲'),
        CurriculumCourse('فلسفه ۱'),
        CurriculumCourse('جغرافیا ۲'),
        CurriculumCourse('روان‌شناسی'),
        CurriculumCourse('انسان و محیط زیست'),
        CurriculumCourse('آمادگی دفاعی'),
      ],
      12: <CurriculumCourse>[
        CurriculumCourse('فارسی ۳', 11.09),
        CurriculumCourse('نگارش ۳'),
        CurriculumCourse('تعلیمات دینی ۳', 8.47),
        CurriculumCourse('زبان خارجی ۳', 6.05),
        CurriculumCourse('سلامت و بهداشت', 1.76),
        CurriculumCourse('ریاضی و آمار ۳', 7.71),
        CurriculumCourse('علوم و فنون ادبی ۳', 8.68),
        CurriculumCourse('عربی ۳، زبان تخصصی رشته', 4.30),
        CurriculumCourse('تاریخ ۳', 5.38),
        CurriculumCourse('جغرافیا ۳', 7.71),
        CurriculumCourse('جامعه‌شناسی ۳', 4.96),
        CurriculumCourse('فلسفه ۲', 5.55),
      ],
    },
  };
}
