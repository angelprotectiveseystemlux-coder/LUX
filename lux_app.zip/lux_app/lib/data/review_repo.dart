import '../core/app_bus.dart';
import '../core/util.dart';
import '../engine/srs.dart';
import 'database.dart';

/// یک مورد در صفِ مرور: یا یک اشتباه، یا یک فصلِ تمام‌شده.
class ReviewItem {
  final bool isMistake;
  final int id;
  final String title;
  final String course;
  final String? answer;
  final String? cause;
  final String? photoPath;
  final String? book;
  final int? page;
  final SrsCard card;

  const ReviewItem({
    required this.isMistake,
    required this.id,
    required this.title,
    required this.course,
    required this.card,
    this.answer,
    this.cause,
    this.photoPath,
    this.book,
    this.page,
  });
}

class ReviewRepo {
  ReviewRepo._();

  static const List<String> causes = <String>[
    'بی‌دقتی',
    'فراموشی',
    'ندانستن مبحث',
    'اشتباه محاسباتی',
    'کمبود وقت',
    'سؤال دشوار',
  ];

  static int _endOfToday() {
    final n = DateTime.now();
    return DateTime(n.year, n.month, n.day + 1).millisecondsSinceEpoch;
  }

  static SrsCard _card(Map<String, Object?> r) => SrsCard(
        ef: asDouble(r['ef'], 2.5),
        reps: asInt(r['reps']),
        intervalDays: asInt(r['interval_days']),
        due: r['due_ts'] == null ? DateTime.now() : fromTs(r['due_ts']),
      );

  /// موردهایی که تا پایانِ امروز موعدِ مرورشان رسیده؛ قدیمی‌ترین اول.
  static Future<List<ReviewItem>> due() async {
    final db = LuxDb.instance;
    final end = _endOfToday();
    final out = <ReviewItem>[];

    final ms = await db.rawQuery(
      'SELECT m.*, c.name AS course, b.title AS book FROM mistakes m '
      'LEFT JOIN courses c ON c.id = m.course_id LEFT JOIN books b ON b.id = m.book_id '
      "WHERE m.status = 'open' AND (m.due_ts IS NULL OR m.due_ts < ?) ORDER BY m.due_ts IS NULL, m.due_ts",
      [end],
    );
    for (final r in ms) {
      out.add(ReviewItem(
        isMistake: true,
        id: asInt(r['id']),
        title: asStr(r['title']),
        course: asStr(r['course']),
        answer: asStr(r['answer']).isEmpty ? null : asStr(r['answer']),
        cause: asStr(r['cause']).isEmpty ? null : asStr(r['cause']),
        photoPath: asStr(r['photo_path']).isEmpty ? null : asStr(r['photo_path']),
        book: asStr(r['book']).isEmpty ? null : asStr(r['book']),
        page: r['page'] == null ? null : asInt(r['page']),
        card: _card(r),
      ));
    }

    final cs = await db.rawQuery(
      'SELECT ch.*, b.title AS book, c.name AS course FROM chapters ch '
      'JOIN books b ON b.id = ch.book_id LEFT JOIN courses c ON c.id = b.course_id '
      'WHERE ch.done = 1 AND ch.due_ts IS NOT NULL AND ch.due_ts < ? ORDER BY ch.due_ts',
      [end],
    );
    for (final r in cs) {
      final from = r['start_page'] == null ? null : asInt(r['start_page']);
      final to = r['end_page'] == null ? null : asInt(r['end_page']);
      out.add(ReviewItem(
        isMistake: false,
        id: asInt(r['id']),
        title: asStr(r['title']),
        course: asStr(r['course']),
        book: asStr(r['book']),
        page: from,
        answer: from == null ? null : 'صفحه‌ی $from${to == null ? '' : ' تا $to'} کتابِ «${asStr(r['book'])}»',
        card: _card(r),
      ));
    }
    return out;
  }

  static Future<int> dueCount() async => (await due()).length;

  /// نتیجه‌ی مرور: [q] از ۰ تا ۵ (SM-2)
  static Future<void> review(ReviewItem it, int q) async {
    final now = DateTime.now();
    final next = Srs.review(it.card, q, now);
    final db = LuxDb.instance;
    if (it.isMistake) {
      final mastered = next.intervalDays >= 30;
      final rows = await db.query('mistakes', where: 'id = ?', args: [it.id], limit: 1);
      final count = rows.isEmpty ? 0 : asInt(rows.first['review_count']);
      await db.update(
        'mistakes',
        <String, Object?>{
          'ef': next.ef,
          'reps': next.reps,
          'interval_days': next.intervalDays,
          'due_ts': mastered ? null : next.due.millisecondsSinceEpoch,
          'status': mastered ? 'mastered' : 'open',
          'review_count': count + 1,
        },
        where: 'id = ?',
        args: [it.id],
      );
    } else {
      final rows = await db.query('chapters', where: 'id = ?', args: [it.id], limit: 1);
      final count = rows.isEmpty ? 0 : asInt(rows.first['review_count']);
      await db.update(
        'chapters',
        <String, Object?>{
          'ef': next.ef,
          'reps': next.reps,
          'interval_days': next.intervalDays,
          'due_ts': next.due.millisecondsSinceEpoch,
          'review_count': count + 1,
        },
        where: 'id = ?',
        args: [it.id],
      );
    }
    AppBus.bump();
  }

  // ───────────────────────── اشتباهات ─────────────────────────

  static Future<List<Map<String, Object?>>> mistakes() => LuxDb.instance.rawQuery(
        'SELECT m.*, c.name AS course, b.title AS book FROM mistakes m '
        'LEFT JOIN courses c ON c.id = m.course_id LEFT JOIN books b ON b.id = m.book_id '
        'ORDER BY m.created_at DESC',
      );

  static Future<int> saveMistake({
    int? id,
    int? courseId,
    int? bookId,
    int? page,
    required String title,
    String answer = '',
    String cause = '',
    String? photoPath,
    String status = 'open',
  }) async {
    final values = <String, Object?>{
      'course_id': courseId,
      'book_id': bookId,
      'page': page,
      'title': title,
      'answer': answer,
      'cause': cause,
      'photo_path': photoPath,
      'status': status,
    };
    int rid;
    if (id == null) {
      values['created_at'] = DateTime.now().millisecondsSinceEpoch;
      values['due_ts'] = DateTime.now().millisecondsSinceEpoch;
      rid = await LuxDb.instance.insert('mistakes', values);
    } else {
      if (status == 'open') {
        // دوباره باز شد: همین امروز مرور شود
        final old = await LuxDb.instance.query('mistakes', where: 'id = ?', args: [id], limit: 1);
        if (old.isNotEmpty && asStr(old.first['status']) == 'mastered') {
          values['due_ts'] = DateTime.now().millisecondsSinceEpoch;
          values['reps'] = 0;
          values['interval_days'] = 0;
        }
      }
      await LuxDb.instance.update('mistakes', values, where: 'id = ?', args: [id]);
      rid = id;
    }
    AppBus.bump();
    return rid;
  }

  static Future<void> deleteMistake(int id) async {
    await LuxDb.instance.delete('mistakes', where: 'id = ?', args: [id]);
    AppBus.bump();
  }
}
