import '../core/util.dart';
import 'database.dart';

/// منطقِ «بعد از امتحان بپرس چطور بود»:
/// زمانِ پرسیدن = دیرترینِ (ساعتِ ثابتِ روز، مثلاً ۱۴:۰۰ که از مدرسه برمی‌گردی) و (شروعِ امتحان + مدتِ تعیین‌شده).
class ExamAskStore {
  ExamAskStore._();

  static const String _kMin = 'exam_ask_min';
  static const int defaultMinutes = 14 * 60;

  static Future<int> askMinutes() async {
    final v = int.tryParse(await LuxDb.instance.kvGet(_kMin) ?? '');
    return (v ?? defaultMinutes).clamp(0, 1439).toInt();
  }

  static Future<void> setAskMinutes(int m) => LuxDb.instance.kvSet(_kMin, '${m.clamp(0, 1439)}');

  static DateTime askAt(DateTime examAt, int offsetMin, int fixedMin) {
    final fixed = DateTime(examAt.year, examAt.month, examAt.day, fixedMin ~/ 60, fixedMin % 60);
    final byOffset = examAt.add(Duration(minutes: offsetMin <= 0 ? 90 : offsetMin));
    return fixed.isAfter(byOffset) ? fixed : byOffset;
  }

  static String doneKey(int id) => 'exam_ask_done_$id';
  static String snoozeKey(int id) => 'exam_ask_snooze_$id';
  static String feelKey(int id) => 'exam_feel_$id';

  /// امتحان‌هایی که وقتِ پرسیدنشان رسیده و هنوز جواب نداده‌ای.
  static Future<List<Map<String, Object?>>> due() async {
    final db = LuxDb.instance;
    final now = DateTime.now();
    final from = now.subtract(const Duration(days: 7)).millisecondsSinceEpoch;
    final rows = await db.rawQuery(
      'SELECT e.*, c.name AS course_name FROM exams e JOIN courses c ON c.id = e.course_id '
      "WHERE e.status = 'planned' AND e.at_ts >= ? AND e.at_ts <= ? ORDER BY e.at_ts",
      [from, now.millisecondsSinceEpoch],
    );
    final fixed = await askMinutes();
    final out = <Map<String, Object?>>[];
    for (final r in rows) {
      final id = asInt(r['id']);
      if (await db.kvGet(doneKey(id)) == '1') continue;
      final at = askAt(fromTs(r['at_ts']), asInt(r['ask_offset_min'], 90), fixed);
      if (at.isAfter(now)) continue;
      final sn = int.tryParse(await db.kvGet(snoozeKey(id)) ?? '');
      if (sn != null && sn > now.millisecondsSinceEpoch) continue;
      out.add(r);
    }
    return out;
  }
}
