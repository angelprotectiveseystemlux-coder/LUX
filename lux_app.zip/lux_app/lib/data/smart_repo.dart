import 'dart:convert';
import 'dart:math' as math;

import 'package:flutter/services.dart';

import '../core/jalali_utils.dart';
import '../core/util.dart';
import '../engine/grades.dart';
import '../engine/smart/estimators.dart';
import '../engine/smart/models.dart';
import '../engine/smart/scheduler.dart';
import '../engine/smart/simulator.dart';
import '../services/smart_notifs.dart';
import 'database.dart';
import 'holidays.dart';
import 'study_repo.dart';

/// خروجیِ کاملِ «برنامه‌ی هوشمند» برای صفحه‌ها.
class SmartBundle {
  final SSnapshot snapshot;
  final List<SBlock> blocks; // همه‌ی بلوک‌های امروز تا افق (به‌جز ردشده‌ها)
  final SPlanResult meta;
  final SimResult? sim;
  final Map<int, CourseModel> models;
  final List<double> hourScores;
  const SmartBundle({required this.snapshot, required this.blocks, required this.meta, required this.sim, required this.models, required this.hourScores});

  List<SBlock> on(int key) => [for (final b in blocks) if (b.day == key) b]..sort((a, b) => a.startMin.compareTo(b.startMin));
}

/// خواندن، ساختن و ذخیره‌ی برنامه‌ی هوشمند.
class SmartRepo {
  SmartRepo._();

  static SmartBundle? _cache;
  static DateTime? _cacheAt;

  // ───────── تنظیمات ─────────

  static Future<SSettings> settings() async {
    final db = LuxDb.instance;
    int i(String? v, int d) => int.tryParse(v ?? '') ?? d;
    final st = SSettings();
    st.target = (double.tryParse(await db.kvGet('smart_target') ?? '') ?? 18).clamp(10, 20).toDouble();
    st.schoolEndMin = i(await db.kvGet('smart_school_end'), 14 * 60).clamp(0, 1439).toInt();
    st.restAfterSchoolMin = i(await db.kvGet('smart_rest'), 60).clamp(0, 300).toInt();
    st.bedMin = i(await db.kvGet('smart_bed'), 22 * 60 + 30).clamp(18 * 60, 1439).toInt();
    st.offStartMin = i(await db.kvGet('smart_off_start'), 9 * 60).clamp(0, 14 * 60).toInt();
    final md = int.tryParse(await db.kvGet('smart_max_daily') ?? '');
    st.maxDailyMin = md == null || md <= 0 ? null : md.clamp(30, 720).toInt();
    st.blockMin = i(await db.kvGet('smart_block'), 45).clamp(25, 90).toInt();
    st.horizonDays = i(await db.kvGet('smart_horizon'), 7).clamp(3, 14).toInt();
    return st;
  }

  static Future<void> saveSettings(SSettings st) async {
    final db = LuxDb.instance;
    await db.kvSet('smart_target', '${st.target}');
    await db.kvSet('smart_school_end', '${st.schoolEndMin}');
    await db.kvSet('smart_rest', '${st.restAfterSchoolMin}');
    await db.kvSet('smart_bed', '${st.bedMin}');
    await db.kvSet('smart_off_start', '${st.offStartMin}');
    await db.kvSet('smart_max_daily', '${st.maxDailyMin ?? 0}');
    await db.kvSet('smart_block', '${st.blockMin}');
    await db.kvSet('smart_horizon', '${st.horizonDays}');
    invalidate();
  }

  static void invalidate() {
    _cache = null;
    _cacheAt = null;
  }

  // ───────── خواندنِ دیتا ─────────

  static DateTime _ts(Object? v) => fromTs(v);

  static Future<SSnapshot> snapshot({DateTime? at}) async {
    final db = LuxDb.instance;
    final now = at ?? DateTime.now();
    final st = await settings();
    final from90 = now.subtract(const Duration(days: 90)).millisecondsSinceEpoch;

    final courseRows = await StudyRepo.courses();
    final courses = [
      for (final r in courseRows)
        SCourse(
          id: asInt(r['id']),
          name: asStr(r['name']),
          coef: asDouble(r['coef'], 1),
          difficulty: asInt(r['difficulty'], 3).clamp(1, 5).toInt(),
          maxScore: asDouble(r['max_score'], 20),
          finalShare: asDouble(r['final_share'], 50),
          colorValue: r['color'] == null ? null : asInt(r['color']),
        ),
    ];
    final ids = {for (final c in courses) c.id};

    final examRows = await db.rawQuery('SELECT * FROM exams WHERE status != ?', ['canceled']);
    final exams = <SExam>[
      for (final r in examRows)
        if (ids.contains(asInt(r['course_id'])))
          SExam(
            id: asInt(r['id']),
            courseId: asInt(r['course_id']),
            at: _ts(r['at_ts']),
            weight: asDouble(r['weight'], 1),
            maxScore: asDouble(r['max_score'], 20),
            difficulty: asInt(r['difficulty'], 3),
            readiness: r['readiness'] == null ? null : asInt(r['readiness']),
            title: asStr(r['title']).isEmpty ? asStr(r['type_name']) : asStr(r['title']),
            scope: asStr(r['scope_note']),
            status: asStr(r['status'], 'planned'),
            score: r['score'] == null ? null : asDouble(r['score']),
            isFinal: asStr(r['type_name']) == kFinalExamType,
          ),
    ];

    final gradeRows = await db.rawQuery(
      'SELECT g.*, CASE WHEN e.id IS NOT NULL THEN (CASE WHEN e.type_name = ? THEN 1 ELSE 0 END) '
      "ELSE (CASE WHEN g.phase = 'final' THEN 1 ELSE 0 END) END AS is_final "
      'FROM grades g LEFT JOIN exams e ON e.id = g.exam_id',
      [kFinalExamType],
    );
    final grades = <SGrade>[
      for (final r in gradeRows)
        if (ids.contains(asInt(r['course_id'])))
          SGrade(
            courseId: asInt(r['course_id']),
            examId: r['exam_id'] == null ? null : asInt(r['exam_id']),
            score20: asDouble(r['max_score'], 20) <= 0 ? 0 : asDouble(r['score']) / asDouble(r['max_score'], 20) * 20,
            weight: asDouble(r['weight'], 1),
            at: _ts(r['at_ts']),
            isFinal: asInt(r['is_final']) == 1,
            isConference: asStr(r['kind']) == 'conference',
          ),
    ];

    final sessions = <SSession>[];
    final ss = await db.rawQuery('SELECT * FROM study_sessions WHERE end_ts IS NOT NULL AND start_ts >= ?', [from90]);
    for (final r in ss) {
      final a = _ts(r['start_ts']);
      final b = _ts(r['end_ts']);
      if (!b.isAfter(a) || b.difference(a).inHours > 8) continue;
      sessions.add(SSession(
        courseId: r['course_id'] == null ? null : asInt(r['course_id']),
        start: a,
        end: b,
        quality: r['quality'] == null ? null : asInt(r['quality']),
        completed: asInt(r['completed']) == 1,
      ));
    }
    final rs = await db.rawQuery(
      'SELECT r.*, b.course_id AS cid FROM reading_sessions r JOIN books b ON b.id = r.book_id WHERE r.start_ts >= ?',
      [from90],
    );
    final bookPages = <int, double>{};
    final bookHours = <int, double>{};
    var allPages = 0.0, allHours = 0.0;
    for (final r in rs) {
      final a = _ts(r['start_ts']);
      final b = _ts(r['end_ts']);
      if (!b.isAfter(a) || b.difference(a).inHours > 6) continue;
      sessions.add(SSession(courseId: r['cid'] == null ? null : asInt(r['cid']), start: a, end: b));
      final fp = r['from_page'] == null ? null : asInt(r['from_page']);
      final tp = r['to_page'] == null ? null : asInt(r['to_page']);
      if (fp != null && tp != null && tp > fp && tp - fp <= 200) {
        final bid = asInt(r['book_id']);
        final hrs = b.difference(a).inSeconds / 3600.0;
        bookPages[bid] = (bookPages[bid] ?? 0) + (tp - fp);
        bookHours[bid] = (bookHours[bid] ?? 0) + hrs;
        allPages += tp - fp;
        allHours += hrs;
      }
    }
    final globalSpeed = allHours >= 0.5 ? (allPages / allHours).clamp(6.0, 60.0).toDouble() : 18.0;
    final bookRows = await db.query('books');
    final books = <SBook>[
      for (final r in bookRows)
        SBook(
          id: asInt(r['id']),
          courseId: r['course_id'] == null ? null : asInt(r['course_id']),
          title: asStr(r['title']),
          pages: asInt(r['pages']),
          lastPage: asInt(r['last_page']),
          pagesPerHour: (bookHours[asInt(r['id'])] ?? 0) >= 0.4 ? ((bookPages[asInt(r['id'])] ?? 0) / bookHours[asInt(r['id'])]!).clamp(6.0, 60.0).toDouble() : globalSpeed,
        ),
    ];

    final chRows = await db.rawQuery('SELECT ch.*, b.course_id AS cid FROM chapters ch JOIN books b ON b.id = ch.book_id');
    final chapters = <SChapter>[
      for (final r in chRows)
        SChapter(
          id: asInt(r['id']),
          bookId: asInt(r['book_id']),
          courseId: r['cid'] == null ? null : asInt(r['cid']),
          title: asStr(r['title']),
          startPage: r['start_page'] == null ? null : asInt(r['start_page']),
          endPage: r['end_page'] == null ? null : asInt(r['end_page']),
          done: asInt(r['done']) == 1,
          due: r['due_ts'] == null ? null : _ts(r['due_ts']),
          ef: asDouble(r['ef'], 2.5),
          reps: asInt(r['reps']),
        ),
    ];

    final mRows = await db.query('mistakes');
    final mistakes = <SMistake>[
      for (final r in mRows)
        SMistake(
          id: asInt(r['id']),
          courseId: r['course_id'] == null ? null : asInt(r['course_id']),
          bookId: r['book_id'] == null ? null : asInt(r['book_id']),
          page: r['page'] == null ? null : asInt(r['page']),
          cause: asStr(r['cause']),
          open: asStr(r['status'], 'open') == 'open',
          due: r['due_ts'] == null ? null : _ts(r['due_ts']),
        ),
    ];

    final slotRows = await db.query('class_slots');
    final slots = [
      for (final r in slotRows)
        SSlot(weekday: asInt(r['weekday']), startMin: asInt(r['start_min']), endMin: asInt(r['end_min']), courseId: r['course_id'] == null ? null : asInt(r['course_id'])),
    ];

    final taskRows = await db.rawQuery("SELECT * FROM tasks WHERE status = 'open'");
    final tasks = [
      for (final r in taskRows)
        STask(
          id: asInt(r['id']),
          courseId: r['course_id'] == null ? null : asInt(r['course_id']),
          title: asStr(r['title']),
          due: r['due_ts'] == null ? null : _ts(r['due_ts']),
          priority: asInt(r['priority'], 2),
        ),
    ];

    final jRows = await db.rawQuery('SELECT * FROM journal ORDER BY day DESC LIMIT 14');
    final journal = <SJournal>[];
    for (final r in jRows) {
      final d = DateTime.tryParse(asStr(r['day']));
      if (d == null) continue;
      journal.add(SJournal(
        day: d,
        mood: r['mood'] == null ? null : asInt(r['mood']),
        energy: r['energy'] == null ? null : asInt(r['energy']),
        sleepH: r['sleep_h'] == null ? null : asDouble(r['sleep_h']),
      ));
    }

    final refRows = await db.query('exam_reflections', orderBy: 'created_at DESC', limit: 40);
    final reflections = [
      for (final r in refRows)
        SReflection(
          examId: r['exam_id'] == null ? null : asInt(r['exam_id']),
          courseId: r['course_id'] == null ? null : asInt(r['course_id']),
          reasons: asStr(r['reasons']).split(',').where((e) => e.trim().isNotEmpty).toSet(),
          at: _ts(r['created_at']),
        ),
    ];

    final mockRows = await db.query('mocks', where: 'score IS NOT NULL', args: const <Object?>[]);
    final mocks = [
      for (final r in mockRows)
        SMock(
          courseId: r['course_id'] == null ? null : asInt(r['course_id']),
          at: _ts(r['at_ts']),
          score20: asDouble(r['max_score'], 20) <= 0 ? 0 : asDouble(r['score']) / asDouble(r['max_score'], 20) * 20,
        ),
    ];

    final histKey = dayKey(now.subtract(const Duration(days: 60)));
    final hRows = await db.rawQuery("SELECT * FROM smart_blocks WHERE day >= ? AND status != 'planned'", [histKey]);
    final history = [for (final r in hRows) _blockOf(r)];

    final off = <int>{};
    final events = <int, List<List<int>>>{};
    final today = dateOnly(now);
    final calRows = await db.rawQuery('SELECT * FROM cal_items WHERE time_min IS NOT NULL AND yearly = 0');
    for (var i = 0; i < 16; i++) {
      final d = DateTime(today.year, today.month, today.day + i);
      if (HolidayData.isOffDay(d)) off.add(dayKey(d));
    }
    for (final r in calRows) {
      final d = DateTime.tryParse(asStr(r['day']));
      if (d == null) continue;
      final k = dayKey(d);
      if (d.isBefore(today) || d.isAfter(today.add(const Duration(days: 16)))) continue;
      if (asStr(r['kind']) == 'holiday') continue;
      final t = asInt(r['time_min']);
      (events[k] ??= <List<int>>[]).add(<int>[t, t + 60]);
    }

    // فاصله‌ی من با بهترین رقیب (روی ۲۰)
    final rivalGap = <int, double>{};
    try {
      final rr = await db.rawQuery(
        'SELECT e.course_id AS cid, rs.rival_id AS rid, AVG(rs.score / e.max_score * 20) AS r, AVG(e.score / e.max_score * 20) AS me '
        "FROM rival_scores rs JOIN exams e ON e.id = rs.exam_id WHERE e.status = 'done' AND e.score IS NOT NULL AND e.max_score > 0 "
        'GROUP BY e.course_id, rs.rival_id',
      );
      for (final r in rr) {
        final cid = asInt(r['cid']);
        final gap = asDouble(r['r']) - asDouble(r['me']);
        final prev = rivalGap[cid];
        if (prev == null || gap > prev) rivalGap[cid] = gap;
      }
    } catch (_) {}

    final due = await db.rawQuery('SELECT COUNT(*) AS n FROM cards WHERE due_ts IS NULL OR due_ts <= ?', [today.add(const Duration(days: 1)).millisecondsSinceEpoch]);

    final rule = await StudyRepo.behaviorRule();
    final counts = await StudyRepo.behaviorCounts();
    final behavior = <int, double>{};
    final override = <int, double>{};
    for (final c in courses) {
      final cnt = counts[c.id];
      if (cnt != null) behavior[c.id] = rule.delta(cnt[0], cnt[1]);
      final ov = double.tryParse(await db.kvGet('cont_override_${c.id}') ?? '');
      if (ov != null) override[c.id] = ov;
    }

    return SSnapshot(
      now: now,
      settings: st,
      courses: courses,
      exams: exams,
      grades: grades,
      sessions: sessions,
      books: books,
      chapters: chapters,
      mistakes: mistakes,
      slots: slots,
      tasks: tasks,
      journal: journal,
      reflections: reflections,
      mocks: mocks,
      history: history,
      offDays: off,
      events: events,
      rivalGap: rivalGap,
      cardsDue: asInt(due.first['n']),
      behavior: behavior,
      contOverride: override,
    );
  }

  // ───────── بلوک‌ها در پایگاه‌داده ─────────

  static SBlock _blockOf(Map<String, Object?> r) => SBlock(
        id: asInt(r['id']),
        day: asInt(r['day']),
        startMin: asInt(r['start_min']),
        durMin: asInt(r['dur_min']),
        kind: asStr(r['kind']),
        courseId: r['course_id'] == null ? null : asInt(r['course_id']),
        refId: r['ref_id'] == null ? null : asInt(r['ref_id']),
        title: asStr(r['title']),
        reason: asStr(r['reason']),
        status: asStr(r['status'], 'planned'),
        locked: asInt(r['locked']) == 1,
        startedAt: r['started_at'] == null ? null : _ts(r['started_at']),
        doneAt: r['done_at'] == null ? null : _ts(r['done_at']),
      );

  static Future<List<SBlock>> blocksFrom(int key, {int? to}) async {
    final rows = await LuxDb.instance.rawQuery(
      'SELECT * FROM smart_blocks WHERE day >= ? ${to == null ? '' : 'AND day <= ?'} ORDER BY day, start_min',
      to == null ? [key] : [key, to],
    );
    return [for (final r in rows) _blockOf(r)];
  }

  static Future<void> _insert(SBlock b, DateTime now) => LuxDb.instance.insert('smart_blocks', <String, Object?>{
        'day': b.day,
        'start_min': b.startMin,
        'dur_min': b.durMin,
        'kind': b.kind,
        'course_id': b.courseId,
        'ref_id': b.refId,
        'title': b.title,
        'reason': b.reason,
        'status': b.status,
        'locked': b.locked ? 1 : 0,
        'created_at': now.millisecondsSinceEpoch,
      }).then((_) {});

  /// بلوک‌های گذشته را «رد شده/انجام شده» می‌کند تا برنامه از رفتارِ واقعی‌ات یاد بگیرد.
  static Future<void> reconcile(SSnapshot s) async {
    final db = LuxDb.instance;
    final now = s.now;
    final todayKey = dayKey(now);
    final rows = await db.rawQuery("SELECT * FROM smart_blocks WHERE status = 'planned' AND day <= ?", [todayKey]);
    for (final r in rows) {
      final b = _blockOf(r);
      final d = dayFromKey(b.day);
      final start = DateTime(d.year, d.month, d.day, 0, b.startMin);
      final end = start.add(Duration(minutes: b.durMin));
      var mins = 0.0;
      DateTime? last;
      if (b.courseId != null && b.kind != 'micro') {
        for (final x in s.sessions) {
          if (x.courseId != b.courseId) continue;
          final a = start.subtract(const Duration(minutes: 30));
          final z = end.add(const Duration(minutes: 90));
          if (!x.end.isAfter(a) || !x.start.isBefore(z)) continue;
          mins += x.minutes;
          if (last == null || x.end.isAfter(last)) last = x.end;
        }
      }
      if (b.kind != 'micro' && mins >= b.durMin * 0.7) {
        await db.update('smart_blocks', <String, Object?>{'status': 'done', 'done_at': (last ?? end).millisecondsSinceEpoch}, where: 'id = ?', args: [b.id]);
      } else if (b.day < todayKey || now.isAfter(end.add(const Duration(minutes: 45)))) {
        await db.update('smart_blocks', <String, Object?>{'status': 'skipped'}, where: 'id = ?', args: [b.id]);
      }
    }
  }

  static String _signature(SSnapshot s) {
    final planned = s.exams.where((e) => e.status == 'planned').length;
    final done = s.exams.where((e) => e.status == 'done').length;
    final doneCh = s.chapters.where((c) => c.done).length;
    final openM = s.mistakes.where((m) => m.open).length;
    final cfg = '${s.settings.target}|${s.settings.schoolEndMin}|${s.settings.bedMin}|${s.settings.maxDailyMin}|${s.settings.blockMin}|${s.settings.horizonDays}';
    return '${dayKey(s.now)}|$planned|$done|${s.grades.length}|${s.tasks.length}|$doneCh|$openM|${s.courses.length}|$cfg';
  }

  /// برنامه را (در صورت نیاز) از نو می‌چیند و همه‌چیز را برای صفحه‌ها برمی‌گرداند.
  static Future<SmartBundle> load({bool regenerate = false, bool useCache = false}) async {
    if (useCache && _cache != null && _cacheAt != null && DateTime.now().difference(_cacheAt!).inMinutes < 2 && !regenerate) return _cache!;
    final db = LuxDb.instance;
    final s0 = await snapshot();
    await reconcile(s0);
    final s = await snapshot(at: s0.now);
    final todayKey = dayKey(s.now);
    final endKey = dayKey(s.now.add(Duration(days: s.settings.horizonDays)));
    var stored = await blocksFrom(todayKey, to: endKey);
    var meta = Scheduler.run(s, keep: stored);

    final sig = _signature(s);
    final lastSig = await db.kvGet('smart_gen_sig');
    final lastTs = int.tryParse(await db.kvGet('smart_gen_ts') ?? '') ?? 0;
    final hasPlanned = stored.any((b) => b.status == 'planned');
    final stale = s.now.millisecondsSinceEpoch - lastTs > const Duration(hours: 4).inMilliseconds;
    if (regenerate || sig != lastSig || !hasPlanned || stale) {
      await db.delete('smart_blocks', where: "day >= ? AND status = 'planned' AND locked = 0", args: [todayKey]);
      for (final b in meta.blocks) {
        await _insert(b, s.now);
      }
      await db.kvSet('smart_gen_sig', sig);
      await db.kvSet('smart_gen_ts', '${s.now.millisecondsSinceEpoch}');
      stored = await blocksFrom(todayKey, to: endKey);
      try {
        await SmartNotifs.sync([for (final b in stored) if (b.status != 'rejected') b], Estimators.execStats(s), s.now);
      } catch (_) {}
    }
    final visible = [for (final b in stored) if (b.status != 'rejected') b];
    SimResult? sim;
    try {
      sim = Simulator.run(s, meta.forecasts, runs: 900);
    } catch (_) {}
    _pushWidget(visible, s);
    final models = Estimators.courseModels(s);
    final bundle = SmartBundle(snapshot: s, blocks: visible, meta: meta, sim: sim, models: models, hourScores: Estimators.hourScores(s));
    _cache = bundle;
    _cacheAt = DateTime.now();
    return bundle;
  }

  static const MethodChannel _widgetCh = MethodChannel('lux/widget');

  /// ویجتِ صفحه‌ی اصلی را با بلوکِ بعدی به‌روز می‌کند.
  static void _pushWidget(List<SBlock> blocks, SSnapshot s) {
    try {
      final key = dayKey(s.now);
      final nowMin = s.now.hour * 60 + s.now.minute;
      SBlock? next;
      for (final b in blocks) {
        if (b.day != key || b.status != 'planned' || b.kind == 'micro' || b.endMin <= nowMin) continue;
        if (next == null || b.startMin < next.startMin) next = b;
      }
      String two2(int v) => v.toString().padLeft(2, '0');
      final title = next == null ? 'LUX' : next.title;
      final sub = next == null ? 'برای باقیِ امروز بلوکی نمانده' : 'ساعت ${two2(next.startMin ~/ 60)}:${two2(next.startMin % 60)} · ${next.durMin} دقیقه';
      _widgetCh.invokeMethod<Object?>('update', <String, Object?>{'title': title, 'sub': latinDigits0(sub).replaceAllMapped(RegExp(r'\d'), (m) => String.fromCharCode(0x06F0 + int.parse(m.group(0)!)))});
    } catch (_) {}
  }

  // ───────── کنش‌های کاربر ─────────

  static Future<void> markStarted(int id) =>
      LuxDb.instance.update('smart_blocks', <String, Object?>{'started_at': DateTime.now().millisecondsSinceEpoch}, where: 'id = ?', args: [id]).then((_) => invalidate());

  static Future<void> markDone(int id) =>
      LuxDb.instance.update('smart_blocks', <String, Object?>{'status': 'done', 'done_at': DateTime.now().millisecondsSinceEpoch}, where: 'id = ?', args: [id]).then((_) => invalidate());

  static Future<void> markSkipped(int id) =>
      LuxDb.instance.update('smart_blocks', <String, Object?>{'status': 'skipped'}, where: 'id = ?', args: [id]).then((_) => invalidate());

  /// حذفِ بلوک = بازخورد: بعداً کمتر در همان ساعت/درس گذاشته می‌شود. بعدش دوباره می‌چیند.
  static Future<void> reject(int id) async {
    await LuxDb.instance.update('smart_blocks', <String, Object?>{'status': 'rejected'}, where: 'id = ?', args: [id]);
    invalidate();
    await LuxDb.instance.kvSet('smart_gen_sig', '');
  }

  static Future<void> setLocked(int id, bool v) =>
      LuxDb.instance.update('smart_blocks', <String, Object?>{'locked': v ? 1 : 0}, where: 'id = ?', args: [id]).then((_) => invalidate());

  static Future<void> move(int id, int startMin) =>
      LuxDb.instance.update('smart_blocks', <String, Object?>{'start_min': startMin, 'locked': 1}, where: 'id = ?', args: [id]).then((_) => invalidate());

  static Future<void> addCustom({required int day, required int startMin, required int durMin, required String title, int? courseId}) async {
    await _insert(
      SBlock(day: day, startMin: startMin, durMin: durMin, kind: 'learn', courseId: courseId, title: title, reason: 'بلوکِ دستی که خودت اضافه کردی.', locked: true),
      DateTime.now(),
    );
    invalidate();
  }

  // ───────── تحلیلِ بعد از امتحان ─────────

  static const List<String> reasonKeys = <String>['dontknow', 'time', 'careless', 'stress', 'scope', 'good'];
  static const List<String> reasonNames = <String>['بلد نبودم', 'وقت کم آوردم', 'بی‌دقتی کردم', 'استرس داشتم', 'سؤال خارج از محدوده بود', 'خوب خوانده بودم'];

  static Future<void> saveReflection({required int examId, int? courseId, required List<String> reasons, int? feel, String note = ''}) async {
    final db = LuxDb.instance;
    await db.delete('exam_reflections', where: 'exam_id = ?', args: [examId]);
    await db.insert('exam_reflections', <String, Object?>{
      'exam_id': examId,
      'course_id': courseId,
      'reasons': reasons.join(','),
      'feel': feel,
      'lost_note': note,
      'created_at': DateTime.now().millisecondsSinceEpoch,
    });
    invalidate();
    await db.kvSet('smart_gen_sig', '');
  }

  static Future<bool> hasReflection(int examId) async {
    final r = await LuxDb.instance.query('exam_reflections', where: 'exam_id = ?', args: [examId], limit: 1);
    return r.isNotEmpty;
  }

  // ───────── «اگر… چه می‌شود؟» ─────────

  static SimResult whatIf(SmartBundle b, {required int courseId, required double extraHours}) =>
      Simulator.run(b.snapshot, b.meta.forecasts, extraHours: <int, double>{courseId: extraHours}, runs: 1200);

  // ───────── ثبتِ سریع ─────────

  /// «فیزیک ۴۵ دقیقه»، «ریاضی یک ساعت و نیم»، «شیمی ۲ ساعت» → (درس، دقیقه)
  static ({int? courseId, String courseName, int minutes})? parseQuick(String text, List<SCourse> courses) {
    String norm(String x) => latinDigits0(x)
        .replaceAll('ي', 'ی')
        .replaceAll('ك', 'ک')
        .replaceAll('\u200c', ' ')
        .toLowerCase();
    final t = norm(text);
    SCourse? best;
    var bestLen = 0;
    for (final c in courses) {
      final n = norm(c.name);
      if (n.isEmpty) continue;
      if (t.contains(n) && n.length > bestLen) {
        best = c;
        bestLen = n.length;
      }
    }
    if (best == null) {
      for (final c in courses) {
        final first = norm(c.name).split(' ').first;
        if (first.length >= 3 && t.contains(first)) {
          best = c;
          break;
        }
      }
    }
    var minutes = 0.0;
    final hm = RegExp(r'(\d+(?:\.\d+)?)\s*(?:ساعت|h)').firstMatch(t);
    final mm = RegExp(r'(\d+(?:\.\d+)?)\s*(?:دقیقه|دقیقه‌|min|m)').firstMatch(t);
    if (hm != null) minutes += (double.tryParse(hm.group(1)!) ?? 0) * 60;
    if (mm != null) minutes += double.tryParse(mm.group(1)!) ?? 0;
    if (hm == null && mm == null) {
      final bare = RegExp(r'(\d+)').firstMatch(t);
      if (bare != null) minutes = double.tryParse(bare.group(1)!) ?? 0;
    }
    if (t.contains('یک ساعت') && hm == null) minutes += 60;
    if (t.contains('دو ساعت') && hm == null) minutes += 120;
    if (t.contains('سه ساعت') && hm == null) minutes += 180;
    if (t.contains('نیم ساعت')) minutes += 30;
    if ((t.contains('و نیم') || t.contains('ونیم')) && minutes >= 60 && minutes % 60 == 0) minutes += 30;
    if (minutes < 5 || minutes > 600) return null;
    return (courseId: best?.id, courseName: best?.name ?? '', minutes: minutes.round());
  }

  static String latinDigits0(String s) {
    final sb = StringBuffer();
    for (final r in s.runes) {
      if (r >= 0x06F0 && r <= 0x06F9) {
        sb.writeCharCode(48 + r - 0x06F0);
      } else if (r >= 0x0660 && r <= 0x0669) {
        sb.writeCharCode(48 + r - 0x0660);
      } else {
        sb.writeCharCode(r);
      }
    }
    return sb.toString();
  }

  static Future<void> logSession({required int? courseId, required int minutes}) async {
    final end = DateTime.now();
    final start = end.subtract(Duration(minutes: minutes));
    await LuxDb.instance.insert('study_sessions', <String, Object?>{
      'course_id': courseId,
      'start_ts': start.millisecondsSinceEpoch,
      'end_ts': end.millisecondsSinceEpoch,
      'kind': 'free',
      'planned_min': minutes,
      'completed': 1,
    });
    invalidate();
  }

  // ───────── مستمرِ اعلام‌شده از معلم ─────────

  static Future<double?> contOverride(int courseId) async => double.tryParse(await LuxDb.instance.kvGet('cont_override_$courseId') ?? '');

  static Future<void> setContOverride(int courseId, double? v) async {
    final db = LuxDb.instance;
    await db.kvSet('cont_override_$courseId', v == null ? '' : '$v');
    invalidate();
  }

  static int minutesOfBlocksDone(List<SBlock> bs) => bs.where((b) => b.status == 'done').fold(0, (a, b) => a + b.durMin);

  static double clamp01(double v) => math.max(0.0, math.min(1.0, v));

  static String jsonOf(Object o) => jsonEncode(o);
}
