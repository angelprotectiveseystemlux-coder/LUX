import 'dart:convert';
import '../core/util.dart';
import '../services/notification_service.dart';
import 'database.dart';
import 'exam_ask_store.dart';

/// یادآورهای امتحان و تکلیف. شناسه‌ها برای هر مورد ثابت‌اند تا بشود لغو/بازسازی کرد.
class Reminders {
  Reminders._();

  static const int _examBase = 100000;
  static const int _taskBase = 200000;
  static const int slots = 4;

  static int _examId(int id, int k) => _examBase + id * 10 + k;
  static int _taskId(int id, int k) => _taskBase + id * 10 + k;

  static List<int> parse(Object? json) {
    if (json == null) return <int>[];
    try {
      final v = jsonDecode(json.toString());
      if (v is List) return v.map((e) => asInt(e)).where((e) => e >= 0).toList();
    } catch (_) {}
    return <int>[];
  }

  static String encode(List<int> minutes) => jsonEncode(minutes);

  static String label(int minutes) {
    if (minutes == 0) return 'سرِ موعد';
    if (minutes % 10080 == 0) return '${minutes ~/ 10080} هفته قبل';
    if (minutes % 1440 == 0) return '${minutes ~/ 1440} روز قبل';
    if (minutes % 60 == 0) return '${minutes ~/ 60} ساعت قبل';
    return '$minutes دقیقه قبل';
  }

  static Future<void> _cancelAll(int Function(int, int) idOf, int id) async {
    for (var k = 0; k < slots; k++) {
      try {
        await NotificationService.instance.cancel(idOf(id, k));
      } catch (_) {}
    }
  }

  /// اعلانِ «امتحان چطور بود؟» (شناسه‌ی اسلاتِ ۹ هر امتحان)
  static Future<void> _cancelAsk(int examId) async {
    try {
      await NotificationService.instance.cancel(_examId(examId, 9));
    } catch (_) {}
  }

  static Future<void> syncAsk(int examId) async {
    await _cancelAsk(examId);
    final rows = await LuxDb.instance.rawQuery(
      'SELECT e.at_ts, e.status, e.ask_offset_min, c.name AS course '
      'FROM exams e JOIN courses c ON c.id = e.course_id WHERE e.id = ?',
      [examId],
    );
    if (rows.isEmpty) return;
    final e = rows.first;
    if (asStr(e['status']) != 'planned') return;
    final when = ExamAskStore.askAt(fromTs(e['at_ts']), asInt(e['ask_offset_min'], 90), await ExamAskStore.askMinutes());
    if (!when.isAfter(DateTime.now())) return;
    try {
      await NotificationService.instance.schedule(
        id: _examId(examId, 9),
        title: 'امتحان ${asStr(e['course'])} چطور بود؟',
        body: 'یک لحظه بگو چطور شد؛ نمره یا حالِ خودت را ثبت کن.',
        when: when,
      );
    } catch (_) {}
  }

  /// برای امتحان‌های پیش‌رو (و چند روزِ اخیر)، اعلانِ «چطور بود؟» را دوباره می‌سازد.
  static Future<void> resyncAsks() async {
    final from = DateTime.now().subtract(const Duration(days: 1)).millisecondsSinceEpoch;
    final rows = await LuxDb.instance.rawQuery("SELECT id FROM exams WHERE status = 'planned' AND at_ts >= ?", [from]);
    for (final r in rows) {
      await syncAsk(asInt(r['id']));
    }
  }

  static Future<void> syncExam(int examId) async {
    await _cancelAll(_examId, examId);
    await syncAsk(examId);
    final rows = await LuxDb.instance.rawQuery(
      'SELECT e.at_ts, e.title, e.type_name, e.status, e.remind_json, c.name AS course '
      'FROM exams e JOIN courses c ON c.id = e.course_id WHERE e.id = ?',
      [examId],
    );
    if (rows.isEmpty) return;
    final e = rows.first;
    if (asStr(e['status']) != 'planned') return;
    final at = fromTs(e['at_ts']);
    final list = parse(e['remind_json']);
    final what = asStr(e['title']).isNotEmpty ? asStr(e['title']) : asStr(e['type_name'], 'امتحان');
    for (var k = 0; k < list.length && k < slots; k++) {
      final when = at.subtract(Duration(minutes: list[k]));
      if (!when.isAfter(DateTime.now())) continue;
      try {
        await NotificationService.instance.schedule(
          id: _examId(examId, k),
          title: 'امتحان ${asStr(e['course'])}',
          body: list[k] == 0 ? '$what همین حالا شروع می‌شود.' : '$what — ${label(list[k])}',
          when: when,
        );
      } catch (_) {}
    }
  }

  static Future<void> cancelExam(int examId) async {
    await _cancelAll(_examId, examId);
    await _cancelAsk(examId);
  }

  static Future<void> syncTask(int taskId) async {
    await _cancelAll(_taskId, taskId);
    final rows = await LuxDb.instance.query('tasks', where: 'id = ?', args: [taskId], limit: 1);
    if (rows.isEmpty) return;
    final t = rows.first;
    if (asStr(t['status']) != 'open' || t['due_ts'] == null) return;
    final due = fromTs(t['due_ts']);
    final list = parse(t['remind_json']);
    for (var k = 0; k < list.length && k < slots; k++) {
      final when = due.subtract(Duration(minutes: list[k]));
      if (!when.isAfter(DateTime.now())) continue;
      try {
        await NotificationService.instance.schedule(
          id: _taskId(taskId, k),
          title: 'تکلیف: ${asStr(t['title'])}',
          body: list[k] == 0 ? 'موعد تکلیف رسید.' : 'موعد تکلیف — ${label(list[k])}',
          when: when,
        );
      } catch (_) {}
    }
  }

  static Future<void> cancelTask(int taskId) => _cancelAll(_taskId, taskId);
}
