import '../core/util.dart';
import 'database.dart';

/// دسترسی به داده‌ی رقابت: روشن/خاموش، فهرست رقبا و نمره‌ی رقبا در هر امتحان.
class RivalryRepo {
  RivalryRepo._();

  static const String _key = 'rivalry_on';

  static Future<bool> enabled() async => (await LuxDb.instance.kvGet(_key)) == '1';

  static Future<void> setEnabled(bool v) => LuxDb.instance.kvSet(_key, v ? '1' : '0');

  static Future<List<Map<String, Object?>>> rivals() => LuxDb.instance.query('rivals', orderBy: 'id');

  /// نمره‌ی هر رقیب در یک امتحان (فقط رقبایی که نمره‌شان ثبت شده)
  static Future<Map<int, double>> scoresForExam(int examId) async {
    final rows = await LuxDb.instance.query('rival_scores', where: 'exam_id = ?', args: [examId]);
    return {for (final r in rows) asInt(r['rival_id']): asDouble(r['score'])};
  }

  /// null = «نمره‌اش را نمی‌دانم» → ردیفِ نمره حذف می‌شود.
  static Future<void> saveExamScores(int examId, Map<int, double?> scores) async {
    final db = LuxDb.instance;
    for (final e in scores.entries) {
      final v = e.value;
      if (v == null) {
        await db.delete('rival_scores', where: 'rival_id = ? AND exam_id = ?', args: [e.key, examId]);
      } else {
        await db.insert('rival_scores', <String, Object?>{'rival_id': e.key, 'exam_id': examId, 'score': v});
      }
    }
  }

  /// افزودنِ یک یا چند رقیب (نام‌های تکراری نادیده گرفته می‌شوند). تعداد افزوده‌شده را برمی‌گرداند.
  static Future<int> addRivals(List<String> names) async {
    final db = LuxDb.instance;
    final existing = {for (final r in await rivals()) asStr(r['name']).trim().toLowerCase()};
    var k = await db.count('rivals');
    var added = 0;
    for (final raw in names) {
      final n = raw.trim();
      if (n.isEmpty || existing.contains(n.toLowerCase())) continue;
      existing.add(n.toLowerCase());
      await db.insert('rivals', <String, Object?>{
        'name': n,
        // رنگ ۰ مالِ خودِ کاربر است؛ رقبا از ۱ تا ۷ می‌چرخند.
        'color': 1 + (k % 7),
        'created_at': DateTime.now().millisecondsSinceEpoch,
      });
      k++;
      added++;
    }
    return added;
  }

  static Future<void> deleteRival(int id) async {
    final db = LuxDb.instance;
    await db.delete('rival_scores', where: 'rival_id = ?', args: [id]);
    await db.delete('rivals', where: 'id = ?', args: [id]);
  }
}
