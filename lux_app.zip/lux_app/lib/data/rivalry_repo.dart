import '../core/util.dart';
import 'database.dart';

/// دسترسی به داده‌ی رقابت: روشن/خاموش، فهرست رقبا و نمره‌ی رقبا در هر امتحان.
class RivalryRepo {
  RivalryRepo._();

  static const String _key = 'rivalry_on';

  static Future<bool> enabled() async => (await LuxDb.instance.kvGet(_key)) == '1';

  static Future<void> setEnabled(bool v) => LuxDb.instance.kvSet(_key, v ? '1' : '0');

  static Future<List<Map<String, Object?>>> rivals() => LuxDb.instance.query('rivals', orderBy: 'id');

  /// نمره‌ی هر رقیب در یک امتحان (فقط رقبایی که نمره‌شان ثبت شده)
  static Future<Map<int, double>> scoresForExam(int examId) async {
    final rows = await LuxDb.instance.query('rival_scores', where: 'exam_id = ?', args: [examId]);
    return {for (final r in rows) asInt(r['rival_id']): asDouble(r['score'])};
  }

  /// null = «نمره‌اش را نمی‌دانم» → ردیفِ نمره حذف می‌شود.
  static Future<void> saveExamScores(int examId, Map<int, double?> scores) async {
    final db = LuxDb.instance;
    for (final e in scores.entries) {
      final v = e.value;
      if (v == null) {
        await db.delete('rival_scores', where: 'rival_id = ? AND exam_id = ?', args: [e.key, examId]);
      } else {
        await db.insert('rival_scores', <String, Object?>{'rival_id': e.key, 'exam_id': examId, 'score': v});
      }
    }
  }

  /// امتحان‌های انجام‌شده (دارای نمره) به ترتیبِ درس و تاریخ؛ برای ثبتِ نمره‌ی گذشته‌ی رقیبِ تازه.
  static Future<List<Map<String, Object?>>> doneExams() => LuxDb.instance.rawQuery(
        'SELECT e.id, e.course_id, e.at_ts, e.max_score, e.score, e.title, e.type_name, c.name AS cname '
        'FROM exams e JOIN courses c ON c.id = e.course_id '
        "WHERE e.status = 'done' ORDER BY c.name, e.at_ts, e.id",
      );

  /// نمره‌های ثبت‌شده‌ی یک رقیب: {شناسه‌ی امتحان: نمره}
  static Future<Map<int, double>> scoresOfRival(int rivalId) async {
    final rows = await LuxDb.instance.query('rival_scores', where: 'rival_id = ?', args: [rivalId]);
    return {for (final r in rows) asInt(r['exam_id']): asDouble(r['score'])};
  }

  /// افزودنِ یک یا چند رقیب (نام‌های تکراری نادیده گرفته می‌شوند). شناسه‌ی رقبای تازه را برمی‌گرداند.
  static Future<List<int>> addRivalIds(List<String> names) async {
    final db = LuxDb.instance;
    final existing = {for (final r in await rivals()) asStr(r['name']).trim().toLowerCase()};
    var k = await db.count('rivals');
    final ids = <int>[];
    for (final raw in names) {
      final n = raw.trim();
      if (n.isEmpty || existing.contains(n.toLowerCase())) continue;
      existing.add(n.toLowerCase());
      final id = await db.insert('rivals', <String, Object?>{
        'name': n,
        // رنگ ۰ مالِ خودِ کاربر است؛ رقبا از ۱ تا ۷ می‌چرخند.
        'color': 1 + (k % 7),
        'created_at': DateTime.now().millisecondsSinceEpoch,
      });
      ids.add(id);
      k++;
    }
    return ids;
  }

  /// افزودنِ یک یا چند رقیب؛ تعدادِ افزوده‌شده را برمی‌گرداند.
  static Future<int> addRivals(List<String> names) async => (await addRivalIds(names)).length;

  // ───────── مثبت و منفی و کنفرانسِ رقبا ─────────

  /// {شناسه‌ی رقیب: {شناسه‌ی درس: [مثبت، منفی]}}
  static Future<Map<int, Map<int, List<int>>>> behaviorCounts() async {
    final rows = await LuxDb.instance.query('rival_behavior');
    final out = <int, Map<int, List<int>>>{};
    for (final r in rows) {
      out.putIfAbsent(asInt(r['rival_id']), () => <int, List<int>>{})[asInt(r['course_id'])] =
          <int>[asInt(r['positives']), asInt(r['negatives'])];
    }
    return out;
  }

  /// نمره‌ی کنفرانسِ همه‌ی رقبا (از ۲۰): ردیف‌هایی با rival_id، course_id، score، at_ts
  static Future<List<Map<String, Object?>>> conferenceRows() => LuxDb.instance.query('rival_conf');

  static Future<Map<int, List<int>>> behaviorOfRival(int rivalId) async =>
      (await behaviorCounts())[rivalId] ?? <int, List<int>>{};

  static Future<Map<int, double>> conferenceOfRival(int rivalId) async {
    final rows = await LuxDb.instance.query('rival_conf', where: 'rival_id = ?', args: [rivalId]);
    return {for (final r in rows) asInt(r['course_id']): asDouble(r['score'])};
  }

  /// مثبت و منفی ([مثبت، منفی] به‌ازای هر درس) و کنفرانس (null = «نمره‌اش را نمی‌دانم») یک رقیب را ذخیره می‌کند.
  static Future<void> saveRivalCourseData(
    int rivalId, {
    required Map<int, List<int>> behavior,
    required Map<int, double?> conference,
  }) async {
    final db = LuxDb.instance;
    for (final e in behavior.entries) {
      await db.delete('rival_behavior', where: 'rival_id = ? AND course_id = ?', args: [rivalId, e.key]);
      final pos = e.value[0], neg = e.value[1];
      if (pos > 0 || neg > 0) {
        await db.insert('rival_behavior', <String, Object?>{
          'rival_id': rivalId,
          'course_id': e.key,
          'positives': pos,
          'negatives': neg,
        });
      }
    }
    final now = DateTime.now().millisecondsSinceEpoch;
    for (final e in conference.entries) {
      final old = await db.query('rival_conf', where: 'rival_id = ? AND course_id = ?', args: [rivalId, e.key], limit: 1);
      final ts = old.isEmpty ? now : asInt(old.first['at_ts'], now);
      await db.delete('rival_conf', where: 'rival_id = ? AND course_id = ?', args: [rivalId, e.key]);
      final v = e.value;
      if (v != null) {
        await db.insert('rival_conf', <String, Object?>{
          'rival_id': rivalId,
          'course_id': e.key,
          'score': v,
          'at_ts': ts,
        });
      }
    }
  }

  static Future<void> deleteRival(int id) async {
    final db = LuxDb.instance;
    await db.delete('rival_behavior', where: 'rival_id = ?', args: [id]);
    await db.delete('rival_conf', where: 'rival_id = ?', args: [id]);
    await db.delete('rival_scores', where: 'rival_id = ?', args: [id]);
    await db.delete('rivals', where: 'id = ?', args: [id]);
  }
}
