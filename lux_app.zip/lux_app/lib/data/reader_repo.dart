import '../core/app_bus.dart';
import '../core/util.dart';
import 'database.dart';

/// رنگ‌های هایلایت و کاربردِ پیشنهادیِ هرکدام
const List<int> kHlColors = <int>[0xFFFFD54F, 0xFF66BB6A, 0xFF42A5F5, 0xFFEF5350, 0xFFAB47BC, 0xFFFFA726];
const List<String> kHlNames = <String>['مهم', 'تعریف و مفهوم', 'نکته‌ی تکمیلی', 'دشوار', 'نکته‌ی امتحانی', 'نیازمند مرور'];

/// وضعیتِ صفحه
const List<String> kPageStatusKeys = <String>['reading', 'done', 'review', 'hard'];
const List<String> kPageStatusNames = <String>['در حال مطالعه', 'مطالعه شد', 'نیازمند مرور', 'دشوار'];
const List<int> kPageStatusColors = <int>[0xFF42A5F5, 0xFF66BB6A, 0xFFFFA726, 0xFFEF5350];

class ReaderRepo {
  ReaderRepo._();

  /// کتاب‌هایی که فایل PDF دارند، با پیشرفت و زمانِ مطالعه
  static Future<List<Map<String, Object?>>> library() => LuxDb.instance.rawQuery(
        'SELECT b.*, c.name AS course, '
        "(SELECT COUNT(*) FROM annotations a WHERE a.book_id = b.id AND a.kind = 'status' AND a.note = 'done') AS done_pages, "
        '(SELECT MAX(rs.end_ts) FROM reading_sessions rs WHERE rs.book_id = b.id) AS last_read, '
        '(SELECT COALESCE(SUM(rs.end_ts - rs.start_ts), 0) FROM reading_sessions rs WHERE rs.book_id = b.id) AS read_ms '
        'FROM books b LEFT JOIN courses c ON c.id = b.course_id '
        "WHERE b.file_path IS NOT NULL AND b.file_path != '' "
        'ORDER BY COALESCE(last_read, b.added_at, 0) DESC',
      );

  static Future<Map<String, Object?>?> book(int id) async {
    final r = await LuxDb.instance.rawQuery(
      'SELECT b.*, c.name AS course FROM books b LEFT JOIN courses c ON c.id = b.course_id WHERE b.id = ?',
      [id],
    );
    return r.isEmpty ? null : r.first;
  }

  static Future<int> addBook({required String path, required String title, int? courseId, required int pages}) async {
    final id = await LuxDb.instance.insert('books', <String, Object?>{
      'course_id': courseId,
      'title': title,
      'pages': pages,
      'file_path': path,
      'last_page': 0,
      'added_at': DateTime.now().millisecondsSinceEpoch,
    });
    AppBus.bump();
    return id;
  }

  /// فایلِ PDF را به یک کتابِ موجود وصل می‌کند.
  static Future<void> attachPdf(int bookId, String path, int pages) async {
    await LuxDb.instance.update('books', <String, Object?>{'file_path': path, 'pages': pages}, where: 'id = ?', args: [bookId]);
    AppBus.bump();
  }

  static Future<void> updateBook(int id, {required String title, int? courseId}) async {
    await LuxDb.instance.update('books', <String, Object?>{'title': title, 'course_id': courseId}, where: 'id = ?', args: [id]);
    AppBus.bump();
  }

  static Future<void> setPages(int bookId, int pages) =>
      LuxDb.instance.update('books', <String, Object?>{'pages': pages}, where: 'id = ?', args: [bookId]);

  static Future<void> saveProgress(int bookId, int page) =>
      LuxDb.instance.update('books', <String, Object?>{'last_page': page}, where: 'id = ?', args: [bookId]);

  static Future<void> addSession(int bookId, DateTime start, DateTime end, int fromPage, int toPage) async {
    await LuxDb.instance.insert('reading_sessions', <String, Object?>{
      'book_id': bookId,
      'start_ts': start.millisecondsSinceEpoch,
      'end_ts': end.millisecondsSinceEpoch,
      'from_page': fromPage,
      'to_page': toPage,
    });
    AppBus.bump();
  }

  static Future<List<Map<String, Object?>>> annotations(int bookId) =>
      LuxDb.instance.query('annotations', where: 'book_id = ?', args: [bookId], orderBy: 'page, id');

  static Future<List<Map<String, Object?>>> chapters(int bookId) =>
      LuxDb.instance.query('chapters', where: 'book_id = ?', args: [bookId], orderBy: 'start_page, id');

  static Future<int> addAnnotation(int bookId, int page, String kind, {String? data, String? note, int? color}) =>
      LuxDb.instance.insert('annotations', <String, Object?>{
        'book_id': bookId,
        'page': page,
        'kind': kind,
        'data': data,
        'note': note,
        'color': color,
        'created_at': DateTime.now().millisecondsSinceEpoch,
      });

  static Future<void> updateAnnotation(int id, {String? note, int? color}) async {
    final v = <String, Object?>{};
    if (note != null) v['note'] = note;
    if (color != null) v['color'] = color;
    if (v.isEmpty) return;
    await LuxDb.instance.update('annotations', v, where: 'id = ?', args: [id]);
  }

  static Future<void> deleteAnnotation(int id) => LuxDb.instance.delete('annotations', where: 'id = ?', args: [id]);

  /// وضعیتِ یک صفحه را می‌گذارد (null = پاک کردن)
  static Future<void> setStatus(int bookId, int page, String? status) async {
    await LuxDb.instance.delete('annotations', where: "book_id = ? AND page = ? AND kind = 'status'", args: [bookId, page]);
    if (status != null) {
      await addAnnotation(bookId, page, 'status', note: status);
    }
    AppBus.bump();
  }

  /// فایل‌های PDF بدون ردیفِ کتاب مهم نیستند؛ فقط اندازه‌ی فایل برای نمایشِ حجم
  static String sizeLabel(int bytes) {
    if (bytes < 1024 * 1024) return '${faSize(bytes / 1024)} کیلوبایت';
    return '${faSize(bytes / (1024 * 1024))} مگابایت';
  }

  static String faSize(double v) {
    final s = v.toStringAsFixed(v >= 10 ? 0 : 1);
    const fa = '۰۱۲۳۴۵۶۷۸۹';
    return s.replaceAllMapped(RegExp(r'\d'), (m) => fa[int.parse(m[0]!)]);
  }

  static int toInt(Object? v) => asInt(v);
}
