import 'package:shamsi_date/shamsi_date.dart';
import '../core/jalali_utils.dart';

/// نوعِ یک مناسبت در تقویم
enum OccasionType { holiday, occasion, world }

class Occasion {
  final String title;
  final OccasionType type;

  /// تخمینی: تاریخ قمری این مناسبت هنوز با تقویم رسمی تطبیق داده نشده و ممکن است ±۱ روز جابه‌جا شود.
  final bool tentative;
  const Occasion(this.title, this.type, {this.tentative = false});
  bool get isHoliday => type == OccasionType.holiday;
}

const List<String> hijriMonths = <String>[
  'محرم', 'صفر', 'ربیع‌الاول', 'ربیع‌الثانی', 'جمادی‌الاول', 'جمادی‌الثانی',
  'رجب', 'شعبان', 'رمضان', 'شوال', 'ذی‌القعده', 'ذی‌الحجه',
];

const List<String> gregorianMonthsEn = <String>[
  'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec',
];

class _J {
  final int m;
  final int d;
  final String t;
  final OccasionType type;
  const _J(this.m, this.d, this.t, [this.type = OccasionType.occasion]);
}

class _L {
  /// d = 0 یعنی «آخرین روزِ ماه»
  final int m;
  final int d;
  final String t;
  final bool holiday;
  const _L(this.m, this.d, this.t, [this.holiday = false]);
}

class _G {
  final int m;
  final int d;
  final String t;
  const _G(this.m, this.d, this.t);
}

/// تعطیلات رسمی و مناسبت‌های تقویم ایران.
/// - شمسیِ ثابت: مستقیم از تاریخ شمسی.
/// - قمری: از تقویم قمری (جدولی) حساب می‌شود و برای ماه‌هایی که تقویم رسمی منتشر شده با همان اصلاح می‌شود؛
///   بقیه «تخمینی» علامت می‌خورند، چون در ایران آغاز ماه‌های قمری با رؤیت هلال تعیین می‌شود.
class HolidayData {
  HolidayData._();

  static final Map<String, List<Occasion>> _index = <String, List<Occasion>>{};
  static bool _built = false;

  static String _key(DateTime d) => '${d.year}-${two(d.month)}-${two(d.day)}';

  static void _add(DateTime d, Occasion o) => _index.putIfAbsent(_key(d), () => <Occasion>[]).add(o);

  /// مناسبت‌های یک روز (تعطیلی‌ها اول)
  static List<Occasion> of(DateTime day) {
    _build();
    final l = _index[_key(day)];
    if (l == null) return const <Occasion>[];
    final out = List<Occasion>.from(l);
    out.sort((a, b) => a.type.index.compareTo(b.type.index));
    return out;
  }

  static bool isHoliday(DateTime day) => of(day).any((o) => o.isHoliday);

  /// جمعه یا تعطیلِ رسمی
  static bool isOffDay(DateTime day) => weekdayIndex(day) == 6 || isHoliday(day);

  // ───────────────────────── قمری ─────────────────────────

  /// آغاز ماه‌های قمری که با تقویم رسمی ایران تطبیق داده شده‌اند (کلید: سال×۱۰۰ + ماه).
  static final Map<int, DateTime> _verified = <int, DateTime>{
    144609: DateTime(2025, 3, 2),
    144610: DateTime(2025, 3, 31),
    144612: DateTime(2025, 5, 28),
    144701: DateTime(2025, 6, 27),
    144702: DateTime(2025, 7, 27),
    144703: DateTime(2025, 8, 25),
    144707: DateTime(2025, 12, 22),
    144709: DateTime(2026, 2, 19),
    144710: DateTime(2026, 3, 21),
    144712: DateTime(2026, 5, 18),
    144801: DateTime(2026, 6, 16),
    144802: DateTime(2026, 7, 16),
    144803: DateTime(2026, 8, 14),
    144807: DateTime(2026, 12, 11),
    144808: DateTime(2027, 1, 10),
    144809: DateTime(2027, 2, 8),
    144810: DateTime(2027, 3, 10),
  };

  static DateTime _tabular(int hy, int hm, int hd) {
    final ord = hd + ((59 * (hm - 1) + 1) ~/ 2) + (hy - 1) * 354 + ((3 + 11 * hy) ~/ 30) + 227014;
    final u = DateTime.utc(1970, 1, 1).add(Duration(days: ord - 719163));
    return DateTime(u.year, u.month, u.day);
  }

  static DateTime _monthStart(int hy, int hm) {
    var y = hy;
    var m = hm;
    if (m > 12) {
      y += 1;
      m -= 12;
    }
    return _verified[y * 100 + m] ?? _tabular(y, m, 1);
  }

  static bool _isVerified(int hy, int hm) => _verified.containsKey(hy * 100 + hm);

  /// تاریخ قمری یک روز: [سال، ماه، روز]
  static List<int> hijriOf(DateTime d) {
    final day = dateOnly(d);
    final guess = ((day.year - 622) * 33 / 32).floor();
    for (var y = guess + 1; y >= guess - 2; y--) {
      for (var m = 12; m >= 1; m--) {
        final s = _monthStart(y, m);
        if (!s.isAfter(day)) {
          return <int>[y, m, daysBetween(s, day) + 1];
        }
      }
    }
    return <int>[guess, 1, 1];
  }

  static String hijriLabel(DateTime d) {
    final h = hijriOf(d);
    return '${faDigits(h[2])} ${hijriMonths[h[1] - 1]} ${faDigits(h[0])}';
  }

  static String gregorianLabel(DateTime d) => '${gregorianMonthsEn[d.month - 1]} ${d.day}, ${d.year}';

  // ───────────────────────── ساخت نمایه ─────────────────────────

  static const int _fromY = 1402;
  static const int _toY = 1413;

  static void _build() {
    if (_built) return;
    _built = true;

    for (var y = _fromY; y <= _toY; y++) {
      for (final e in _jalali) {
        if (e.d > jalaliMonthLength(y, e.m)) continue;
        _add(Jalali(y, e.m, e.d).toDateTime(), Occasion(e.t, e.type));
      }
      // آخرین چهارشنبه‌ی سال و شبِ چهارشنبه‌سوری
      final eLen = jalaliMonthLength(y, 12);
      for (var d = eLen; d >= 1; d--) {
        final dt = Jalali(y, 12, d).toDateTime();
        if (weekdayIndex(dt) == 4) {
          _add(dt, const Occasion('آخرین چهارشنبه‌ی سال', OccasionType.occasion));
          _add(dt.subtract(const Duration(days: 1)), const Occasion('شبِ چهارشنبه‌سوری', OccasionType.occasion));
          break;
        }
      }
    }

    for (var gy = _fromY + 621; gy <= _toY + 622; gy++) {
      for (final e in _world) {
        _add(DateTime(gy, e.m, e.d), Occasion(e.t, OccasionType.world));
      }
    }

    for (var hy = 1443; hy <= 1457; hy++) {
      for (final e in _lunar) {
        final DateTime date;
        if (e.d == 0) {
          date = _monthStart(hy, e.m + 1).subtract(const Duration(days: 1));
        } else {
          date = _monthStart(hy, e.m).add(Duration(days: e.d - 1));
        }
        final tentative = e.d == 0 ? !_isVerified(e.m == 12 ? hy + 1 : hy, e.m == 12 ? 1 : e.m + 1) : !_isVerified(hy, e.m);
        _add(
          DateTime(date.year, date.month, date.day),
          Occasion(e.t, e.holiday ? OccasionType.holiday : OccasionType.occasion, tentative: tentative),
        );
      }
    }
  }

  // ───────────────────────── داده‌ها ─────────────────────────

  static const List<_J> _jalali = <_J>[
    // فروردین
    _J(1, 1, 'آغاز سال نو · عید نوروز', OccasionType.holiday),
    _J(1, 2, 'عید نوروز', OccasionType.holiday),
    _J(1, 3, 'عید نوروز', OccasionType.holiday),
    _J(1, 4, 'عید نوروز', OccasionType.holiday),
    _J(1, 6, 'زادروز زرتشت'),
    _J(1, 12, 'روز جمهوری اسلامی ایران', OccasionType.holiday),
    _J(1, 13, 'روز طبیعت (سیزده‌به‌در)', OccasionType.holiday),
    _J(1, 20, 'روز ملی فناوری هسته‌ای'),
    _J(1, 21, 'شهادت سپهبد علی صیاد شیرازی'),
    _J(1, 29, 'روز ارتش جمهوری اسلامی ایران'),
    // اردیبهشت
    _J(2, 1, 'روز بزرگداشت سعدی'),
    _J(2, 9, 'روز شوراها'),
    _J(2, 10, 'روز ملی خلیج فارس'),
    _J(2, 11, 'روز بزرگداشت شیخ بهایی · روز معمار'),
    _J(2, 12, 'روز معلم'),
    _J(2, 25, 'روز بزرگداشت فردوسی'),
    _J(2, 27, 'روز ارتباطات و روابط عمومی'),
    _J(2, 28, 'روز بزرگداشت حکیم عمر خیام'),
    // خرداد
    _J(3, 3, 'آزادسازی خرمشهر'),
    _J(3, 14, 'رحلت امام خمینی (ره)', OccasionType.holiday),
    _J(3, 15, 'قیام ۱۵ خرداد', OccasionType.holiday),
    _J(3, 25, 'روز ملی گل و گیاه'),
    // تیر
    _J(4, 1, 'روز اصناف'),
    _J(4, 7, 'روز قوه قضائیه · شهادت آیت‌الله بهشتی'),
    _J(4, 8, 'روز مبارزه با سلاح‌های شیمیایی و میکروبی'),
    _J(4, 14, 'روز قلم'),
    // مرداد
    _J(5, 5, 'سالروز صدور فرمان مشروطیت'),
    _J(5, 17, 'روز خبرنگار'),
    _J(5, 26, 'بازگشت آزادگان به میهن'),
    _J(5, 28, 'کودتای ۲۸ مرداد'),
    // شهریور
    _J(6, 1, 'روز بزرگداشت ابوعلی سینا · روز پزشک'),
    _J(6, 8, 'روز مبارزه با تروریسم'),
    _J(6, 14, 'روز تعاون'),
    _J(6, 17, 'قیام ۱۷ شهریور'),
    _J(6, 27, 'روز شعر و ادب فارسی'),
    _J(6, 31, 'آغاز هفته دفاع مقدس'),
    // مهر
    _J(7, 1, 'آغاز سال تحصیلی'),
    _J(7, 7, 'روز آتش‌نشانی و ایمنی'),
    _J(7, 20, 'روز بزرگداشت حافظ'),
    // آبان
    _J(8, 13, 'روز دانش‌آموز'),
    _J(8, 14, 'روز فرهنگ عمومی'),
    _J(8, 24, 'روز کتاب و کتاب‌خوانی'),
    // آذر
    _J(9, 5, 'روز بسیج مستضعفان'),
    _J(9, 7, 'روز نیروی دریایی'),
    _J(9, 16, 'روز دانشجو'),
    _J(9, 30, 'شب یلدا'),
    // دی
    _J(10, 7, 'سالروز نهضت سوادآموزی'),
    _J(10, 13, 'شهادت سردار سلیمانی · روز جهانی مقاومت'),
    _J(10, 19, 'قیام مردم قم'),
    _J(10, 22, 'تشکیل شورای انقلاب'),
    // بهمن
    _J(11, 12, 'بازگشت امام خمینی · آغاز دهه فجر'),
    _J(11, 19, 'روز نیروی هوایی'),
    _J(11, 21, 'شکسته شدن حکومت نظامی'),
    _J(11, 22, 'پیروزی انقلاب اسلامی', OccasionType.holiday),
    // اسفند
    _J(12, 5, 'روز مهندسی'),
    _J(12, 15, 'روز درختکاری'),
    _J(12, 29, 'روز ملی شدن صنعت نفت ایران', OccasionType.holiday),
  ];

  static const List<_L> _lunar = <_L>[
    _L(1, 1, 'آغاز ماه محرم'),
    _L(1, 9, 'تاسوعای حسینی', true),
    _L(1, 10, 'عاشورای حسینی', true),
    _L(1, 25, 'شهادت امام سجاد (ع)'),
    _L(2, 20, 'اربعین حسینی', true),
    _L(2, 28, 'رحلت پیامبر اکرم (ص) و شهادت امام حسن مجتبی (ع)', true),
    _L(2, 0, 'شهادت امام رضا (ع)', true),
    _L(3, 8, 'شهادت امام حسن عسکری (ع) · آغاز امامت امام زمان (عج)', true),
    _L(3, 17, 'میلاد پیامبر اکرم (ص) و امام جعفر صادق (ع)', true),
    _L(5, 5, 'ولادت حضرت زینب (س) · روز پرستار'),
    _L(6, 3, 'شهادت حضرت فاطمه زهرا (س)', true),
    _L(6, 20, 'ولادت حضرت فاطمه (س) · روز مادر'),
    _L(7, 13, 'ولادت امام علی (ع) · روز پدر', true),
    _L(7, 27, 'مبعث پیامبر اکرم (ص)', true),
    _L(8, 3, 'ولادت امام حسین (ع) · روز پاسدار'),
    _L(8, 4, 'ولادت حضرت عباس (ع) · روز جانباز'),
    _L(8, 5, 'ولادت امام سجاد (ع)'),
    _L(8, 15, 'نیمه شعبان · ولادت امام زمان (عج)', true),
    _L(9, 1, 'آغاز ماه رمضان'),
    _L(9, 15, 'ولادت امام حسن مجتبی (ع)'),
    _L(9, 19, 'ضربت خوردن امام علی (ع)'),
    _L(9, 21, 'شهادت امام علی (ع)', true),
    _L(9, 23, 'شبِ قدر (شب ۲۳ رمضان)'),
    _L(10, 1, 'عید سعید فطر', true),
    _L(10, 2, 'تعطیل به مناسبت عید فطر', true),
    _L(10, 25, 'شهادت امام جعفر صادق (ع)', true),
    _L(11, 11, 'ولادت امام رضا (ع)'),
    _L(12, 10, 'عید سعید قربان', true),
    _L(12, 18, 'عید سعید غدیر خم', true),
  ];

  static const List<_G> _world = <_G>[
    _G(1, 1, 'سال نو میلادی'),
    _G(2, 14, 'ولنتاین'),
    _G(3, 8, 'روز جهانی زن'),
    _G(4, 22, 'روز جهانی زمین'),
    _G(5, 1, 'روز جهانی کارگر'),
    _G(6, 5, 'روز جهانی محیط زیست'),
    _G(10, 5, 'روز جهانی معلم'),
    _G(11, 20, 'روز جهانی کودک'),
    _G(12, 10, 'روز جهانی حقوق بشر'),
    _G(12, 25, 'کریسمس'),
  ];
}
