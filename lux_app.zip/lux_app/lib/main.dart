import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_localizations/flutter_localizations.dart';

import 'core/theme.dart';
import 'data/database.dart';
import 'data/backup.dart';
import 'data/profile_repo.dart';
import 'services/lock_service.dart';
import 'services/notification_service.dart';
import 'ui/lock/lock_screen.dart';
import 'ui/onboarding/onboarding_flow.dart';
import 'ui/shell/app_shell.dart';
import 'ui/widgets/haptic.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await SystemChrome.setPreferredOrientations(<DeviceOrientation>[DeviceOrientation.portraitUp]);
  await SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
  SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
    statusBarColor: Colors.transparent,
    systemNavigationBarColor: Colors.transparent,
    statusBarIconBrightness: Brightness.light,
    systemNavigationBarIconBrightness: Brightness.light,
  ));

  await LuxDb.instance.open();
  Haptic.enabled = (await LuxDb.instance.kvGet('haptics') ?? '1') == '1';
  try {
    await NotificationService.instance.init();
  } catch (_) {
    // اگر نوتیف راه نیفتاد، بقیه‌ی اپ باید کار کند.
  }
  final onboarded = await ProfileRepo.isOnboarded();
  final locked = onboarded && await LockService.hasPin();
  runApp(LuxApp(onboarded: onboarded, locked: locked));
  if (onboarded) {
    // اگر مجوز اعلان/آلارم هنوز داده نشده، بعد از بالا آمدن اپ از خود اندروید می‌پرسد.
    unawaited(NotificationService.instance.ensurePermissions().catchError((_) => (false, false)));
  }
}

class LuxApp extends StatefulWidget {
  final bool onboarded;
  final bool locked;
  const LuxApp({super.key, required this.onboarded, required this.locked});

  @override
  State<LuxApp> createState() => _LuxAppState();
}

class _LuxAppState extends State<LuxApp> with WidgetsBindingObserver {
  late bool _onboarded = widget.onboarded;
  late bool _locked = widget.locked;
  DateTime? _pausedAt;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.paused) {
      _pausedAt = DateTime.now();
      // فایل داده‌ی خودکار را به‌روز نگه می‌داریم.
      unawaited(Backup.autoSave());
    } else if (state == AppLifecycleState.resumed) {
      final at = _pausedAt;
      _pausedAt = null;
      if (at != null && _onboarded && DateTime.now().difference(at).inSeconds > 20) {
        LockService.hasPin().then((has) {
          if (has && mounted) setState(() => _locked = true);
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'LUX',
      debugShowCheckedModeBanner: false,
      theme: LuxTheme.dark(),
      locale: const Locale('fa', 'IR'),
      supportedLocales: const [Locale('fa', 'IR')],
      localizationsDelegates: const [
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
      ],
      // قفل روی کلِ Navigator می‌نشیند تا صفحه‌های بازِ داخلی هم پوشانده شوند.
      builder: (context, child) => Stack(
        fit: StackFit.expand,
        children: [
          child ?? const SizedBox.shrink(),
          if (_locked)
            Positioned.fill(
              child: LockScreen(key: const ValueKey('lock'), onUnlocked: () => setState(() => _locked = false)),
            ),
        ],
      ),
      home: AnimatedSwitcher(
        duration: const Duration(milliseconds: 500),
        child: _onboarded
            ? const AppShell(key: ValueKey('shell'))
            : OnboardingFlow(key: const ValueKey('onboarding'), onDone: () => setState(() => _onboarded = true)),
      ),
    );
  }
}
