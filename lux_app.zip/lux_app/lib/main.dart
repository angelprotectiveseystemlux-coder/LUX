import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_localizations/flutter_localizations.dart';

import 'core/theme.dart';
import 'data/database.dart';
import 'data/profile_repo.dart';
import 'services/notification_service.dart';
import 'ui/onboarding/onboarding_flow.dart';
import 'ui/shell/app_shell.dart';
import 'ui/widgets/haptic.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await SystemChrome.setPreferredOrientations(<DeviceOrientation>[DeviceOrientation.portraitUp]);
  await SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
  SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
    statusBarColor: Colors.transparent,
    systemNavigationBarColor: Colors.transparent,
    statusBarIconBrightness: Brightness.light,
    systemNavigationBarIconBrightness: Brightness.light,
  ));

  await LuxDb.instance.open();
  Haptic.enabled = (await LuxDb.instance.kvGet('haptics') ?? '1') == '1';
  try {
    await NotificationService.instance.init();
  } catch (_) {
    // اگر نوتیف راه نیفتاد، بقیه‌ی اپ باید کار کند.
  }
  final onboarded = await ProfileRepo.isOnboarded();
  runApp(LuxApp(onboarded: onboarded));
  if (onboarded) {
    // اگر مجوز اعلان/آلارم هنوز داده نشده، بعد از بالا آمدن اپ از خود اندروید می‌پرسد.
    unawaited(NotificationService.instance.ensurePermissions().catchError((_) => (false, false)));
  }
}

class LuxApp extends StatefulWidget {
  final bool onboarded;
  const LuxApp({super.key, required this.onboarded});

  @override
  State<LuxApp> createState() => _LuxAppState();
}

class _LuxAppState extends State<LuxApp> {
  late bool _onboarded = widget.onboarded;

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'LUX',
      debugShowCheckedModeBanner: false,
      theme: LuxTheme.dark(),
      locale: const Locale('fa', 'IR'),
      supportedLocales: const [Locale('fa', 'IR')],
      localizationsDelegates: const [
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
      ],
      home: AnimatedSwitcher(
        duration: const Duration(milliseconds: 500),
        child: _onboarded
            ? const AppShell(key: ValueKey('shell'))
            : OnboardingFlow(key: const ValueKey('onboarding'), onDone: () => setState(() => _onboarded = true)),
      ),
    );
  }
}
