import 'dart:async';
import 'dart:ui' show PlatformDispatcher;

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_localizations/flutter_localizations.dart';

import 'core/app_gate.dart';
import 'core/app_theme.dart';
import 'core/theme.dart';
import 'data/database.dart';
import 'data/backup.dart';
import 'data/calendar_repo.dart';
import 'data/profile_repo.dart';
import 'services/bag_reminders.dart';
import 'services/daily_brief.dart';
import 'services/lock_service.dart';
import 'services/notification_service.dart';
import 'ui/lock/lock_screen.dart';
import 'ui/onboarding/onboarding_flow.dart';
import 'ui/widgets/splash_intro.dart';
import 'ui/shell/app_shell.dart';
import 'ui/widgets/haptic.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  // چرخشِ صفحه آزاد است (از تنظیمِ «چرخش خودکار» گوشی پیروی می‌کند).
  await SystemChrome.setPreferredOrientations(DeviceOrientation.values);
  await SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
  SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
    statusBarColor: Colors.transparent,
    systemNavigationBarColor: Colors.transparent,
    statusBarIconBrightness: Brightness.light,
    systemNavigationBarIconBrightness: Brightness.light,
  ));

  await LuxDb.instance.open();
  await AppTheme.instance.load();
  Haptic.enabled = (await LuxDb.instance.kvGet('haptics') ?? '1') == '1';
  try {
    await NotificationService.instance.init();
  } catch (_) {
    // اگر نوتیف راه نیفتاد، بقیه‌ی اپ باید کار کند.
  }
  final onboarded = await ProfileRepo.isOnboarded();
  final locked = onboarded && await LockService.hasPin();
  runApp(LuxApp(onboarded: onboarded, locked: locked));
  if (onboarded) {
    DailyBrief.start();
    BagReminders.start();
    unawaited(CalendarRepo.resyncAll());
    // اگر مجوز اعلان/آلارم هنوز داده نشده، بعد از بالا آمدن اپ از خود اندروید می‌پرسد.
    unawaited(NotificationService.instance.ensurePermissions().catchError((_) => (false, false)));
  }
}

class LuxApp extends StatefulWidget {
  final bool onboarded;
  final bool locked;
  const LuxApp({super.key, required this.onboarded, required this.locked});

  @override
  State<LuxApp> createState() => _LuxAppState();
}

class _LuxAppState extends State<LuxApp> with WidgetsBindingObserver {
  late bool _onboarded = widget.onboarded;
  late bool _locked = widget.locked;
  late bool _showSplash = widget.onboarded && AppTheme.instance.splash;
  DateTime? _pausedAt;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    AppTheme.instance.addListener(_onTheme);
  }

  void _onTheme() {
    if (mounted) setState(() {});
  }

  @override
  void didChangePlatformBrightness() {
    AppTheme.instance.systemChanged(PlatformDispatcher.instance.platformBrightness);
  }

  @override
  void dispose() {
    AppTheme.instance.removeListener(_onTheme);
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.paused) {
      _pausedAt = DateTime.now();
      // فایل داده‌ی خودکار را به‌روز نگه می‌داریم.
      unawaited(Backup.autoSave());
    } else if (state == AppLifecycleState.resumed) {
      final at = _pausedAt;
      _pausedAt = null;
      if (at != null && _onboarded && DateTime.now().difference(at).inSeconds > 20) {
        LockService.hasPin().then((has) {
          if (has && mounted) setState(() => _locked = true);
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final t = AppTheme.instance;
    AppGate.blocked = _showSplash || _locked;
    return MaterialApp(
      // با عوض‌شدن تم، کلید عوض می‌شود و کلِ برنامه با رنگ‌های تازه ساخته می‌شود.
      key: ValueKey<String>(t.key),
      title: 'LUX',
      debugShowCheckedModeBanner: false,
      theme: LuxTheme.build(),
      locale: const Locale('fa', 'IR'),
      supportedLocales: const [Locale('fa', 'IR')],
      localizationsDelegates: const [
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
      ],
      builder: (context, child) {
        final dark = t.brightness == Brightness.dark;
        final icons = dark ? Brightness.light : Brightness.dark;
        final mq = MediaQuery.of(context);
        return AnnotatedRegion<SystemUiOverlayStyle>(
          value: SystemUiOverlayStyle(
            statusBarColor: Colors.transparent,
            systemNavigationBarColor: Colors.transparent,
            statusBarIconBrightness: icons,
            systemNavigationBarIconBrightness: icons,
          ),
          child: MediaQuery(
            data: mq.copyWith(textScaler: TextScaler.linear(mq.textScaler.scale(1.0) * t.textScale)),
            // انیمیشن ورود و قفل روی کلِ Navigator می‌نشینند تا صفحه‌های بازِ داخلی هم پوشانده شوند.
            child: Stack(
              fit: StackFit.expand,
              children: [
                child ?? const SizedBox.shrink(),
                if (_showSplash && !_locked)
                  Positioned.fill(
                    child: SplashIntro(key: const ValueKey('splash'), onDone: () => setState(() => _showSplash = false)),
                  ),
                if (_locked)
                  Positioned.fill(
                    child: LockScreen(key: const ValueKey('lock'), onUnlocked: () => setState(() => _locked = false)),
                  ),
              ],
            ),
          ),
        );
      },
      home: AnimatedSwitcher(
        duration: const Duration(milliseconds: 500),
        child: _onboarded
            ? const AppShell(key: ValueKey('shell'))
            : OnboardingFlow(key: const ValueKey('onboarding'), onDone: () => setState(() => _onboarded = true)),
      ),
    );
  }
}
