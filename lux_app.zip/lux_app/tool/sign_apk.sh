#!/usr/bin/env bash
# امضای نهایی APK با کلید ثابتِ خودت (تا آپدیت روی نصب قبلی ممکن باشد).
set -e
APK=build/app/outputs/flutter-apk/app-release.apk
OUT=build/app/outputs/flutter-apk/lux.apk
BT=$(ls -d "$ANDROID_HOME"/build-tools/* | sort -V | tail -1)

if [ -n "$KEYSTORE_BASE64" ]; then
  echo "$KEYSTORE_BASE64" | base64 -d > /tmp/lux.jks
  "$BT/zipalign" -p -f 4 "$APK" /tmp/aligned.apk
  "$BT/apksigner" sign --ks /tmp/lux.jks --ks-pass "pass:$KEYSTORE_PASSWORD" \
    --ks-key-alias "$KEY_ALIAS" --key-pass "pass:$KEY_PASSWORD" --out "$OUT" /tmp/aligned.apk
  "$BT/apksigner" verify "$OUT"
  echo "APK signed with your release key."
else
  echo "::warning::KEYSTORE secrets are not set. APK is signed with a throw-away debug key; updating over an older install will fail."
  cp "$APK" "$OUT"
fi
