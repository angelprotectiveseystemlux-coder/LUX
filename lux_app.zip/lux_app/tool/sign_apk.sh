#!/usr/bin/env bash
# Final CI step: produce lux.apk from Flutter's app-release.apk.
#
# - With the KEYSTORE_* secrets set, the APK is zip-aligned and signed with
#   your permanent key, so new builds can update an older install.
# - Without them, Flutter's debug signature is kept (fine for personal use,
#   but updating over an install signed with another key will fail).
set -euo pipefail

SRC=build/app/outputs/flutter-apk/app-release.apk
OUT=build/app/outputs/flutter-apk/lux.apk

[ -f "$SRC" ] || { echo "::error::$SRC not found"; exit 1; }

BUILD_TOOLS=$(ls -d "${ANDROID_HOME:?ANDROID_HOME is not set}"/build-tools/* | sort -V | tail -1)

if [ -z "${KEYSTORE_BASE64:-}" ]; then
  echo "::warning::KEYSTORE secrets are not set. APK keeps the debug signature; updating over an older install signed with another key will fail."
  cp "$SRC" "$OUT"
else
  : "${KEYSTORE_PASSWORD:?KEYSTORE_PASSWORD is not set}"
  : "${KEY_ALIAS:?KEY_ALIAS is not set}"
  : "${KEY_PASSWORD:?KEY_PASSWORD is not set}"

  KEYSTORE=$(mktemp --suffix=.jks)
  ALIGNED=$(mktemp --suffix=.apk)
  trap 'rm -f "$KEYSTORE" "$ALIGNED"' EXIT

  echo "$KEYSTORE_BASE64" | base64 -d > "$KEYSTORE"
  "$BUILD_TOOLS/zipalign" -p -f 4 "$SRC" "$ALIGNED"
  "$BUILD_TOOLS/apksigner" sign \
    --ks "$KEYSTORE" --ks-pass "pass:$KEYSTORE_PASSWORD" \
    --ks-key-alias "$KEY_ALIAS" --key-pass "pass:$KEY_PASSWORD" \
    --out "$OUT" "$ALIGNED"
  echo "APK signed with your release key."
fi

"$BUILD_TOOLS/apksigner" verify "$OUT"
ls -l "$OUT"
