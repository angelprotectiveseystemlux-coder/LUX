#!/usr/bin/env python3
"""آماده‌سازی پروژه‌ی اندروید بعد از `flutter create` (اجرا در GitHub Actions).
- مانیفست و MainActivity سفارشی
- آیکون‌ها
- فعال‌کردن core library desugaring (لازم برای flutter_local_notifications) و minSdk=23
- دانلود فونت‌ها (اگر شد) و افزودن به pubspec
"""
import pathlib
import re
import shutil
import sys
import urllib.request

ROOT = pathlib.Path('.')
ANDROID = ROOT / 'android'


def log(msg):
    print(f'[ci_prepare] {msg}', flush=True)


def manifest():
    dst = ANDROID / 'app/src/main/AndroidManifest.xml'
    shutil.copy(ROOT / 'android_overrides/AndroidManifest.xml', dst)
    log('AndroidManifest.xml replaced')


def main_activity():
    found = list((ANDROID / 'app/src/main').rglob('MainActivity.kt'))
    if not found:
        log('WARNING: MainActivity.kt not found; skipping high-refresh patch')
        return
    target = found[0]
    text = target.read_text(encoding='utf-8')
    m = re.search(r'^package\s+([\w.]+)', text, re.M)
    pkg = m.group(1) if m else 'com.lux.lux_app'
    tpl = (ROOT / 'android_overrides/MainActivity.kt').read_text(encoding='utf-8')
    target.write_text(tpl.replace('__PACKAGE__', pkg), encoding='utf-8')
    log(f'MainActivity.kt patched (package {pkg})')
    svc = (ROOT / 'android_overrides/FocusService.kt').read_text(encoding='utf-8')
    (target.parent / 'FocusService.kt').write_text(svc.replace('__PACKAGE__', pkg), encoding='utf-8')
    log('FocusService.kt copied')
    wid = (ROOT / 'android_overrides/LuxWidget.kt').read_text(encoding='utf-8')
    (target.parent / 'LuxWidget.kt').write_text(wid.replace('__PACKAGE__', pkg), encoding='utf-8')
    log('LuxWidget.kt copied')


def icons():
    shutil.copytree(ROOT / 'android_res', ANDROID / 'app/src/main/res', dirs_exist_ok=True)
    log('launcher icons copied')


def proguard():
    dst = ANDROID / 'app/proguard-rules.pro'
    shutil.copy(ROOT / 'android_overrides/proguard-rules.pro', dst)
    log('proguard-rules.pro copied')


def gradle():
    kts = ANDROID / 'app/build.gradle.kts'
    groovy = ANDROID / 'app/build.gradle'
    if kts.exists():
        s = kts.read_text(encoding='utf-8')
        if 'isCoreLibraryDesugaringEnabled' not in s:
            s = re.sub(r'(compileOptions\s*\{)', r'\1\n        isCoreLibraryDesugaringEnabled = true', s, count=1)
        s = re.sub(r'minSdk\s*=\s*flutter\.minSdkVersion', 'minSdk = 23', s)
        # بدون این، R8 کلاس‌های Gson پلاگین نوتیف را حذف می‌کند و یادآورها در نسخه‌ی release کار نمی‌کنند.
        if 'isMinifyEnabled' not in s:
            s = re.sub(r'(buildTypes\s*\{\s*release\s*\{)', r'\1\n            isMinifyEnabled = false\n            isShrinkResources = false', s, count=1)
        if 'coreLibraryDesugaring(' not in s:
            s += '\n\ndependencies {\n    coreLibraryDesugaring("com.android.tools:desugar_jdk_libs:2.1.4")\n}\n'
        kts.write_text(s, encoding='utf-8')
        log('build.gradle.kts patched')
    elif groovy.exists():
        s = groovy.read_text(encoding='utf-8')
        if 'coreLibraryDesugaringEnabled' not in s:
            s = re.sub(r'(compileOptions\s*\{)', r'\1\n        coreLibraryDesugaringEnabled true', s, count=1)
        s = re.sub(r'minSdkVersion\s+flutter\.minSdkVersion', 'minSdkVersion 23', s)
        s = re.sub(r'minSdk\s*=?\s*flutter\.minSdkVersion', 'minSdk 23', s)
        if 'minifyEnabled' not in s:
            s = re.sub(r'(buildTypes\s*\{\s*release\s*\{)', r'\1\n            minifyEnabled false\n            shrinkResources false', s, count=1)
        if 'coreLibraryDesugaring ' not in s:
            s += "\n\ndependencies {\n    coreLibraryDesugaring 'com.android.tools:desugar_jdk_libs:2.1.4'\n}\n"
        groovy.write_text(s, encoding='utf-8')
        log('build.gradle patched')
    else:
        log('ERROR: no app/build.gradle(.kts) found')
        sys.exit(1)


GF = 'https://github.com/google/fonts/raw/main/ofl'
GFC = 'https://cdn.jsdelivr.net/gh/google/fonts@main/ofl'
VAZ = 'https://cdn.jsdelivr.net/gh/rastikerdar/vazirmatn@master/fonts/ttf'
VAZ2 = 'https://github.com/rastikerdar/vazirmatn/raw/master/fonts/ttf'
EST = 'aminabedi68/Estedad'


def estedad(weight):
    # نام فایل‌ها بین نسخه‌های مخزن فرق می‌کند؛ چند مسیرِ محتمل را امتحان می‌کنیم.
    out = []
    for ref in ('master', 'main'):
        for sub in ('fonts/ttf', 'fonts/TTF', 'fonts/static', 'fonts', 'dist/ttf', 'ttf'):
            out.append(f'https://cdn.jsdelivr.net/gh/{EST}@{ref}/{sub}/Estedad-{weight}.ttf')
            out.append(f'https://github.com/{EST}/raw/{ref}/{sub}/Estedad-{weight}.ttf')
    return out


FONT_SOURCES = {
    # فونت اصلی متن: Estedad (مدرن و شیک)؛ اگر دانلود نشد، Vazirmatn جایگزین است.
    'Estedad-Regular.ttf': estedad('Regular'),
    'Estedad-Medium.ttf': estedad('Medium'),
    'Estedad-SemiBold.ttf': estedad('SemiBold'),
    'Estedad-Bold.ttf': estedad('Bold'),
    'Vazirmatn-Regular.ttf': [f'{VAZ}/Vazirmatn-Regular.ttf', f'{VAZ2}/Vazirmatn-Regular.ttf'],
    'Vazirmatn-Medium.ttf': [f'{VAZ}/Vazirmatn-Medium.ttf', f'{VAZ2}/Vazirmatn-Medium.ttf'],
    'Vazirmatn-SemiBold.ttf': [f'{VAZ}/Vazirmatn-SemiBold.ttf', f'{VAZ2}/Vazirmatn-SemiBold.ttf'],
    'Vazirmatn-Bold.ttf': [f'{VAZ}/Vazirmatn-Bold.ttf', f'{VAZ2}/Vazirmatn-Bold.ttf'],
    # عنوان‌های بزرگ (فارسی)
    'Lalezar-Regular.ttf': [f'{GF}/lalezar/Lalezar-Regular.ttf', f'{GFC}/lalezar/Lalezar-Regular.ttf'],
    # امضای «By Pishva System» (لاتین، عریض و لوکس)
    'Michroma-Regular.ttf': [f'{GF}/michroma/Michroma-Regular.ttf', f'{GFC}/michroma/Michroma-Regular.ttf'],
    # اعداد نقطه‌ای
    'LuxDot.ttf': ['https://github.com/google/fonts/raw/main/ofl/dotgothic16/DotGothic16-Regular.ttf',
                   'https://cdn.jsdelivr.net/gh/google/fonts@main/ofl/dotgothic16/DotGothic16-Regular.ttf',
                   'https://github.com/google/fonts/raw/main/ofl/silkscreen/Silkscreen-Regular.ttf'],
}


def fetch(urls, dest):
    for u in urls:
        try:
            with urllib.request.urlopen(u, timeout=20) as r:
                data = r.read()
            if len(data) > 10_000 and data[:4] in (b'\x00\x01\x00\x00', b'true', b'OTTO'):
                dest.write_bytes(data)
                return True
            log(f'  not a font: {u}')
        except Exception as e:  # noqa: BLE001
            log(f'  failed {u}: {e}')
    return False


def fonts():
    out = ROOT / 'assets/fonts'
    out.mkdir(parents=True, exist_ok=True)
    got = {}
    for name, urls in FONT_SOURCES.items():
        ok = fetch(urls, out / name)
        got[name] = ok
        log(f'font {name}: {"ok" if ok else "MISSING (will fall back)"}')
    lines = ['', '  fonts:']

    def family(fam, files):
        have = [(n, w) for n, w in files if got.get(n)]
        if not have:
            return
        lines.extend([f'    - family: {fam}', '      fonts:'])
        for n, w in have:
            lines.append(f'        - asset: assets/fonts/{n}')
            if w:
                lines.append(f'          weight: {w}')

    family('Estedad', [('Estedad-Regular.ttf', 400), ('Estedad-Medium.ttf', 500),
                       ('Estedad-SemiBold.ttf', 600), ('Estedad-Bold.ttf', 700)])
    family('Vazirmatn', [('Vazirmatn-Regular.ttf', 400), ('Vazirmatn-Medium.ttf', 500),
                         ('Vazirmatn-SemiBold.ttf', 600), ('Vazirmatn-Bold.ttf', 700)])
    family('Lalezar', [('Lalezar-Regular.ttf', 0)])
    family('Michroma', [('Michroma-Regular.ttf', 0)])
    family('LuxDot', [('LuxDot.ttf', 0)])
    if len(lines) > 2:
        pub = ROOT / 'pubspec.yaml'
        text = pub.read_text(encoding='utf-8').rstrip('\n') + '\n' + '\n'.join(lines) + '\n'
        pub.write_text(text, encoding='utf-8')
        log('pubspec.yaml: fonts section added')


if __name__ == '__main__':
    manifest()
    main_activity()
    icons()
    proguard()
    gradle()
    fonts()
    log('done')
