#!/usr/bin/env python3
"""آماده‌سازی پروژه‌ی اندروید بعد از `flutter create` (اجرا در GitHub Actions).
- مانیفست و MainActivity سفارشی
- آیکون‌ها
- فعال‌کردن core library desugaring (لازم برای flutter_local_notifications) و minSdk=23
- دانلود فونت‌ها (اگر شد) و افزودن به pubspec
"""
import pathlib
import re
import shutil
import sys
import urllib.request

ROOT = pathlib.Path('.')
ANDROID = ROOT / 'android'


def log(msg):
    print(f'[ci_prepare] {msg}', flush=True)


def manifest():
    dst = ANDROID / 'app/src/main/AndroidManifest.xml'
    shutil.copy(ROOT / 'android_overrides/AndroidManifest.xml', dst)
    log('AndroidManifest.xml replaced')


def main_activity():
    found = list((ANDROID / 'app/src/main').rglob('MainActivity.kt'))
    if not found:
        log('WARNING: MainActivity.kt not found; skipping high-refresh patch')
        return
    target = found[0]
    text = target.read_text(encoding='utf-8')
    m = re.search(r'^package\s+([\w.]+)', text, re.M)
    pkg = m.group(1) if m else 'com.lux.lux_app'
    tpl = (ROOT / 'android_overrides/MainActivity.kt').read_text(encoding='utf-8')
    target.write_text(tpl.replace('__PACKAGE__', pkg), encoding='utf-8')
    log(f'MainActivity.kt patched (package {pkg})')


def icons():
    shutil.copytree(ROOT / 'android_res', ANDROID / 'app/src/main/res', dirs_exist_ok=True)
    log('launcher icons copied')


def gradle():
    kts = ANDROID / 'app/build.gradle.kts'
    groovy = ANDROID / 'app/build.gradle'
    if kts.exists():
        s = kts.read_text(encoding='utf-8')
        if 'isCoreLibraryDesugaringEnabled' not in s:
            s = re.sub(r'(compileOptions\s*\{)', r'\1\n        isCoreLibraryDesugaringEnabled = true', s, count=1)
        s = re.sub(r'minSdk\s*=\s*flutter\.minSdkVersion', 'minSdk = 23', s)
        if 'coreLibraryDesugaring(' not in s:
            s += '\n\ndependencies {\n    coreLibraryDesugaring("com.android.tools:desugar_jdk_libs:2.1.4")\n}\n'
        kts.write_text(s, encoding='utf-8')
        log('build.gradle.kts patched')
    elif groovy.exists():
        s = groovy.read_text(encoding='utf-8')
        if 'coreLibraryDesugaringEnabled' not in s:
            s = re.sub(r'(compileOptions\s*\{)', r'\1\n        coreLibraryDesugaringEnabled true', s, count=1)
        s = re.sub(r'minSdkVersion\s+flutter\.minSdkVersion', 'minSdkVersion 23', s)
        s = re.sub(r'minSdk\s*=?\s*flutter\.minSdkVersion', 'minSdk 23', s)
        if 'coreLibraryDesugaring ' not in s:
            s += "\n\ndependencies {\n    coreLibraryDesugaring 'com.android.tools:desugar_jdk_libs:2.1.4'\n}\n"
        groovy.write_text(s, encoding='utf-8')
        log('build.gradle patched')
    else:
        log('ERROR: no app/build.gradle(.kts) found')
        sys.exit(1)


FONT_SOURCES = {
    'Vazirmatn-Regular.ttf': ['https://cdn.jsdelivr.net/gh/rastikerdar/vazirmatn@master/fonts/ttf/Vazirmatn-Regular.ttf',
                              'https://github.com/rastikerdar/vazirmatn/raw/master/fonts/ttf/Vazirmatn-Regular.ttf'],
    'Vazirmatn-Medium.ttf': ['https://cdn.jsdelivr.net/gh/rastikerdar/vazirmatn@master/fonts/ttf/Vazirmatn-Medium.ttf',
                             'https://github.com/rastikerdar/vazirmatn/raw/master/fonts/ttf/Vazirmatn-Medium.ttf'],
    'Vazirmatn-SemiBold.ttf': ['https://cdn.jsdelivr.net/gh/rastikerdar/vazirmatn@master/fonts/ttf/Vazirmatn-SemiBold.ttf',
                               'https://github.com/rastikerdar/vazirmatn/raw/master/fonts/ttf/Vazirmatn-SemiBold.ttf'],
    'Vazirmatn-Bold.ttf': ['https://cdn.jsdelivr.net/gh/rastikerdar/vazirmatn@master/fonts/ttf/Vazirmatn-Bold.ttf',
                           'https://github.com/rastikerdar/vazirmatn/raw/master/fonts/ttf/Vazirmatn-Bold.ttf'],
    'LuxDot.ttf': ['https://github.com/google/fonts/raw/main/ofl/dotgothic16/DotGothic16-Regular.ttf',
                   'https://cdn.jsdelivr.net/gh/google/fonts@main/ofl/dotgothic16/DotGothic16-Regular.ttf',
                   'https://github.com/google/fonts/raw/main/ofl/silkscreen/Silkscreen-Regular.ttf'],
}


def fetch(urls, dest):
    for u in urls:
        try:
            with urllib.request.urlopen(u, timeout=60) as r:
                data = r.read()
            if len(data) > 10_000 and data[:4] in (b'\x00\x01\x00\x00', b'true', b'OTTO'):
                dest.write_bytes(data)
                return True
            log(f'  not a font: {u}')
        except Exception as e:  # noqa: BLE001
            log(f'  failed {u}: {e}')
    return False


def fonts():
    out = ROOT / 'assets/fonts'
    out.mkdir(parents=True, exist_ok=True)
    got = {}
    for name, urls in FONT_SOURCES.items():
        ok = fetch(urls, out / name)
        got[name] = ok
        log(f'font {name}: {"ok" if ok else "MISSING (will fall back to system font)"}')
    lines = ['', '  fonts:']
    vaz = []
    for name, weight in (('Vazirmatn-Regular.ttf', 400), ('Vazirmatn-Medium.ttf', 500),
                         ('Vazirmatn-SemiBold.ttf', 600), ('Vazirmatn-Bold.ttf', 700)):
        if got.get(name):
            vaz.append((name, weight))
    if vaz:
        lines += ['    - family: Vazirmatn', '      fonts:']
        for name, weight in vaz:
            lines += [f'        - asset: assets/fonts/{name}', f'          weight: {weight}']
    if got.get('LuxDot.ttf'):
        lines += ['    - family: LuxDot', '      fonts:', '        - asset: assets/fonts/LuxDot.ttf']
    if len(lines) > 2:
        pub = ROOT / 'pubspec.yaml'
        text = pub.read_text(encoding='utf-8').rstrip('\n') + '\n' + '\n'.join(lines) + '\n'
        pub.write_text(text, encoding='utf-8')
        log('pubspec.yaml: fonts section added')


if __name__ == '__main__':
    manifest()
    main_activity()
    icons()
    gradle()
    fonts()
    log('done')
