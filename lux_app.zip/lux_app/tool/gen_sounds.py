#!/usr/bin/env python3
"""ساخت صداهای پایان جلسه و صداهای محیطی (بدون نیاز به دانلود). خروجی: assets/sounds/*.wav"""
import wave
import numpy as np

SR = 22050
rng = np.random.default_rng(7)


def save(name, x, sr=SR):
    x = np.asarray(x, dtype=np.float64)
    m = np.max(np.abs(x)) or 1.0
    x = x / m * 0.9
    pcm = (x * 32767).astype('<i2')
    with wave.open(f'assets/sounds/{name}.wav', 'wb') as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(sr)
        w.writeframes(pcm.tobytes())


def t(sec, sr=SR):
    return np.arange(int(sec * sr)) / sr


def fade(x, a=0.005, b=0.02, sr=SR):
    n = len(x)
    ia, ib = int(a * sr), int(b * sr)
    env = np.ones(n)
    if ia: env[:ia] = np.linspace(0, 1, ia)
    if ib: env[-ib:] = np.linspace(1, 0, ib)
    return x * env


def note(freq, sec, partials=((1, 1.0),), decay=3.0, sr=SR):
    tt = t(sec, sr)
    y = np.zeros_like(tt)
    for mult, amp in partials:
        y += amp * np.sin(2 * np.pi * freq * mult * tt) * np.exp(-decay * mult ** 0.5 * tt)
    return y


def place(total, parts, sr=SR):
    out = np.zeros(int(total * sr))
    for start, y in parts:
        i = int(start * sr)
        out[i:i + len(y)] += y[:max(0, len(out) - i)]
    return out


# ───────── صداهای پایان ─────────
save('bell', fade(note(880, 3.0, ((1, 1), (2.76, .6), (5.4, .35), (8.93, .2)), decay=1.6), b=0.15))
save('chime', fade(place(2.4, [(0.0, note(1046.5, 1.6, ((1, 1), (2, .3)), decay=3)),
                               (0.22, note(1318.5, 1.6, ((1, 1), (2, .3)), decay=3)),
                               (0.44, note(1568.0, 1.8, ((1, 1), (2, .3)), decay=2.6))]), b=0.2))
beep = fade(np.sin(2 * np.pi * 1000 * t(0.16)), 0.004, 0.01)
save('beep', place(1.4, [(0.0, beep), (0.28, beep), (0.56, beep)]))
save('gong', fade(note(110, 4.0, ((1, 1), (1.5, .5), (2.01, .45), (2.76, .3), (4.1, .2)), decay=0.9), 0.02, 0.3))
save('soft', fade(place(1.6, [(0.0, note(660, 0.9, decay=4)), (0.28, note(880, 1.2, decay=3.5))]), b=0.1))
wood = lambda f: note(f, 0.5, ((1, 1), (3.9, .4), (9.2, .15)), decay=9)
save('wood', fade(place(1.6, [(0.0, wood(523)), (0.2, wood(659)), (0.4, wood(784)), (0.6, wood(1047))]), b=0.1))

# ───────── صداهای محیطی (حلقه‌ای) ─────────
ASR = 16000
N = ASR * 10
F = ASR // 2


def loopify(x, n=N, f=F):
    x = x[:n + f].copy()
    w = np.linspace(0, 1, f)
    head = x[:f] * w + x[n:n + f] * (1 - w)
    out = x[:n].copy()
    out[:f] = head
    return out


def shaped_noise(n, lo, hi, tilt=0.0, sr=ASR):
    spec = np.fft.rfft(rng.normal(size=n))
    fr = np.fft.rfftfreq(n, 1 / sr)
    g = np.zeros_like(fr)
    band = (fr >= lo) & (fr <= hi)
    g[band] = 1.0 / np.maximum(fr[band], 1.0) ** tilt
    return np.fft.irfft(spec * g, n)


n = N + F
white = rng.normal(size=n)
pink = shaped_noise(n, 20, 7900, 0.5)
brown = shaped_noise(n, 20, 4000, 1.0)
save('white', loopify(white), ASR)
save('pink', loopify(pink), ASR)
save('brown', loopify(brown), ASR)

# باران: نویزِ باند‌میانی + قطره‌ها
rain = shaped_noise(n, 800, 7000, 0.15)
rain /= np.max(np.abs(rain))
for _ in range(220):
    i = int(rng.integers(0, n - 400))
    L = int(rng.integers(60, 300))
    drop = rng.normal(size=L) * np.exp(-np.linspace(0, 7, L)) * rng.uniform(0.25, 0.9)
    rain[i:i + L] += drop
rain += 0.5 * shaped_noise(n, 100, 500, 0.4) / 4
save('rain', loopify(rain), ASR)

# موج: نویزِ نرم با پوششِ آهسته (دوره‌های کامل در حلقه)
base = shaped_noise(n, 60, 2500, 0.6)
tt = np.arange(n) / ASR
env = 0.55 + 0.45 * np.sin(2 * np.pi * (2 / 10.0) * tt - 1.2) ** 3
env = np.clip(env, 0.15, 1.0)
save('waves', loopify(base * env), ASR)

# آتش: نویزِ پایین + ترق‌ترق
fire = shaped_noise(n, 40, 900, 0.8)
fire /= np.max(np.abs(fire))
fire *= 0.6
for _ in range(90):
    i = int(rng.integers(0, n - 500))
    L = int(rng.integers(40, 240))
    pop = rng.normal(size=L) * np.exp(-np.linspace(0, 9, L)) * rng.uniform(0.3, 1.0)
    fire[i:i + L] += pop
save('fire', loopify(fire), ASR)
print('ok')
