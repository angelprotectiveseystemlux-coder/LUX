package __PACKAGE__

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.widget.RemoteViews

/** ویجتِ صفحه‌ی اصلی: بلوکِ بعدیِ برنامه‌ی هوشمند. */
class LuxWidget : AppWidgetProvider() {

    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        for (id in appWidgetIds) {
            appWidgetManager.updateAppWidget(id, build(context))
        }
    }

    companion object {
        fun build(ctx: Context): RemoteViews {
            val p = ctx.getSharedPreferences("lux_widget", Context.MODE_PRIVATE)
            val v = RemoteViews(ctx.packageName, R.layout.lux_widget)
            v.setTextViewText(R.id.w_title, p.getString("title", "LUX") ?: "LUX")
            v.setTextViewText(R.id.w_sub, p.getString("sub", "برنامه‌ی امروزت را ببین") ?: "")
            val open = ctx.packageManager.getLaunchIntentForPackage(ctx.packageName)
            if (open != null) {
                val pi = PendingIntent.getActivity(ctx, 7, open, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
                v.setOnClickPendingIntent(R.id.w_root, pi)
            }
            return v
        }

        fun refresh(ctx: Context, title: String?, sub: String?) {
            try {
                val p = ctx.getSharedPreferences("lux_widget", Context.MODE_PRIVATE)
                p.edit().putString("title", title ?: "LUX").putString("sub", sub ?: "").apply()
                val mgr = AppWidgetManager.getInstance(ctx)
                val ids = mgr.getAppWidgetIds(ComponentName(ctx, LuxWidget::class.java))
                for (id in ids) {
                    mgr.updateAppWidget(id, build(ctx))
                }
            } catch (_: Exception) {
            }
        }
    }
}
