# flutter_local_notifications (Gson) — بدون این‌ها در نسخه‌ی release یادآورها کار نمی‌کنند
-keep class com.dexterous.** { *; }
-keepattributes *Annotation*
-keepattributes Signature
-keep class * extends com.google.gson.reflect.TypeToken
-keep class com.google.gson.** { *; }
