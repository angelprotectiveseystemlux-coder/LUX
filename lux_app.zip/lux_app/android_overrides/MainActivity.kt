package __PACKAGE__

import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.os.Build
import android.os.Bundle
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import io.flutter.embedding.android.FlutterFragmentActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel
import java.io.File

/** local_auth (اثر انگشت) به FragmentActivity نیاز دارد. */
class MainActivity : FlutterFragmentActivity() {

    private var pendingResult: MethodChannel.Result? = null
    private var pendingPath: String? = null

    // ───────── ویبره ─────────
    private fun vibrator(): Vibrator? {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            (getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager)?.defaultVibrator
        } else {
            @Suppress("DEPRECATION")
            getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
        }
    }

    /**
     * ویبره با کاربرد «آلارم»، تا حتی وقتی گوشی روی بی‌صدا/ویبره‌ی لمسیِ سیستم خاموش است کار کند.
     * به‌جای افکت‌های از‌پیش‌تعریف‌شده (که روی خیلی از موتورها بی‌اثرند) از یک پالس با دامنه‌ی مشخص استفاده می‌شود.
     */
    private fun fire(kind: String): Boolean {
        val v = vibrator() ?: return false
        if (!v.hasVibrator()) return false
        val ms: Long
        val amp: Int
        when (kind) {
            "tick" -> { ms = 14L; amp = 140 }
            "click" -> { ms = 24L; amp = 200 }
            "long" -> { ms = 450L; amp = 255 }
            else -> { ms = 45L; amp = 255 }
        }
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val strength = if (v.hasAmplitudeControl()) amp else VibrationEffect.DEFAULT_AMPLITUDE
                val effect = VibrationEffect.createOneShot(ms, strength)
                val attrs = AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ALARM)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build()
                @Suppress("DEPRECATION")
                v.vibrate(effect, attrs)
            } else {
                @Suppress("DEPRECATION")
                v.vibrate(ms)
            }
            true
        } catch (_: Exception) {
            false
        }
    }

    // ───────── انتخابگر فایل (ذخیره / بازیابی) ─────────
    private fun startSave(path: String, name: String, result: MethodChannel.Result) {
        pendingResult = result
        pendingPath = path
        val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "application/json"
            putExtra(Intent.EXTRA_TITLE, name)
        }
        startActivityForResult(intent, REQ_SAVE)
    }

    private fun startPick(result: MethodChannel.Result) {
        pendingResult = result
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
        }
        startActivityForResult(intent, REQ_PICK)
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQ_SAVE && requestCode != REQ_PICK) return
        val res = pendingResult ?: return
        pendingResult = null
        val uri = data?.data
        if (resultCode != RESULT_OK || uri == null) {
            if (requestCode == REQ_SAVE) res.success(false) else res.success(null)
            return
        }
        try {
            if (requestCode == REQ_SAVE) {
                val src = File(pendingPath ?: "")
                contentResolver.openOutputStream(uri)?.use { out ->
                    src.inputStream().use { input -> input.copyTo(out) }
                }
                res.success(true)
            } else {
                val dst = File(cacheDir, "lux_import.json")
                contentResolver.openInputStream(uri)?.use { input ->
                    dst.outputStream().use { out -> input.copyTo(out) }
                }
                res.success(dst.absolutePath)
            }
        } catch (e: Exception) {
            if (requestCode == REQ_SAVE) res.success(false) else res.success(null)
        }
    }

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        val messenger = flutterEngine.dartExecutor.binaryMessenger

        MethodChannel(messenger, "lux/haptic").setMethodCallHandler { call, result ->
            if (call.method == "vibrate") {
                result.success(fire(call.argument<String>("kind") ?: "tick"))
            } else {
                result.notImplemented()
            }
        }

        MethodChannel(messenger, "lux/files").setMethodCallHandler { call, result ->
            if (pendingResult != null) {
                result.error("busy", "یک انتخاب فایل در جریان است.", null)
            } else if (call.method == "saveAs") {
                val path = call.argument<String>("path")
                val name = call.argument<String>("name") ?: "lux_backup.json"
                if (path == null) result.success(false) else startSave(path, name, result)
            } else if (call.method == "pick") {
                startPick(result)
            } else {
                result.notImplemented()
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // بالاترین نرخ نمایشِ پشتیبانی‌شده (۹۰/۱۲۰ هرتز) با همان وضوحِ فعلی
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            try {
                @Suppress("DEPRECATION")
                val display = windowManager.defaultDisplay
                val current = display.mode
                var best = current
                for (m in display.supportedModes) {
                    if (m.physicalWidth == current.physicalWidth &&
                        m.physicalHeight == current.physicalHeight &&
                        m.refreshRate > best.refreshRate) {
                        best = m
                    }
                }
                val lp = window.attributes
                lp.preferredDisplayModeId = best.modeId
                window.attributes = lp
            } catch (_: Exception) {
            }
        }
    }

    companion object {
        private const val REQ_SAVE = 4711
        private const val REQ_PICK = 4712
    }
}
