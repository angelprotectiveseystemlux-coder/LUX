package __PACKAGE__

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.pdf.PdfRenderer
import android.os.ParcelFileDescriptor
import android.provider.OpenableColumns
import android.view.WindowManager
import java.io.ByteArrayOutputStream
import java.util.concurrent.Executors
import android.media.AudioAttributes
import android.os.Build
import android.os.Bundle
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import io.flutter.embedding.android.FlutterFragmentActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel
import java.io.File

/** local_auth (اثر انگشت) به FragmentActivity نیاز دارد. */
class MainActivity : FlutterFragmentActivity() {

    private var pendingResult: MethodChannel.Result? = null
    private var pendingPath: String? = null
    private var pendingMime: String = "application/json"

    // ───────── PDF ─────────
    private val pdfExecutor = Executors.newSingleThreadExecutor()
    private var pdfPath: String? = null
    private var pdfFd: ParcelFileDescriptor? = null
    private var pdfRenderer: PdfRenderer? = null

    private fun pdfClose() {
        try { pdfRenderer?.close() } catch (_: Exception) {}
        try { pdfFd?.close() } catch (_: Exception) {}
        pdfRenderer = null
        pdfFd = null
        pdfPath = null
    }

    private fun pdfEnsure(path: String): PdfRenderer {
        if (pdfPath == path && pdfRenderer != null) return pdfRenderer!!
        pdfClose()
        val fd = ParcelFileDescriptor.open(File(path), ParcelFileDescriptor.MODE_READ_ONLY)
        val r = PdfRenderer(fd)
        pdfFd = fd
        pdfRenderer = r
        pdfPath = path
        return r
    }

    // ───────── ویبره ─────────
    private fun vibrator(): Vibrator? {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            (getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager)?.defaultVibrator
        } else {
            @Suppress("DEPRECATION")
            getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
        }
    }

    /**
     * ویبره با کاربرد «آلارم»، تا حتی وقتی گوشی روی بی‌صدا/ویبره‌ی لمسیِ سیستم خاموش است کار کند.
     * به‌جای افکت‌های از‌پیش‌تعریف‌شده (که روی خیلی از موتورها بی‌اثرند) از یک پالس با دامنه‌ی مشخص استفاده می‌شود.
     */
    private fun fire(kind: String): Boolean {
        val v = vibrator() ?: return false
        if (!v.hasVibrator()) return false
        val ms: Long
        val amp: Int
        when (kind) {
            "tick" -> { ms = 14L; amp = 140 }
            "click" -> { ms = 24L; amp = 200 }
            "long" -> { ms = 450L; amp = 255 }
            else -> { ms = 45L; amp = 255 }
        }
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val strength = if (v.hasAmplitudeControl()) amp else VibrationEffect.DEFAULT_AMPLITUDE
                val effect = VibrationEffect.createOneShot(ms, strength)
                val attrs = AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ALARM)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build()
                @Suppress("DEPRECATION")
                v.vibrate(effect, attrs)
            } else {
                @Suppress("DEPRECATION")
                v.vibrate(ms)
            }
            true
        } catch (_: Exception) {
            false
        }
    }

    // ───────── انتخابگر فایل (ذخیره / بازیابی) ─────────
    private fun startSave(path: String, name: String, mime: String, result: MethodChannel.Result) {
        pendingResult = result
        pendingPath = path
        pendingMime = mime
        val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = pendingMime
            putExtra(Intent.EXTRA_TITLE, name)
        }
        startActivityForResult(intent, REQ_SAVE)
    }

    private fun startPick(result: MethodChannel.Result) {
        pendingResult = result
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
        }
        startActivityForResult(intent, REQ_PICK)
    }

    private fun startPickPdf(result: MethodChannel.Result) {
        pendingResult = result
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "application/pdf"
        }
        startActivityForResult(intent, REQ_PICK_PDF)
    }

    private fun displayName(uri: android.net.Uri): String {
        try {
            contentResolver.query(uri, null, null, null, null)?.use { c ->
                val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (i >= 0 && c.moveToFirst()) return c.getString(i) ?: "book.pdf"
            }
        } catch (_: Exception) {}
        return "book.pdf"
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQ_SAVE && requestCode != REQ_PICK && requestCode != REQ_PICK_PDF) return
        val res = pendingResult ?: return
        pendingResult = null
        val uri = data?.data
        if (requestCode == REQ_PICK_PDF) {
            if (resultCode != RESULT_OK || uri == null) {
                res.success(null)
                return
            }
            try {
                val dir = File(filesDir, "pdfs")
                dir.mkdirs()
                val safe = displayName(uri).replace(Regex("[^\\p{L}\\p{N}._ -]"), "_")
                val dst = File(dir, "${System.currentTimeMillis()}_$safe")
                contentResolver.openInputStream(uri)?.use { input ->
                    dst.outputStream().use { out -> input.copyTo(out) }
                }
                res.success(dst.absolutePath)
            } catch (e: Exception) {
                res.success(null)
            }
            return
        }
        if (resultCode != RESULT_OK || uri == null) {
            if (requestCode == REQ_SAVE) res.success(false) else res.success(null)
            return
        }
        try {
            if (requestCode == REQ_SAVE) {
                val src = File(pendingPath ?: "")
                contentResolver.openOutputStream(uri)?.use { out ->
                    src.inputStream().use { input -> input.copyTo(out) }
                }
                res.success(true)
            } else {
                val dst = File(cacheDir, "lux_import.json")
                contentResolver.openInputStream(uri)?.use { input ->
                    dst.outputStream().use { out -> input.copyTo(out) }
                }
                res.success(dst.absolutePath)
            }
        } catch (e: Exception) {
            if (requestCode == REQ_SAVE) res.success(false) else res.success(null)
        }
    }

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        val messenger = flutterEngine.dartExecutor.binaryMessenger
        FocusBridge.attach(flutterEngine, this)

        MethodChannel(messenger, "lux/haptic").setMethodCallHandler { call, result ->
            if (call.method == "vibrate") {
                result.success(fire(call.argument<String>("kind") ?: "tick"))
            } else {
                result.notImplemented()
            }
        }

        MethodChannel(messenger, "lux/pdf").setMethodCallHandler { call, result ->
            when (call.method) {
                "open" -> {
                    val path = call.argument<String>("path")
                    if (path == null) {
                        result.success(null)
                    } else {
                        pdfExecutor.execute {
                            try {
                                val r = pdfEnsure(path)
                                val n = r.pageCount
                                val ratios = ArrayList<Double>(n)
                                for (i in 0 until n) {
                                    val pg = r.openPage(i)
                                    ratios.add(pg.height.toDouble() / pg.width.toDouble())
                                    pg.close()
                                }
                                runOnUiThread { result.success(hashMapOf("count" to n, "ratios" to ratios)) }
                            } catch (e: Exception) {
                                runOnUiThread { result.success(null) }
                            }
                        }
                    }
                }
                "render" -> {
                    val path = call.argument<String>("path")
                    val page = call.argument<Int>("page") ?: 0
                    val width = call.argument<Int>("width") ?: 1080
                    if (path == null) {
                        result.success(null)
                    } else {
                        pdfExecutor.execute {
                            try {
                                val r = pdfEnsure(path)
                                val pg = r.openPage(page.coerceIn(0, r.pageCount - 1))
                                val w = width.coerceIn(200, 2600)
                                val h = (w.toDouble() * pg.height.toDouble() / pg.width.toDouble()).toInt().coerceAtLeast(1)
                                val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
                                bmp.eraseColor(Color.WHITE)
                                pg.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                                pg.close()
                                val out = ByteArrayOutputStream()
                                bmp.compress(Bitmap.CompressFormat.JPEG, 92, out)
                                bmp.recycle()
                                val bytes = out.toByteArray()
                                runOnUiThread { result.success(bytes) }
                            } catch (e: Exception) {
                                runOnUiThread { result.success(null) }
                            }
                        }
                    }
                }
                "close" -> {
                    pdfExecutor.execute { pdfClose() }
                    result.success(true)
                }
                "keepAwake" -> {
                    val on = call.argument<Boolean>("on") ?: false
                    runOnUiThread {
                        if (on) window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                        else window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                    }
                    result.success(true)
                }
                else -> result.notImplemented()
            }
        }

        MethodChannel(messenger, "lux/files").setMethodCallHandler { call, result ->
            if (pendingResult != null) {
                result.error("busy", "یک انتخاب فایل در جریان است.", null)
            } else if (call.method == "saveAs") {
                val path = call.argument<String>("path")
                val name = call.argument<String>("name") ?: "lux_backup.json"
                val mime = call.argument<String>("mime") ?: "application/json"
                if (path == null) result.success(false) else startSave(path, name, mime, result)
            } else if (call.method == "pick") {
                startPick(result)
            } else if (call.method == "pickPdf") {
                startPickPdf(result)
            } else {
                result.notImplemented()
            }
        }
    }

    override fun onDestroy() {
        FocusBridge.detach()
        super.onDestroy()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // بالاترین نرخ نمایشِ پشتیبانی‌شده (۹۰/۱۲۰ هرتز) با همان وضوحِ فعلی
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            try {
                @Suppress("DEPRECATION")
                val display = windowManager.defaultDisplay
                val current = display.mode
                var best = current
                for (m in display.supportedModes) {
                    if (m.physicalWidth == current.physicalWidth &&
                        m.physicalHeight == current.physicalHeight &&
                        m.refreshRate > best.refreshRate) {
                        best = m
                    }
                }
                val lp = window.attributes
                lp.preferredDisplayModeId = best.modeId
                window.attributes = lp
            } catch (_: Exception) {
            }
        }
    }

    companion object {
        private const val REQ_SAVE = 4711
        private const val REQ_PICK = 4712
        private const val REQ_PICK_PDF = 4713
    }
}
