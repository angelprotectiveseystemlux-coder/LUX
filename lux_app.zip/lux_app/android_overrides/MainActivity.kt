package __PACKAGE__

import android.os.Build
import android.os.Bundle
import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // بالاترین نرخ نمایشِ پشتیبانی‌شده (۹۰/۱۲۰ هرتز) با همان وضوحِ فعلی
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            try {
                @Suppress("DEPRECATION")
                val display = windowManager.defaultDisplay
                val current = display.mode
                var best = current
                for (m in display.supportedModes) {
                    if (m.physicalWidth == current.physicalWidth &&
                        m.physicalHeight == current.physicalHeight &&
                        m.refreshRate > best.refreshRate) {
                        best = m
                    }
                }
                val lp = window.attributes
                lp.preferredDisplayModeId = best.modeId
                window.attributes = lp
            } catch (_: Exception) {
            }
        }
    }
}
