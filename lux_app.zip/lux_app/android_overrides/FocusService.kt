package __PACKAGE__

import android.app.Activity
import android.app.AlarmManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.ServiceInfo
import android.graphics.drawable.Icon
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.os.VibrationEffect
import android.os.Vibrator
import android.provider.Settings
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/** ذخیره‌ی وضعیتِ تایمر؛ منبعِ حقیقت همین‌جاست تا با بسته‌شدنِ برنامه هم تایمر گم نشود. */
object FocusStore {
    fun prefs(c: Context): SharedPreferences = c.getSharedPreferences("lux_focus", Context.MODE_PRIVATE)
}

/** پخشِ صدا (پایانِ جلسه و صدای محیطی) با MediaPlayer. */
class Sounds(private val ctx: Context) {
    private var amb: MediaPlayer? = null
    private var ambKey = ""

    private fun file(key: String): File? {
        return try {
            val f = File(ctx.cacheDir, "snd_$key.wav")
            if (!f.exists() || f.length() < 1000) {
                ctx.assets.open("flutter_assets/assets/sounds/$key.wav").use { i ->
                    f.outputStream().use { o -> i.copyTo(o) }
                }
            }
            f
        } catch (_: Exception) {
            null
        }
    }

    fun startAmbient(key: String, vol: Float) {
        if (key.isEmpty()) {
            stopAmbient()
            return
        }
        if (amb != null && ambKey == key) {
            try {
                amb?.setVolume(vol, vol)
                if (amb?.isPlaying == false) amb?.start()
            } catch (_: Exception) {
            }
            return
        }
        stopAmbient()
        val f = file(key) ?: return
        try {
            val mp = MediaPlayer()
            mp.setWakeMode(ctx, PowerManager.PARTIAL_WAKE_LOCK)
            mp.setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .build()
            )
            mp.setDataSource(f.absolutePath)
            mp.isLooping = true
            mp.setVolume(vol, vol)
            mp.prepare()
            mp.start()
            amb = mp
            ambKey = key
        } catch (_: Exception) {
            amb = null
            ambKey = ""
        }
    }

    fun stopAmbient() {
        try { amb?.stop() } catch (_: Exception) {}
        try { amb?.release() } catch (_: Exception) {}
        amb = null
        ambKey = ""
    }

    fun playEnd(key: String, vol: Float) {
        val f = file(key) ?: return
        try {
            val mp = MediaPlayer()
            mp.setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ALARM)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build()
            )
            mp.setDataSource(f.absolutePath)
            mp.setVolume(vol, vol)
            mp.setOnCompletionListener { try { it.release() } catch (_: Exception) {} }
            mp.setOnErrorListener { p, _, _ -> try { p.release() } catch (_: Exception) {}; true }
            mp.prepare()
            mp.start()
        } catch (_: Exception) {
        }
    }
}

/**
 * سرویسِ پیش‌زمینه‌ی تایمرِ تمرکز (پومودورو).
 * با بسته‌شدنِ برنامه هم می‌ماند، صدا را پخش می‌کند، اعلانِ زنده (و جزیره‌ی شیائومی) را به‌روز می‌کند
 * و جلسه‌های تمام‌شده را برای ثبتِ بعدی در پایگاه‌داده نگه می‌دارد.
 */
class FocusService : Service() {

    companion object {
        const val A_START = "lux.focus.START"
        const val A_PAUSE = "lux.focus.PAUSE"
        const val A_RESUME = "lux.focus.RESUME"
        const val A_STOP = "lux.focus.STOP"
        const val A_SKIP = "lux.focus.SKIP"
        const val A_ADD = "lux.focus.ADD"
        const val A_CFG = "lux.focus.CFG"
        const val A_END = "lux.focus.END"
        const val CH_RUN = "lux_focus_run"
        const val CH_DONE = "lux_focus_done"
        const val ID_RUN = 300101
        const val ID_DONE = 300102

        @Volatile
        var listener: (() -> Unit)? = null

        fun send(ctx: Context, action: String, cfg: String? = null) {
            val i = Intent(ctx, FocusService::class.java).setAction(action)
            if (cfg != null) i.putExtra("cfg", cfg)
            try {
                if (Build.VERSION.SDK_INT >= 26) ctx.startForegroundService(i) else ctx.startService(i)
            } catch (_: Exception) {
            }
        }

        fun state(ctx: Context): HashMap<String, Any?> {
            val p = FocusStore.prefs(ctx)
            val m = HashMap<String, Any?>()
            m["active"] = p.getBoolean("active", false)
            m["running"] = p.getBoolean("running", false)
            m["phase"] = p.getString("phase", "focus")
            m["endAt"] = p.getLong("endAt", 0L)
            m["leftMs"] = p.getLong("leftMs", 0L)
            m["totalMs"] = p.getLong("totalMs", 0L)
            m["label"] = p.getString("label", "")
            m["courseId"] = p.getInt("courseId", -1)
            m["cycle"] = p.getInt("cycle", 0)
            m["now"] = System.currentTimeMillis()
            return m
        }

        fun drain(ctx: Context): String {
            val p = FocusStore.prefs(ctx)
            val s = p.getString("pending", "[]") ?: "[]"
            p.edit().putString("pending", "[]").apply()
            return s
        }

        fun isXiaomi(): Boolean {
            val m = (Build.MANUFACTURER ?: "").lowercase()
            val b = (Build.BRAND ?: "").lowercase()
            return m.contains("xiaomi") || b.contains("xiaomi") || b.contains("redmi") || b.contains("poco")
        }

        fun focusProtocol(ctx: Context): Int {
            return try { Settings.System.getInt(ctx.contentResolver, "notification_focus_protocol", 0) } catch (_: Exception) { 0 }
        }

        fun hasFocusPermission(ctx: Context): Boolean {
            return try {
                val uri = Uri.parse("content://miui.statusbar.notification.public")
                val extras = Bundle()
                extras.putString("package", ctx.packageName)
                val b = ctx.contentResolver.call(uri, "canShowFocus", null, extras)
                b?.getBoolean("canShowFocus", false) ?: false
            } catch (_: Exception) {
                false
            }
        }

        fun supportsIsland(): Boolean {
            return try {
                val c = Class.forName("android.os.SystemProperties")
                val m = c.getDeclaredMethod("getBoolean", String::class.java, Boolean::class.javaPrimitiveType)
                (m.invoke(null, "persist.sys.feature.island", false) as? Boolean) ?: false
            } catch (_: Exception) {
                false
            }
        }
    }

    private val handler = Handler(Looper.getMainLooper())
    private var sounds: Sounds? = null
    private val tick = object : Runnable {
        override fun run() {
            onTick()
            handler.postDelayed(this, 1000L)
        }
    }

    private fun prefs() = FocusStore.prefs(this)
    private fun snd(): Sounds {
        var s = sounds
        if (s == null) {
            s = Sounds(this)
            sounds = s
        }
        return s
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        handler.removeCallbacks(tick)
        sounds?.stopAmbient()
        super.onDestroy()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        try {
            when (intent?.action) {
                A_START -> doStart(JSONObject(intent!!.getStringExtra("cfg") ?: "{}"))
                A_PAUSE -> doPause()
                A_RESUME -> doResume()
                A_STOP -> doStop()
                A_SKIP -> doSkip()
                A_ADD -> doAdd()
                A_CFG -> doCfg(JSONObject(intent!!.getStringExtra("cfg") ?: "{}"))
                A_END -> checkEnd()
                else -> {}
            }
        } catch (_: Exception) {
        }
        afterCommand()
        return START_NOT_STICKY
    }

    // ───────── فرمان‌ها ─────────

    private fun storeCfg(e: SharedPreferences.Editor, c: JSONObject) {
        if (c.has("label")) e.putString("label", c.optString("label", ""))
        if (c.has("courseId")) e.putInt("courseId", c.optInt("courseId", -1))
        if (c.has("focusMin")) e.putInt("focusMin", c.optInt("focusMin", 25))
        if (c.has("shortMin")) e.putInt("shortMin", c.optInt("shortMin", 5))
        if (c.has("longMin")) e.putInt("longMin", c.optInt("longMin", 15))
        if (c.has("longEvery")) e.putInt("longEvery", c.optInt("longEvery", 4))
        if (c.has("autoNext")) e.putBoolean("autoNext", c.optBoolean("autoNext", false))
        if (c.has("endSound")) e.putString("endSound", c.optString("endSound", "bell"))
        if (c.has("ambient")) e.putString("ambient", c.optString("ambient", ""))
        if (c.has("ambVol")) e.putFloat("ambVol", c.optDouble("ambVol", 0.6).toFloat())
        if (c.has("vibrate")) e.putBoolean("vibrate", c.optBoolean("vibrate", true))
        if (c.has("island")) e.putInt("island", c.optInt("island", 1))
    }

    private fun minutesOf(phase: String): Int {
        val p = prefs()
        return when (phase) {
            "short" -> p.getInt("shortMin", 5)
            "long" -> p.getInt("longMin", 15)
            else -> p.getInt("focusMin", 25)
        }
    }

    private fun doStart(c: JSONObject) {
        val e = prefs().edit()
        storeCfg(e, c)
        if (c.has("cycle")) e.putInt("cycle", c.optInt("cycle", 0))
        e.apply()
        val phase = c.optString("phase", "focus")
        val total = (if (c.has("minutes")) c.optInt("minutes", minutesOf(phase)) else minutesOf(phase)) * 60000L
        val now = System.currentTimeMillis()
        prefs().edit()
            .putBoolean("active", true)
            .putBoolean("running", true)
            .putString("phase", phase)
            .putLong("totalMs", total)
            .putLong("leftMs", total)
            .putLong("endAt", now + total)
            .putLong("sessionStart", if (phase == "focus") now else 0L)
            .apply()
        scheduleAlarm(now + total)
        applyAmbient()
    }

    private fun doPause() {
        val p = prefs()
        if (!p.getBoolean("active", false) || !p.getBoolean("running", false)) return
        val left = (p.getLong("endAt", 0L) - System.currentTimeMillis()).coerceAtLeast(1000L)
        p.edit().putBoolean("running", false).putLong("leftMs", left).apply()
        cancelAlarm()
        applyAmbient()
    }

    private fun doResume() {
        val p = prefs()
        if (!p.getBoolean("active", false) || p.getBoolean("running", false)) return
        val now = System.currentTimeMillis()
        val left = p.getLong("leftMs", 0L).coerceAtLeast(1000L)
        val e = p.edit().putBoolean("running", true).putLong("endAt", now + left)
        if (p.getString("phase", "focus") == "focus" && p.getLong("sessionStart", 0L) == 0L) {
            e.putLong("sessionStart", now)
        }
        e.apply()
        scheduleAlarm(now + left)
        applyAmbient()
    }

    private fun doStop() {
        prefs().edit().putBoolean("active", false).putBoolean("running", false).apply()
        cancelAlarm()
        applyAmbient()
    }

    private fun doAdd() {
        val p = prefs()
        if (!p.getBoolean("active", false)) return
        val add = 5 * 60000L
        val e = p.edit().putLong("totalMs", p.getLong("totalMs", 0L) + add)
        if (p.getBoolean("running", false)) {
            val end = p.getLong("endAt", 0L) + add
            e.putLong("endAt", end)
            e.apply()
            scheduleAlarm(end)
        } else {
            e.putLong("leftMs", p.getLong("leftMs", 0L) + add)
            e.apply()
        }
    }

    private fun doCfg(c: JSONObject) {
        val e = prefs().edit()
        storeCfg(e, c)
        e.apply()
        applyAmbient()
    }

    private fun doSkip() {
        val p = prefs()
        if (!p.getBoolean("active", false)) return
        finishPhase(natural = false)
    }

    private fun checkEnd(): Boolean {
        val p = prefs()
        if (!p.getBoolean("active", false) || !p.getBoolean("running", false)) return false
        if (System.currentTimeMillis() >= p.getLong("endAt", 0L) - 400L) {
            finishPhase(natural = true)
            return true
        }
        return false
    }

    /** پایانِ فاز (طبیعی یا با «رد کردن») و رفتن به فازِ بعد. */
    private fun finishPhase(natural: Boolean) {
        val p = prefs()
        val now = System.currentTimeMillis()
        val phase = p.getString("phase", "focus") ?: "focus"
        var cycle = p.getInt("cycle", 0)
        var next = "focus"
        if (phase == "focus") {
            val start = p.getLong("sessionStart", 0L)
            val end = if (natural) p.getLong("endAt", now) else now
            val planned = (p.getLong("totalMs", 0L) / 60000L).toInt()
            if (start > 0L && (natural || end - start >= 60000L)) {
                recordSession(p.getInt("courseId", -1), start, end, planned)
                cycle += 1
            }
            val every = p.getInt("longEvery", 4)
            if (every > 0 && cycle >= every) {
                cycle = 0
                next = "long"
            } else {
                next = "short"
            }
        }
        val nextMs = minutesOf(next) * 60000L
        val auto = p.getBoolean("autoNext", false) && natural
        val e = p.edit()
            .putString("phase", next)
            .putInt("cycle", cycle)
            .putLong("totalMs", nextMs)
            .putLong("leftMs", nextMs)
            .putLong("sessionStart", 0L)
            .putBoolean("active", true)
        if (auto) {
            e.putBoolean("running", true).putLong("endAt", now + nextMs)
            if (next == "focus") e.putLong("sessionStart", now)
        } else {
            e.putBoolean("running", false)
        }
        e.apply()
        cancelAlarm()
        if (auto) scheduleAlarm(now + nextMs)
        applyAmbient()
        if (natural) {
            snd().playEnd(p.getString("endSound", "bell") ?: "bell", 1.0f)
            if (p.getBoolean("vibrate", true)) vibrate()
            postDone(phase, next, auto)
        }
    }

    private fun recordSession(courseId: Int, start: Long, end: Long, planned: Int) {
        try {
            val p = prefs()
            val arr = JSONArray(p.getString("pending", "[]") ?: "[]")
            arr.put(JSONObject().put("c", courseId).put("s", start).put("e", end).put("p", planned).put("ok", 1))
            p.edit().putString("pending", arr.toString()).apply()
        } catch (_: Exception) {
        }
    }

    private fun applyAmbient() {
        val p = prefs()
        val on = p.getBoolean("active", false) && p.getBoolean("running", false) && p.getString("phase", "focus") == "focus"
        val key = p.getString("ambient", "") ?: ""
        if (on && key.isNotEmpty()) snd().startAmbient(key, p.getFloat("ambVol", 0.6f)) else sounds?.stopAmbient()
    }

    private fun vibrate() {
        try {
            @Suppress("DEPRECATION")
            val v = getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator ?: return
            if (Build.VERSION.SDK_INT >= 26) {
                v.vibrate(VibrationEffect.createWaveform(longArrayOf(0, 300, 150, 300, 150, 500), -1))
            } else {
                @Suppress("DEPRECATION")
                v.vibrate(longArrayOf(0, 300, 150, 300, 150, 500), -1)
            }
        } catch (_: Exception) {
        }
    }

    // ───────── آلارم ─────────

    private fun alarmIntent(): PendingIntent {
        val i = Intent(this, FocusService::class.java).setAction(A_END)
        val flags = PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        return if (Build.VERSION.SDK_INT >= 26) PendingIntent.getForegroundService(this, 71, i, flags)
        else PendingIntent.getService(this, 71, i, flags)
    }

    private fun scheduleAlarm(at: Long) {
        try {
            val am = getSystemService(Context.ALARM_SERVICE) as AlarmManager
            try {
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, alarmIntent())
            } catch (_: SecurityException) {
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, alarmIntent())
            }
        } catch (_: Exception) {
        }
    }

    private fun cancelAlarm() {
        try {
            (getSystemService(Context.ALARM_SERVICE) as AlarmManager).cancel(alarmIntent())
        } catch (_: Exception) {
        }
    }

    // ───────── حلقه‌ی ثانیه‌ای و اعلان ─────────

    private fun onTick() {
        if (checkEnd()) {
            afterCommand()
            return
        }
        val p = prefs()
        if (!p.getBoolean("active", false) || !p.getBoolean("running", false)) {
            handler.removeCallbacks(tick)
            return
        }
        if (p.getInt("island", 1) != 0 && isXiaomi()) {
            try {
                (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).notify(ID_RUN, buildNotification())
            } catch (_: Exception) {
            }
        }
        listener?.invoke()
    }

    private fun afterCommand() {
        val p = prefs()
        if (!p.getBoolean("active", false)) {
            handler.removeCallbacks(tick)
            cancelAlarm()
            sounds?.stopAmbient()
            try {
                startForegroundCompat(buildIdleNotification())
                if (Build.VERSION.SDK_INT >= 24) stopForeground(Service.STOP_FOREGROUND_REMOVE) else stopForeground(true)
            } catch (_: Exception) {
            }
            try { (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).cancel(ID_RUN) } catch (_: Exception) {}
            listener?.invoke()
            stopSelf()
            return
        }
        val running = p.getBoolean("running", false)
        val n = buildNotification()
        startForegroundCompat(n)
        if (running) {
            handler.removeCallbacks(tick)
            handler.postDelayed(tick, 1000L)
        } else {
            handler.removeCallbacks(tick)
            try {
                if (Build.VERSION.SDK_INT >= 24) stopForeground(Service.STOP_FOREGROUND_DETACH) else stopForeground(false)
                (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).notify(ID_RUN, n)
            } catch (_: Exception) {
            }
        }
        listener?.invoke()
        if (!running) stopSelf()
    }

    private fun startForegroundCompat(n: Notification) {
        try {
            if (Build.VERSION.SDK_INT >= 34) {
                startForeground(ID_RUN, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
            } else {
                startForeground(ID_RUN, n)
            }
        } catch (_: Exception) {
        }
    }

    private fun ensureChannels() {
        if (Build.VERSION.SDK_INT < 26) return
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (nm.getNotificationChannel(CH_RUN) == null) {
            val c = NotificationChannel(CH_RUN, "تایمر تمرکز", NotificationManager.IMPORTANCE_LOW)
            c.description = "اعلان زنده‌ی پومودورو"
            c.setShowBadge(false)
            nm.createNotificationChannel(c)
        }
        if (nm.getNotificationChannel(CH_DONE) == null) {
            val c = NotificationChannel(CH_DONE, "پایان جلسه", NotificationManager.IMPORTANCE_HIGH)
            c.description = "وقتی جلسه‌ی تمرکز یا استراحت تمام می‌شود"
            c.setSound(null, null)
            nm.createNotificationChannel(c)
        }
    }

    private fun builder(channel: String): Notification.Builder {
        ensureChannels()
        return if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, channel)
        else @Suppress("DEPRECATION") Notification.Builder(this)
    }

    private fun faDigits(s: String): String {
        val sb = StringBuilder()
        for (ch in s) sb.append(if (ch in '0'..'9') ('۰' + (ch - '0')) else ch)
        return sb.toString()
    }

    private fun fmt(ms: Long): String {
        val t = (ms.coerceAtLeast(0L) + 999L) / 1000L
        return faDigits(String.format("%02d:%02d", t / 60, t % 60))
    }

    private fun phaseTitle(ph: String) = when (ph) {
        "short" -> "استراحت کوتاه"
        "long" -> "استراحت بلند"
        else -> "تمرکز"
    }

    private fun openApp(): PendingIntent {
        val i = packageManager.getLaunchIntentForPackage(packageName) ?: Intent()
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
        return PendingIntent.getActivity(this, 70, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    }

    private fun actionPi(action: String, code: Int): PendingIntent {
        val i = Intent(this, FocusService::class.java).setAction(action)
        return PendingIntent.getService(this, code, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    }

    private fun action(title: String, action: String, code: Int): Notification.Action {
        return Notification.Action.Builder(Icon.createWithResource(this, applicationInfo.icon), title, actionPi(action, code)).build()
    }

    private fun buildIdleNotification(): Notification {
        return builder(CH_RUN).setSmallIcon(applicationInfo.icon).setContentTitle("LUX").build()
    }

    private fun buildNotification(): Notification {
        val p = prefs()
        val running = p.getBoolean("running", false)
        val phase = p.getString("phase", "focus") ?: "focus"
        val label = p.getString("label", "") ?: ""
        val now = System.currentTimeMillis()
        val left = if (running) (p.getLong("endAt", now) - now) else p.getLong("leftMs", 0L)
        val title = phaseTitle(phase) + if (label.isNotEmpty() && phase == "focus") " · $label" else ""
        val text = if (running) "در حال شمارش…" else "متوقف · ${fmt(left)} مانده"
        val b = builder(CH_RUN)
            .setSmallIcon(applicationInfo.icon)
            .setContentTitle(title)
            .setContentText(text)
            .setContentIntent(openApp())
            .setOnlyAlertOnce(true)
            .setOngoing(running)
            .setCategory(Notification.CATEGORY_PROGRESS)
            .setVisibility(Notification.VISIBILITY_PUBLIC)
        if (running) {
            b.setShowWhen(true).setWhen(p.getLong("endAt", now)).setUsesChronometer(true)
            if (Build.VERSION.SDK_INT >= 24) b.setChronometerCountDown(true)
            b.addAction(action("توقف", A_PAUSE, 81))
        } else {
            b.addAction(action("ادامه", A_RESUME, 82))
        }
        b.addAction(action("رد کردن", A_SKIP, 83))
        b.addAction(action("پایان", A_STOP, 84))

        val extras = Bundle()
        var island = ""
        if (p.getInt("island", 1) != 0 && isXiaomi()) {
            try {
                val pics = Bundle()
                pics.putParcelable("miui.focus.pic_app", Icon.createWithResource(this, applicationInfo.icon))
                extras.putBundle("miui.focus.pics", pics)
                island = islandJson(title, fmt(left), text)
            } catch (_: Exception) {
            }
        }
        b.addExtras(extras)
        val n = b.build()
        if (island.isNotEmpty()) {
            try { n.extras.putString("miui.focus.param", island) } catch (_: Exception) {}
        }
        return n
    }

    /** پارامترهای «جزیره‌ی شیائومی» (HyperOS)؛ اگر دستگاه پشتیبانی نکند نادیده گرفته می‌شود. */
    private fun islandJson(title: String, time: String, sub: String): String {
        val pic = JSONObject().put("type", 1).put("pic", "miui.focus.pic_app")
        val textInfo = JSONObject().put("frontTitle", phaseTitle(prefs().getString("phase", "focus") ?: "focus")).put("title", time).put("useHighLight", false)
        val left = JSONObject().put("type", 1).put("picInfo", pic).put("textInfo", textInfo)
        val big = JSONObject().put("imageTextInfoLeft", left).put("picInfo", pic)
        val small = JSONObject().put("picInfo", pic)
        val island = JSONObject().put("islandProperty", 1).put("bigIslandArea", big).put("smallIslandArea", small)
        val base = JSONObject().put("title", title).put("content", sub.ifEmpty { time }).put("type", 2)
        val v2 = JSONObject()
            .put("protocol", 1)
            .put("business", "study_timer")
            .put("enableFloat", false)
            .put("islandFirstFloat", false)
            .put("updatable", true)
            .put("ticker", time)
            .put("tickerPic", "miui.focus.pic_app")
            .put("aodTitle", "$title $time")
            .put("aodPic", "miui.focus.pic_app")
            .put("param_island", island)
            .put("baseInfo", base)
        return JSONObject().put("param_v2", v2).toString()
    }

    private fun postDone(phase: String, next: String, auto: Boolean) {
        try {
            val title = if (phase == "focus") "جلسه‌ی تمرکز تمام شد" else "استراحت تمام شد"
            val body = if (phase == "focus") {
                if (auto) "استراحت شروع شد." else "آفرین! حالا کمی استراحت کن."
            } else {
                if (auto) "جلسه‌ی بعدی شروع شد." else "وقتِ برگشتن به درس است."
            }
            val n = builder(CH_DONE)
                .setSmallIcon(applicationInfo.icon)
                .setContentTitle(title)
                .setContentText(body)
                .setContentIntent(openApp())
                .setAutoCancel(true)
                .setCategory(Notification.CATEGORY_ALARM)
                .build()
            (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).notify(ID_DONE, n)
        } catch (_: Exception) {
        }
    }
}

/** پلِ Flutter ⇄ سرویس تمرکز. */
object FocusBridge {
    private var preview: Sounds? = null
    private val h = Handler(Looper.getMainLooper())

    fun attach(engine: FlutterEngine, act: Activity) {
        val ch = MethodChannel(engine.dartExecutor.binaryMessenger, "lux/focus")
        FocusService.listener = { act.runOnUiThread { try { ch.invokeMethod("changed", null) } catch (_: Exception) {} } }
        ch.setMethodCallHandler { call, result ->
            try {
                when (call.method) {
                    "start" -> { FocusService.send(act, FocusService.A_START, call.argument<String>("cfg")); result.success(true) }
                    "pause" -> { FocusService.send(act, FocusService.A_PAUSE); result.success(true) }
                    "resume" -> { FocusService.send(act, FocusService.A_RESUME); result.success(true) }
                    "stop" -> { FocusService.send(act, FocusService.A_STOP); result.success(true) }
                    "skip" -> { FocusService.send(act, FocusService.A_SKIP); result.success(true) }
                    "add" -> { FocusService.send(act, FocusService.A_ADD); result.success(true) }
                    "configure" -> {
                        if (FocusStore.prefs(act).getBoolean("active", false)) {
                            FocusService.send(act, FocusService.A_CFG, call.argument<String>("cfg"))
                        } else {
                            // اگر جلسه‌ای فعال نیست، فقط تنظیمات ذخیره می‌شود.
                            val c = org.json.JSONObject(call.argument<String>("cfg") ?: "{}")
                            val e = FocusStore.prefs(act).edit()
                            for (k in c.keys()) {
                                when (val v = c.get(k)) {
                                    is Boolean -> e.putBoolean(k, v)
                                    is Int -> e.putInt(k, v)
                                    is Double -> e.putFloat(k, v.toFloat())
                                    is String -> e.putString(k, v)
                                }
                            }
                            e.apply()
                        }
                        result.success(true)
                    }
                    "state" -> result.success(FocusService.state(act))
                    "drain" -> result.success(FocusService.drain(act))
                    "info" -> {
                        val m = HashMap<String, Any?>()
                        m["xiaomi"] = FocusService.isXiaomi()
                        m["protocol"] = FocusService.focusProtocol(act)
                        m["focusPerm"] = FocusService.hasFocusPermission(act)
                        m["island"] = FocusService.supportsIsland()
                        m["sdk"] = Build.VERSION.SDK_INT
                        result.success(m)
                    }
                    "openNotifSettings" -> {
                        val i = Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, act.packageName)
                        act.startActivity(i)
                        result.success(true)
                    }
                    "openAppSettings" -> {
                        val i = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + act.packageName))
                        act.startActivity(i)
                        result.success(true)
                    }
                    "preview" -> {
                        val key = call.argument<String>("key") ?: ""
                        val vol = (call.argument<Double>("vol") ?: 0.8).toFloat()
                        val ambient = call.argument<Boolean>("ambient") ?: false
                        val s = preview ?: Sounds(act).also { preview = it }
                        s.stopAmbient()
                        if (ambient) {
                            s.startAmbient(key, vol)
                            h.removeCallbacksAndMessages(null)
                            h.postDelayed({ s.stopAmbient() }, 5000L)
                        } else {
                            s.playEnd(key, 1.0f)
                        }
                        result.success(true)
                    }
                    "stopPreview" -> { preview?.stopAmbient(); result.success(true) }
                    else -> result.notImplemented()
                }
            } catch (e: Exception) {
                result.success(null)
            }
        }
    }

    fun detach() {
        FocusService.listener = null
        try { preview?.stopAmbient() } catch (_: Exception) {}
    }
}
